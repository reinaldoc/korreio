<!DOCTYPE TS><TS>
<context>
    <name>dKorreio</name>
    <message>
        <source>Distinguished Name</source>
        <translation></translation>
    </message>
    <message>
        <source>Attribute</source>
        <translation>Atributo</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Usuário</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation>Permissões</translation>
    </message>
    <message>
        <source>IMAP Mailbox</source>
        <translation></translation>
    </message>
    <message>
        <source>Partition</source>
        <translation>Partição-IMAP</translation>
    </message>
    <message>
        <source>Used</source>
        <translation>Utilizado</translation>
    </message>
    <message>
        <source>Limit</source>
        <translation>Limite</translation>
    </message>
    <message>
        <source>%</source>
        <translation></translation>
    </message>
    <message>
        <source>IMAP Users</source>
        <translation>Usuário IMAP</translation>
    </message>
    <message>
        <source>Active script</source>
        <translation>Script ativo</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation></translation>
    </message>
    <message>
        <source>Option</source>
        <translation></translation>
    </message>
    <message>
        <source>Sender</source>
        <translation>Remetente</translation>
    </message>
    <message>
        <source>Items</source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Auto-expire</source>
        <translation>Expirar</translation>
    </message>
    <message>
        <source>ACL anyone</source>
        <translation></translation>
    </message>
    <message>
        <source>Korreio (c) Copyleft 2008 - Reinaldo de Carvalho &lt;reinaldoc@gmail.com&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>objectClass=*</source>
        <translation></translation>
    </message>
    <message>
        <source>ou=*</source>
        <translation></translation>
    </message>
    <message>
        <source>cn=*</source>
        <translation></translation>
    </message>
    <message>
        <source>uid=*</source>
        <translation></translation>
    </message>
    <message>
        <source>mail=*</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Remover</translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation></translation>
    </message>
    <message>
        <source>Ldap Browser</source>
        <translation>Ldap Browser</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation>Novo registro</translation>
    </message>
    <message>
        <source>New User</source>
        <translation>Novo Usuário</translation>
    </message>
    <message>
        <source>New Organization</source>
        <translation>Nova Organização</translation>
    </message>
    <message>
        <source>Define Password</source>
        <translation>Trocar senha</translation>
    </message>
    <message>
        <source>Samba Populate</source>
        <translation></translation>
    </message>
    <message>
        <source>objectClass</source>
        <translation></translation>
    </message>
    <message>
        <source>structuralObjectClass</source>
        <translation></translation>
    </message>
    <message>
        <source>uid</source>
        <translation></translation>
    </message>
    <message>
        <source>cn</source>
        <translation></translation>
    </message>
    <message>
        <source>sn</source>
        <translation></translation>
    </message>
    <message>
        <source>mail</source>
        <translation></translation>
    </message>
    <message>
        <source>gecos</source>
        <translation></translation>
    </message>
    <message>
        <source>description</source>
        <translation></translation>
    </message>
    <message>
        <source>homeDirectory</source>
        <translation></translation>
    </message>
    <message>
        <source>loginShell</source>
        <translation></translation>
    </message>
    <message>
        <source>uidNumber</source>
        <translation></translation>
    </message>
    <message>
        <source>gidNumber</source>
        <translation></translation>
    </message>
    <message>
        <source>userPassword</source>
        <translation></translation>
    </message>
    <message>
        <source>shadowLastChange</source>
        <translation></translation>
    </message>
    <message>
        <source>shadowMin</source>
        <translation></translation>
    </message>
    <message>
        <source>shadowMax</source>
        <translation></translation>
    </message>
    <message>
        <source>shadowWarning</source>
        <translation></translation>
    </message>
    <message>
        <source>shadowInactive</source>
        <translation></translation>
    </message>
    <message>
        <source>shadowExpire</source>
        <translation></translation>
    </message>
    <message>
        <source>shadowFlag</source>
        <translation></translation>
    </message>
    <message>
        <source>carLicense</source>
        <translation></translation>
    </message>
    <message>
        <source>displayName</source>
        <translation></translation>
    </message>
    <message>
        <source>homePhone</source>
        <translation></translation>
    </message>
    <message>
        <source>l</source>
        <translation></translation>
    </message>
    <message>
        <source>street</source>
        <translation></translation>
    </message>
    <message>
        <source>postalCode</source>
        <translation></translation>
    </message>
    <message>
        <source>o</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaLMPassword</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaNTPassword</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaPwdLastSet</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaLogonTime</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaLogoffTime</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaKickoffTime</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaPwdCanChange</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaPwdMustChange</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaAcctFlags</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaHomePath</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaHomeDrive</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaLogonScript</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaProfilePath</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaUserWorkstations</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaPrimaryGroupSID</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaDomainName</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaMungedDial</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaBadPasswordCount</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaBadPasswordTime</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaPasswordHistory</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaLogonHours</source>
        <translation></translation>
    </message>
    <message>
        <source>mailAlternateAddress</source>
        <translation></translation>
    </message>
    <message>
        <source>ipHostNumber</source>
        <translation></translation>
    </message>
    <message>
        <source>owner</source>
        <translation></translation>
    </message>
    <message>
        <source>manager</source>
        <translation></translation>
    </message>
    <message>
        <source>serialNumber</source>
        <translation></translation>
    </message>
    <message>
        <source>member</source>
        <translation></translation>
    </message>
    <message>
        <source>inetOrgPerson</source>
        <translation></translation>
    </message>
    <message>
        <source>posixAccount</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaSamAccount</source>
        <translation></translation>
    </message>
    <message>
        <source>shadowAccount</source>
        <translation></translation>
    </message>
    <message>
        <source>top</source>
        <translation></translation>
    </message>
    <message>
        <source>simpleSecurityObject</source>
        <translation></translation>
    </message>
    <message>
        <source>organization</source>
        <translation></translation>
    </message>
    <message>
        <source>organizationalUnit</source>
        <translation></translation>
    </message>
    <message>
        <source>organizationalRole</source>
        <translation></translation>
    </message>
    <message>
        <source>groupOfNames</source>
        <translation></translation>
    </message>
    <message>
        <source>device</source>
        <translation></translation>
    </message>
    <message>
        <source>ipHost</source>
        <translation></translation>
    </message>
    <message>
        <source>ipNetwork</source>
        <translation></translation>
    </message>
    <message>
        <source>referral</source>
        <translation></translation>
    </message>
    <message>
        <source>extensibleObject</source>
        <translation></translation>
    </message>
    <message>
        <source>+</source>
        <translation></translation>
    </message>
    <message>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Aplicar</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;New User&lt;/b&gt;</source>
        <translation>&lt;b&gt;Novo Usuário&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;inetOrgPerson&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <source>&lt;b&gt;cn&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <source>&lt;b&gt;mail&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Locality:</source>
        <translation>Localidade:</translation>
    </message>
    <message>
        <source>&lt;b&gt;l&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Address:</source>
        <translation>Endereço:</translation>
    </message>
    <message>
        <source>&lt;b&gt;street&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Postal code:</source>
        <translation>CEP:</translation>
    </message>
    <message>
        <source>&lt;b&gt;postalCode&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Phone number:</source>
        <translation>Telefone:</translation>
    </message>
    <message>
        <source>&lt;b&gt;homePhone&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <source>&lt;b&gt;userPassword&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Password (again):</source>
        <translation>Senha (redigite):</translation>
    </message>
    <message>
        <source>&lt;b&gt;posixAccount&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Uid number:</source>
        <translation>Uid number:</translation>
    </message>
    <message>
        <source>&lt;b&gt;uidNumber&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Gid number:</source>
        <translation>Gid number:</translation>
    </message>
    <message>
        <source>&lt;b&gt;gidNumber&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Home:</source>
        <translation>Home:</translation>
    </message>
    <message>
        <source>&lt;b&gt;homeDirectory&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Shell:</source>
        <translation>Shell:</translation>
    </message>
    <message>
        <source>&lt;b&gt;loginShell&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>100</source>
        <translation></translation>
    </message>
    <message>
        <source>User id:</source>
        <translation>Usuário:</translation>
    </message>
    <message>
        <source>&lt;b&gt;uid&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>/bin/bash</source>
        <translation></translation>
    </message>
    <message>
        <source>/home</source>
        <translation></translation>
    </message>
    <message>
        <source>1000</source>
        <translation></translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Achar</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaSamAccount&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Domain:</source>
        <translation>Domínio:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaDomain&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Group:</source>
        <translation>Grupo:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaPrimaryGroupSID&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Force user change password</source>
        <translation>Trocar senha no primeiro logon</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaPwdMustChange&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Drive Path:</source>
        <translation>Drive Path:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaHomePath&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Profile type:</source>
        <translation>Profile type:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaProfilePath&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Logon script:</source>
        <translation>Logon script:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLogonScript&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Drive:</source>
        <translation>Drive:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaHomeDrive&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Local</source>
        <translation>Local</translation>
    </message>
    <message>
        <source>Remote</source>
        <translation>Remoto</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Domain Users (513)</source>
        <translation></translation>
    </message>
    <message>
        <source>Domain Guests (514)</source>
        <translation></translation>
    </message>
    <message>
        <source>Domain Admins (512)</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;astSipPeer&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>User:</source>
        <translation>Usuário:</translation>
    </message>
    <message>
        <source>&lt;b&gt;astUsername&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>astSecret</source>
        <translation></translation>
    </message>
    <message>
        <source>Ramal:</source>
        <translation>Ramal:</translation>
    </message>
    <message>
        <source>&lt;b&gt;astName&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Porta:</translation>
    </message>
    <message>
        <source>5070</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;radiusProfile&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>dialup</source>
        <translation></translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Voltar</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Próximo</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Cadastrar</translation>
    </message>
    <message>
        <source>&lt;b&gt;New Organization&lt;/b&gt;</source>
        <translation>&lt;b&gt;Nova Organização&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;ou&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Define password&lt;/b&gt;</source>
        <translation>&lt;b&gt;Trocar senha&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Attribute:</source>
        <translation>Atributo:</translation>
    </message>
    <message>
        <source>sambaLMPassword/sambaNTPassword</source>
        <translation></translation>
    </message>
    <message>
        <source>{SSHA}</source>
        <translation></translation>
    </message>
    <message>
        <source>{SMD5}</source>
        <translation></translation>
    </message>
    <message>
        <source>{CRYPT}</source>
        <translation></translation>
    </message>
    <message>
        <source>{SHA}</source>
        <translation></translation>
    </message>
    <message>
        <source>{MD5}</source>
        <translation></translation>
    </message>
    <message>
        <source>{TEXT}</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;Samba Populate&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>P&amp;opulate</source>
        <translation>P&amp;opulate</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Extend lock after new logon errors:</source>
        <translation>Extender bloqueio de conta:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLockoutObservationWindow&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Unlock account after:</source>
        <translation>Desbloquear conta após:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLockoutDuration&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Minimun password lenght:</source>
        <translation>Tamanho mínimo para a senha:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaMinPwdLength&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>First uidNumber:</source>
        <translation>uidNumber inicial:</translation>
    </message>
    <message>
        <source>Logon errors to lock account:</source>
        <translation>Bloquear conta após erros de logon:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLockoutThreshold&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Deny password reuse:</source>
        <translation>Impedir reutilização de senha:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaPwdHistoryLength&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>First gidNumber:</source>
        <translation>gidNumber inicial:</translation>
    </message>
    <message>
        <source>Wait before change password:</source>
        <translation>Aguarda após troca de senha:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaMinPwdAge&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Force change password:</source>
        <translation>Solicitar troca de senha após:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaMaxPwdAge&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Root password:</source>
        <translation>Senha do root:</translation>
    </message>
    <message>
        <source>&lt;b&gt;userPassword&lt;br&gt;sambaLMPassword&lt;br&gt;sambaNTPassword&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>SMB Domain:</source>
        <translation>Domínio SMB:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaDomainName&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>SID:</source>
        <translation>SID:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <source>hours</source>
        <translation>horas</translation>
    </message>
    <message>
        <source>days</source>
        <translation>dias</translation>
    </message>
    <message>
        <source>&amp;LDAP Manager</source>
        <translation>&amp;LDAP Manager</translation>
    </message>
    <message>
        <source>Mailbox:</source>
        <translation>Mailbox:</translation>
    </message>
    <message>
        <source>&amp;Search</source>
        <translation>Pe&amp;squisar</translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation></translation>
    </message>
    <message>
        <source>Global</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;Permissions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Permissões&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Annotation&lt;/b&gt;</source>
        <translation>&lt;b&gt;Annotation&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Annotation:</source>
        <translation>Annotation:</translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/expire</source>
        <translation></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/partition</source>
        <translation></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/size</source>
        <translation></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/lastupdate</source>
        <translation></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/lastpop</source>
        <translation></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/squat</source>
        <translation></translation>
    </message>
    <message>
        <source>/comment</source>
        <translation></translation>
    </message>
    <message>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <source>Value:</source>
        <translation>Valor:</translation>
    </message>
    <message>
        <source>R</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;Quota&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Used:</source>
        <translation>Utilizado:</translation>
    </message>
    <message>
        <source>Limit:</source>
        <translation>Limite:</translation>
    </message>
    <message>
        <source>Kbytes</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Imap Manager</source>
        <translation>&amp;Imap Manager</translation>
    </message>
    <message>
        <source>Partition:</source>
        <translation>Partition:</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation>&amp;Mover</translation>
    </message>
    <message>
        <source>Alt+M</source>
        <translation></translation>
    </message>
    <message>
        <source>0 ~ 0 Mbytes ~ 0%</source>
        <translation></translation>
    </message>
    <message>
        <source>Used/Limit</source>
        <translation>Em uso/Limite</translation>
    </message>
    <message>
        <source>Imap &amp;Partitions</source>
        <translation>Imap &amp;Partitions</translation>
    </message>
    <message>
        <source>Script:</source>
        <translation>Script:</translation>
    </message>
    <message>
        <source>x</source>
        <translation></translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Encaminhar</translation>
    </message>
    <message>
        <source>Keep and Forward</source>
        <translation>Encaminhar e salvar</translation>
    </message>
    <message>
        <source>Select folder by sender</source>
        <translation>Escolher pasta pelo remetente</translation>
    </message>
    <message>
        <source>Select folder by senders</source>
        <translation>Escolher pasta por remetentes</translation>
    </message>
    <message>
        <source>Discard Spam</source>
        <translation>Descartar Spam</translation>
    </message>
    <message>
        <source>Select folder if Spam</source>
        <translation>Escolher pasta se for Spam</translation>
    </message>
    <message>
        <source>Vacation if not Spam</source>
        <translation>Férias, se não for Spam</translation>
    </message>
    <message>
        <source>Vacation</source>
        <translation>Férias</translation>
    </message>
    <message>
        <source>Sie&amp;ve Manager</source>
        <translation>Sie&amp;ve Manager</translation>
    </message>
    <message>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <source>Services</source>
        <translation></translation>
    </message>
    <message>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <source>Postfix</source>
        <translation></translation>
    </message>
    <message>
        <source>3.1</source>
        <translation></translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Utilidades</translation>
    </message>
    <message>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;Files&lt;/b&gt;</source>
        <translation>&lt;b&gt;Arquivos&lt;/b&gt;</translation>
    </message>
    <message>
        <source>/etc/cyrus.conf</source>
        <translation></translation>
    </message>
    <message>
        <source>/etc/imapd.conf</source>
        <translation></translation>
    </message>
    <message>
        <source>/etc/saslauthd.conf</source>
        <translation></translation>
    </message>
    <message>
        <source>/etc/default/saslauthd</source>
        <translation></translation>
    </message>
    <message>
        <source>/etc/postfix/main.cf</source>
        <translation></translation>
    </message>
    <message>
        <source>/etc/postfix/master.cf</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Salvar</translation>
    </message>
    <message>
        <source>P&amp;ostmap</source>
        <translation>P&amp;ostmap</translation>
    </message>
    <message>
        <source>&lt;b&gt;Postfix&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Sa&amp;ve</source>
        <translation>Sal&amp;var</translation>
    </message>
    <message>
        <source>Alt+V</source>
        <translation></translation>
    </message>
    <message>
        <source>Defaults values</source>
        <translation>Opções padrões</translation>
    </message>
    <message>
        <source>All options</source>
        <translation>Todas as opções</translation>
    </message>
    <message>
        <source>Configured options</source>
        <translation>Opções configuradas</translation>
    </message>
    <message>
        <source>&lt;b&gt;Services&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Service:</source>
        <translation>Serviço:</translation>
    </message>
    <message>
        <source>postfix</source>
        <translation></translation>
    </message>
    <message>
        <source>slapd</source>
        <translation></translation>
    </message>
    <message>
        <source>cyrus2.2</source>
        <translation></translation>
    </message>
    <message>
        <source>restart</source>
        <translation></translation>
    </message>
    <message>
        <source>stop</source>
        <translation></translation>
    </message>
    <message>
        <source>start</source>
        <translation></translation>
    </message>
    <message>
        <source>S&amp;ervices Manager</source>
        <translation>S&amp;ervices Manager</translation>
    </message>
    <message>
        <source>&amp;Update</source>
        <translation>&amp;Atualizar</translation>
    </message>
    <message>
        <source>Alt+U</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;Total:&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>0/0</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Queue Manager</source>
        <translation>&amp;Queue Manager</translation>
    </message>
    <message>
        <source>Log</source>
        <translation></translation>
    </message>
    <message>
        <source>LDAP</source>
        <translation></translation>
    </message>
    <message>
        <source>2.1</source>
        <translation></translation>
    </message>
    <message>
        <source>Annotation</source>
        <translation></translation>
    </message>
    <message>
        <source>2.2.1</source>
        <translation></translation>
    </message>
    <message>
        <source>IMAP</source>
        <translation></translation>
    </message>
    <message>
        <source>2.2</source>
        <translation></translation>
    </message>
    <message>
        <source>SSH</source>
        <translation></translation>
    </message>
    <message>
        <source>2.3</source>
        <translation></translation>
    </message>
    <message>
        <source>Servers</source>
        <translation>Servidores</translation>
    </message>
    <message>
        <source>Populate</source>
        <translation></translation>
    </message>
    <message>
        <source>4.1.1.1</source>
        <translation></translation>
    </message>
    <message>
        <source>SMB</source>
        <translation></translation>
    </message>
    <message>
        <source>4.1.1</source>
        <translation></translation>
    </message>
    <message>
        <source>Schema</source>
        <translation></translation>
    </message>
    <message>
        <source>4.1.2</source>
        <translation></translation>
    </message>
    <message>
        <source>4.1</source>
        <translation></translation>
    </message>
    <message>
        <source>4.2</source>
        <translation></translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation>Preferências</translation>
    </message>
    <message>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP Server&lt;/b&gt;</source>
        <translation>&lt;b&gt;Servidor LDAP&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Server:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Servidor:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Admin user:</source>
        <translation>Usuário:</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <source>BaseDN:</source>
        <translation>BaseDN:</translation>
    </message>
    <message>
        <source>Del</source>
        <translation></translation>
    </message>
    <message>
        <source>ldap://</source>
        <translation></translation>
    </message>
    <message>
        <source>ldaps://</source>
        <translation></translation>
    </message>
    <message>
        <source>389</source>
        <translation></translation>
    </message>
    <message>
        <source>Expand referrals</source>
        <translation>Expandir referências</translation>
    </message>
    <message>
        <source>Don&apos;t verify SSL certificate (must restart)</source>
        <translation>Não verificar certificado SSL (feche o programa)</translation>
    </message>
    <message>
        <source>Get</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;IMAP Server&lt;/b&gt;</source>
        <translation>&lt;b&gt;Servidor IMAP&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Sieve port:</source>
        <translation>Porta Sieve:</translation>
    </message>
    <message>
        <source>imap://</source>
        <translation></translation>
    </message>
    <message>
        <source>imaps://</source>
        <translation></translation>
    </message>
    <message>
        <source>143</source>
        <translation></translation>
    </message>
    <message>
        <source>2000</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;SSH Server&lt;/b&gt;</source>
        <translation>&lt;b&gt;Servidor SSH&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Sudo:</source>
        <translation>Sudo:</translation>
    </message>
    <message>
        <source>22</source>
        <translation></translation>
    </message>
    <message>
        <source>Disabled (root login)</source>
        <translation>Desativado (root login)</translation>
    </message>
    <message>
        <source>&lt;b&gt;Servers&lt;/b&gt;</source>
        <translation>&lt;b&gt;Servidores&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP Preferences&lt;/b&gt;</source>
        <translation>&lt;b&gt;Preferências LDAP&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Auto-complete admin:</source>
        <translation>Auto-complear usuário:</translation>
    </message>
    <message>
        <source>cn=admin</source>
        <translation></translation>
    </message>
    <message>
        <source>cn=manager</source>
        <translation></translation>
    </message>
    <message>
        <source>uid=root,ou=users</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;Filters&lt;/b&gt;</source>
        <translation>&lt;b&gt;Filtros&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Password&lt;/b&gt;</source>
        <translation>&lt;b&gt;Senha&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Force change password at next logon (samba{LM-NT}Password)</source>
        <translation>Trocar senha no próximo logon (samba{LM-NT})Password)</translation>
    </message>
    <message>
        <source>&lt;b&gt;IMAP Preferences&lt;/b&gt;</source>
        <translation>&lt;b&gt;Preferências IMAP&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Default IMAP folders&lt;/b&gt;</source>
        <translation>&lt;b&gt;Sub-pastas IMAP&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Trash</translation>
    </message>
    <message>
        <source>60</source>
        <translation></translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Sent</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Drafts</translation>
    </message>
    <message>
        <source>Spam</source>
        <translation>Spam</translation>
    </message>
    <message>
        <source>30</source>
        <translation></translation>
    </message>
    <message>
        <source>p</source>
        <translation></translation>
    </message>
    <message>
        <source>Expire:</source>
        <translation>Expirar:</translation>
    </message>
    <message>
        <source>Acl post:</source>
        <translation>ACL Post:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Default Quota&lt;/b&gt;</source>
        <translation>&lt;b&gt;Quota padrão&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Mbytes</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP SMB Preferences&lt;/b&gt;</source>
        <translation>&lt;b&gt;Preferências LDAP SMB&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Domain:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Domínio:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>S:</source>
        <translation>S:</translation>
    </message>
    <message>
        <source>Perfil:</source>
        <translation>Perfil:</translation>
    </message>
    <message>
        <source>netlogon.bat</source>
        <translation></translation>
    </message>
    <message>
        <source>#UID#.bat</source>
        <translation></translation>
    </message>
    <message>
        <source>Uid counter:</source>
        <translation>Contador de Uid:</translation>
    </message>
    <message>
        <source>SID Dn:</source>
        <translation>SID Dn:</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaSID&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP SMB Populate Preferences&lt;/b&gt;</source>
        <translation>&lt;b&gt;Preferências LDAP SMB Populate&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaUnixIdPool&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>86400</source>
        <translation></translation>
    </message>
    <message>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP Schema Preferences&lt;/b&gt;</source>
        <translation>&lt;b&gt;Preferências LDAP Schema&lt;/b&gt;</translation>
    </message>
    <message>
        <source>To Add objectClasses</source>
        <translation>Ao adicionar objectClasses</translation>
    </message>
    <message>
        <source>&lt;b&gt;Auxiliary schema&lt;/b&gt;</source>
        <translation>&lt;b&gt;Schema auxiliar&lt;/b&gt;</translation>
    </message>
    <message>
        <source>ou</source>
        <translation></translation>
    </message>
    <message>
        <source>domain1</source>
        <translation></translation>
    </message>
    <message>
        <source>ref</source>
        <translation></translation>
    </message>
    <message>
        <source>sambaSID</source>
        <translation></translation>
    </message>
    <message>
        <source>S-0-0-00-0000000000-0000000000-0000000000-0000</source>
        <translation></translation>
    </message>
    <message>
        <source>[U          ]</source>
        <translation></translation>
    </message>
    <message>
        <source>2147483647</source>
        <translation></translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>\\PDC\profiles\#UID#</source>
        <translation></translation>
    </message>
    <message>
        <source>S-0-0-00-0000000000-0000000000-0000000000-514</source>
        <translation></translation>
    </message>
    <message>
        <source>XXX</source>
        <translation></translation>
    </message>
    <message>
        <source>logon.bat</source>
        <translation></translation>
    </message>
    <message>
        <source>\\PDC-SRV\#UID#</source>
        <translation></translation>
    </message>
    <message>
        <source>H:</source>
        <translation>H:</translation>
    </message>
    <message>
        <source>/home/</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;Log&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Recent</source>
        <translation>Recente</translation>
    </message>
    <message>
        <source>Full</source>
        <translation>Completo</translation>
    </message>
    <message>
        <source>&lt;b&gt;IMAP Server Annotation&lt;/b&gt;</source>
        <translation>&lt;b&gt;Servidor IMAP: Annotation&lt;/b&gt;</translation>
    </message>
    <message>
        <source>/admin</source>
        <translation></translation>
    </message>
    <message>
        <source>/motd</source>
        <translation></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/shutdown</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Configuration</source>
        <translation>&amp;Configurações</translation>
    </message>
    <message>
        <source>Korreio - Mail Management</source>
        <translation>Korreio - Administração de Correio Eletrônico</translation>
    </message>
    <message>
        <source>&lt;b&gt;User&lt;/b&gt;. Use comma as user separator.</source>
        <translation>&lt;b&gt;Usuário&lt;/b&gt;. Use vírgulas como separador.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Full name&lt;/b&gt;</source>
        <translation>&lt;b&gt;Nome completo&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;user@example.com&lt;/b&gt;</source>
        <translation>&lt;b&gt;usuario@exemplo.com.br&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Av. Example, N 123&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;District, City, State&lt;/b&gt;</source>
        <translation>&lt;b&gt;Bairro, Cidade, Estado&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;000000&lt;/b&gt;</source>
        <translation>&lt;b&gt;00000-000&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;+1 (55) 5555-5555&lt;/b&gt;</source>
        <translation>&lt;b&gt;+55 (11) 5555-5555&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Example Av. N 123&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Alterar</translation>
    </message>
    <message>
        <source>&lt;b&gt;net getlocalsid DOMAIN&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;b&gt;0: disabled&lt;/b&gt;</source>
        <translation>&lt;b&gt;0: desabilitar&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;-1: disabled&lt;/b&gt;</source>
        <translation>&lt;b&gt;-1: desabilitar&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Ler</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <source>Write</source>
        <translation>Escrever</translation>
    </message>
    <message>
        <source>Post</source>
        <translation>Postar</translation>
    </message>
    <message>
        <source>&lt;b&gt;L&lt;/b&gt;: List
&lt;br&gt;&lt;b&gt;R&lt;/b&gt;: Read&lt;br&gt;&lt;b&gt;S&lt;/b&gt;: Read status
&lt;br&gt;&lt;b&gt;W&lt;/b&gt;: Write status
&lt;br&gt;&lt;b&gt;I&lt;/b&gt;: Write message &lt;br&gt;&lt;b&gt;C&lt;/b&gt;: Create/Delete folders
&lt;br&gt;&lt;b&gt;D&lt;/b&gt;: Delete message
&lt;br&gt;&lt;b&gt;P&lt;/b&gt;: Post
&lt;br&gt;&lt;b&gt;A&lt;/b&gt;: Add/Delete Acls</source>
        <translation>&lt;b&gt;L&lt;/b&gt;: Listar
&lt;br&gt;&lt;b&gt;R&lt;/b&gt;: Ler mensagem
&lt;br&gt;&lt;b&gt;S&lt;/b&gt;: Ler status
&lt;br&gt;&lt;b&gt;W&lt;/b&gt;: Escrever status
&lt;br&gt;&lt;b&gt;I&lt;/b&gt;: Escrever mesagem
&lt;br&gt;&lt;b&gt;C&lt;/b&gt;: Criar/Remover pastas
&lt;br&gt;&lt;b&gt;D&lt;/b&gt;: Remover mensagens
&lt;br&gt;&lt;b&gt;P&lt;/b&gt;: Postar
&lt;br&gt;&lt;b&gt;A&lt;/b&gt;: Adicionar/Remover Acls</translation>
    </message>
    <message>
        <source>&lt;b&gt;Add&lt;/b&gt;</source>
        <translation>&lt;b&gt;Adicionar&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Delete&lt;/b&gt;</source>
        <translation>&lt;b&gt;Remover&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Reconstruct&lt;/b&gt;</source>
        <translation>&lt;b&gt;Reconstruir&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Activate&lt;/b&gt;</source>
        <translation>&lt;b&gt;Ativar&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Disable&lt;/b&gt;</source>
        <translation>&lt;b&gt;Desativar&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Arquivos</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <source>To Delete objectClasses</source>
        <translation>Ao remover objectClasses</translation>
    </message>
    <message>
        <source>ldap://127.0.0.1/ou=example,o=Example%20Corporation</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Entry</source>
        <translation>&amp;Registro</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Novo</translation>
    </message>
    <message>
        <source>&amp;User</source>
        <translation>&amp;Usuário</translation>
    </message>
    <message>
        <source>&amp;Organization</source>
        <translation>&amp;Organização</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>C&amp;ut</source>
        <translation>&amp;Recortar</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>C&amp;olar</translation>
    </message>
    <message>
        <source>&amp;Set Password</source>
        <translation>&amp;Trocar senha</translation>
    </message>
    <message>
        <source>S&amp;amba populate</source>
        <translation>Samba &amp;Populate</translation>
    </message>
    <message>
        <source>Set as &amp;Base</source>
        <translation>Usar como &amp;Base</translation>
    </message>
    <message>
        <source>&amp;Back to Base</source>
        <translation>Ret&amp;ornar a Base</translation>
    </message>
    <message>
        <source>&amp;Server</source>
        <translation>&amp;Servidor</translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation>&amp;Renomear</translation>
    </message>
    <message>
        <source>Re&amp;construct</source>
        <translation>Re&amp;construir</translation>
    </message>
    <message>
        <source>This libraries can not be found:
%1</source>
        <translation>Os seguintes módulos não foram carregados:
%1</translation>
    </message>
    <message>
        <source>Select &amp;all</source>
        <translation>Selecionar &amp;todas</translation>
    </message>
    <message>
        <source>Set &amp;Quota...</source>
        <translation>Definir &amp;Quota...</translation>
    </message>
    <message>
        <source>&amp;Flush</source>
        <translation>&amp;Flush</translation>
    </message>
    <message>
        <source>&amp;Hold</source>
        <translation>&amp;Hold</translation>
    </message>
    <message>
        <source>&amp;Unhold</source>
        <translation>&amp;Unhold</translation>
    </message>
    <message>
        <source>&amp;Requeue</source>
        <translation>&amp;Requeue</translation>
    </message>
    <message>
        <source>&amp;Show message</source>
        <translation>&amp;Ver mensagem</translation>
    </message>
    <message>
        <source>For &amp;all</source>
        <translation>Para &amp;todas</translation>
    </message>
    <message>
        <source>\\server\profiles\#UID#</source>
        <translation></translation>
    </message>
    <message>
        <source>\\server\#UID#\.profile</source>
        <translation></translation>
    </message>
    <message>
        <source>\\server\#UID#</source>
        <translation></translation>
    </message>
    <message>
        <source>Host: %1</source>
        <translation></translation>
    </message>
    <message>
        <source>User: %1</source>
        <translation>Usuário: %1</translation>
    </message>
    <message>
        <source>Base: %1</source>
        <translation></translation>
    </message>
    <message>
        <source>Imap delimiter: %1</source>
        <translation>Separador IMAP: %1</translation>
    </message>
    <message>
        <source>Confirm!</source>
        <translation>Confirme!</translation>
    </message>
    <message>
        <source>Check mailbox for deletion:

    - %1

</source>
        <translation>Verifique caixas postal a remover:

    - %1

</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Sim</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Não</translation>
    </message>
    <message>
        <source>Warning!</source>
        <translation>Atenção!</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>Quota</source>
        <translation></translation>
    </message>
    <message>
        <source>Set quota limit (Kbytes):</source>
        <translation>Definir quota limite (Kbytes):</translation>
    </message>
    <message>
        <source>Confirm entry deletion:

    - %1

</source>
        <translation>Deseja remover o registro:

    - %1

</translation>
    </message>
    <message>
        <source>Confirm all messages deletion request from user &apos;%1&apos;?</source>
        <translation>Deseja remover todas as mensagens do usuário &apos;%1&apos;?</translation>
    </message>
    <message>
        <source>Confirm message &apos;%1&apos; deletion request from user &apos;%2&apos;?</source>
        <translation>Deseja remover a mensagem &apos;%1&apos; do usuário &apos;%2&apos;?</translation>
    </message>
    <message>
        <source>    Warning: the FLUSH operation cause negative interference in QMGR 
sent messages scheduler algorithm, especially in large queues.
Use only when necessary.</source>
        <translation>    Atenção: a ação de FLUSH interfere negativamente no algoritmo de
escalonamento de envio de mensagens do QMGR com filas grandes.
Use somente quando necessário.</translation>
    </message>
    <message>
        <source>Confim set all messages on hold?</source>
        <translation>Deseja colocar todas as mensagens em espera (hold)?</translation>
    </message>
    <message>
        <source>Confirm set all messages to delivery (unhold)?</source>
        <translation>Deseja proceder com a entrega de todas as mensagens (unhold)?</translation>
    </message>
    <message>
        <source>Confirm transport requeue for all messages?</source>
        <translation>Deseja reconsultar o transporte para todas as mensagens (requeue)?</translation>
    </message>
    <message>
        <source>Confirme all messages deletion request?</source>
        <translation>Deseja remover todas as mensagens?</translation>
    </message>
    <message>
        <source>Can&apos;t load libraries</source>
        <translation>Não foi possível carregar os módulos</translation>
    </message>
    <message>
        <source>search results many entries, server limit anwser. Set a filter properly.</source>
        <translation>a pesquisa resulta em muitos registros, e o servidor limitou as respostas. Use um filtro adequado.</translation>
    </message>
    <message>
        <source>invalid syntax for search filter. Set a filter properly.</source>
        <translation>sintáxe inválida para o filtro de pesquisa. Use um filtro adequado.</translation>
    </message>
    <message>
        <source>search don&apos;t have results.</source>
        <translation>a pesquisa não retornou resultados.</translation>
    </message>
    <message>
        <source>entry already exists.</source>
        <translation>o registro já existe.</translation>
    </message>
    <message>
        <source>objectClass &apos;%1&apos; require attribute &apos;%2&apos;.</source>
        <translation>objectClass &apos;%1&apos; necessita do atributo &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>attribute &apos;%1&apos; is not supported by these objectClass&apos;s.</source>
        <translation>atributo &apos;%1&apos; não é suportado por estes objectClasses.</translation>
    </message>
    <message>
        <source>incompatible objectClasses &apos;%1&apos; e &apos;%2&apos;.</source>
        <translation>objectClasses incompatíveis: &apos;%1&apos; e &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>object class violation (%1).</source>
        <translation>violação de objectClasses (%1).</translation>
    </message>
    <message>
        <source>connection refused to %1.</source>
        <translation>conexão recusada para %1.</translation>
    </message>
    <message>
        <source>attribute &apos;%1&apos; undefined at schema.</source>
        <translation>atributo &apos;%1&apos; não definido no schema.</translation>
    </message>
    <message>
        <source>no write permission by user &apos;%1&apos; or wrong ldap authentication.</source>
        <translation>sem permissão de escrita para o usuário &apos;%1&apos; ou erro de autenticação.</translation>
    </message>
    <message>
        <source>invalid fingerprint to %1 (man-in-the-middle attack).</source>
        <translation>ssh-fingerprint inválido para %1 (man-in-the-middle?).</translation>
    </message>
    <message>
        <source>connection dropped to %1.</source>
        <translation>o servidor terminou a conexão &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>connection timeout to %1.</source>
        <translation>a conexão %1 sofreu timeout.</translation>
    </message>
    <message>
        <source>can&apos;t make directory ~/.korreio (%1).</source>
        <translation>não foi possível criar diretório ~/.korreio (%1).</translation>
    </message>
    <message>
        <source>can&apos;t read configuration file ~/.korreio/korreio.conf (%1).</source>
        <translation>não foi possível ler arquivo de configuração ~/.korreio/korreio.conf (%1).</translation>
    </message>
    <message>
        <source>Configuration saved.</source>
        <translation>Configuração salva.</translation>
    </message>
    <message>
        <source>set objectClass/attribute.</source>
        <translation>informe o objectClass/atributo.</translation>
    </message>
    <message>
        <source>%1 connected.</source>
        <translation>%1 conectado.</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation></translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <source>Warn</source>
        <translation>Atenção</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>%1 (%2).</source>
        <translation>%1 (%2).</translation>
    </message>
    <message>
        <source>parent mailbox &apos;%1&apos; don&apos;t exist.</source>
        <translation>caixa postal superior &apos;%1&apos; não existe.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; created.</source>
        <translation>caixa postal &apos;%1&apos; criada.</translation>
    </message>
    <message>
        <source>set mailbox.</source>
        <translation>informe a caixa postal.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; creation failed.</source>
        <translation>não foi possível criar a caixa postal &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>select mailbox for deletion.</source>
        <translation>informe a caixa postal a ser removida.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; deletion aborted.</source>
        <translation>remoção da caixa postal &apos;%1&apos; cancelada.</translation>
    </message>
    <message>
        <source>no write permission to parent entry &apos;%1&apos;.</source>
        <translation>sem permissão de escrita no nó superior: &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; already exists.</source>
        <translation>caixa postal &apos;%1&apos; já existe.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; deleted.</source>
        <translation>caixa postal &apos;%1&apos; removida.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; deletion failed. (%2)</source>
        <translation>não foi possível remover a caixa postal &apos;%1&apos;. (%2)</translation>
    </message>
    <message>
        <source>select mailbox to set quota.</source>
        <translation>informa a caixa postal para definição de quota.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; seted quota to &apos;%2 Kbytes&apos;.</source>
        <translation>caixa postal &apos;%1&apos; teve sua quota configurada para &apos;%2 Kbytes&apos;.</translation>
    </message>
    <message>
        <source>can&apos;t set quota to mailbox &apos;%1&apos;.</source>
        <translation>não foi possível configurar quota para a caixa postal &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>select mailbox for reconstruct.</source>
        <translation>informe a caixa postal a ser reconstruida.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has been reconstructed.</source>
        <translation>caixa postal &apos;%1&apos; reconstruida.</translation>
    </message>
    <message>
        <source>can&apos;t reconstruct mailbox &apos;%1&apos;.</source>
        <translation>não foi possível reconstruir a caixa postal &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; already exist.</source>
        <translation>caixa postal &apos;%1&apos; já existe.</translation>
    </message>
    <message>
        <source>can&apos;t detect IMAP-partition to &apos;%1&apos;.</source>
        <translation>não foi possível detectar a partição-IMAP para &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>rename aborted.</source>
        <translation>a renomeação foi cancelada.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; renamed to &apos;%2&apos;.</source>
        <translation>caixa postal &apos;%1&apos; renomeada para &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>can&apos;t rename &apos;%1&apos;. Verify option: &quot;allowusermoves: yes&quot;.</source>
        <translation>não foi possível renomear a caixa postal &apos;%1&apos;. Verique a opção: &quot;allowusermoves: yes&quot;.</translation>
    </message>
    <message>
        <source>select annotation.</source>
        <translation>informa a annotation.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has annotation &apos;%2&apos; set to &apos;%3&apos;.</source>
        <translation>caixa postal &apos;%1&apos; teve a annotation &apos;%2&apos; configurada para &apos;%3&apos;.</translation>
    </message>
    <message>
        <source>can&apos;t set annotation &apos;%1&apos; for mailbox &apos;%2&apos; (%3).</source>
        <translation>não foi possível configurar a annotation &apos;%1&apos; para a caixa postal &apos;%2&apos; (%3).</translation>
    </message>
    <message>
        <source>select mailbox to set annotation.</source>
        <translation>informe a caixa postal para aplicar a annotation.</translation>
    </message>
    <message>
        <source>select a mailbox.</source>
        <translation>informe a caixa postal.</translation>
    </message>
    <message>
        <source>select mailbox for ACL deletion.</source>
        <translation>informe a caixa postal para remoção da ACL.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has ACL to &apos;%2&apos; deleted.</source>
        <translation>caixa postal &apos;%1&apos; teve a ACL para &apos;%2&apos; removida.</translation>
    </message>
    <message>
        <source>can&apos;t delete ACL to &apos;%1&apos; for mailbox &apos;%2&apos;.</source>
        <translation>não foi possível remover a ACL para &apos;%1&apos; da caixa postal &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>select mailbox to set ACL.</source>
        <translation>informe a caixa postal para aplicar a ACL.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has added ACL &apos;%2&apos; to user &apos;%3&apos;.</source>
        <translation>caixa postal &apos;%1&apos; teve adicionado a ACL &apos;%2&apos; para o usuário &apos;%3&apos;.</translation>
    </message>
    <message>
        <source>can&apos;t set ACL &apos;%1&apos; to user &apos;%2&apos; for mailbox &apos;%3&apos;.</source>
        <translation>não foi possível adicionar a ACL &apos;%1&apos; para o usuário &apos;%2&apos; na caixa postal &apos;%3&apos;.</translation>
    </message>
    <message>
        <source>select IMAP-Partition.</source>
        <translation>informe a partição-IMAP.</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; moved to IMAP-Partition &apos;%2&apos;.</source>
        <translation>caixa postal &apos;%1&apos; movida para partição-IMAP &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>can&apos;t move mailbox &apos;%1&apos; to IMAP-Partition &apos;%2&apos;. (%3)</source>
        <translation>não foi possível mover a caixa postal &apos;%1&apos; para a partição-IMAP &apos;%2&apos;. (%3)</translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has set quota to &apos;%2 Kbytes&apos;.</source>
        <translation>caixa postal &apos;%1&apos; teve quota definida para &apos;%2 Kbytes&apos;.</translation>
    </message>
    <message>
        <source>set quota aborted.</source>
        <translation>a definição de quota foi cancelada.</translation>
    </message>
    <message>
        <source>set netbios domains.</source>
        <translation>informe o domínio netbios.</translation>
    </message>
    <message>
        <source>set user name.</source>
        <translation>informe o nome do usuário.</translation>
    </message>
    <message>
        <source>password don&apos;t match, type again.</source>
        <translation>as senhas não conferem, digite-as novamente.</translation>
    </message>
    <message>
        <source>set uid.</source>
        <translation>informe o id do usuário.</translation>
    </message>
    <message>
        <source>set uidNumber.</source>
        <translation>informe o uidNumber.</translation>
    </message>
    <message>
        <source>set gidNumber.</source>
        <translation>informe o gidNumber.</translation>
    </message>
    <message>
        <source>set home directory.</source>
        <translation>informe o diretório home do usuário.</translation>
    </message>
    <message>
        <source>domain &apos;%1&apos; is not configured.</source>
        <translation>domínio &apos;%1&apos; não esta configurado.</translation>
    </message>
    <message>
        <source>SIDdn for domain &apos;%1&apos; is not configured.</source>
        <translation>SIDdn para o domínio &apos;%1&apos; não esta configurado.</translation>
    </message>
    <message>
        <source>uidNumber counter for domain &apos;%1&apos; is not configured.</source>
        <translation>o contado de uidNumber para o domínio &apos;%1&apos; não esta configurado.</translation>
    </message>
    <message>
        <source>set user for asterisk.</source>
        <translation>informe o usuário para o asterisk.</translation>
    </message>
    <message>
        <source>set ramal for asterisk user.</source>
        <translation>informe o ramal do usuário para o asterisk.</translation>
    </message>
    <message>
        <source>set port for asterisk.</source>
        <translation>informe a porta do asterisk.</translation>
    </message>
    <message>
        <source>set user radius group.</source>
        <translation>informe o grupo do radius do usuário.</translation>
    </message>
    <message>
        <source>entry &apos;%1&apos; added.</source>
        <translation>registro &apos;%1&apos; adicionado.</translation>
    </message>
    <message>
        <source>entry &apos;%1&apos; modified.</source>
        <translation>registro &apos;%1&apos; modificado.</translation>
    </message>
    <message>
        <source>select a entry.</source>
        <translation>selecione um registro.</translation>
    </message>
    <message>
        <source>select a attribute to be DN.</source>
        <translation>selecione um atributo para ser o DN.</translation>
    </message>
    <message>
        <source>entry &apos;%1&apos; deleted.</source>
        <translation>registro &apos;%1&apos; removido.</translation>
    </message>
    <message>
        <source>can&apos;t delete entry &apos;%1&apos;.</source>
        <translation>não foi possível remover o registro &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>entry &apos;%1&apos; deletion been aborted.</source>
        <translation>a remoção do registro &apos;%1&apos; foi cancelada.</translation>
    </message>
    <message>
        <source>selected attribute will be Distinguish Name.</source>
        <translation>o atributo selecionado será o Distinguish Name.</translation>
    </message>
    <message>
        <source>entry Distinguish Name &apos;%1&apos; changed.</source>
        <translation>registro &apos;%1&apos; teve seu Distinguish Name alterado.</translation>
    </message>
    <message>
        <source>the entry will be added to &apos;%1&apos;.</source>
        <translation>registro será adicionado em &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>you need select a entry.</source>
        <translation>selecione um registro.</translation>
    </message>
    <message>
        <source>selected entry to password change is &apos;%1&apos;.</source>
        <translation>registro selecionado para a troca de senha é &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>selected entry to populate is &apos;%1&apos;.</source>
        <translation>registro selecionado para ser populado para o samba é &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>select at least one attribute.</source>
        <translation>selecione ao menos um atributo de senha.</translation>
    </message>
    <message>
        <source>passwords don&apos;t match, type again.</source>
        <translation>senhas não conferem, digite-as novamente.</translation>
    </message>
    <message>
        <source>unsupported hash.</source>
        <translation>hash não suportado.</translation>
    </message>
    <message>
        <source>set netbios domain name.</source>
        <translation>informe o domínio netbios.</translation>
    </message>
    <message>
        <source>set netbios domain SID.</source>
        <translation>informe o SID do domínio netbios.</translation>
    </message>
    <message>
        <source>set uid=root password.</source>
        <translation>informe a senha para uid=root.</translation>
    </message>
    <message>
        <source>can&apos;t add entry &apos;%1&apos;.</source>
        <translation>não foi possível adicionar o registro &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>invalid request. Operation can&apos;t be done.</source>
        <translation>requisição inválida.</translation>
    </message>
    <message>
        <source>running remote request: %1.</source>
        <translation>executando comando remoto: %1.</translation>
    </message>
    <message>
        <source>saving file: %1</source>
        <translation>salvando arquivo: %1</translation>
    </message>
    <message>
        <source>option &apos;%1&apos; is set.</source>
        <translation>opção &apos;%1&apos; foi configurada.</translation>
    </message>
    <message>
        <source>can&apos;t set option &apos;%1&apos;.</source>
        <translation>não foi possível configurar opção &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>set file name.</source>
        <translation>informe o nome do arquivo.</translation>
    </message>
    <message>
        <source>file &apos;%1&apos; not found.</source>
        <translation>arquivo &apos;%1&apos; não encontrado.</translation>
    </message>
    <message>
        <source>hash &apos;%1.db&apos; created.</source>
        <translation>hash &apos;%1.db&apos; criado.</translation>
    </message>
    <message>
        <source>can&apos;t create hash &apos;%1.db&apos;.</source>
        <translation>não foi possível criar hash &apos;%1.db&apos;.</translation>
    </message>
    <message>
        <source>%1 disconnected. (wrong user or password)</source>
        <translation>%1 desconectado. (usuário ou senha inválidos)</translation>
    </message>
    <message>
        <source>%1 disconnected. (connection refused)</source>
        <translation>%1 desconectado. (conexão recusada)</translation>
    </message>
    <message>
        <source>set sieve script name.</source>
        <translation>informe o nome do script sieve.</translation>
    </message>
    <message>
        <source>&apos;#USER#&apos; macro will be replaced properly.</source>
        <translation>a macro &apos;#USER#&apos; será substituida adequadamente.</translation>
    </message>
    <message>
        <source>command not found: %1.</source>
        <translation>comando não encontrado: &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; processed message(s).</source>
        <translation>&apos;%1&apos; mensagem(ns) processada(s).</translation>
    </message>
    <message>
        <source>deletion request was aborted.</source>
        <translation>a remoção foi cancelada.</translation>
    </message>
    <message>
        <source>flush request was aborted.</source>
        <translation>o &apos;flush&apos; foi cancelado.</translation>
    </message>
    <message>
        <source>hold on request was aborted.</source>
        <translation>o &apos;hold&apos; foi cancelado.</translation>
    </message>
    <message>
        <source>unhold request was aborted.</source>
        <translation>o &apos;unhold&apos; foi cancelado.</translation>
    </message>
    <message>
        <source>transport requeue request was aborted.</source>
        <translation>o &apos;requeue&apos; foi cancelado.</translation>
    </message>
    <message>
        <source>- Check if user is not logged by POP/IMAP before you proceed.
         # grep -r johndoe /var/lib/cyrus/proc/
</source>
        <translation>- Verifique se este usuário não esta logado via POP/IMAP antes de prosseguir.
         # grep -r johndoe /var/lib/cyrus/proc/
</translation>
    </message>
    <message>
        <source>- The option &quot;allowusermoves: yes&quot; must be configured at imap.conf.</source>
        <translation>- A opção &quot;allowusermoves: yes&quot; deve estar configurada no imap.conf.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Templates:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Modelos:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Enable without password (NOPASSWD)</source>
        <translation>Ativado sem senha (NOPASSWD)</translation>
    </message>
    <message>
        <source>Imap delimiter: disconnected</source>
        <translation>Separador IMAP: desconectado</translation>
    </message>
    <message>
        <source>type a valid mailbox name.</source>
        <translation>digite uma nome de caixa postal válido.</translation>
    </message>
    <message>
        <source>wrong user or password to %1.</source>
        <translation>usuário ou senha incorretos em %1.</translation>
    </message>
    <message>
        <source>user is not cyrus administrator to %1.</source>
        <translation>usuário não é administrador do cyrus em %1.</translation>
    </message>
</context>
</TS>
