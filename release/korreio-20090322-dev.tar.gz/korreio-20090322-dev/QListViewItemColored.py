
class QListViewItemColored(QListViewItem):
  def __init__(self, *args):
    QListViewItem.__init__(self, *args)

  def paintCell(self, p, cg, column, width, align):
    g = QColorGroup(cg)
    g.setColor( QColorGroup.Base, QColor("grey95"))
#    g.setColor( QColorGroup.Text, QColor("darkgreen"))
    QListViewItem.paintCell(self, p, g, column, width, align)
