# Copyright (c) 2007 -  Reinaldo Carvalho <reinaldoc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.

void dKorreio::cyrus_search() {
m = self.cyrus_connect()
mailboxes = m.lm("user",self.iCyrUser.text().ascii()+"*")
print m.lm(None)
m.logout()
self.lvCyrus.clear()
mailbox = []
if self.iCyrMailbox.text().ascii():
    mailbox = self.iCyrMailbox.text().ascii().split("/")
lastlen=99
tree = {}
i=True
for group in mailboxes:
    for id in mailboxes[group]:
      print group+"::"+id
      idlist = id.split("/")
      if idlist[0] == "INBOX":
        idlist[0] = self.iCyrusUser.text().ascii()
      elif idlist[0] == "user":
        idlist = idlist[1:]
      newlen = len(idlist)
      if newlen == 1:
        tree[1] = QListViewItem(self.lvCyrus)
        tree[1].setText(0,idlist[-1])
      elif newlen == 2:
        tree[2] = QListViewItem(tree[1])
        tree[2].setText(0,idlist[-1])
      else:
        tree[newlen] = QListViewItem(tree[newlen-1])
        tree[newlen].setText(0,idlist[-1])
      if len(mailbox) > newlen:
        if tree[newlen].text(0).ascii() == mailbox[newlen-1]:
          tree[newlen].setOpen(True)
          tree[newlen].setSelected(True)
          self.lvCyrus.setCurrentItem(tree[newlen])
          i=False
if i:
    self.lvCyrus.currentItem().setSelected(True)
}


void dKorreio::save_config() {
import os.path

try:
    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')
    f.write('cyrus.mode='+self.cbCyrusMode.currentText().ascii()+'\n')
    f.write('cyrus.host='+self.iCyrusHost.text().ascii()+'\n')
    f.write('cyrus.port='+self.iCyrusPort.text().ascii()+'\n')
    f.write('cyrus.user='+self.iCyrusUser.text().ascii()+'\n')
    f.write('cyrus.pass='+self.iCyrusPass.text().ascii()+'\n')
    f.write('cyrus.part='+self.iCyrusPart.text().ascii()+'\n')
    f.write('ldap.mode='+self.cbLdapMode.currentText().ascii()+'\n')
    f.write('ldap.host='+self.iLdapHost.text().ascii()+'\n')
    f.write('ldap.port='+self.iLdapPort.text().ascii()+'\n')
    f.write('ldap.basedn='+self.iLdapBaseDN.text().ascii()+'\n')
    f.write('ldap.user='+self.iLdapUser.text().ascii()+'\n')
    f.write('ldap.pass='+self.iLdapPass.text().ascii()+'\n')
    f.write('ldap.ref='+str(self.cLdapRef.isChecked())+'\n')
    f.write('ldap.cert='+str(self.cLdapCert.isChecked())+'\n')
    f.write('ssh.host='+self.iSshHost.text().ascii()+'\n')
    f.write('ssh.port='+self.iSshPort.text().ascii()+'\n')
    f.write('ssh.user='+self.iSshUser.text().ascii()+'\n')
    f.write('ssh.pass='+self.iSshPass.text().ascii()+'\n')
    f.close()
    os.chmod(os.path.expanduser("~/.korreio/korreio.conf"), 0600)
    self.console("Configuração salva.".encode('iso-8859-1'))
except OSError, e:
    self.parse_exception("OSError", e)

}


void dKorreio::load_config() {
import os.path
try:
    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
    conf=f.read()
    f.close()
except IOError, e:
    self.parse_exception("IOError", e)
    return True

confList = conf.split("\n")
confList.pop()
confDict = {}

for line in confList:
   key=line.split("=")
   confDict[key[0]] = "=".join(key[1:])

self.cbCyrusMode.setCurrentText(confDict.get("cyrus.mode"))
self.iCyrusHost.setText(confDict.get("cyrus.host"))
self.iCyrusPort.setText(confDict.get("cyrus.port"))
self.iCyrusUser.setText(confDict.get("cyrus.user"))
self.iCyrusPass.setText(confDict.get("cyrus.pass"))
self.iCyrusPart.setText(confDict.get("cyrus.part"))
self.cbLdapMode.setCurrentText(confDict.get("ldap.mode"))
self.iLdapHost.setText(confDict.get("ldap.host"))
self.iLdapPort.setText(confDict.get("ldap.port"))
self.iLdapBaseDN.setText(confDict.get("ldap.basedn"))
self.iLdapUser.setText(confDict.get("ldap.user"))
self.iLdapPass.setText(confDict.get("ldap.pass"))
if confDict.get("ldap.ref") == "True":
    self.cLdapRef.setChecked(True)
if confDict.get("ldap.cert") == "True":
    self.cLdapCert.setChecked(True)
self.iSshHost.setText(confDict.get("ssh.host"))
self.iSshPort.setText(confDict.get("ssh.port"))
self.iSshUser.setText(confDict.get("ssh.user"))
self.iSshPass.setText(confDict.get("ssh.pass"))

self.console("Configuração carregada.".encode('iso-8859-1'))

}


void dKorreio::tab_changed() {
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
menu=str(self.wKorreio.tabLabel(self.wKorreio.currentPage()))
if menu == "LDAP Manager":
    self.load_config()
}


void dKorreio::mailbox_clicked() {

item=self.lvCyrus.currentItem()
if item.childCount() == 0:
    self.pCyrDelete.setEnabled(True)
else:
    self.pCyrDelete.setEnabled(False)
mailbox=item.text(0).ascii()
while item.parent() is not None:
    mailbox=item.parent().text(0).ascii()+"/"+mailbox
    item=item.parent()
self.iCyrMailbox.setText(mailbox)

if len(mailbox.split("/")) == 1:
    self.gbQuota.setEnabled(True)
    self.iQuotaUsed.setEnabled(False)
else:
    self.gbQuota.setEnabled(False)

m = self.cyrus_connect()
quota = m.lq("user",self.iCyrMailbox.text().ascii())
self.iQuotaUsed.setText(str(quota[0]))
self.iQuota.setText(str(quota[1]))
self.permissions = m.lam("user",mailbox)
self.cbUserACL.clear()
for user in self.permissions:
    self.cbUserACL.insertItem(user)
self.check_permissions()
if self.cbUserACL.count() > 1:
    self.cbUserACL.popup()

}

void dKorreio::create_mailbox() {
import re
if re.search("-",self.iCyrMailbox.text().ascii()):
    self.console("Usuarios com - causam erro na funcao cyrus_search(), por enquanto esta desabilitado.")
    return True
m = self.cyrus_connect()
if self.iCyrusPart.text().ascii():
    m.cm("user", self.iCyrMailbox.text().ascii(),self.iCyrusPart.text().ascii())
else:
    m.cm("user", self.iCyrMailbox.text().ascii())
m.sam("user", self.iCyrMailbox.text().ascii(), self.iCyrusUser.text().ascii(), " ")
m.logout()
self.cyrus_search()
}


void dKorreio::delete_mailbox() {
m = self.cyrus_connect()
m.sam("user", self.iCyrMailbox.text().ascii(), self.iCyrusUser.text().ascii(), "c")
m.dm("user", self.iCyrMailbox.text().ascii())
m.logout()
self.cyrus_search()
}


void dKorreio::set_quota() {
m = self.cyrus_connect()
m.sq("user",self.iCyrMailbox.text().ascii(),self.iQuota.text().ascii())
m.logout()
}

void dKorreio::check_permissions() {
mailbox_perm = self.permissions[self.cbUserACL.currentText().ascii()]
import re
if re.search("l",mailbox_perm): self.cCyrPermL.setChecked(True)
else: self.cCyrPermL.setChecked(False)
if re.search("r",mailbox_perm): self.cCyrPermR.setChecked(True)
else: self.cCyrPermR.setChecked(False)
if re.search("s",mailbox_perm): self.cCyrPermS.setChecked(True)
else: self.cCyrPermS.setChecked(False)
if re.search("w",mailbox_perm): self.cCyrPermW.setChecked(True)
else: self.cCyrPermW.setChecked(False)
if re.search("i",mailbox_perm): self.cCyrPermI.setChecked(True)
else: self.cCyrPermI.setChecked(False)
if re.search("p",mailbox_perm): self.cCyrPermP.setChecked(True)
else: self.cCyrPermP.setChecked(False)
if re.search("c",mailbox_perm): self.cCyrPermC.setChecked(True)
else: self.cCyrPermC.setChecked(False)
if re.search("d",mailbox_perm): self.cCyrPermD.setChecked(True)
else: self.cCyrPermD.setChecked(False)
if re.search("a",mailbox_perm): self.cCyrPermA.setChecked(True)
else: self.cCyrPermA.setChecked(False)
}


void dKorreio::set_cyracl() {
perm=""
if self.cCyrPermL.isChecked():
    perm="l"
if self.cCyrPermR.isChecked():
    perm=perm+"r"
if self.cCyrPermS.isChecked():
    perm=perm+"s"
if self.cCyrPermW.isChecked():
    perm=perm+"w"
if self.cCyrPermI.isChecked():
    perm=perm+"i"
if self.cCyrPermP.isChecked():
    perm=perm+"p"
if self.cCyrPermC.isChecked():
    perm=perm+"c"
if self.cCyrPermD.isChecked():
    perm=perm+"d"
if self.cCyrPermA.isChecked():
    perm=perm+"a"

import cyruslib
if self.cbCyrusMode.currentText().ascii() == "imaps://":
    cyrmode = 1
else:
    cyrmode = 0
m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),cyrmode)
m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
m.sam("user",self.iCyrMailbox.text().ascii(),self.cbUserACL.currentText().ascii(),perm)
}


void dKorreio::reconstruct_mailbox() {
import cyruslib
if self.cbCyrusMode.currentText().ascii() == "imaps://":
    cyrmode = 1
else:
    cyrmode = 0
m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),cyrmode)
m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
m.reconstruct("user",self.iCyrMailbox.text().ascii())

}


void dKorreio::get_ldap_basedn() {
import ldap
try:
    l = ldap.open(self.iLdapHost.text().ascii(),int(self.iLdapPort.text().ascii()))
    l.protocol_version = ldap.VERSION3
    if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
        l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
    else:
        l.simple_bind()
    searchScope = ldap.SCOPE_BASE
    searchFilter = "objectclass=*"
    retrieveAttributes = ["namingContexts"]
    ldap_result_id = l.search("", searchScope, searchFilter, retrieveAttributes)
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if (result_data == []):
            break
        else:
            if result_type == ldap.RES_SEARCH_ENTRY:
                for j in result_data:
                     self.iLdapBaseDN.setText(j[1]["namingContexts"][0])
                     self.iLdapUser.setText("cn=admin,"+j[1]["namingContexts"][0])
                     return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
}


void dKorreio::set_imap_port() {
if self.cbCyrusMode.currentText().ascii() == "imap://":
    self.iCyrusPort.setText("143")
else:
    self.iCyrusPort.setText("993")
}


void dKorreio::cyrus_connect() {
import cyruslib
if self.cbCyrusMode.currentText().ascii() == "imaps://":
    cyrmode = 1
else:
    cyrmode = 0
m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),cyrmode)
m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
return m
}


void dKorreio::ldap_search() {
    def create_nodes(dn):
        dnlist = dn.split(",")
        dnnode = ",".join(dnlist[1:])
        if not self.nodes.get(dnnode):
            create_nodes(dnnode)            
        self.nodes[dn] = QListViewItem(self.nodes.get(dnnode))
        self.nodes[dn].setText(0,dnlist[0])
        
    import re
    basedn = self.iLdapBaseDN.text().ascii()
    try:
        olddn = self.get_full_dn()
    except AttributeError, e:
        olddn = basedn
    self.lvLdap.clear()
    self.nodes = {}
    self.nodes[basedn] = QListViewItem(self.lvLdap)
    self.nodes[basedn].setText(0,basedn)
    self.nodes[basedn].setOpen(True)
    if self.cbLdapFilter.currentText().ascii() == '':
        filter = "(objectClass=*)"
    else:
        filter = "("+self.cbLdapFilter.currentText().ascii()+")"
    self.ldap_attr = self.ldap_result(filter)
    try:
        basednattrs = self.ldap_attr.get(basedn)
        del self.ldap_attr[basedn]
    except KeyError, e:
        pass
    for dn in self.ldap_attr:
        if not self.nodes.get(dn):
            create_nodes(dn)
    try:
        self.ldap_attr[basedn] = basednattrs
    except KeyError, e:
        pass
    i = 0
    while olddn != basedn:
        try:
            self.nodes[olddn].setOpen(True)
            if i == 0:
                self.lvLdap.setSelected(self.nodes[olddn], True)
                i = 1
        except KeyError, e:
            pass
        dnlist = olddn.split(",")
        olddn = ",".join(dnlist[1:])
    if i == 0:
        self.lvLdap.currentItem().setSelected(True)
    self.ldap_dn_clicked()
}

void dKorreio::ldap_connect() {
try:
    import ldap
    if self.cLdapCert.isChecked():
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
    l = ldap.initialize(self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
    if self.cLdapRef.isChecked():
        ldap.set_option(ldap.OPT_REFERRALS,1)
    l.protocol_version = ldap.VERSION3
    l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
    return l
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
}

void dKorreio::ldap_result(a0) {
import ldap
try:
    l = self.ldap_connect()
    searchScope = ldap.SCOPE_SUBTREE
    searchFilter = a0
    retrieveAttributes = None
    ldap_result_id = l.search(self.iLdapBaseDN.text().ascii(), searchScope, searchFilter, retrieveAttributes)
    ldap_result = {}
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if (result_data == []):
            break
        elif result_type == ldap.RES_SEARCH_ENTRY:
            ldap_result[result_data[0][0]] = result_data[0][1]
    return ldap_result
except ldap.LDAPError, e:
    if e[0]["desc"] == "Size limit exceeded":
        self.console("Número de registros excedido. Utilize um filtro mais restritivo.")
        return ldap_result
    else:
        self.parse_exception("LDAPError", e)
}

void dKorreio::ldap_dn_clicked() {
self.lvLdapAttr.clear()
self.wsLdap.raiseWidget(0)
self.cbLdapStack.setCurrentItem(0)
dn = self.get_full_dn()
try:
    for attribute,values in self.ldap_attr.get(dn).items():
        for value in values:
           item = QListViewItem(self.lvLdapAttr)
           item.setText(0,attribute)
           item.setText(1,value)
except AttributeError, e:
    pass
item = self.lvLdap.currentItem()
if item.parent() is None or item.childCount() != 0:
    self.pLdapDelete.setEnabled(False)
else:
    self.pLdapDelete.setEnabled(True)

if self.lvLdapAttr.childCount() > 0:
    self.lvLdapAttr.setCurrentItem(self.lvLdapAttr.firstChild())
    self.lvLdapAttr.currentItem().setSelected(True)
}

void dKorreio::ldap_dn_doubleclicked() {
if self.lvLdap.currentItem().childCount() == 0:
    self.rdnold = self.get_full_dn()
    self.lvLdap.currentItem().setRenameEnabled(0,True)
    self.lvLdap.currentItem().startRename(0)
}

void dKorreio::ldap_insert_user() {
import md5
import base64
dn = "cn="+self.iLdapCn.text().ascii()+","+self.get_full_dn()
attrs = {}
attrs['objectclass'] = ['inetOrgPerson']
attrs['cn'] = self.iLdapCn.text().ascii()
attrs['sn'] = self.iLdapCn.text().ascii().split(" ")[-1]
emails = self.iLdapMail.text().ascii().split(",")
attrs['mail'] = emails[0]
if len(emails) > 0:
    attrs['l'] = emails[1:]
m = md5.new(self.iLdapUserP.text().ascii())
attrs['userPassword'] = '{md5}'+base64.encodestring(m.digest())
self.ldap_add(dn,attrs)
self.ldap_search()
self.wsLdap.raiseWidget(1)
}


void dKorreio::ldap_add(a0,a1) {
# a0 = DN, a1 = attrs
import ldap
import ldap.modlist as modlist
try:
    ldif = modlist.addModlist(a1)
    l = self.ldap_connect()
    l.add_s(a0,ldif)
    l.unbind_s()
    self.console("Registro "+a0+" adicionado com sucesso.")
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False
}

void dKorreio::ldap_modify_rdn( a0, a1, a2) {
#a0 = oldDN, a1 = newDN, a2 = newDNexist
import ldap
try:
    l = self.ldap_connect()
    l.rename_s(a0,a1,None,a2)
    l.unbind_s()
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False
}

void dKorreio::view_ldap_modify() {
stack = self.cbLdapStack.currentItem()
if stack == 0:
    old = {}
    for attribute,values in self.ldap_attr.get(self.get_full_dn()).items():
        if old.get(attribute):
           old[attribute].extend(values)
        else:
           old[attribute] = values

    new = {}
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if new.get(item.text(0).ascii()):
            new[item.text(0).ascii()].extend([item.text(1).ascii()])
        else:
            new[item.text(0).ascii()] = [item.text(1).ascii()]
        item = item.nextSibling()

    if not self.ldap_modify(self.get_full_dn(),old,new):
        return False
else:
    new = {}
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if item.isSelected():
            dn=item.text(0).ascii()+"="+item.text(1).ascii()+","+self.get_full_dn()
        if new.get(item.text(0).ascii()):
            new[item.text(0).ascii()].extend([item.text(1).ascii()])
        else:
            new[item.text(0).ascii()] = [item.text(1).ascii()]
        item = item.nextSibling()
    try:
        if not self.ldap_add(dn,new):
            return False
    except UnboundLocalError, e:
        self.console("Selecione o DN entre os atributos.")
        return False

self.ldap_search()
}

void dKorreio::ldap_insert_ou() {
dn = "ou="+self.iLdapOu.text().ascii()+","+self.get_full_dn()
attrs = {}
attrs['objectclass'] = ['organizationalUnit']
attrs['ou'] = self.iLdapOu.text().ascii()
self.ldap_add(dn,attrs)
self.ldap_search()
self.wsLdap.raiseWidget(2)
}


void dKorreio::ldap_remove_entry() {
dn = self.get_full_dn()
if dn is not None:
    self.ldap_del_entry(dn)
    self.ldap_search()
    self.ldap_dn_clicked()
}

void dKorreio::ldap_remove_attr() {
self.lvLdapAttr.takeItem(self.lvLdapAttr.currentItem())
self.lvLdapAttr.currentItem().setSelected(True)
}

void dKorreio::ldap_rename_attr_value() {
if not self.lvLdap.currentItem().text(0).ascii() == "=".join([self.lvLdapAttr.currentItem().text(0).ascii(),self.lvLdapAttr.currentItem().text(1).ascii()]):
    self.lvLdapAttr.currentItem().setRenameEnabled(1,True)
    self.lvLdapAttr.currentItem().startRename(1)
}

void dKorreio::ldap_add_attr() {
if self.cbLdapAttr.currentText().ascii() != '':
    item = QListViewItem(self.lvLdapAttr)
    item.setText(0,self.cbLdapAttr.currentText().ascii())
    item.setText(1,self.cbLdapValue.currentText().ascii())
}

void dKorreio::ldap_rename_rdn() {
if self.rdnold.split(",")[0] == self.lvLdap.currentItem().text(0).ascii():
    return True
dnexist = 1
item = self.lvLdapAttr.firstChild()
while item is not None:
    if item.text(0).ascii()+"="+item.text(1).ascii() == self.lvLdap.currentItem().text(0).ascii():
        dnexist = 0
    item = item.nextSibling()

if not self.ldap_modify_rdn(self.rdnold, self.lvLdap.currentItem().text(0).ascii(),dnexist):
    self.lvLdap.currentItem().setText(0, self.rdnold.split(",")[0])
    return False
self.lvLdapAttr.clear()
}

void dKorreio::ldap_del_entry( a0 ) {
l = self.ldap_connect()
l.delete_s(a0)
}

void dKorreio::postfix_postconf() {
import re
if self.rbPostconfN.isChecked():
    cmd = "postconf -n"
elif self.rbPostconfAll.isChecked():
    cmd = "postconf"
if self.rbPostconfD.isChecked():
    cmd = "postconf -d"
cmd = self.ssh_cmd(cmd)
self.postconf = {}
lastOpt = self.cbPostconf.currentText().ascii()
self.cbPostconf.clear()
i = 0
for config in cmd:
    if re.search("=",config):
        configlist = config.strip().split("=")
        configlist[0]=configlist[0].strip(" ")
        self.postconf[configlist[0]] = configlist[1]
        self.cbPostconf.insertItem(configlist[0])
        if configlist[0] == lastOpt:
            lastItem = i
        i = i + 1
try:
    self.cbPostconf.setCurrentItem(lastItem)
except UnboundLocalError, e:
    pass
self.postconf_changed()
}


void dKorreio::ssh_cmd(a0) {
import pexpect
import re
try:
    self.console("Executando comando remoto: "+a0)
    child = pexpect.spawn('ssh -p'+self.iSshPort.text().ascii()+' '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+' "'+a0+'"')
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        self.console("Aceitando SSH fingerprint")
        child.sendline('yes')
        child.expect('assword', timeout=2)
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    print_cmd=[]
    for line in child:
        line = re.sub("(\n|\r)","",line)
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    self.console("Erro na conexão: "+self.iSshHost.text().ascii())
except pexpect.TIMEOUT, t:
   self.console("Timeout na conexão: "+self.iSshHost.text().ascii())
return print_cmd
}


void dKorreio::postconf_changed() {
import re
value = self.postconf.get(self.cbPostconf.currentText().ascii())
value = re.sub("( )+"," ",value)
value = re.sub(", ",",",value)
value = re.sub(",",",\n",value)
value = re.sub("^ ","",value)
self.tePostconf.setText(value)
}


void dKorreio::postconf_save() {
import re
value = re.sub(",",", ",self.tePostconf.text().ascii())
value = re.sub("( )+"," ",value)
value = re.sub("\n","",value)
value = re.sub("\r","",value)
print self.ssh_cmd("postconf -e "+self.cbPostconf.currentText().ascii()+"='"+value+"'")
}


void dKorreio::postfix_open_conf() {
import re
value = self.ssh_cmd("cat "+self.iPostFileOpen.text().ascii())
values = ""
for line in value[1:]:
    values = values+line+"\n"
if re.search("^cat:",values):
    self.console("Arquivo "+self.iPostFileOpen.text().ascii()+" nao encontrado.")
    return True
self.tePostFileOpen.setText(values)
}


void dKorreio::postfix_save_conf() {
if self.tePostFileOpen.length () == 0:
    self.ssh_cmd("rm -f "+self.iPostFileOpen.text().ascii())
    return True
f = open("/tmp/korreio.tmp", 'w')
for line in self.tePostFileOpen.text().ascii():
    f.write(line)
f.close()
self.scp_cmd(self.iPostFileOpen.text().ascii())
}


void dKorreio::scp_cmd( a0 ) {
import pexpect
import re
try:
    self.console("Salvando arquivo remoto: "+a0)
    child = pexpect.spawn('scp -P'+self.iSshPort.text().ascii()+' /tmp/korreio.tmp '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+':"'+a0+'"')
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        self.console("Aceitando SSH fingerprint")
        child.sendline('yes')
        child.expect('assword', timeout=2)
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    print_cmd=[]
    for line in child:
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    self.console("Erro na conexão: "+self.iSshHost.text().ascii())
except pexpect.TIMEOUT, t:
    self.console("Timeout na conexão: "+self.iSshHost.text().ascii())

}


void dKorreio::postfix_stop() {
value = self.ssh_cmd("/etc/init.d/postfix stop")
for line in value[1:]:
   self.console(line)
}


void dKorreio::postfix_start() {
value = self.ssh_cmd("/etc/init.d/postfix start")
for line in value[1:]:
    self.console(line)
}


void dKorreio::postfix_restart() {
value = self.ssh_cmd("/etc/init.d/postfix restart")
for line in value[1:]:
    self.console(line)
}


void dKorreio::get_full_dn() {
item = self.lvLdap.currentItem()
dn = item.text(0).ascii()
while item.parent() is not None:
    dn = dn+","+item.parent().text(0).ascii()
    item = item.parent()
return dn
}


void dKorreio::imap_new_acl() {
self.cbUserACL.setCurrentText("")
self.cCyrPermL.setChecked(True)
self.cCyrPermR.setChecked(True)
self.cCyrPermS.setChecked(True)
self.cCyrPermW.setChecked(True)
self.cCyrPermI.setChecked(False)
self.cCyrPermP.setChecked(False)
self.cCyrPermC.setChecked(False)
self.cCyrPermD.setChecked(False)
self.cCyrPermA.setChecked(False)
}


void dKorreio::set_ldap_port() {
if self.cbLdapMode.currentText().ascii() == "ldap://":
    self.iLdapPort.setText("389")
else:
    self.iLdapPort.setText("636")
}




void dKorreio::view_ldap_change_widgetstack() {
selected_stack = self.cbLdapStack.currentItem()
if selected_stack < 4:
    self.wsLdap.raiseWidget(selected_stack)
    if selected_stack == 0:
        self.ldap_dn_clicked()
else:
    self.lvLdapAttr.clear()
    self.wsLdap.raiseWidget(0)
    attrs=[]
    if selected_stack == 4:
        attrs = [('objectClass','person'),('cn',''),('sn',''),('objectClass','posixAccount'),('uid',''),('uidNumber',''),('gidNumber',''),('homeDirectory','')]
    elif selected_stack == 5:
        attrs = [('objectClass','inetOrgPerson'),('cn',''),('sn','')]
    elif selected_stack == 6:
        attrs = [('objectClass','person'),('cn',''),('sn',''),('objectClass','posixAccount'),('uid',''),('uidNumber',''),('gidNumber',''),('homeDirectory',''),('objectClass','sambaSamAccount'),('sambaSID','')]
    for attr,value in attrs:
        item = QListViewItem(self.lvLdapAttr)
        item.setText(0,attr)
        item.setText(1,value)
    self.console("Por favor, selecione um dos atributos para ser o DN do novo regsitro antes de criá-lo.".encode('iso-8859-1'))
}


void dKorreio::ldap_passwd() {
import sha
from binascii import b2a_base64, a2b_base64
from random import randrange

salt = ''
for n in range(7):
    salt += chr(randrange(256))

old={}
item = self.lvLdapAttr.firstChild()
while item is not None:
    if item.text(0).ascii() == 'userPassword':
        old["userPassword"] = item.text(1).ascii()
        break
    item = item.nextSibling()
    
new={}
new["userPassword"] = "{SSHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]

self.ldap_modify(self.get_full_dn(),old,new)
}


void dKorreio::ldap_modify( a0, a1,a2 ) {
dn=a0
old=a1
new=a2
import ldap
import ldap.modlist as modlist
try:
    ldif = modlist.modifyModlist(old,new)
    l = self.ldap_connect()
    l.modify_s(dn,ldif)
    l.unbind_s()
    self.console("Registro "+dn+" alterado com sucesso.")
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False
}


void dKorreio::console( a0 ) {
import datetime
text=datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S ")+a0
self.tlConsole.setText(text)

import os.path

try:
    os.mkdir(os.path.expanduser("~/.korreio"),0700)
except OSError, e:
    pass

try:
    f = open(os.path.expanduser("~/.korreio/korreio.log"), 'w')
    f.write(text+'\n')
    f.close()
except OSError, e:
    print e
}


void dKorreio::parse_exception( a0, a1 ) {
if a0 == "LDAPError":
    if a1[0]['desc'] == "Object class violation":
        self.console(a1[0]['info'])
    elif a1[0]['desc'] == "Naming violation":
        self.console(a1[0]['info'])
    else:
        self.console(str(a1))
else:
    self.console(str(a1))

}
