# Copyright (c) 2007-2008 -  Reinaldo Carvalho <reinaldoc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.

void dKorreio::init() {

global  sha, md5, smbpasswd, pexpect, pxssh, b2a_base64, choice, letters, digits
import sha, md5, smbpasswd, pexpect, pxssh
from binascii import b2a_base64
from random import choice
from string import letters, digits

global re, datetime, sys, os, ldap, modlist, cyruslib, sievelib, threading
import re, datetime, sys, os.path, ldap, ldap.modlist as modlist, cyruslib, sievelib, threading

reload(sys)
sys.setdefaultencoding("utf-8")

}

void dKorreio::customEvent( a0 ) {
event = a0
if event.type() == "set_console_text":
    self.console(event.data())
}

void dKorreio::statusBar() {
pass
}

void dKorreio::imap_connect() {

def imap_connect_now():
    if self.cbCyrusMode.currentText().ascii() == "imaps://": ssl = True
    else: ssl = False
    self.m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),ssl)
    if self.m.ALIVE:
        if self.m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii()):
            if self.m.ADMIN is not None:
                self.console("Servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+" conectado com sucesso.")
            else:
                self.m.logout()
                self.console("Erro ao conectar no servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+". (Usuário não possui direito de administrador)".encode('iso-8859-1'))
        else:
            self.console("Erro ao conectar no servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+". (Usuário ou senha inválidos)".encode('iso-8859-1'))
    else:
        self.console("Erro ao conectar no servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+". (Conexão recusada)".encode('iso-8859-1'))

try:
    # Is connected?
    if self.m.m.isadmin():
        # Server changed?
        if self.imap_connect_active_mode != self.cbCyrusMode.currentText().ascii() or self.imap_connect_active_host != self.iCyrusHost.text().ascii() or self.imap_connect_active_port != self.iCyrusPort.text().ascii() or self.imap_connect_active_user != self.iCyrusUser.text().ascii():
            imap_connect_now()
    else:
        imap_connect_now()
except AttributeError, e:
    # First connection
    imap_connect_now()

self.imap_connect_active_mode = self.cbCyrusMode.currentText().ascii()
self.imap_connect_active_host = self.iCyrusHost.text().ascii()
self.imap_connect_active_port = self.iCyrusPort.text().ascii()
self.imap_connect_active_user = self.iCyrusUser.text().ascii()

self.tConfShowImapSep.setText("Imap delimiter: "+self.m.SEP)

return self.m
}

void dKorreio::imap_search() {

# Save current selection
oldmailbox=['','']
if self.lvCyrus.childCount() > 1:
    item=self.lvCyrus.currentItem()
    oldmailbox[0]=item.text(0).ascii()
    while item.parent() is not None:
        oldmailbox[0]=item.parent().text(0).ascii()
        item=item.parent()

if self.lvCyrusGlobal.childCount() > 1:
    item=self.lvCyrusGlobal.currentItem()
    oldmailbox[1]=item.text(0).ascii()
    while item.parent() is not None:
        oldmailbox[1]=item.parent().text(0).ascii()
        item=item.parent()

self.lvCyrus.clear()
self.lvCyrusGlobal.clear()
self.iImapMailbox.clear()
self.cbUserACL.clear()
self.iQuota.clear()
self.iQuotaUsed.clear()
self.iAnnotationExpire.clear()

# Imap query
imap = self.imap_connect()
if self.iImapSearch.text().ascii():
    pattern = "user"+imap.SEP+self.iImapSearch.text().ascii()+"*"
else:
    pattern = "*"
mailboxes = imap.lm(pattern)

def create_nodes(dn):
    dnlist = dn.split(imap.SEP)
    dnnode = imap.SEP.join(dnlist[:-1])
    if not self.tree.get(dnnode):
        create_nodes(dnnode)
    self.tree[dn] = QListViewItem(self.tree.get(dnnode))
    self.tree[dn].setText(0,dnlist[-1])

try:
    self.tree = {}
    for id in mailboxes:
        idlist = id.split(imap.SEP)
        if re.search("^user",id):
            id = imap.SEP.join(idlist[1:])
            if len(idlist) == 2:
                self.tree[id] = QListViewItem(self.lvCyrus)
                self.tree[id].setText(0, id)
                continue
        elif len(idlist) == 1:
            self.tree[id] = QListViewItem(self.lvCyrusGlobal)
            self.tree[id].setText(0, idlist[0])
            continue
        idlist = id.split(imap.SEP)
        if not self.tree.get(id):
            create_nodes(id)
        else:
            print "Erro obtendo "+ idlist[-1]
except KeyError, e:
    pass

try:
    def selectItem(item):
        self.lvCyrus.setCurrentItem(item)
        item.setOpen(True)
        item.setSelected(True)

    item=self.lvCyrus.firstChild()
    if oldmailbox[0] == '':
        selectItem(item)
    else:
        while item is not None:
            if item.text(0).ascii() == oldmailbox[0]:
                selectItem(item)
                self.lvCyrus.scrollBy(0,item.itemPos())
                break
            item=item.nextSibling()
        if item is None:
            selectItem(self.lvCyrus.firstChild())
except AttributeError, e:
    pass

try:
    def selectItem(item):
        self.lvCyrusGlobal.setCurrentItem(item)
        item.setOpen(True)
        item.setSelected(True)

    item=self.lvCyrusGlobal.firstChild()
    if oldmailbox[1] == '':
        selectItem(item)
    else:
        item=self.lvCyrusGlobal.firstChild()
        while item is not None:
            if item.text(0).ascii() == oldmailbox[1]:
                selectItem(item)
                self.lvCyrusGlobal.scrollBy(0,item.itemPos())
                break
            item=item.nextSibling()
        if item is None:
            selectItem(self.lvCyrusGlobal.firstChild())

except AttributeError, e:
    pass

if self.lvCyrus.childCount() > 0:
    self.action_imap_mailbox_clicked()
}

void dKorreio::imap_create_mailbox() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Informe a mailbox para ser criada.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""
if self.iCyrusPart.text().ascii():
    if imap.cm(mbtype+self.iImapMailbox.text().ascii(),self.iCyrusPart.text().ascii()):
        self.console("Mailbox "+self.iImapMailbox.text().ascii()+" criada com sucesso.")
    else:
        self.console("Erro ao criar Mailbox "+self.iImapMailbox.text().ascii()+".")
        return False
else:
    if imap.cm(mbtype+self.iImapMailbox.text().ascii()):
        self.console("Mailbox "+self.iImapMailbox.text().ascii()+" criada com sucesso.")
    else:
        self.console("Erro ao criar Mailbox "+self.iImapMailbox.text().ascii()+".")
        return False

if self.iConfImapQuota.text().ascii():
    imap.sq(mbtype+self.iImapMailbox.text().ascii(),self.iConfImapQuota.text().ascii())

if self.cbImapMailbox.currentItem() == 0:
    if len(self.iImapMailbox.text().ascii().split(imap.SEP)) == 1:
        folders=self.confDict.get("imap.dflfolders").split(",")
        for folder in folders:
            if len(folder) == 0: continue
            imap.cm("user"+imap.SEP+self.iImapMailbox.text().ascii()+imap.SEP+folder)
            if folder == self.iConfImapACLp.text().ascii():
                imap.sam("user"+imap.SEP+self.iImapMailbox.text().ascii()+imap.SEP+folder, "anyone", "p")
            if folder == self.iConfImapExpire.text().ascii():
                imap.setannotation("user"+imap.SEP+self.iImapMailbox.text().ascii()+imap.SEP+folder,"/vendor/cmu/cyrus-imapd/expire",self.iConfImapExpireDays.text().ascii())

self.imap_search()

if self.cbImapMailbox.currentItem() == 0:
    self.action_imap_mailbox_clicked()
    self.lvCyrus.currentItem().setSelected(True)
else:
    self.action_imap_gmailbox_clicked()
    self.lvCyrusGlobal.currentItem().setSelected(True)
}

void dKorreio::imap_delete_mailbox() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para exclusão.".encode('iso-8859-1'))
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""

def delete_mailbox(mailbox):
    imap.sam(mailbox, self.iCyrusUser.text().ascii(), "c")
    if imap.dm(mailbox):
        self.console("Mailbox %s removida com sucesso." % mailbox)
    else:
        self.console("Erro ao remover Mailbox %s." % mailbox)
        raise "Error deleting mailbox %s" % mailbox

if len(self.iImapMailbox.text().ascii().split(imap.SEP)) == 1:
    delete_mailbox(mbtype+self.iImapMailbox.text().ascii())
else:
    # Cyrus is not recursive for subfolders
    for mailbox in imap.lm(mbtype+self.iImapMailbox.text().ascii()+imap.SEP+"*"):
        delete_mailbox(mailbox)
    delete_mailbox(mbtype+self.iImapMailbox.text().ascii())

if self.cbImapMailbox.currentItem() == 0:
    if self.lvCyrus.currentItem().parent() is None:
        self.lvCyrus.takeItem(self.lvCyrus.currentItem())
    else:
        self.lvCyrus.currentItem().parent().takeItem(self.lvCyrus.currentItem())
    self.lvCyrus.currentItem().setSelected(True)
    self.action_imap_mailbox_clicked()
else:
    if self.lvCyrusGlobal.currentItem().parent() is None:
        self.lvCyrusGlobal.takeItem(self.lvCyrusGlobal.currentItem())
    else:
        self.lvCyrusGlobal.currentItem().parent().takeItem(self.lvCyrusGlobal.currentItem())
    self.lvCyrusGlobal.currentItem().setSelected(True)
    self.action_imap_gmailbox_clicked()

}

void dKorreio::imap_set_quota() {
if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplicar a quota.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""
if imap.sq(mbtype+self.iImapMailbox.text().ascii(),self.iQuota.text().ascii()):
    self.console("Quota de "+self.iQuota.text().ascii()+"Kbytes configurada com sucesso para o usuário ".encode('iso-8859-1')+self.iImapMailbox.text().ascii()+".")
else:
    self.console("Erro ao configurar quota para o usuário ".encode('iso-8859-1')+self.iImapMailbox.text().ascii()+".")
}

void dKorreio::imap_set_acl() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplicar a ACL.")
    return True

perm=""
if self.cCyrPermL.isChecked():
    perm="l"
if self.cCyrPermR.isChecked():
    perm=perm+"r"
if self.cCyrPermS.isChecked():
    perm=perm+"s"
if self.cCyrPermW.isChecked():
    perm=perm+"w"
if self.cCyrPermI.isChecked():
    perm=perm+"i"
if self.cCyrPermP.isChecked():
    perm=perm+"p"
if self.cCyrPermC.isChecked():
    perm=perm+"c"
if self.cCyrPermD.isChecked():
    perm=perm+"d"
if self.cCyrPermA.isChecked():
    perm=perm+"a"

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""
if imap.sam(mbtype+self.iImapMailbox.text().ascii(), self.cbUserACL.currentText().ascii(), perm):
    self.console("Mailbox "+self.iImapMailbox.text().ascii()+": ACL "+perm+" aplicada para usuário ".encode('iso-8859-1')+self.cbUserACL.currentText().ascii())
else:
    self.console("Mailbox "+self.iImapMailbox.text().ascii()+": erro ao aplicar ACL "+perm+" para usuário "+self.cbUserACL.currentText().ascii())
}

void dKorreio::imap_new_acl() {
self.cbUserACL.setCurrentText("")
self.cbUserACL.setFocus()
self.cCyrPermL.setChecked(True)
self.cCyrPermR.setChecked(True)
self.cCyrPermS.setChecked(True)
self.cCyrPermW.setChecked(True)
self.cCyrPermI.setChecked(False)
self.cCyrPermP.setChecked(False)
self.cCyrPermC.setChecked(False)
self.cCyrPermD.setChecked(False)
self.cCyrPermA.setChecked(False)
}

void dKorreio::imap_reconstruct() {
if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para reconstruir.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""
if imap.reconstruct(mbtype+self.iImapMailbox.text().ascii()):
    self.console("Mailbox "+self.iImapMailbox.text().ascii()+" esta sendo reconstruida.")
else:
    self.console("Erro ao reconstruir "+self.iImapMailbox.text().ascii()+".")
}

void dKorreio::imap_set_annotation_expire() {
if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplica o auto-expire.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""

if imap.setannotation(mbtype+self.iImapMailbox.text().ascii(),"/vendor/cmu/cyrus-imapd/expire",self.iAnnotationExpire.text().ascii()):
    self.console("Auto-expire de "+self.iAnnotationExpire.text().ascii()+" dias configurado com sucesso para mailbox ".encode('iso-8859-1')+self.iImapMailbox.text().ascii()+".")
else:
    self.console("Erro ao configurar auto-expirea para mailbox ".encode('iso-8859-1')+self.iImapMailbox.text().ascii()+".")

}

void dKorreio::imap_partition_search() {

self.lvImapPartition.clear()
self.lvImapPartitionGlobal.clear()
self.cbImapPartition.clear()

partitions = {}

imap = self.imap_connect()

mailboxes = imap.getannotation("user"+imap.SEP+self.iImapPartitionSearch.text().ascii()+"%","/vendor/cmu/cyrus-imapd/partition")
if mailboxes[0] == True:
    for mailbox in mailboxes[1]:
        idlist = mailbox.split(imap.SEP)
        item = QListViewItem(self.lvImapPartition)
        item.setText(0, imap.SEP.join(idlist[1:]))
        item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
        partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""

mailboxes = imap.getannotation(self.iImapPartitionSearch.text().ascii()+"%","/vendor/cmu/cyrus-imapd/partition")
if mailboxes[0] == True:
    for mailbox in mailboxes[1]:
        item = QListViewItem(self.lvImapPartitionGlobal)
        item.setText(0, mailbox)
        item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
        partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""

for i in partitions:
    self.cbImapPartition.insertItem(i)
}

void dKorreio::imap_partition_move() {

imap = self.imap_connect()
item = self.lvImapPartition.firstChild()
while item is not None:
    if item.isSelected():
        self.console("Movendo "+item.text(0).ascii()+" para imap-partition: "+self.cbImapPartition.currentText().ascii())
        mailbox="user"+imap.SEP+item.text(0).ascii()
        imap.rename(mailbox, mailbox, self.cbImapPartition.currentText().ascii())
    item=item.nextSibling()

item = self.lvImapPartitionGlobal.firstChild()
while item is not None:
    if item.isSelected():
        self.console("Movendo "+item.text(0).ascii()+" para imap-partition: "+self.cbImapPartition.currentText().ascii())
        imap.rename(item.text(0).ascii(), item.text(0).ascii(), self.cbImapPartition.currentText().ascii())
    item=item.nextSibling()

self.imap_partition_search()

}

void dKorreio::imap_rename( a0, a1 ) {

currentItem = a0

imap = self.imap_connect()
item = a0
new = item.text(0).ascii()
while item.parent() is not None:
    item=item.parent()        
    new = item.text(0).ascii()+imap.SEP+new

if self.mailboxold != new:
    if len(imap.lm(a1+new)) > 0:
        self.console("Mailbox "+new+" já existe.".encode('iso-8859-1'))
        currentItem.setText(0,self.mailboxold.split(m.SEP)[-1])
        return True
    if imap.rename(a1+self.mailboxold,a1+new):
        self.console("Mailbox "+self.mailboxold+" renomeada com sucesso para "+new+".")
    else:
        self.console("Não foi possível renomear "+self.mailboxold+" para "+new+".")
        currentItem.setText(0,self.mailboxold.split(imap.SEP)[-1])
}

void dKorreio::imap_rename_mailbox() {
    self.imap_rename(self.lvCyrus.currentItem(),"user"+self.m.SEP)
}

void dKorreio::imap_gmailbox_rename() {
    self.imap_rename(self.lvCyrusGlobal.currentItem(),"")
}

void dKorreio::save_config() {

try:
    try:
        self.confDict
    except AttributeError, e:
        self.confDict = {}

    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')

#
# LDAP Connection
#

    if not self.iLdapConnection.text().ascii():
        self.console("Preencha o nome da conexão LDAP.")
    else:
        i=0
        while self.confDict.get("ldap"+str(i)+".name"):
            if self.confDict.get("ldap"+str(i)+".name") == self.iLdapConnection.text().ascii():
                break
            i=i+1
        tmpLast=i
        f.write('ldap.last=ldap'+str(i)+'\n')

        self.confDict["ldap"+str(i)+".name"]=self.iLdapConnection.text().ascii()
        self.confDict["ldap"+str(i)+".mode"]=self.cbLdapMode.currentText().ascii()
        self.confDict["ldap"+str(i)+".host"]=self.iLdapHost.text().ascii()
        self.confDict["ldap"+str(i)+".port"]=self.iLdapPort.text().ascii()
        self.confDict["ldap"+str(i)+".basedn"]=self.cbLdapBaseDN.currentText().ascii()
        self.confDict["ldap"+str(i)+".user"]=self.iLdapUser.text().ascii()
        self.confDict["ldap"+str(i)+".pass"]=self.iLdapPass.text().ascii()
        self.confDict["ldap"+str(i)+".ref"]=str(self.cLdapRef.isChecked())
        self.confDict["ldap"+str(i)+".cert"]=str(self.cLdapCert.isChecked())

        i=0
        self.cbLdapConnection.clear()
        while self.confDict.get("ldap"+str(i)+".name"):
            self.cbLdapConnection.insertItem(self.confDict.get("ldap"+str(i)+".name"))
            for j in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                opt='ldap'+str(i)+'.'+j
                f.write(opt+"="+self.confDict.get(opt)+'\n')
            i=i+1
        self.cbLdapConnection.setCurrentItem(tmpLast)

#
# IMAP Connection
#

    if not self.iCyrusConnection.text().ascii():
        self.console("Preencha o nome da conexão IMAP.")
    else:
        i=0
        while self.confDict.get("imap"+str(i)+".name"):
            if self.confDict.get("imap"+str(i)+".name") == self.iCyrusConnection.text().ascii():
                break
            i=i+1
        tmpLast=i
        f.write('imap.last=imap'+str(i)+'\n')

        self.confDict["imap"+str(i)+".name"]=self.iCyrusConnection.text().ascii()
        self.confDict["imap"+str(i)+".mode"]=self.cbCyrusMode.currentText().ascii()
        self.confDict["imap"+str(i)+".host"]=self.iCyrusHost.text().ascii()
        self.confDict["imap"+str(i)+".port"]=self.iCyrusPort.text().ascii()
        self.confDict["imap"+str(i)+".sieport"]=self.iCyrusSievePort.text().ascii()
        self.confDict["imap"+str(i)+".user"]=self.iCyrusUser.text().ascii()
        self.confDict["imap"+str(i)+".pass"]=self.iCyrusPass.text().ascii()
        self.confDict["imap"+str(i)+".part"]=self.iCyrusPart.text().ascii()

        i=0
        self.cbCyrusConnection.clear()
        while self.confDict.get("imap"+str(i)+".name"):
            self.cbCyrusConnection.insertItem(self.confDict.get("imap"+str(i)+".name"))
            for j in ['name','mode','host','port','sieport','user','pass','part']:
                opt='imap'+str(i)+'.'+j
                f.write(opt+"="+self.confDict.get(opt)+'\n')
            i=i+1
        self.cbCyrusConnection.setCurrentItem(tmpLast)

#
# SSH Connection
#

    if not self.iSSHConnection.text().ascii():
        self.console("Preencha o nome da conexão SSH.")
    else:
        i=0
        while self.confDict.get("ssh"+str(i)+".name"):
            if self.confDict.get("ssh"+str(i)+".name") == self.iSSHConnection.text().ascii():
                break
            i=i+1
        tmpLast=i
        f.write('ssh.last=ssh'+str(i)+'\n')

        self.confDict["ssh"+str(i)+".name"]=self.iSSHConnection.text().ascii()
        self.confDict["ssh"+str(i)+".host"]=self.iSshHost.text().ascii()
        self.confDict["ssh"+str(i)+".port"]=self.iSshPort.text().ascii()
        self.confDict["ssh"+str(i)+".user"]=self.iSshUser.text().ascii()
        self.confDict["ssh"+str(i)+".pass"]=self.iSshPass.text().ascii()

        i=0
        self.cbSSHConnection.clear()
        while self.confDict.get("ssh"+str(i)+".name"):
            self.cbSSHConnection.insertItem(self.confDict.get("ssh"+str(i)+".name"))
            for j in ['name','host','port','user','pass']:
                opt='ssh'+str(i)+'.'+j
                f.write(opt+"="+self.confDict.get(opt)+'\n')
            i=i+1
        self.cbSSHConnection.setCurrentItem(tmpLast)

#
# IMAP Prefs
#

    folders=[]
    for folder in range(0,self.lbConfImapFolders.count()):
        folders.extend([self.lbConfImapFolders.item(folder).text().ascii()])
    f.write('imap.dflfolders='+",".join(folders)+'\n')
    f.write('imap.dflquota='+self.iConfImapQuota.text().ascii()+'\n')
    f.write('imap.dflexpirefolder='+self.iConfImapExpire.text().ascii()+'\n')
    f.write('imap.dflexpiredays='+self.iConfImapExpireDays.text().ascii()+'\n')
    f.write('imap.addaclp='+self.iConfImapACLp.text().ascii()+'\n')


#
# LDAP Prefs
#
    item=self.lvConfLdap.firstChild()
    item=item.firstChild()
    i=0
    while item is not None:
        subitem=item.firstChild()
        while subitem is not None:
            if subitem.text(1).ascii() is None: value=""
            else: value=subitem.text(1).ascii()
            f.write("ldap.objectclass"+str(i)+"="+item.text(0).ascii()+"."+subitem.text(0).ascii()+"."+value+'\n')
            subitem=subitem.nextSibling()
            i=i+1
        item=item.nextSibling()
#
# End
#
    f.close()
    os.chmod(os.path.expanduser("~/.korreio/korreio.conf"), 0600)
    self.console("Configuração salva.".encode('iso-8859-1'))
except OSError, e:
    self.parse_exception("OSError", e)

}


void dKorreio::load_config() {

try:
    os.mkdir(os.path.expanduser("~/.korreio"),0700)
except OSError, e:
    if e[0] != 17:
        self.console("Error creating ~/.korreio "+e)
        print "Error creating ~/.korreio "+e
        return False

try:
    if not os.path.isfile(os.path.expanduser("~/.korreio/korreio.conf")):
        self.save_config()
except OSError, e:
    pass

try:
    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
    conf=f.read()
    f.close()
except IOError, e:
    return True

confList = conf.split("\n")
confList.pop()
self.confDict = {}

for line in confList:
   key=line.split("=")
   self.confDict[key[0]] = "=".join(key[1:])

#
# LDAP Connection
#

i=0
self.cbLdapConnection.clear()
while self.confDict.get("ldap"+str(i)+".name"):
    self.cbLdapConnection.insertItem(self.confDict.get("ldap"+str(i)+".name"))
    i=i+1

lastConn=self.confDict.get("ldap.last")
if lastConn:
    self.cbLdapConnection.setCurrentText(self.confDict.get(lastConn+".name"))
    self.iLdapConnection.setText(self.confDict.get(lastConn+".name"))
    self.cbLdapMode.setCurrentText(self.confDict.get(lastConn+".mode"))
    self.iLdapHost.setText(self.confDict.get(lastConn+".host"))
    self.iLdapPort.setText(self.confDict.get(lastConn+".port"))
    self.cbLdapBaseDN.clear()
    self.cbLdapBaseDN.insertItem(self.confDict.get(lastConn+".basedn"))
    self.iLdapUser.setText(self.confDict.get(lastConn+".user"))
    self.iLdapPass.setText(self.confDict.get(lastConn+".pass"))
    if self.confDict.get(lastConn+".ref") == "True":
        self.cLdapRef.setChecked(True)
    if self.confDict.get(lastConn+".cert") == "True":
        self.cLdapCert.setChecked(True)

#
# IMAP Connection
#

i=0
self.cbCyrusConnection.clear()
while self.confDict.get("imap"+str(i)+".name"):
    self.cbCyrusConnection.insertItem(self.confDict.get("imap"+str(i)+".name"))
    i=i+1

lastConn=self.confDict.get("imap.last")
if lastConn:
    self.cbCyrusConnection.setCurrentText(self.confDict.get(lastConn+".name"))
    self.iCyrusConnection.setText(self.confDict.get(lastConn+".name"))
    self.cbCyrusMode.setCurrentText(self.confDict.get(lastConn+".mode"))
    self.iCyrusHost.setText(self.confDict.get(lastConn+".host"))
    self.iCyrusPort.setText(self.confDict.get(lastConn+".port"))
    self.iCyrusSievePort.setText(self.confDict.get(lastConn+".sieport"))
    self.iCyrusUser.setText(self.confDict.get(lastConn+".user"))
    self.iCyrusPass.setText(self.confDict.get(lastConn+".pass"))
    self.iCyrusPart.setText(self.confDict.get(lastConn+".part"))

#
# SSH Connection
#

i=0
self.cbSSHConnection.clear()
while self.confDict.get("ssh"+str(i)+".name"):
    self.cbSSHConnection.insertItem(self.confDict.get("ssh"+str(i)+".name"))
    i=i+1

lastConn=self.confDict.get("ssh.last")
if lastConn:
    self.cbSSHConnection.setCurrentText(self.confDict.get(lastConn+".name"))
    self.iSSHConnection.setText(self.confDict.get(lastConn+".name"))
    self.iSshHost.setText(self.confDict.get(lastConn+".host"))
    self.iSshPort.setText(self.confDict.get(lastConn+".port"))
    self.iSshUser.setText(self.confDict.get(lastConn+".user"))
    self.iSshPass.setText(self.confDict.get(lastConn+".pass"))

#
# IMAP Prefs
#

self.lbConfImapFolders.clear()
for folder in self.confDict.get("imap.dflfolders").split(","):
    self.lbConfImapFolders.insertItem(folder)
self.iConfImapQuota.setText(self.confDict.get("imap.dflquota"))
self.iConfImapExpire.setText(self.confDict.get("imap.dflexpirefolder"))
self.iConfImapExpireDays.setText(self.confDict.get("imap.dflexpiredays"))
self.iConfImapACLp.setText(self.confDict.get("imap.addaclp"))

#
# LDAP Prefs
#

self.lvConfLdap.clear()
item = QListViewItem(self.lvConfLdap)
item.setText(0,'objectClass')
item.setOpen(True)
objnodes = {}
i=0
while self.confDict.get("ldap.objectclass"+str(i)):
    objclass = self.confDict.get("ldap.objectclass"+str(i)).split(".")
    if not objnodes.get(objclass[0]):
        objnodes[objclass[0]] = QListViewItem(item)
        objnodes[objclass[0]].setText(0,objclass[0])
    subitem=QListViewItem(objnodes[objclass[0]])
    subitem.setText(0,objclass[1])
    subitem.setText(1,".".join(objclass[2:]))
    i=i+1

}

void dKorreio::action_module_changed() {
menu=str(self.wKorreio.tabLabel(self.wKorreio.currentPage()))
if menu == "LDAP Manager":
    try:
        self.loadconfig
    except:
        self.loadconfig = 1
        self.load_config()
elif menu == "Configurações":
    self.action_config_change_widgetstack()
}


void dKorreio::action_imap_mailbox_clicked() {
self.cbImapMailbox.setCurrentItem(0)
self.action_imap_mailbox_get_info(self.lvCyrus.currentItem(),"user")
}

void dKorreio::action_imap_gmailbox_clicked() {
self.cbImapMailbox.setCurrentItem(1)
self.action_imap_mailbox_get_info(self.lvCyrusGlobal.currentItem(),"")
}

void dKorreio::action_imap_mailbox_get_info( a0, a1 ) {

imap = self.imap_connect()
item = a0
if a1:
    mbtype = a1+imap.SEP
else:
    mbtype = a1

mailbox=item.text(0).ascii()
while item.parent() is not None:
    mailbox=item.parent().text(0).ascii()+imap.SEP+mailbox
    item=item.parent()

self.iImapMailbox.setText(mailbox)

if len(mailbox.split(imap.SEP)) == 1:
    self.pSetQuota.setEnabled(True)
else:
    self.pSetQuota.setEnabled(False)

quota = imap.lq(mbtype+mailbox.split(imap.SEP)[0])
self.iQuotaUsed.setText("%s" % quota[0])
self.iQuota.setText("%s" % quota[1])

self.permissions = imap.lam(mbtype+mailbox)
self.cbUserACL.clear()
i=0
for acl in self.permissions:
    self.cbUserACL.insertItem(acl)
    i=i+1
self.tlImapACl.setText("{"+str(i)+"}")
self.action_imap_show_permissions()

expire = imap.getannotation(mbtype+mailbox,"/vendor/cmu/cyrus-imapd/expire")
if expire[0]:
    self.iAnnotationExpire.setText(expire[1][mbtype+mailbox]["/vendor/cmu/cyrus-imapd/expire"])
else:
    self.iAnnotationExpire.setText("")

}

void dKorreio::action_imap_show_permissions() {

mailbox_perm = self.permissions[self.cbUserACL.currentText().ascii()]
if re.search("l",mailbox_perm): self.cCyrPermL.setChecked(True)
else: self.cCyrPermL.setChecked(False)
if re.search("r",mailbox_perm): self.cCyrPermR.setChecked(True)
else: self.cCyrPermR.setChecked(False)
if re.search("s",mailbox_perm): self.cCyrPermS.setChecked(True)
else: self.cCyrPermS.setChecked(False)
if re.search("w",mailbox_perm): self.cCyrPermW.setChecked(True)
else: self.cCyrPermW.setChecked(False)
if re.search("i",mailbox_perm): self.cCyrPermI.setChecked(True)
else: self.cCyrPermI.setChecked(False)
if re.search("p",mailbox_perm): self.cCyrPermP.setChecked(True)
else: self.cCyrPermP.setChecked(False)
if re.search("c",mailbox_perm): self.cCyrPermC.setChecked(True)
else: self.cCyrPermC.setChecked(False)
if re.search("d",mailbox_perm): self.cCyrPermD.setChecked(True)
else: self.cCyrPermD.setChecked(False)
if re.search("a",mailbox_perm): self.cCyrPermA.setChecked(True)
else: self.cCyrPermA.setChecked(False)
}

void dKorreio::get_ldap_basedn() {
try:
    if self.cLdapCert.isChecked():
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
    l = ldap.initialize(self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
    if self.cLdapRef.isChecked():
        ldap.set_option(ldap.OPT_REFERRALS,1)
    else:
        ldap.set_option(ldap.OPT_REFERRALS,0)
    l.protocol_version = ldap.VERSION3
    if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
        l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
    else:
        l.simple_bind()
    searchScope = ldap.SCOPE_BASE
    searchFilter = "objectclass=*"
    retrieveAttributes = ["namingContexts"]
    ldap_result_id = l.search("", searchScope, searchFilter, retrieveAttributes)
    self.cbLdapBaseDN.clear()
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if (result_data == []):
            break
        else:
            if result_type == ldap.RES_SEARCH_ENTRY:
                for j in result_data:
                     for root in j[1]["namingContexts"]:
                         self.cbLdapBaseDN.insertItem(root)
                         if not self.iLdapUser.text().ascii():
                             self.iLdapUser.setText("cn=admin,"+root)
    if self.cbLdapBaseDN.count() > 1:
            self.cbLdapBaseDN.popup()
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
}


void dKorreio::action_imap_set_port( a0 ) {
print a0
if self.cbCyrusMode.currentText().ascii() == "imap://":
    self.iCyrusPort.setText("143")
else:
    self.iCyrusPort.setText("993")
}

void dKorreio::ldap_connect() {
try:
    if self.cLdapCert.isChecked():
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
    else:
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,2)
    if self.cLdapRef.isChecked():
        ldap.set_option(ldap.OPT_REFERRALS,1)
    else:
        ldap.set_option(ldap.OPT_REFERRALS,0)
    l = ldap.initialize(self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
    l.protocol_version = ldap.VERSION3
    l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
    return l
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
}

void dKorreio::ldap_search() {

def create_nodes(dn):
    dnlist = dn.split(",")
    dnnode = ",".join(dnlist[1:])
    if not self.nodes.get(dnnode):
        if not dnnode == dnnode.split(",")[0]:
            create_nodes(dnnode)
        else:
            print "Erro fatal: servidor ldap retonou basedn diferente da consulta."
            print "            O servidor exige basedn case sensitive. Verifique."
    self.nodes[dn] = QListViewItem(self.nodes.get(dnnode))
    self.nodes[dn].setText(0,dnlist[0])

if self.cbLdapFilter.count() == 10:
    self.cbLdapFilter.removeItem(4)
self.cbLdapFilter.insertItem(self.cbLdapFilter.currentText().ascii())

basedn = self.cbLdapBaseDN.currentText().ascii()
try:
    olddn = self.ldap_get_dn()
except AttributeError, e:
    olddn = basedn

self.lvLdap.clear()
self.nodes = {}
self.nodes[basedn] = QListViewItem(self.lvLdap)
self.nodes[basedn].setText(0,basedn)
self.nodes[basedn].setOpen(True)

if not self.cbLdapFilter.currentText().ascii():
    filter = "(objectClass=*)"
else:
    filter = "("+str(self.__tr(self.cbLdapFilter.currentText().ascii()))+")"
self.ldap_attr = self.ldap_result(filter)

try:
    basednattrs = self.ldap_attr.get(basedn)
    del self.ldap_attr[basedn]
except KeyError, e:
    pass

for dn in self.ldap_attr:
    if not self.nodes.get(dn):
        create_nodes(dn)
try:
    self.ldap_attr[basedn] = basednattrs
except KeyError, e:
    pass

try:
    self.lvLdap.setCurrentItem(self.nodes[olddn])
    self.lvLdap.currentItem().setSelected(True)
except KeyError, e:
    pass

while olddn != basedn:
    try:
        self.nodes[olddn].setOpen(True)
    except KeyError, e:
        pass
    olddn = ",".join(olddn.split(",")[1:])
    if len(olddn) == 0:
        break

self.lvLdap.scrollBy(0,self.lvLdap.currentItem().itemPos())
self.ldap_dn_clicked()

}

void dKorreio::ldap_result( a0 ) {
try:
    l = self.ldap_connect()
    searchScope = ldap.SCOPE_SUBTREE
    searchFilter = a0
    retrieveAttributes = None
    ldap_result_id = l.search(self.cbLdapBaseDN.currentText().ascii(), searchScope, searchFilter, retrieveAttributes)
    ldap_result = {}
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if result_type == ldap.RES_SEARCH_RESULT:
            break
        elif result_type == ldap.RES_SEARCH_ENTRY:
            ldap_result[result_data[0][0].encode('iso-8859-1')] = result_data[0][1]
        elif result_type == ldap.RES_SEARCH_REFERENCE:
            ldap_result[result_data[0][1][0].split("/")[3].split("?")[0]] = {'ref': [result_data[0][1][0]]}
        else:
            print "Result type not implemented. "+str(result_type)

    return ldap_result
except ldap.LDAPError, e:
    if e[0]["desc"] == "Size limit exceeded":
        self.console("Quantidade de registros excedido. Utilize um filtro mais restritivo.")
        return ldap_result
    else:
        self.parse_exception("LDAPError", e)
}

void dKorreio::ldap_dn_clicked() {
self.lvLdapAttr.clear()
self.wsLdap.raiseWidget(0)
self.cbLdapStack.setCurrentItem(0)
dn = self.ldap_get_dn()
try:
    for attribute,values in self.ldap_attr.get(dn).items():
        for value in values:
            item = QListViewItem(self.lvLdapAttr)
            item.setText(0,attribute)
            try:
                item.setText(1,value.encode('iso-8859-1'))
            except UnicodeDecodeError, e:
                item.setText(1,value)
except AttributeError, e:
    pass
item = self.lvLdap.currentItem()
if item.parent() is None or item.childCount() != 0:
    self.pLdapDelete.setEnabled(False)
else:
    self.pLdapDelete.setEnabled(True)

if self.lvLdapAttr.childCount() > 0:
    self.lvLdapAttr.setCurrentItem(self.lvLdapAttr.firstChild())
    self.lvLdapAttr.currentItem().setSelected(True)
}

void dKorreio::ldap_dn_doubleclicked() {
if self.lvLdap.currentItem().childCount() == 0:
    self.rdnold = str(self.__tr(self.ldap_get_dn()))
    self.lvLdap.currentItem().setRenameEnabled(0,True)
    self.lvLdap.currentItem().startRename(0)
}

void dKorreio::ldap_insert_user() {

cn=str(self.__tr(self.iLdapCn.text().ascii()))
dn = str(self.__tr("cn="+self.iLdapCn.text().ascii()+","+self.ldap_get_dn()))
attrs = {}
attrs['objectclass'] = ['inetOrgPerson']
attrs['cn'] = cn
attrs['sn'] = cn.split(" ")[-1]
emails = self.iLdapMail.text().ascii().split(",")
attrs['mail'] = emails[0]
if len(emails) > 0:
    attrs['l'] = emails[1:]
m = md5.new(self.iLdapUserP.text().ascii())
attrs['userPassword'] = '{md5}'+base64.encodestring(m.digest())
self.ldap_add(dn,attrs)
self.ldap_search()
self.wsLdap.raiseWidget(1)
}


void dKorreio::ldap_add( a0, a1 ) {
# a0 = DN, a1 = attrs
try:
    ldif = modlist.addModlist(a1)
    l = self.ldap_connect()
    l.add_s(a0,ldif)
    l.unbind_s()
    self.console("Registro "+a0.encode('iso-8859-1')+" adicionado com sucesso.")
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False
}

void dKorreio::action_ldap_modify() {
stack = self.cbLdapStack.currentItem()
if stack == 0:
    old = {}
    for attribute,values in self.ldap_attr.get(self.ldap_get_dn()).items():
        if old.get(attribute):
           old[attribute].extend(values)
        else:
           old[attribute] = values

    new = {}
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if new.get(item.text(0).ascii()):
            new[item.text(0).ascii()].extend([str(self.__tr(item.text(1).ascii()))])
        else:
            new[item.text(0).ascii()] = [str(self.__tr(item.text(1).ascii()))]
        item = item.nextSibling()

    if not self.ldap_modify(self.ldap_get_dn(),old,new):
        return False
else:
    new = {}
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if item.isSelected():
            dn=item.text(0).ascii()+"="+item.text(1).ascii()+","+self.ldap_get_dn()
        if new.get(item.text(0).ascii()):
            new[item.text(0).ascii()].extend([item.text(1).ascii()])
        else:
            new[item.text(0).ascii()] = [item.text(1).ascii()]
        item = item.nextSibling()
    try:
        if not self.ldap_add(dn,new):
            return False
    except UnboundLocalError, e:
        self.console("Selecione o DN entre os atributos.")
        return False

self.ldap_search()
}

void dKorreio::ldap_insert_ou() {
dn = "ou="+self.iLdapOu.text().ascii()+","+self.ldap_get_dn()
attrs = {}
attrs['objectclass'] = ['organizationalUnit']
attrs['ou'] = self.iLdapOu.text().ascii()
self.ldap_add(dn,attrs)
self.ldap_search()
self.wsLdap.raiseWidget(2)
}


void dKorreio::ldap_remove_entry() {
dn = str(self.__tr(self.ldap_get_dn()))
if dn is not None:
    if self.ldap_del_entry(dn):
        self.console("Registro "+dn.encode('iso-8859-1')+" removido com sucesso.")
        self.lvLdap.currentItem().parent().takeItem(self.lvLdap.currentItem())
        self.lvLdap.currentItem().setSelected(True)
        self.ldap_dn_clicked()
}

void dKorreio::ldap_remove_attr() {
self.lvLdapAttr.takeItem(self.lvLdapAttr.currentItem())
try:
    self.lvLdapAttr.currentItem().setSelected(True)
except AttributeError, e:
    pass
}

void dKorreio::ldap_rename_attr_value() {
if not self.lvLdap.currentItem().text(0).ascii() == "=".join([self.lvLdapAttr.currentItem().text(0).ascii(),self.lvLdapAttr.currentItem().text(1).ascii()]):
    self.lvLdapAttr.currentItem().setRenameEnabled(1,True)
    self.lvLdapAttr.currentItem().startRename(1)
}

void dKorreio::ldap_add_attr() {
attr=self.cbLdapAttr.currentText().ascii()
value=self.cbLdapValue.currentText().ascii()
if attr == '':
    return True

attrs = [(attr,value)]

if attr.lower() == 'objectclass':
    if value == '':
        return True
    item=self.lvConfLdap.firstChild()
    item=item.firstChild()
    while item is not None:
        subitem=item.firstChild()
        if item.text(0).ascii().lower() == value.lower():
            while subitem is not None:
                if subitem.text(1).ascii() is None: newvalue=""
                else: newvalue=subitem.text(1).ascii()
                attrs.extend([(subitem.text(0).ascii(),newvalue)])
                subitem=subitem.nextSibling()
        item=item.nextSibling()

for attr,value in attrs:
    item=self.lvLdapAttr.firstChild()
    jump=False
    while item is not None:
        if item.text(0).ascii() == attr and (item.text(1).ascii() == value or value == ''):
            jump=True
            break
        item=item.nextSibling()
    if jump:
        continue
    item = QListViewItem(self.lvLdapAttr)
    item.setText(0,attr)
    item.setText(1,value)
if self.cbLdapStack.currentItem() == 4:
    self.console("Por favor, selecione um dos atributos para ser o DN do novo registro antes de criá-lo.".encode('iso-8859-1'))

}

void dKorreio::ldap_rename_rdn() {
rdnnew=str(self.__tr(self.lvLdap.currentItem().text(0).ascii()))
if self.rdnold.split(",")[0] == rdnnew:
    return True
dnexist = 1
item = self.lvLdapAttr.firstChild()
while item is not None:
    if item.text(0).ascii()+"="+str(self.__tr(item.text(1).ascii())) == rdnnew:
        dnexist = 0
    item = item.nextSibling()
if self.ldap_modify_rdn(self.rdnold, rdnnew,dnexist):
    self.console("Registro "+self.rdnold.encode('iso-8859-1')+" alterado com sucesso.")
    self.lvLdapAttr.clear()
    return True
else:
    self.lvLdap.currentItem().setText(0, self.rdnold.split(",")[0])
    return False
}


void dKorreio::ldap_modify_rdn( a0, a1, a2 ) {
#a0 = oldDN, a1 = newDN, a2 = newDNexist
try:
    l = self.ldap_connect()
    l.rename_s(a0,a1,None,a2)
    l.unbind_s()
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False
}

void dKorreio::ldap_del_entry( a0 ) {
l = self.ldap_connect()
try:
    l.delete_s(a0)
    return True
except ldap.STRONG_AUTH_REQUIRED, e:
    self.console("Permissão negada para remover registro: ".encode('iso-8859-1')+a0)
    return False
}

void dKorreio::postfix_postconf() {
if self.rbPostconfN.isChecked():
    cmd = "postconf -n"
elif self.rbPostconfAll.isChecked():
    cmd = "postconf"
if self.rbPostconfD.isChecked():
    cmd = "postconf -d"
cmd = self.ssh_open(cmd)
self.postconf = {}
lastOpt = self.cbPostconf.currentText().ascii()
self.cbPostconf.clear()
i = 0
for config in cmd:
    if re.search("=",config):
        configlist = config.strip().split("=")
        configlist[0]=configlist[0].strip(" ")
        self.postconf[configlist[0]] = configlist[1]
        self.cbPostconf.insertItem(configlist[0])
        if configlist[0] == lastOpt:
            lastItem = i
        i = i + 1
try:
    self.cbPostconf.setCurrentItem(lastItem)
except UnboundLocalError, e:
    pass
self.postconf_changed()
}


void dKorreio::ssh_open( a0 ) {
print_cmd=[]
try:
    self.console("Executando comando remoto: "+a0)
    child = pexpect.spawn('ssh -p'+self.iSshPort.text().ascii()+' '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+' "'+a0+'"')
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        self.console("Aceitando SSH fingerprint")
        child.sendline('yes')
        child.expect('assword', timeout=2)
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    for line in child:
        line = re.sub("(\n|\r)","",line)
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    self.console("Erro na conexão: ".encode('iso8859-1')+self.iSshHost.text().ascii())
except pexpect.TIMEOUT, t:
   self.console("Timeout na conexão: ".encode('iso8859-1')+self.iSshHost.text().ascii())
return print_cmd
}

void dKorreio::ssh_connect() {
try:
    if self.ssh_connect_active_host != self.iSshHost.text().ascii() or self.ssh_connect_active_port != self.iSshPort.text().ascii() or self.ssh_connect_active_user != self.iSshUser.text().ascii():
        pass
    elif self.ssh:
        return self.ssh
except:
    pass

self.ssh = pxssh.pxssh()
if self.ssh.login ("-p%s %s" % (self.iSshPort.text().ascii(), self.iSshHost.text().ascii()), self.iSshUser.text().ascii(), self.iSshPass.text().ascii()):
    self.ssh_connect_active_host = self.iSshHost.text().ascii()
    self.ssh_connect_active_port = self.iSshPort.text().ascii()
    self.ssh_connect_active_user = self.iSshUser.text().ascii()
    return self.ssh
else:
    raise "Authentication error."
}

void dKorreio::ssh_exec( a0 ) {

s = self.ssh_connect()
s.sendline ("%s > /dev/null 2>&1 && echo OK" % a0)
s.prompt()
if re.search("\nOK", s.before):
    return True
else:
    return False
}

void dKorreio::postconf_changed() {

value = self.postconf.get(self.cbPostconf.currentText().ascii())
value = re.sub("( )+"," ",value)
value = re.sub(", ",",",value)
value = re.sub(",",",\n",value)
value = re.sub("^ ","",value)
self.tePostconf.setText(value)
}


void dKorreio::postconf_save() {

value = re.sub(",",", ",self.tePostconf.text().ascii())
value = re.sub("( )+"," ",value)
value = re.sub("\n","",value)
value = re.sub("\r","",value)
option = self.cbPostconf.currentText().ascii()
if self.ssh_exec("postconf -e %s=%s" % (option, value) ):
    self.console("Opção %s configurada com sucesso.".encode('iso-8859-1') % option )
else:
    self.console("Erro ao configurar %s." % option )

}


void dKorreio::postfix_open_conf() {

value = self.ssh_open("cat "+self.iPostFileOpen.text().ascii())
values = ""
for line in value[1:]:
    values = values+line+"\n"
if re.search("^cat:",values):
    self.console("Arquivo "+self.iPostFileOpen.text().ascii()+" nao encontrado.")
    return True
self.tePostFileOpen.setText(values)
}


void dKorreio::postfix_save_conf() {
if self.tePostFileOpen.length () == 0:
    self.ssh_exec("rm -f "+self.iPostFileOpen.text().ascii())
    return True
f = open("/tmp/korreio.tmp", 'w')
for line in self.tePostFileOpen.text().ascii():
    f.write(line)
f.close()
self.scp_cmd(self.iPostFileOpen.text().ascii())
}

void dKorreio::scp_cmd( a0 ) {

try:
    self.console("Salvando arquivo remoto: "+a0)
    child = pexpect.spawn('scp -P'+self.iSshPort.text().ascii()+' /tmp/korreio.tmp '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+':"'+a0+'"')
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        self.console("Aceitando SSH fingerprint")
        child.sendline('yes')
        child.expect('assword', timeout=2)
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    print_cmd=[]
    for line in child:
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    self.console("Erro na conexão: "+self.iSshHost.text().ascii())
except pexpect.TIMEOUT, t:
    self.console("Timeout na conexão: "+self.iSshHost.text().ascii())

}

void dKorreio::postfix_postmap() {
file = self.iPostFileOpen.text().ascii()
if self.ssh_exec("postmap %s" % file):
    self.console("Database %s.db gerada com sucesso." % file )
else:
    self.console("Erro ao gerar database %s.db." % file )
}

void dKorreio::postfix_stop() {
if self.ssh_exec("/etc/init.d/postfix stop"):
    self.console("Postfix parado com sucesso.")
else:
    self.console("Erro ao parar Postfix.")
}


void dKorreio::postfix_start() {
if self.ssh_exec("/etc/init.d/postfix start"):
    self.console("Postfix iniciado com sucesso.")
else:
    self.console("Erro ao iniciar Postfix.")
}


void dKorreio::postfix_restart() {
if self.ssh_exec("/etc/init.d/postfix restart"):
    self.console("Postfix reiniciado com sucesso.")
else:
    self.console("Erro ao reiniciar Postfix.")
}


void dKorreio::ldap_get_dn() {
item = self.lvLdap.currentItem()
dn = item.text(0).ascii()
while item.parent() is not None:
    dn = dn+","+item.parent().text(0).ascii()
    item = item.parent()
return dn
}

void dKorreio::action_ldap_set_port() {
if self.cbLdapMode.currentText().ascii() == "ldap://":
    self.iLdapPort.setText("389")
else:
    self.iLdapPort.setText("636")
}

void dKorreio::action_ldap_change_widgetstack() {

selected_stack = self.cbLdapStack.currentItem()

if self.lvLdap.currentItem() is None:
    if selected_stack != 0:
        self.cbLdapStack.setCurrentItem(0)
        self.console("Selecione o registro para executar esta ação.".encode('iso-8859-1'))
    return True

if selected_stack < 4:
    self.wsLdap.raiseWidget(selected_stack)
    if selected_stack == 0:
        self.ldap_dn_clicked()
else:
    self.lvLdapAttr.clear()
    self.wsLdap.raiseWidget(0)
    self.console("O novo registro será inserido na base: ".encode('iso8859-1')+self.ldap_get_dn()+".")
}


void dKorreio::ldap_passwd() {

if not self.cbLdapUserPassword.isChecked() and not self.cbLdapSambaPassword.isChecked():
    self.console("Selecione ao menos uma opção.".encode('iso-8859-1'))
    return False

old={}
new={}

if self.cbLdapUserPassword.isChecked():

    salt = ''
    for i in range(16):
        salt += choice(letters+digits)

    old["userPassword"] = 'None'
    hash = self.cbUserPassword.currentText().ascii()
    if hash == "{SSHA}":
        new["userPassword"] = "{SSHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]
    elif hash == "{SHA}":
        new["userPassword"] = "{SHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii()).digest())[:-1]
    elif hash == "{SMD5}":
        new["userPassword"] = "{SMD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]
    elif hash == "{MD5}":
        new["userPassword"] = "{MD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii()).digest())[:-1]
    elif hash == "{CRYPT}":
        salt = ''
        for i in [0,1]:
            salt += choice(letters+digits)
        new["userPassword"] = "{CRYPT}" + crypt.crypt(str(self.iLdapPasswd.text().ascii()),salt)
    elif hash == "{PLAINTEXT}":
        new["userPassword"] = self.iLdapPasswd.text().ascii()
    else:
        self.console("Algoritmo não implementando.".encode('iso-8859-1'))
        return False

if self.cbLdapSambaPassword.isChecked():
    old["sambaNTPassword"] = 'None'
    new["sambaNTPassword"] = smbpasswd.nthash(self.iLdapPasswd.text().ascii())
    old["sambaLMPassword"] = 'None'
    new["sambaLMPassword"] = smbpasswd.lmhash(self.iLdapPasswd.text().ascii())

self.ldap_modify(self.ldap_get_dn(),old,new)
}


void dKorreio::ldap_modify( a0, a1, a2 ) {
dn=str(self.__tr(a0))
old=a1
new=a2
try:
    ldif = modlist.modifyModlist(old,new)
    l = self.ldap_connect()
    l.modify_s(dn,ldif)
    l.unbind_s()
    self.console("Registro "+dn.encode('iso-8859-1')+" alterado com sucesso.")
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False
}


void dKorreio::console( a0 ) {
text=datetime.datetime.now().strftime("%d %b %Y %H:%M:%S ")+a0
self.tlConsole.setText(text)

try:
    f = open(os.path.expanduser("~/.korreio/korreio.log"), 'a')
    f.write(text+'\n')
    f.close()
except OSError, e:
    print e
}


void dKorreio::parse_exception( a0, a1 ) {
if a0 == "LDAPError":
    if a1[0]['desc'] == "Object class violation":
        self.console(a1[0]['info'])
    elif a1[0]['desc'] == "Naming violation":
        self.console(a1[0]['info'])
    elif a1[0]['desc'] == "Can't contact LDAP server":
        self.console("Erro ao conectar host "+self.iLdapHost.text().ascii())
    elif a1[0]['info'] == "no write access to parent":
        self.console("Sem permissão de escrita no referral, autentique-se nesta raiz: ".encode('iso-8859-1')+self.ldap_get_dn())
    elif a1[0]['desc'] == "No such attribute":
        self.console(a1[0]['info'])
    else:
        self.console(str(a1))
else:
    self.console(str(a1))

}

void dKorreio::action_mailbox_doubleclicked() {
if self.lvCyrus.currentItem().parent() is not None:
    item = self.lvCyrus.currentItem()
    self.mailboxold = item.text(0).ascii()
    while item.parent() is not None:
        item=item.parent()        
        self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
    self.lvCyrus.currentItem().setRenameEnabled(0,True)
    self.lvCyrus.currentItem().startRename(0)
if self.cbUserACL.count() > 1:
    self.cbUserACL.popup()

}

void dKorreio::action_gmailbox_doubleclicked() {
item = self.lvCyrusGlobal.currentItem()
self.mailboxold = item.text(0).ascii()
while item.parent() is not None:
    item=item.parent()        
    self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
self.lvCyrusGlobal.currentItem().setRenameEnabled(0,True)
self.lvCyrusGlobal.currentItem().startRename(0)

}

void dKorreio::action_config_change_widgetstack() {
item=self.lvConfig.currentItem()
if item.parent() is None:
   if  item.text(0).ascii() == "Servidores":
        self.wsConfig.raiseWidget(3)
        self.tConfShowLdapServer.setText("Host: "+self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
        self.tConfShowLdapUser.setText("User: "+self.iLdapUser.text().ascii())
        self.tConfShowLdapBaseDN.setText("Base: "+self.cbLdapBaseDN.currentText().ascii())
        self.tConfShowImapServer.setText("Host: "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii())
        self.tConfShowImapUser.setText("User: "+self.iCyrusUser.text().ascii())
        self.tConfShowSshServer.setText("Host: ssh://"+self.iSshHost.text().ascii()+":"+self.iSshPort.text().ascii())
        self.tConfShowSshUser.setText("User: "+self.iSshUser.text().ascii())
elif item.parent().text(0).ascii()+"."+item.text(0).ascii() == "Servidores.LDAP":
    self.wsConfig.raiseWidget(0)
elif item.parent().text(0).ascii()+"."+item.text(0).ascii() == "Servidores.IMAP":
    self.wsConfig.raiseWidget(1)
elif item.parent().text(0).ascii()+"."+item.text(0).ascii() == "Servidores.SSH":
    self.wsConfig.raiseWidget(2)
elif str(self.__tr(item.parent().text(0).ascii()))+"."+item.text(0).ascii() == "Preferências.LDAP":
    self.wsConfig.raiseWidget(4)
elif str(self.__tr(item.parent().text(0).ascii()))+"."+item.text(0).ascii() == "Preferências.IMAP":
    self.wsConfig.raiseWidget(5)
}


void dKorreio::action_config_ldap_connection() {
i=0
while self.confDict.get("ldap"+str(i)+".name"):
    if self.confDict.get("ldap"+str(i)+".name") == self.cbLdapConnection.currentText().ascii():
        lastConn="ldap"+str(i)
    i=i+1

self.iLdapConnection.setText(self.confDict.get(lastConn+".name"))
self.cbLdapMode.setCurrentText(self.confDict.get(lastConn+".mode"))
self.iLdapHost.setText(self.confDict.get(lastConn+".host"))
self.iLdapPort.setText(self.confDict.get(lastConn+".port"))
self.cbLdapBaseDN.clear()
self.cbLdapBaseDN.insertItem(self.confDict.get(lastConn+".basedn"))
self.iLdapUser.setText(self.confDict.get(lastConn+".user"))
self.iLdapPass.setText(self.confDict.get(lastConn+".pass"))
if self.confDict.get(lastConn+".ref") == "True":
    self.cLdapRef.setChecked(True)
else:
    self.cLdapRef.setChecked(False)
if self.confDict.get(lastConn+".cert") == "True":
    self.cLdapCert.setChecked(True)
else:
    self.cLdapCert.setChecked(False)

}


void dKorreio::action_config_imap_connection() {
i=0
while self.confDict.get("imap"+str(i)+".name"):
    if self.confDict.get("imap"+str(i)+".name") == self.cbCyrusConnection.currentText().ascii():
        lastConn="imap"+str(i)
    i=i+1

self.iCyrusConnection.setText(self.confDict.get(lastConn+".name"))
self.cbCyrusMode.setCurrentText(self.confDict.get(lastConn+".mode"))
self.iCyrusHost.setText(self.confDict.get(lastConn+".host"))
self.iCyrusPort.setText(self.confDict.get(lastConn+".port"))
self.iCyrusSievePort.setText(self.confDict.get(lastConn+".sieport"))
self.iCyrusUser.setText(self.confDict.get(lastConn+".user"))
self.iCyrusPass.setText(self.confDict.get(lastConn+".pass"))
self.iCyrusPart.setText(self.confDict.get(lastConn+".part"))
}


void dKorreio::action_config_ssh_connection() {
i=0
while self.confDict.get("ssh"+str(i)+".name"):
    if self.confDict.get("ssh"+str(i)+".name") == self.cbSSHConnection.currentText().ascii():
        lastConn="ssh"+str(i)
    i=i+1
self.iSSHConnection.setText(self.confDict.get(lastConn+".name"))
self.iSshHost.setText(self.confDict.get(lastConn+".host"))
self.iSshPort.setText(self.confDict.get(lastConn+".port"))
self.iSshUser.setText(self.confDict.get(lastConn+".user"))
self.iSshPass.setText(self.confDict.get(lastConn+".pass"))
}

void dKorreio::action_del_ldap_connection() {
    if not self.cbLdapConnection.currentText().ascii():
        return True
    i=0
    while self.confDict.get("ldap"+str(i)+".name"):
        if self.confDict.get("ldap"+str(i)+".name") == self.cbLdapConnection.currentText().ascii():
            j=i+1
            while self.confDict.get("ldap"+str(j)+".name"):
                for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                    self.confDict["ldap"+str(j-1)+"."+opt]=self.confDict.get("ldap"+str(j)+"."+opt)
                j=j+1
        i=i+1
    for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
        del self.confDict["ldap"+str(i-1)+"."+opt]

    i=self.cbLdapConnection.currentItem()
    self.cbLdapConnection.removeItem(i)
    if i > 0:
        self.cbLdapConnection.setCurrentItem(i-1)
        self.action_config_ldap_connection()
    elif self.cbLdapConnection.count() > 0:
        self.cbLdapConnection.setCurrentItem(0)
        self.action_config_ldap_connection()
    else:
        self.iLdapConnection.clear()
        self.cbLdapMode.setCurrentText("ldap://")
        self.iLdapHost.clear()
        self.iLdapPort.setText("389")
        self.cbLdapBaseDN.clear()
        self.iLdapUser.clear()
        self.iLdapPass.clear()
        self.cLdapRef.setChecked(False)
        self.cLdapCert.setChecked(False)

}

void dKorreio::action_del_imap_connection() {
    if not self.cbCyrusConnection.currentText().ascii():
        return True
    i=0
    while self.confDict.get("imap"+str(i)+".name"):
        if self.confDict.get("imap"+str(i)+".name") == self.cbCyrusConnection.currentText().ascii():
            j=i+1
            while self.confDict.get("imap"+str(j)+".name"):
                for opt in ['name','mode','host','port','sieport','user','pass','part']:
                    self.confDict["imap"+str(j-1)+"."+opt]=self.confDict.get("imap"+str(j)+"."+opt)
                j=j+1
        i=i+1
    for opt in ['name','mode','host','port','sieport','user','pass','part']:
        del self.confDict["imap"+str(i-1)+"."+opt]

    i=self.cbCyrusConnection.currentItem()
    self.cbCyrusConnection.removeItem(i)
    if i > 0:
        self.cbCyrusConnection.setCurrentItem(i-1)
        self.action_config_imap_connection()
    elif self.cbCyrusConnection.count() > 0:
        self.cbCyrusConnection.setCurrentItem(0)
        self.action_config_imap_connection()
    else:
        self.iCyrusConnection.clear()
        self.cbCyrusMode.setCurrentText("imap://")
        self.iCyrusHost.clear()
        self.iCyrusPort.setText("143")
        self.iCyrusSievePort.setText("2000")
        self.iCyrusUser.clear()
        self.iCyrusPass.clear()
        self.iCyrusPart.clear()
}


void dKorreio::action_del_ssh_connection() {
    if not self.cbSSHConnection.currentText().ascii():
        return True
    i=0
    while self.confDict.get("ssh"+str(i)+".name"):
        if self.confDict.get("ssh"+str(i)+".name") == self.cbSSHConnection.currentText().ascii():
            j=i+1
            while self.confDict.get("ssh"+str(j)+".name"):
                for opt in ['name','host','port','user','pass']:
                    self.confDict["ssh"+str(j-1)+"."+opt]=self.confDict.get("ssh"+str(j)+"."+opt)
                j=j+1
        i=i+1
    for opt in ['name','host','port','user','pass']:
        del self.confDict["ssh"+str(i-1)+"."+opt]

    i=self.cbSSHConnection.currentItem()
    self.cbSSHConnection.removeItem(i)
    if i > 0:
        self.cbSSHConnection.setCurrentItem(i-1)
        self.action_config_ssh_connection()
    elif self.cbSSHConnection.count() > 0:
        self.cbSSHConnection.setCurrentItem(0)
        self.action_config_ssh_connection()
    else:
        self.iSSHConnection.clear()
        self.iSshHost.clear()
        self.iSshPort.setText("22")
        self.iSshUser.clear()
        self.iSshPass.clear()

}


void dKorreio::action_conf_imap_add_default_folder() {
self.lbConfImapFolders.insertItem(self.iConfImapFolder.text().ascii())
self.iConfImapFolder.clear()
}


void dKorreio::action_conf_imap_del_default_folder() {
self.lbConfImapFolders.removeItem(self.lbConfImapFolders.currentItem())
}


void dKorreio::sieve_search() {

self.lvSieve.clear()
imap = self.imap_connect()
for user in imap.lm("user"+imap.SEP+self.iSieveSearch.text().ascii()+"%"):
    user=user.split(imap.SEP)[1]
    item = QListViewItem(self.lvSieve)
    item.setText(0, user)
    if self.cSieveScript.isChecked():
        s = self.sieve_connect(user)
        scripts = s.listscripts()
        s.logout()
        if scripts[0] == 'OK':
            for script,active in scripts[1]:
                if active:
                    item.setText(1, script)
                    break
}

void dKorreio::sieve_connect( a0 ) {

admin = self.iCyrusUser.text().ascii().split("@")
if admin[0] != self.iCyrusUser.text().ascii():
    user = a0+"@"+admin[1]
else:
    user = a0

s = sievelib.MANAGESIEVE(self.iCyrusHost.text().ascii(),int(self.iCyrusSievePort.text().ascii()))
if s.alive:
    if s.login('PLAIN',user,self.iCyrusPass.text().ascii(),self.iCyrusUser.text().ascii()):
        self.console("Servidor sieve://"+self.iCyrusHost.text().ascii()+":"+self.iCyrusSievePort.text().ascii()+"/"+user+" conectado com sucesso.")
    else:
        self.console("Erro ao conectar no servidor sieve://"+self.iCyrusHost.text().ascii()+":"+self.iCyrusSievePort.text().ascii()+"/"+user+". (Usuário ou senha inválidos)".encode('iso-8859-1'))
else:
    self.console("Erro ao conectar no servidor sieve://"+self.iCyrusHost.text().ascii()+":"+self.iCyrusSievePort.text().ascii()+"/"+user+". (Conexão recusada)".encode('iso-8859-1'))
    
return s

}

void dKorreio::sieve_user_clicked() {

self.teSieveScript.clear()
self.cbSieveScript.clear()

item = self.lvSieve.currentItem()
if item is None:
    return True

s = self.sieve_connect(item.text(0).ascii())
scripts = s.listscripts()
s.logout()

if scripts[0] == 'OK':
    for script,active in scripts[1]:
        self.cbSieveScript.insertItem(script)
        if self.lvSieve.currentItem().text(1).ascii() == script:
            self.cbSieveScript.setCurrentText(script)

if self.cbSieveScript.count() > 0:
    self.sieve_get_script()

}


void dKorreio::sieve_get_script() {
s = self.sieve_connect(self.lvSieve.currentItem().text(0).ascii())
script = s.getscript(self.cbSieveScript.currentText().ascii())
s.logout()

self.teSieveScript.clear()
if script[0] == 'OK':
    self.teSieveScript.setText(script[1])
}


void dKorreio::sieve_set_script() {

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        if self.cbSieveScript.currentText().ascii():
            status = s.putscript(self.cbSieveScript.currentText().ascii(),self.teSieveScript.text().ascii().replace("#USER#",item.text(0).ascii()))
            if status == 'OK':
                item.setText(1,self.cbSieveScript.currentText().ascii())
                s.setactive(self.cbSieveScript.currentText().ascii())
        else:
            item.setText(1,"")
            s.setactive()
        s.logout()
    item=item.nextSibling()

self.sieve_get_script()
}

void dKorreio::sieve_unset_script() {

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        s.setactive()
        s.logout()
        item.setText(1,"")
    item=item.nextSibling()

}


void dKorreio::sieve_del_script() {
if not self.cbSieveScript.currentText().ascii():
    self.console("Digite o nome do script.")
    return True

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        if s.deletescript(self.cbSieveScript.currentText().ascii()) == 'OK':
            if self.cbSieveScript.currentText().ascii() == item.text(1).ascii():
                item.setText(1,"")
        s.logout()
    item=item.nextSibling()

self.sieve_get_script()

}


void dKorreio::sieve_select_all() {
self.lvSieve.selectAll(True)
}


void dKorreio::sieve_use_template() {

try:
    sep = self.m.SEP
except AttributeError, e:
    sep = "/"

self.cbSieveScript.setCurrentText("script.siv")
template = self.lbSieveScripts.currentItem()
if template == 0:
    self.teSieveScript.setText("redirect \"destinatario@dominio.com\";\n")

elif template == 1:
    self.teSieveScript.setText("""redirect "destinatario@dominio.com";
keep;
""".replace("        ",""))

elif template == 2:
    self.teSieveScript.setText("""require "fileinto";
if address :contains "from" "remetente1@dominio1.com.br" {
   fileinto "INBOX%(sep)sPasta1";
}
""".replace("        ","") % {'sep':sep})

elif template == 3:
    self.teSieveScript.setText("""require "fileinto";
if address :contains "from" ["from1@dom1.com","from2@dom2.com"] {
    fileinto "INBOX%(sep)sPasta1";
}
elsif address :contains "from" ["from3@dom3.com","from4@dom4.com"] {
    fileinto "INBOX%(sep)sPasta2";
}
""".replace("        ","") % {'sep':sep})

elif template == 4:
    self.teSieveScript.setText("""if header :contains "X-Spam-Flag" "YES" {
    discard;
}
""".replace("        ",""))

elif template == 5:
    self.teSieveScript.setText("""require "fileinto";
if header :contains "X-Spam-Flag" "YES" {
    fileinto "INBOX%(sep)sSpam";
}
""".replace("        ","") % {'sep':sep})

elif template == 6:
    self.console("A macro #USER# será substituida pelo respectivo usuário.".encode('iso-8859-1'))
    if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
        domain="dominio.com.br"
    else:
        domain=self.iCyrusUser.text().ascii().split("@")[1]
    self.teSieveScript.setText("""require ["vacation","fileinto"];

if header :contains "X-Spam-Flag" "YES" {
    fileinto "INBOX%(sep)sSpam";
    stop;
}

vacation :days 5
:subject "Estou ausente"
:addresses ["#USER#@%(domain)s"]
 "Estarei ausente entre os dias ....

 Obrigado,

 --
 xxxxxxxxxxxx";
""".replace("        ","") % {'sep':sep,'domain':domain})

elif template == 7:
    if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
        domain="dominio.com.br"
    else:
        domain=self.iCyrusUser.text().ascii().split("@")[1]
    self.console("A macro #USER# será substituida pelo respectivo usuário.".encode('iso-8859-1'))
    self.teSieveScript.setText("""require "vacation";
vacation :days 5
:subject "Estou ausente."
:addresses ["#USER#@%(domain)s"]
 "Estarei ausente entre os dias ....

 Obrigado,

 --
 xxxxxxxxxxxx";
""".replace("        ","") % {'domain':domain})
}


void dKorreio::action_conf_ldap_add_attr() {

itemroot=self.lvConfLdap.firstChild()
if itemroot.isSelected():
    newitem=QListViewItem(itemroot)
    newitem.setText(0,self.iConfLdapAttr.text().ascii())
    newitem.setText(1,self.iConfLdapValue.text().ascii())
    return True
item=itemroot.firstChild()
while item is not None:
    if item.isSelected():
        item.setOpen(True)
        newitem=QListViewItem(item)
        newitem.setText(0,self.iConfLdapAttr.text().ascii())
        newitem.setText(1,self.iConfLdapValue.text().ascii())
        return True
    subitem=item.firstChild()
    while subitem is not None:
        if subitem.isSelected():
            subitem.setOpen(True)
            newitem=QListViewItem(item)
            newitem.setText(0,self.iConfLdapAttr.text().ascii())
            newitem.setText(1,self.iConfLdapValue.text().ascii())
            return True
        subitem=subitem.nextSibling()
    item=item.nextSibling()

}


void dKorreio::action_conf_ldap_del_attr() {

itemroot=self.lvConfLdap.firstChild()
item=itemroot.firstChild()
while item is not None:
    if item.isSelected():
        itemroot.takeItem(item)
        self.lvConfLdap.currentItem().setSelected(True)
        return True
    subitem=item.firstChild()
    while subitem is not None:
        if subitem.isSelected():
            item.takeItem(subitem)
            self.lvConfLdap.currentItem().setSelected(True)
            return True
        subitem=subitem.nextSibling()
    item=item.nextSibling()

}


void dKorreio::action_imap_selectall() {

if self.lvImapPartition.hasFocus():
    self.lvImapPartition.selectAll(True)
    self.lvImapPartitionGlobal.selectAll(False)
else:
    self.lvImapPartitionGlobal.selectAll(True)
    self.lvImapPartition.selectAll(False)

}

void dKorreio::queue_load() {

re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)\s+(\d+)\s([A-Z][a-z][a-z])\s([A-Z][a-z][a-z])\s+(\d+)\s(\d\d:\d\d:\d\d)\s+(.*)')
re_rcpt  = re.compile(r'\s+(.*@.*)\b')
re_log  = re.compile(r'(\s+)?\(.*\)')

self.iQueueMessage.clear()
self.lvQueue.clear()

itemFrom = {}
itemQueueID = {}
self.itemLog = {}

for line in self.ssh_open("postqueue -p"):
    if re.search("\s\d\d:\d\d:\d\d", line):
        tmp = ""
        match = re_queueid.match(line)
        if match is not None:
            #print "regexp: %s %s %s %s %s %s %s" % (match.group(1), match.group(2), match.group(3), match.group(4), match.group(5), match.group(6), match.group(7))
            mailFrom = match.group(7)
            if not itemFrom.get(mailFrom):
                itemFrom[mailFrom] = QListViewItem(self.lvQueue)
                itemFrom[mailFrom].setText(0,match.group(7))
            queueid = match.group(1)
            itemQueueID[queueid] = QListViewItem(itemFrom[mailFrom])
            itemQueueID[queueid].setText(0,match.group(1))
            itemQueueID[queueid].setOpen(True)
            continue
    match = re_log.match(line)
    if match is not None:
        tmp = line
        continue
    match = re_rcpt.match(line)
    if match is not None:
        self.itemLog["%s:%s" % ( queueid, match.group(1) )] = tmp
        tmp = ""
        itemRcpt = QListViewItem(itemQueueID[queueid])
        itemRcpt.setText(0,match.group(1))

item = self.lvQueue.firstChild()
total = [0, 0]
while item is not None:
    count = item.childCount()
    subcount = 0
    if count > 0:
        subitem = item.firstChild()
        while subitem is not None:
            subcount = subcount + subitem.childCount()
            subitem.setText(1,"%s" % subitem.childCount())
            subitem = subitem.nextSibling()
    item.setText(1,"%s/%s" % (count, subcount))
    item = item.nextSibling()
    total[0] = total[0] + count
    total[1] = total[1] + subcount

self.console("A fila contém %s mensagens para %s destinatários.".encode('iso-8859-1') % (total[0], total[1]))
self.lvQueue.setColumnWidth(0, 300)
self.lvQueue.setColumnWidth(1, 70)

}

void dKorreio::queue_get_message() {

item = self.lvQueue.currentItem()

if item is None:
    self.pQueueDel.setEnabled(False)
    return True

if item.parent() is None:
    self.pQueueDel.setEnabled(True)
    return True

if item.childCount() == 0:
    self.pQueueDel.setEnabled(False)
    self.iQueueMessage.setText(self.itemLog.get("%s:%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) ) )
    return True

queueid = item.text(0).ascii()
re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
match = re_queueid.match(queueid)
if match is not None:
    self.pQueueDel.setEnabled(True)
    self.iQueueMessage.setText("\n".join(self.ssh_open("postcat -q %s" % match.group(1))[1:]))

}


void dKorreio::queue_del_message() {

self.iQueueMessage.clear()

item = self.lvQueue.currentItem()
re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')

if item.parent() is None:
    subitem = item.firstChild()
    success = False
    queuelist = []
    while subitem is not None:
        queuelist.append(re_queueid.match(subitem.text(0).ascii()).group(1))
        if len(queuelist) == 50 or subitem.nextSibling() is None:
            if self.ssh_exec("cat <<< \"%s\" | postsuper -d - " % "\n".join(queuelist)):
                success = True
            queuelist = []
        subitem = subitem.nextSibling()
    if success:
        self.console("%s mensagen(s) removida(s) com sucesso." % item.childCount())
    self.lvQueue.takeItem(item)
    return True

match = re_queueid.match(item.text(0).ascii())
if match is not None:
    if self.ssh_exec("postsuper -d %s" % match.group(1)):
        self.console("Mensagem %s removida com sucesso." % match.group(1))
    else:
        self.console("Não foi possível remover a mensagem %s.".encode('iso-8859-1') % match.group(1))
    count = item.parent().text(1).ascii().split("/")
    if int(count[0]) == 1:
        self.lvQueue.takeItem(item.parent())
    else:
        item.parent().setText(1 ,"%s/%s" % (str(int(count[0]) - 1), str(int(count[1]) - int(item.childCount()))))
        item.parent().takeItem(item)

}

