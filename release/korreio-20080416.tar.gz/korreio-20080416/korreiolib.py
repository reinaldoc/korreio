# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'korreiolib.ui'
#
# Created: Qua Abr 16 21:27:10 2008
#      by: The PyQt User Interface Compiler (pyuic) 3.16
#
# WARNING! All changes made in this file will be lost!


from qt import *


class dKorreio(QMainWindow):
    def __init__(self,parent = None,name = None,fl = 0):
        QMainWindow.__init__(self,parent,name,fl)
        self.statusBar()

        if not name:
            self.setName("dKorreio")


        self.setCentralWidget(QWidget(self,"qt_central_widget"))
        dKorreioLayout = QGridLayout(self.centralWidget(),1,1,8,6,"dKorreioLayout")

        self.tlConsole = QLabel(self.centralWidget(),"tlConsole")
        self.tlConsole.setMinimumSize(QSize(0,24))
        self.tlConsole.setMaximumSize(QSize(32767,24))
        self.tlConsole.setFrameShape(QLabel.StyledPanel)
        self.tlConsole.setFrameShadow(QLabel.Sunken)

        dKorreioLayout.addWidget(self.tlConsole,1,0)

        self.wKorreio = QTabWidget(self.centralWidget(),"wKorreio")
        self.wKorreio.setMinimumSize(QSize(0,550))

        self.tabLdap = QWidget(self.wKorreio,"tabLdap")
        tabLdapLayout = QGridLayout(self.tabLdap,1,1,8,6,"tabLdapLayout")

        self.splitter8 = QSplitter(self.tabLdap,"splitter8")
        self.splitter8.setOrientation(QSplitter.Horizontal)

        LayoutWidget = QWidget(self.splitter8,"layout7")
        layout7 = QVBoxLayout(LayoutWidget,0,6,"layout7")

        self.cbLdapFilter = QComboBox(0,LayoutWidget,"cbLdapFilter")
        self.cbLdapFilter.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed,0,0,self.cbLdapFilter.sizePolicy().hasHeightForWidth()))
        self.cbLdapFilter.setMinimumSize(QSize(280,0))
        self.cbLdapFilter.setAcceptDrops(1)
        self.cbLdapFilter.setEditable(1)
        self.cbLdapFilter.setAutoCompletion(1)
        self.cbLdapFilter.setDuplicatesEnabled(0)
        layout7.addWidget(self.cbLdapFilter)

        self.lvLdap = QListView(LayoutWidget,"lvLdap")
        self.lvLdap.addColumn(self.__tr("Distinguished Name"))
        self.lvLdap.setRootIsDecorated(1)
        self.lvLdap.setResizeMode(QListView.AllColumns)
        layout7.addWidget(self.lvLdap)

        self.pLdapDelete = QPushButton(LayoutWidget,"pLdapDelete")
        self.pLdapDelete.setEnabled(0)
        self.pLdapDelete.setMinimumSize(QSize(80,27))
        self.pLdapDelete.setMaximumSize(QSize(130,26))
        layout7.addWidget(self.pLdapDelete)

        LayoutWidget_2 = QWidget(self.splitter8,"layout21")
        layout21 = QGridLayout(LayoutWidget_2,1,1,0,6,"layout21")

        layout9 = QHBoxLayout(None,0,6,"layout9")

        self.pLdapSearch = QPushButton(LayoutWidget_2,"pLdapSearch")
        self.pLdapSearch.setMaximumSize(QSize(32767,26))
        layout9.addWidget(self.pLdapSearch)
        spacer26_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout9.addItem(spacer26_2)

        self.cbLdapStack = QComboBox(0,LayoutWidget_2,"cbLdapStack")
        layout9.addWidget(self.cbLdapStack)

        layout21.addLayout(layout9,0,0)

        self.wsLdap = QWidgetStack(LayoutWidget_2,"wsLdap")
        self.wsLdap.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Minimum,0,0,self.wsLdap.sizePolicy().hasHeightForWidth()))
        self.wsLdap.setMargin(-8)

        self.WStackPage = QWidget(self.wsLdap,"WStackPage")
        WStackPageLayout = QGridLayout(self.WStackPage,1,1,8,6,"WStackPageLayout")

        self.lvLdapAttr = QListView(self.WStackPage,"lvLdapAttr")
        self.lvLdapAttr.addColumn(self.__tr("Atributo"))
        self.lvLdapAttr.addColumn(self.__tr("Valor"))
        self.lvLdapAttr.setLineWidth(2)
        self.lvLdapAttr.setAllColumnsShowFocus(1)
        self.lvLdapAttr.setShowSortIndicator(1)
        self.lvLdapAttr.setResizeMode(QListView.LastColumn)
        self.lvLdapAttr.setDefaultRenameAction(QListView.Accept)

        WStackPageLayout.addMultiCellWidget(self.lvLdapAttr,0,0,0,5)
        spacer2 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout.addItem(spacer2,1,4)

        self.cbLdapAttr = QComboBox(0,self.WStackPage,"cbLdapAttr")
        self.cbLdapAttr.setEditable(1)
        self.cbLdapAttr.setAutoCompletion(1)

        WStackPageLayout.addWidget(self.cbLdapAttr,1,0)

        self.cbLdapValue = QComboBox(0,self.WStackPage,"cbLdapValue")
        self.cbLdapValue.setEditable(1)
        self.cbLdapValue.setAutoCompletion(1)

        WStackPageLayout.addWidget(self.cbLdapValue,1,1)

        self.pLdapAddAttr = QPushButton(self.WStackPage,"pLdapAddAttr")
        self.pLdapAddAttr.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pLdapAddAttr.sizePolicy().hasHeightForWidth()))
        self.pLdapAddAttr.setMaximumSize(QSize(30,32767))

        WStackPageLayout.addWidget(self.pLdapAddAttr,1,2)

        self.pLdapDeleteAttr = QPushButton(self.WStackPage,"pLdapDeleteAttr")
        self.pLdapDeleteAttr.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pLdapDeleteAttr.sizePolicy().hasHeightForWidth()))
        self.pLdapDeleteAttr.setMaximumSize(QSize(30,32767))

        WStackPageLayout.addWidget(self.pLdapDeleteAttr,1,3)

        self.pLdapModify = QPushButton(self.WStackPage,"pLdapModify")

        WStackPageLayout.addWidget(self.pLdapModify,1,5)
        self.wsLdap.addWidget(self.WStackPage,0)

        self.WStackPage_2 = QWidget(self.wsLdap,"WStackPage_2")
        self.wsLdap.addWidget(self.WStackPage_2,1)

        self.WStackPage_3 = QWidget(self.wsLdap,"WStackPage_3")
        WStackPageLayout_2 = QGridLayout(self.WStackPage_3,1,1,8,6,"WStackPageLayout_2")

        self.wsLdapForm = QWidgetStack(self.WStackPage_3,"wsLdapForm")

        self.WStackPage_4 = QWidget(self.wsLdapForm,"WStackPage_4")
        WStackPageLayout_3 = QGridLayout(self.WStackPage_4,1,1,8,6,"WStackPageLayout_3")

        layout46_2 = QVBoxLayout(None,0,0,"layout46_2")

        self.textLabel1_2_3 = QLabel(self.WStackPage_4,"textLabel1_2_3")
        layout46_2.addWidget(self.textLabel1_2_3)

        self.line22_2 = QFrame(self.WStackPage_4,"line22_2")
        self.line22_2.setFrameShape(QFrame.HLine)
        self.line22_2.setFrameShadow(QFrame.Sunken)
        self.line22_2.setFrameShape(QFrame.HLine)
        layout46_2.addWidget(self.line22_2)

        WStackPageLayout_3.addLayout(layout46_2,0,0)
        spacer146 = QSpacerItem(20,50,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_3.addItem(spacer146,2,0)

        self.frame23 = QFrame(self.WStackPage_4,"frame23")
        self.frame23.setFrameShape(QFrame.NoFrame)
        self.frame23.setFrameShadow(QFrame.Raised)
        frame23Layout = QGridLayout(self.frame23,1,1,8,6,"frame23Layout")

        self.textLabel3_2 = QLabel(self.frame23,"textLabel3_2")
        self.textLabel3_2.setMinimumSize(QSize(120,0))

        frame23Layout.addWidget(self.textLabel3_2,0,0)

        self.iLdapFormCn = QLineEdit(self.frame23,"iLdapFormCn")
        self.iLdapFormCn.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormCn,0,1)

        self.textLabel5 = QLabel(self.frame23,"textLabel5")

        frame23Layout.addWidget(self.textLabel5,1,0)

        self.iLdapFormMail = QLineEdit(self.frame23,"iLdapFormMail")
        self.iLdapFormMail.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormMail,1,1)

        self.textLabel5_3 = QLabel(self.frame23,"textLabel5_3")

        frame23Layout.addWidget(self.textLabel5_3,3,0)

        self.textLabel3_2_3 = QLabel(self.frame23,"textLabel3_2_3")

        frame23Layout.addWidget(self.textLabel3_2_3,2,0)

        self.iLdapFormStreet = QLineEdit(self.frame23,"iLdapFormStreet")
        self.iLdapFormStreet.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormStreet,2,1)

        self.iLdapFormL = QLineEdit(self.frame23,"iLdapFormL")
        self.iLdapFormL.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormL,3,1)

        self.textLabel3_2_4 = QLabel(self.frame23,"textLabel3_2_4")

        frame23Layout.addWidget(self.textLabel3_2_4,4,0)

        self.iLdapFormPostalCode = QLineEdit(self.frame23,"iLdapFormPostalCode")
        self.iLdapFormPostalCode.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormPostalCode,4,1)

        self.textLabel5_4 = QLabel(self.frame23,"textLabel5_4")

        frame23Layout.addWidget(self.textLabel5_4,5,0)

        self.iLdapFormHomePhone = QLineEdit(self.frame23,"iLdapFormHomePhone")
        self.iLdapFormHomePhone.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormHomePhone,5,1)

        self.iLdapFormUserP = QLineEdit(self.frame23,"iLdapFormUserP")
        self.iLdapFormUserP.setMinimumSize(QSize(270,0))
        self.iLdapFormUserP.setEchoMode(QLineEdit.Password)

        frame23Layout.addWidget(self.iLdapFormUserP,6,1)

        self.textLabel1_3 = QLabel(self.frame23,"textLabel1_3")

        frame23Layout.addWidget(self.textLabel1_3,6,0)
        spacer28 = QSpacerItem(50,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame23Layout.addItem(spacer28,6,2)

        WStackPageLayout_3.addWidget(self.frame23,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_4,0)

        self.WStackPage_5 = QWidget(self.wsLdapForm,"WStackPage_5")
        WStackPageLayout_4 = QGridLayout(self.WStackPage_5,1,1,8,6,"WStackPageLayout_4")
        spacer146_2 = QSpacerItem(20,16,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_4.addItem(spacer146_2,2,0)

        layout53 = QGridLayout(None,1,1,0,0,"layout53")

        self.textLabel1_2_3_2 = QLabel(self.WStackPage_5,"textLabel1_2_3_2")

        layout53.addWidget(self.textLabel1_2_3_2,0,0)
        spacer156 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout53.addItem(spacer156,0,2)

        self.line22_2_2 = QFrame(self.WStackPage_5,"line22_2_2")
        self.line22_2_2.setFrameShape(QFrame.HLine)
        self.line22_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_2_2.setFrameShape(QFrame.HLine)

        layout53.addMultiCellWidget(self.line22_2_2,1,1,0,2)

        self.cLdapFormPosix = QCheckBox(self.WStackPage_5,"cLdapFormPosix")

        layout53.addWidget(self.cLdapFormPosix,0,1)

        WStackPageLayout_4.addLayout(layout53,0,0)

        self.fLdapFormPosix = QFrame(self.WStackPage_5,"fLdapFormPosix")
        self.fLdapFormPosix.setEnabled(0)
        self.fLdapFormPosix.setFrameShape(QFrame.NoFrame)
        self.fLdapFormPosix.setFrameShadow(QFrame.Raised)
        fLdapFormPosixLayout = QGridLayout(self.fLdapFormPosix,1,1,8,6,"fLdapFormPosixLayout")

        self.textLabel5_2_2 = QLabel(self.fLdapFormPosix,"textLabel5_2_2")

        fLdapFormPosixLayout.addWidget(self.textLabel5_2_2,1,0)

        self.textLabel1_3_3_2 = QLabel(self.fLdapFormPosix,"textLabel1_3_3_2")

        fLdapFormPosixLayout.addWidget(self.textLabel1_3_3_2,2,0)

        self.iLdapFormUidNumber = QLineEdit(self.fLdapFormPosix,"iLdapFormUidNumber")
        self.iLdapFormUidNumber.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormUidNumber,1,1)

        self.textLabel1_3_3 = QLabel(self.fLdapFormPosix,"textLabel1_3_3")

        fLdapFormPosixLayout.addWidget(self.textLabel1_3_3,4,0)

        self.textLabel5_2 = QLabel(self.fLdapFormPosix,"textLabel5_2")

        fLdapFormPosixLayout.addWidget(self.textLabel5_2,3,0)

        self.iLdapFormGidNumber = QLineEdit(self.fLdapFormPosix,"iLdapFormGidNumber")
        self.iLdapFormGidNumber.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormGidNumber,2,1)

        self.iLdapFormUid = QLineEdit(self.fLdapFormPosix,"iLdapFormUid")
        self.iLdapFormUid.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormUid,0,1)

        self.textLabel3_2_2 = QLabel(self.fLdapFormPosix,"textLabel3_2_2")
        self.textLabel3_2_2.setMinimumSize(QSize(120,0))

        fLdapFormPosixLayout.addWidget(self.textLabel3_2_2,0,0)

        self.iLdapFormLoginShell = QLineEdit(self.fLdapFormPosix,"iLdapFormLoginShell")
        self.iLdapFormLoginShell.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormLoginShell,3,1)

        self.iLdapFormHomeDirectory = QLineEdit(self.fLdapFormPosix,"iLdapFormHomeDirectory")
        self.iLdapFormHomeDirectory.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormHomeDirectory,4,1)
        spacer28_3 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormPosixLayout.addItem(spacer28_3,4,2)

        WStackPageLayout_4.addWidget(self.fLdapFormPosix,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_5,1)

        WStackPageLayout_2.addMultiCellWidget(self.wsLdapForm,1,1,0,2)
        spacer75 = QSpacerItem(80,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_2.addMultiCell(spacer75,1,1,3,4)

        layout51 = QGridLayout(None,1,1,0,0,"layout51")

        self.line22 = QFrame(self.WStackPage_3,"line22")
        self.line22.setFrameShape(QFrame.HLine)
        self.line22.setFrameShadow(QFrame.Sunken)
        self.line22.setFrameShape(QFrame.HLine)

        layout51.addMultiCellWidget(self.line22,1,1,0,1)

        self.textLabel1_2 = QLabel(self.WStackPage_3,"textLabel1_2")
        self.textLabel1_2.setMinimumSize(QSize(250,0))
        self.textLabel1_2.setMaximumSize(QSize(32767,26))

        layout51.addWidget(self.textLabel1_2,0,0)
        spacer148 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51.addItem(spacer148,0,1)

        WStackPageLayout_2.addMultiCellLayout(layout51,0,0,0,4)

        self.pLdapFormBack = QPushButton(self.WStackPage_3,"pLdapFormBack")
        self.pLdapFormBack.setMaximumSize(QSize(110,26))

        WStackPageLayout_2.addWidget(self.pLdapFormBack,4,0)

        self.pLdapFormNext = QPushButton(self.WStackPage_3,"pLdapFormNext")
        self.pLdapFormNext.setMaximumSize(QSize(110,26))

        WStackPageLayout_2.addWidget(self.pLdapFormNext,4,1)

        self.pLdapAddUser = QPushButton(self.WStackPage_3,"pLdapAddUser")
        self.pLdapAddUser.setMaximumSize(QSize(110,26))

        WStackPageLayout_2.addWidget(self.pLdapAddUser,4,4)
        spacer152 = QSpacerItem(20,40,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_2.addItem(spacer152,2,1)
        spacer76 = QSpacerItem(220,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_2.addMultiCell(spacer76,4,4,2,3)

        self.line24 = QFrame(self.WStackPage_3,"line24")
        self.line24.setFrameShape(QFrame.HLine)
        self.line24.setFrameShadow(QFrame.Sunken)
        self.line24.setFrameShape(QFrame.HLine)

        WStackPageLayout_2.addMultiCellWidget(self.line24,3,3,0,4)
        self.wsLdap.addWidget(self.WStackPage_3,2)

        self.WStackPage_6 = QWidget(self.wsLdap,"WStackPage_6")
        WStackPageLayout_5 = QGridLayout(self.WStackPage_6,1,1,8,6,"WStackPageLayout_5")

        layout51_2 = QGridLayout(None,1,1,0,0,"layout51_2")

        self.line22_3 = QFrame(self.WStackPage_6,"line22_3")
        self.line22_3.setFrameShape(QFrame.HLine)
        self.line22_3.setFrameShadow(QFrame.Sunken)
        self.line22_3.setFrameShape(QFrame.HLine)

        layout51_2.addMultiCellWidget(self.line22_3,1,1,0,1)

        self.textLabel1_2_4 = QLabel(self.WStackPage_6,"textLabel1_2_4")
        self.textLabel1_2_4.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4.setMaximumSize(QSize(32767,26))

        layout51_2.addWidget(self.textLabel1_2_4,0,0)
        spacer148_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2.addItem(spacer148_2,0,1)

        WStackPageLayout_5.addMultiCellLayout(layout51_2,0,0,0,1)

        self.pLdapAddOu = QPushButton(self.WStackPage_6,"pLdapAddOu")
        self.pLdapAddOu.setMaximumSize(QSize(110,26))

        WStackPageLayout_5.addWidget(self.pLdapAddOu,4,1)

        self.line27 = QFrame(self.WStackPage_6,"line27")
        self.line27.setFrameShape(QFrame.HLine)
        self.line27.setFrameShadow(QFrame.Sunken)
        self.line27.setFrameShape(QFrame.HLine)

        WStackPageLayout_5.addMultiCellWidget(self.line27,3,3,0,1)

        self.frame24 = QFrame(self.WStackPage_6,"frame24")
        self.frame24.setFrameShape(QFrame.NoFrame)
        self.frame24.setFrameShadow(QFrame.Raised)
        frame24Layout = QGridLayout(self.frame24,1,1,8,6,"frame24Layout")

        self.textLabel2_3 = QLabel(self.frame24,"textLabel2_3")

        frame24Layout.addWidget(self.textLabel2_3,0,0)

        self.iLdapOu = QLineEdit(self.frame24,"iLdapOu")
        self.iLdapOu.setMinimumSize(QSize(270,0))

        frame24Layout.addWidget(self.iLdapOu,0,1)
        spacer31 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame24Layout.addItem(spacer31,0,2)

        WStackPageLayout_5.addWidget(self.frame24,1,0)
        spacer159 = QSpacerItem(20,200,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_5.addItem(spacer159,2,0)
        self.wsLdap.addWidget(self.WStackPage_6,3)

        self.WStackPage_7 = QWidget(self.wsLdap,"WStackPage_7")
        WStackPageLayout_6 = QGridLayout(self.WStackPage_7,1,1,8,6,"WStackPageLayout_6")
        spacer161 = QSpacerItem(21,190,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_6.addItem(spacer161,2,0)

        self.pLdapPasswd = QPushButton(self.WStackPage_7,"pLdapPasswd")
        self.pLdapPasswd.setMinimumSize(QSize(110,0))
        self.pLdapPasswd.setMaximumSize(QSize(110,26))

        WStackPageLayout_6.addWidget(self.pLdapPasswd,4,1)

        self.line29 = QFrame(self.WStackPage_7,"line29")
        self.line29.setFrameShape(QFrame.HLine)
        self.line29.setFrameShadow(QFrame.Sunken)
        self.line29.setFrameShape(QFrame.HLine)

        WStackPageLayout_6.addMultiCellWidget(self.line29,3,3,0,1)

        self.frame25 = QFrame(self.WStackPage_7,"frame25")
        self.frame25.setFrameShape(QFrame.NoFrame)
        self.frame25.setFrameShadow(QFrame.Raised)
        frame25Layout = QGridLayout(self.frame25,1,1,8,6,"frame25Layout")

        self.cbUserPassword = QComboBox(0,self.frame25,"cbUserPassword")
        self.cbUserPassword.setEnabled(1)
        self.cbUserPassword.setMinimumSize(QSize(0,23))
        self.cbUserPassword.setMaximumSize(QSize(100,32767))

        frame25Layout.addWidget(self.cbUserPassword,0,2)

        self.cbLdapUserPassword = QCheckBox(self.frame25,"cbLdapUserPassword")
        self.cbLdapUserPassword.setChecked(1)

        frame25Layout.addWidget(self.cbLdapUserPassword,0,1)
        spacer30 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame25Layout.addItem(spacer30,0,3)
        spacer30_2 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame25Layout.addItem(spacer30_2,1,3)
        spacer28_2 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame25Layout.addItem(spacer28_2,2,3)

        self.iLdapPasswd = QLineEdit(self.frame25,"iLdapPasswd")
        self.iLdapPasswd.setMinimumSize(QSize(270,0))
        self.iLdapPasswd.setMaximumSize(QSize(270,32767))
        self.iLdapPasswd.setEchoMode(QLineEdit.Password)

        frame25Layout.addMultiCellWidget(self.iLdapPasswd,2,2,1,2)
        spacer30_2_2 = QSpacerItem(90,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame25Layout.addItem(spacer30_2_2,1,2)

        self.textLabel1_3_2_2 = QLabel(self.frame25,"textLabel1_3_2_2")
        self.textLabel1_3_2_2.setMinimumSize(QSize(100,0))

        frame25Layout.addMultiCellWidget(self.textLabel1_3_2_2,0,1,0,0)

        self.textLabel1_3_2 = QLabel(self.frame25,"textLabel1_3_2")

        frame25Layout.addWidget(self.textLabel1_3_2,2,0)

        self.cbLdapSambaPassword = QCheckBox(self.frame25,"cbLdapSambaPassword")
        self.cbLdapSambaPassword.setMinimumSize(QSize(0,50))

        frame25Layout.addWidget(self.cbLdapSambaPassword,1,1)

        WStackPageLayout_6.addWidget(self.frame25,1,0)

        layout51_2_2 = QGridLayout(None,1,1,0,0,"layout51_2_2")

        self.line22_3_2 = QFrame(self.WStackPage_7,"line22_3_2")
        self.line22_3_2.setFrameShape(QFrame.HLine)
        self.line22_3_2.setFrameShadow(QFrame.Sunken)
        self.line22_3_2.setFrameShape(QFrame.HLine)

        layout51_2_2.addMultiCellWidget(self.line22_3_2,1,1,0,1)

        self.textLabel1_2_4_2 = QLabel(self.WStackPage_7,"textLabel1_2_4_2")
        self.textLabel1_2_4_2.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4_2.setMaximumSize(QSize(32767,26))

        layout51_2_2.addWidget(self.textLabel1_2_4_2,0,0)
        spacer148_2_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2_2.addItem(spacer148_2_2,0,1)

        WStackPageLayout_6.addMultiCellLayout(layout51_2_2,0,0,0,1)
        self.wsLdap.addWidget(self.WStackPage_7,4)

        layout21.addWidget(self.wsLdap,1,0)

        tabLdapLayout.addWidget(self.splitter8,0,0)
        self.wKorreio.insertTab(self.tabLdap,QString.fromLatin1(""))

        self.tabCyrus = QWidget(self.wKorreio,"tabCyrus")
        tabCyrusLayout = QGridLayout(self.tabCyrus,1,1,8,6,"tabCyrusLayout")

        self.tCyrUser = QLabel(self.tabCyrus,"tCyrUser")
        self.tCyrUser.setMinimumSize(QSize(65,0))

        tabCyrusLayout.addMultiCellWidget(self.tCyrUser,0,0,0,1)

        self.iImapSearch = QLineEdit(self.tabCyrus,"iImapSearch")
        self.iImapSearch.setMinimumSize(QSize(220,0))
        self.iImapSearch.setMaximumSize(QSize(220,32767))

        tabCyrusLayout.addWidget(self.iImapSearch,0,2)

        self.pImapSearch = QPushButton(self.tabCyrus,"pImapSearch")

        tabCyrusLayout.addWidget(self.pImapSearch,0,3)
        spacer1 = QSpacerItem(470,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabCyrusLayout.addMultiCell(spacer1,0,0,4,8)

        self.lvCyrus = QListView(self.tabCyrus,"lvCyrus")
        self.lvCyrus.addColumn(self.__tr("IMAP Mailboxes"))
        self.lvCyrus.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,0,1,self.lvCyrus.sizePolicy().hasHeightForWidth()))
        self.lvCyrus.setShowSortIndicator(1)
        self.lvCyrus.setRootIsDecorated(1)
        self.lvCyrus.setResizeMode(QListView.AllColumns)

        tabCyrusLayout.addMultiCellWidget(self.lvCyrus,1,1,0,6)

        self.lvCyrusGlobal = QListView(self.tabCyrus,"lvCyrusGlobal")
        self.lvCyrusGlobal.addColumn(self.__tr("Global IMAP Mailboxes"))
        self.lvCyrusGlobal.setShowSortIndicator(1)
        self.lvCyrusGlobal.setRootIsDecorated(1)
        self.lvCyrusGlobal.setResizeMode(QListView.AllColumns)

        tabCyrusLayout.addWidget(self.lvCyrusGlobal,1,8)

        self.line21 = QFrame(self.tabCyrus,"line21")
        self.line21.setFrameShape(QFrame.VLine)
        self.line21.setFrameShadow(QFrame.Sunken)
        self.line21.setFrameShape(QFrame.VLine)

        tabCyrusLayout.addMultiCellWidget(self.line21,1,4,7,7)

        self.lvImapAcl = QListView(self.tabCyrus,"lvImapAcl")
        self.lvImapAcl.addColumn(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f"))
        self.lvImapAcl.addColumn(self.__trUtf8("\x50\x65\x72\x6d\x69\x73\x73\xc3\xb5\x65\x73"))
        self.lvImapAcl.setSelectionMode(QListView.Extended)
        self.lvImapAcl.setAllColumnsShowFocus(1)
        self.lvImapAcl.setResizeMode(QListView.LastColumn)

        tabCyrusLayout.addMultiCellWidget(self.lvImapAcl,3,3,0,6)
        spacer33_2_2_2_2 = QSpacerItem(340,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabCyrusLayout.addItem(spacer33_2_2_2_2,2,8)

        layout39 = QHBoxLayout(None,0,6,"layout39")

        self.cbImapMailbox = QComboBox(0,self.tabCyrus,"cbImapMailbox")
        self.cbImapMailbox.setMinimumSize(QSize(85,0))
        self.cbImapMailbox.setMaximumSize(QSize(90,32767))
        layout39.addWidget(self.cbImapMailbox)

        self.iImapMailbox = QLineEdit(self.tabCyrus,"iImapMailbox")
        self.iImapMailbox.setEnabled(1)
        layout39.addWidget(self.iImapMailbox)

        self.pCyrAdd = QPushButton(self.tabCyrus,"pCyrAdd")
        self.pCyrAdd.setMinimumSize(QSize(30,0))
        self.pCyrAdd.setMaximumSize(QSize(30,32767))
        layout39.addWidget(self.pCyrAdd)

        self.pCyrDelete = QPushButton(self.tabCyrus,"pCyrDelete")
        self.pCyrDelete.setEnabled(1)
        self.pCyrDelete.setMinimumSize(QSize(30,0))
        self.pCyrDelete.setMaximumSize(QSize(30,32767))
        layout39.addWidget(self.pCyrDelete)

        self.pCyrReconstruct = QPushButton(self.tabCyrus,"pCyrReconstruct")
        self.pCyrReconstruct.setMinimumSize(QSize(30,0))
        self.pCyrReconstruct.setMaximumSize(QSize(30,32767))
        layout39.addWidget(self.pCyrReconstruct)

        tabCyrusLayout.addMultiCellLayout(layout39,2,2,0,6)

        self.frame20 = QFrame(self.tabCyrus,"frame20")
        self.frame20.setFrameShape(QFrame.NoFrame)
        self.frame20.setFrameShadow(QFrame.Raised)
        frame20Layout = QGridLayout(self.frame20,1,1,0,6,"frame20Layout")
        spacer36 = QSpacerItem(30,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame20Layout.addItem(spacer36,4,4)

        self.iQuotaUsed = QLineEdit(self.frame20,"iQuotaUsed")
        self.iQuotaUsed.setMinimumSize(QSize(90,25))
        self.iQuotaUsed.setMaximumSize(QSize(90,25))
        self.iQuotaUsed.setAlignment(QLineEdit.AlignRight)
        self.iQuotaUsed.setReadOnly(1)

        frame20Layout.addWidget(self.iQuotaUsed,1,1)

        self.pSetQuota = QPushButton(self.frame20,"pSetQuota")
        self.pSetQuota.setMaximumSize(QSize(40,32767))

        frame20Layout.addWidget(self.pSetQuota,2,3)

        self.pSetExpire = QPushButton(self.frame20,"pSetExpire")
        self.pSetExpire.setMaximumSize(QSize(40,32767))

        frame20Layout.addWidget(self.pSetExpire,4,3)
        spacer33_2 = QSpacerItem(50,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame20Layout.addItem(spacer33_2,1,4)
        spacer34 = QSpacerItem(60,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame20Layout.addItem(spacer34,2,4)

        self.textLabel2_5 = QLabel(self.frame20,"textLabel2_5")

        frame20Layout.addWidget(self.textLabel2_5,4,0)

        layout41 = QGridLayout(None,1,1,0,0,"layout41")

        self.textLabel4_2_2 = QLabel(self.frame20,"textLabel4_2_2")

        layout41.addWidget(self.textLabel4_2_2,0,0)
        spacer138 = QSpacerItem(210,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout41.addItem(spacer138,0,1)

        self.line3_2_2 = QFrame(self.frame20,"line3_2_2")
        self.line3_2_2.setFrameShape(QFrame.HLine)
        self.line3_2_2.setFrameShadow(QFrame.Sunken)
        self.line3_2_2.setFrameShape(QFrame.HLine)

        layout41.addMultiCellWidget(self.line3_2_2,1,1,0,1)

        frame20Layout.addMultiCellLayout(layout41,3,3,0,4)
        spacer33_2_2 = QSpacerItem(30,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame20Layout.addItem(spacer33_2_2,1,3)

        layout42 = QGridLayout(None,1,1,0,0,"layout42")

        self.line3_2 = QFrame(self.frame20,"line3_2")
        self.line3_2.setFrameShape(QFrame.HLine)
        self.line3_2.setFrameShadow(QFrame.Sunken)
        self.line3_2.setFrameShape(QFrame.HLine)

        layout42.addMultiCellWidget(self.line3_2,1,1,0,1)
        spacer33_2_2_2 = QSpacerItem(250,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout42.addItem(spacer33_2_2_2,0,1)

        self.textLabel4_2 = QLabel(self.frame20,"textLabel4_2")

        layout42.addWidget(self.textLabel4_2,0,0)

        frame20Layout.addMultiCellLayout(layout42,0,0,0,4)

        self.textLabel1_6 = QLabel(self.frame20,"textLabel1_6")

        frame20Layout.addWidget(self.textLabel1_6,4,2)

        self.iAnnotationExpire = QLineEdit(self.frame20,"iAnnotationExpire")
        self.iAnnotationExpire.setMaximumSize(QSize(90,32767))
        self.iAnnotationExpire.setAlignment(QLineEdit.AlignRight)

        frame20Layout.addWidget(self.iAnnotationExpire,4,1)

        self.textLabel1 = QLabel(self.frame20,"textLabel1")

        frame20Layout.addWidget(self.textLabel1,1,0)

        self.iQuota = QLineEdit(self.frame20,"iQuota")
        self.iQuota.setMinimumSize(QSize(90,0))
        self.iQuota.setMaximumSize(QSize(90,32767))
        self.iQuota.setAlignment(QLineEdit.AlignRight)

        frame20Layout.addWidget(self.iQuota,2,1)

        self.textLabel2_2 = QLabel(self.frame20,"textLabel2_2")

        frame20Layout.addWidget(self.textLabel2_2,2,0)

        self.textLabel2 = QLabel(self.frame20,"textLabel2")

        frame20Layout.addWidget(self.textLabel2,2,2)

        self.textLabel2_4 = QLabel(self.frame20,"textLabel2_4")

        frame20Layout.addWidget(self.textLabel2_4,1,2)
        spacer144 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame20Layout.addItem(spacer144,5,1)

        tabCyrusLayout.addMultiCellWidget(self.frame20,3,4,8,8)

        self.textLabel2_6 = QLabel(self.tabCyrus,"textLabel2_6")

        tabCyrusLayout.addWidget(self.textLabel2_6,4,0)

        self.iImapAclUser = QLineEdit(self.tabCyrus,"iImapAclUser")
        self.iImapAclUser.setMinimumSize(QSize(240,0))

        tabCyrusLayout.addMultiCellWidget(self.iImapAclUser,4,4,1,2)

        self.cbACL = QComboBox(0,self.tabCyrus,"cbACL")
        self.cbACL.setMinimumSize(QSize(145,0))
        self.cbACL.setMaximumSize(QSize(145,32767))
        self.cbACL.setEditable(1)

        tabCyrusLayout.addMultiCellWidget(self.cbACL,4,4,3,4)

        self.pImapAclAdd = QPushButton(self.tabCyrus,"pImapAclAdd")
        self.pImapAclAdd.setMinimumSize(QSize(30,0))
        self.pImapAclAdd.setMaximumSize(QSize(30,32767))

        tabCyrusLayout.addWidget(self.pImapAclAdd,4,5)

        self.pImapAclDel = QPushButton(self.tabCyrus,"pImapAclDel")
        self.pImapAclDel.setMinimumSize(QSize(30,0))
        self.pImapAclDel.setMaximumSize(QSize(30,32767))

        tabCyrusLayout.addWidget(self.pImapAclDel,4,6)
        self.wKorreio.insertTab(self.tabCyrus,QString.fromLatin1(""))

        self.TabPage = QWidget(self.wKorreio,"TabPage")
        TabPageLayout = QGridLayout(self.TabPage,1,1,8,6,"TabPageLayout")

        self.splitter2 = QSplitter(self.TabPage,"splitter2")
        self.splitter2.setOrientation(QSplitter.Horizontal)

        self.lvImapPartition = QListView(self.splitter2,"lvImapPartition")
        self.lvImapPartition.addColumn(self.__tr("IMAP Mailboxes"))
        self.lvImapPartition.addColumn(self.__tr("Partition"))
        self.lvImapPartition.addColumn(self.__tr("Tamanho"))
        self.lvImapPartition.setSelectionMode(QListView.Extended)
        self.lvImapPartition.setAllColumnsShowFocus(1)
        self.lvImapPartition.setShowSortIndicator(1)
        self.lvImapPartition.setRootIsDecorated(1)
        self.lvImapPartition.setResizeMode(QListView.AllColumns)

        self.lvImapPartitionGlobal = QListView(self.splitter2,"lvImapPartitionGlobal")
        self.lvImapPartitionGlobal.addColumn(self.__tr("Global IMAP Mailboxes"))
        self.lvImapPartitionGlobal.addColumn(self.__tr("Partition"))
        self.lvImapPartitionGlobal.addColumn(self.__tr("Tamanho"))
        self.lvImapPartitionGlobal.setSelectionMode(QListView.Extended)
        self.lvImapPartitionGlobal.setAllColumnsShowFocus(1)
        self.lvImapPartitionGlobal.setShowSortIndicator(1)
        self.lvImapPartitionGlobal.setRootIsDecorated(1)
        self.lvImapPartitionGlobal.setResizeMode(QListView.AllColumns)

        TabPageLayout.addWidget(self.splitter2,1,0)

        layout30 = QHBoxLayout(None,0,6,"layout30")

        self.tCyrUser_2 = QLabel(self.TabPage,"tCyrUser_2")
        self.tCyrUser_2.setMinimumSize(QSize(65,0))
        layout30.addWidget(self.tCyrUser_2)

        self.iImapPartitionSearch = QLineEdit(self.TabPage,"iImapPartitionSearch")
        self.iImapPartitionSearch.setMinimumSize(QSize(220,0))
        self.iImapPartitionSearch.setMaximumSize(QSize(220,32767))
        layout30.addWidget(self.iImapPartitionSearch)

        self.pImapPartitionSearch = QPushButton(self.TabPage,"pImapPartitionSearch")
        layout30.addWidget(self.pImapPartitionSearch)

        self.cImapSize = QCheckBox(self.TabPage,"cImapSize")
        self.cImapSize.setChecked(1)
        layout30.addWidget(self.cImapSize)
        spacer1_2 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout30.addItem(spacer1_2)

        self.pImapSelectAll = QPushButton(self.TabPage,"pImapSelectAll")
        layout30.addWidget(self.pImapSelectAll)

        TabPageLayout.addLayout(layout30,0,0)

        layout31 = QHBoxLayout(None,0,6,"layout31")

        self.textLabel1_2_2 = QLabel(self.TabPage,"textLabel1_2_2")
        self.textLabel1_2_2.setMinimumSize(QSize(65,0))
        layout31.addWidget(self.textLabel1_2_2)

        self.cbImapPartition = QComboBox(0,self.TabPage,"cbImapPartition")
        self.cbImapPartition.setMinimumSize(QSize(220,0))
        self.cbImapPartition.setMaximumSize(QSize(220,32767))
        self.cbImapPartition.setEditable(1)
        self.cbImapPartition.setAutoCompletion(1)
        self.cbImapPartition.setDuplicatesEnabled(0)
        layout31.addWidget(self.cbImapPartition)

        self.pImapPartitionMove = QPushButton(self.TabPage,"pImapPartitionMove")
        self.pImapPartitionMove.setMinimumSize(QSize(100,0))
        self.pImapPartitionMove.setMaximumSize(QSize(100,32767))
        layout31.addWidget(self.pImapPartitionMove)
        spacer38_2 = QSpacerItem(390,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout31.addItem(spacer38_2)

        layout6 = QHBoxLayout(None,0,6,"layout6")

        self.tlImapSize = QLabel(self.TabPage,"tlImapSize")
        self.tlImapSize.setMinimumSize(QSize(200,0))
        self.tlImapSize.setAlignment(QLabel.AlignVCenter | QLabel.AlignRight)
        layout6.addWidget(self.tlImapSize)

        self.cImapSizeUpdate = QCheckBox(self.TabPage,"cImapSizeUpdate")
        self.cImapSizeUpdate.setMinimumSize(QSize(20,0))
        self.cImapSizeUpdate.setMaximumSize(QSize(20,32767))
        self.cImapSizeUpdate.setChecked(1)
        layout6.addWidget(self.cImapSizeUpdate)
        layout31.addLayout(layout6)

        TabPageLayout.addLayout(layout31,2,0)
        self.wKorreio.insertTab(self.TabPage,QString.fromLatin1(""))

        self.TabPage_2 = QWidget(self.wKorreio,"TabPage_2")
        TabPageLayout_2 = QGridLayout(self.TabPage_2,1,1,8,6,"TabPageLayout_2")

        self.tCyrUser_2_2 = QLabel(self.TabPage_2,"tCyrUser_2_2")
        self.tCyrUser_2_2.setMinimumSize(QSize(65,0))
        self.tCyrUser_2_2.setMaximumSize(QSize(60,32767))

        TabPageLayout_2.addWidget(self.tCyrUser_2_2,0,0)

        self.iSieveSearch = QLineEdit(self.TabPage_2,"iSieveSearch")
        self.iSieveSearch.setMinimumSize(QSize(220,0))
        self.iSieveSearch.setMaximumSize(QSize(220,32767))

        TabPageLayout_2.addWidget(self.iSieveSearch,0,1)

        self.cSieveScript = QCheckBox(self.TabPage_2,"cSieveScript")
        self.cSieveScript.setChecked(1)

        TabPageLayout_2.addWidget(self.cSieveScript,0,3)

        self.pSieveSearch = QPushButton(self.TabPage_2,"pSieveSearch")

        TabPageLayout_2.addWidget(self.pSieveSearch,0,2)

        self.pSieveSelectAll = QPushButton(self.TabPage_2,"pSieveSelectAll")

        TabPageLayout_2.addWidget(self.pSieveSelectAll,0,5)
        spacer61 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout_2.addItem(spacer61,0,4)

        self.splitter5 = QSplitter(self.TabPage_2,"splitter5")
        self.splitter5.setOrientation(QSplitter.Vertical)

        self.lvSieve = QListView(self.splitter5,"lvSieve")
        self.lvSieve.addColumn(self.__tr("IMAP Users"))
        self.lvSieve.addColumn(self.__tr("Script ativo"))
        self.lvSieve.setSelectionMode(QListView.Extended)
        self.lvSieve.setAllColumnsShowFocus(1)
        self.lvSieve.setShowSortIndicator(1)
        self.lvSieve.setRootIsDecorated(1)
        self.lvSieve.setResizeMode(QListView.LastColumn)

        LayoutWidget_3 = QWidget(self.splitter5,"layout13")
        layout13 = QVBoxLayout(LayoutWidget_3,0,6,"layout13")

        layout12 = QHBoxLayout(None,0,6,"layout12")

        self.textLabel1_2_2_2 = QLabel(LayoutWidget_3,"textLabel1_2_2_2")
        self.textLabel1_2_2_2.setMinimumSize(QSize(65,0))
        layout12.addWidget(self.textLabel1_2_2_2)

        self.cbSieveScript = QComboBox(0,LayoutWidget_3,"cbSieveScript")
        self.cbSieveScript.setMinimumSize(QSize(220,0))
        self.cbSieveScript.setEditable(1)
        self.cbSieveScript.setAutoCompletion(1)
        self.cbSieveScript.setDuplicatesEnabled(0)
        layout12.addWidget(self.cbSieveScript)

        self.pSieveScriptActive = QPushButton(LayoutWidget_3,"pSieveScriptActive")
        self.pSieveScriptActive.setMaximumSize(QSize(30,32767))
        layout12.addWidget(self.pSieveScriptActive)

        self.pSieveScriptDisable = QPushButton(LayoutWidget_3,"pSieveScriptDisable")
        self.pSieveScriptDisable.setMaximumSize(QSize(30,32767))
        layout12.addWidget(self.pSieveScriptDisable)

        self.pSieveScriptRemove = QPushButton(LayoutWidget_3,"pSieveScriptRemove")
        self.pSieveScriptRemove.setMaximumSize(QSize(30,32767))
        layout12.addWidget(self.pSieveScriptRemove)
        spacer61_2_2 = QSpacerItem(100,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout12.addItem(spacer61_2_2)
        layout13.addLayout(layout12)

        self.splitter4 = QSplitter(LayoutWidget_3,"splitter4")
        self.splitter4.setOrientation(QSplitter.Horizontal)

        self.teSieveScript = QTextEdit(self.splitter4,"teSieveScript")
        self.teSieveScript.setMinimumSize(QSize(600,200))

        LayoutWidget_4 = QWidget(self.splitter4,"layout11")
        layout11 = QGridLayout(LayoutWidget_4,1,1,0,6,"layout11")
        spacer129 = QSpacerItem(121,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout11.addItem(spacer129,0,1)

        self.lbSieveScripts = QListBox(LayoutWidget_4,"lbSieveScripts")

        layout11.addMultiCellWidget(self.lbSieveScripts,1,1,0,1)

        self.textLabel1_8 = QLabel(LayoutWidget_4,"textLabel1_8")

        layout11.addWidget(self.textLabel1_8,0,0)
        layout13.addWidget(self.splitter4)

        TabPageLayout_2.addMultiCellWidget(self.splitter5,1,1,0,5)
        self.wKorreio.insertTab(self.TabPage_2,QString.fromLatin1(""))

        self.TabPage_3 = QWidget(self.wKorreio,"TabPage_3")
        TabPageLayout_3 = QGridLayout(self.TabPage_3,1,1,8,6,"TabPageLayout_3")

        layout7_2 = QHBoxLayout(None,0,6,"layout7_2")

        self.pPostStart = QPushButton(self.TabPage_3,"pPostStart")
        layout7_2.addWidget(self.pPostStart)

        self.pPostStop = QPushButton(self.TabPage_3,"pPostStop")
        layout7_2.addWidget(self.pPostStop)

        self.pPostRestart = QPushButton(self.TabPage_3,"pPostRestart")
        layout7_2.addWidget(self.pPostRestart)
        spacer27 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout7_2.addItem(spacer27)

        TabPageLayout_3.addLayout(layout7_2,2,0)

        self.buttonGroup2 = QButtonGroup(self.TabPage_3,"buttonGroup2")
        self.buttonGroup2.setColumnLayout(0,Qt.Vertical)
        self.buttonGroup2.layout().setSpacing(6)
        self.buttonGroup2.layout().setMargin(8)
        buttonGroup2Layout = QGridLayout(self.buttonGroup2.layout())
        buttonGroup2Layout.setAlignment(Qt.AlignTop)

        self.pPostMainSave = QPushButton(self.buttonGroup2,"pPostMainSave")

        buttonGroup2Layout.addWidget(self.pPostMainSave,1,6)
        spacer18 = QSpacerItem(81,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2Layout.addMultiCell(spacer18,2,2,0,1)

        self.textLabel6 = QLabel(self.buttonGroup2,"textLabel6")

        buttonGroup2Layout.addWidget(self.textLabel6,1,0)
        spacer31_2 = QSpacerItem(192,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer31_2,0,7)

        self.rbPostconfD = QRadioButton(self.buttonGroup2,"rbPostconfD")

        buttonGroup2Layout.addMultiCellWidget(self.rbPostconfD,0,0,4,6)
        spacer19 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer19,1,1)
        spacer20 = QSpacerItem(20,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer20,1,5)

        self.cbPostconf = QComboBox(0,self.buttonGroup2,"cbPostconf")
        self.cbPostconf.setMinimumSize(QSize(340,0))

        buttonGroup2Layout.addMultiCellWidget(self.cbPostconf,1,1,2,4)

        self.tePostconf = QTextEdit(self.buttonGroup2,"tePostconf")

        buttonGroup2Layout.addMultiCellWidget(self.tePostconf,2,2,2,7)

        self.rbPostconfAll = QRadioButton(self.buttonGroup2,"rbPostconfAll")

        buttonGroup2Layout.addWidget(self.rbPostconfAll,0,3)

        self.textLabel1_4 = QLabel(self.buttonGroup2,"textLabel1_4")

        buttonGroup2Layout.addWidget(self.textLabel1_4,0,0)
        spacer19_2 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer19_2,0,1)
        spacer21 = QSpacerItem(192,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer21,1,7)

        self.rbPostconfN = QRadioButton(self.buttonGroup2,"rbPostconfN")
        self.rbPostconfN.setAutoMask(1)

        buttonGroup2Layout.addWidget(self.rbPostconfN,0,2)

        TabPageLayout_3.addWidget(self.buttonGroup2,0,0)

        self.groupBox10 = QGroupBox(self.TabPage_3,"groupBox10")
        self.groupBox10.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,0,0,self.groupBox10.sizePolicy().hasHeightForWidth()))
        self.groupBox10.setColumnLayout(0,Qt.Vertical)
        self.groupBox10.layout().setSpacing(6)
        self.groupBox10.layout().setMargin(8)
        groupBox10Layout = QGridLayout(self.groupBox10.layout())
        groupBox10Layout.setAlignment(Qt.AlignTop)

        self.textLabel7 = QLabel(self.groupBox10,"textLabel7")

        groupBox10Layout.addWidget(self.textLabel7,0,0)
        spacer14 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer14,0,1)
        spacer15 = QSpacerItem(80,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addMultiCell(spacer15,1,1,0,1)

        self.pPostFileOpen = QPushButton(self.groupBox10,"pPostFileOpen")

        groupBox10Layout.addWidget(self.pPostFileOpen,0,4)
        spacer12 = QSpacerItem(20,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer12,0,3)

        self.tePostFileOpen = QTextEdit(self.groupBox10,"tePostFileOpen")

        groupBox10Layout.addMultiCellWidget(self.tePostFileOpen,1,1,2,9)

        self.iPostFileOpen = QLineEdit(self.groupBox10,"iPostFileOpen")
        self.iPostFileOpen.setMinimumSize(QSize(340,0))

        groupBox10Layout.addWidget(self.iPostFileOpen,0,2)
        spacer13 = QSpacerItem(20,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer13,0,5)
        spacer13_2 = QSpacerItem(20,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer13_2,0,7)

        self.pPostFileSave = QPushButton(self.groupBox10,"pPostFileSave")

        groupBox10Layout.addWidget(self.pPostFileSave,0,6)

        self.pPostFilePostmap = QPushButton(self.groupBox10,"pPostFilePostmap")

        groupBox10Layout.addWidget(self.pPostFilePostmap,0,8)
        spacer17 = QSpacerItem(110,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer17,0,9)

        TabPageLayout_3.addWidget(self.groupBox10,1,0)
        self.wKorreio.insertTab(self.TabPage_3,QString.fromLatin1(""))

        self.TabPage_4 = QWidget(self.wKorreio,"TabPage_4")
        TabPageLayout_4 = QGridLayout(self.TabPage_4,1,1,8,6,"TabPageLayout_4")

        self.pQueueLoad = QPushButton(self.TabPage_4,"pQueueLoad")
        self.pQueueLoad.setMinimumSize(QSize(87,0))
        self.pQueueLoad.setMaximumSize(QSize(87,32767))

        TabPageLayout_4.addWidget(self.pQueueLoad,1,0)

        self.pQueueDel = QPushButton(self.TabPage_4,"pQueueDel")

        TabPageLayout_4.addWidget(self.pQueueDel,1,2)
        spacer2_2 = QSpacerItem(730,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout_4.addItem(spacer2_2,1,1)

        self.splitter7 = QSplitter(self.TabPage_4,"splitter7")
        self.splitter7.setOrientation(QSplitter.Horizontal)

        self.lvQueue = QListView(self.splitter7,"lvQueue")
        self.lvQueue.addColumn(self.__tr("Remetente"))
        self.lvQueue.addColumn(self.__tr("Items"))
        self.lvQueue.setMinimumSize(QSize(400,0))
        self.lvQueue.setAllColumnsShowFocus(1)
        self.lvQueue.setShowSortIndicator(1)
        self.lvQueue.setRootIsDecorated(1)
        self.lvQueue.setResizeMode(QListView.LastColumn)

        self.iQueueMessage = QTextEdit(self.splitter7,"iQueueMessage")

        TabPageLayout_4.addMultiCellWidget(self.splitter7,0,0,0,2)
        self.wKorreio.insertTab(self.TabPage_4,QString.fromLatin1(""))

        self.tabConfig = QWidget(self.wKorreio,"tabConfig")
        tabConfigLayout = QGridLayout(self.tabConfig,1,1,8,6,"tabConfigLayout")

        self.splitter7_2 = QSplitter(self.tabConfig,"splitter7_2")
        self.splitter7_2.setOrientation(QSplitter.Horizontal)

        LayoutWidget_5 = QWidget(self.splitter7_2,"layout16")
        layout16 = QVBoxLayout(LayoutWidget_5,0,6,"layout16")

        self.lvConfig = QListView(LayoutWidget_5,"lvConfig")
        self.lvConfig.addColumn(self.__tr("Menu"))
        self.lvConfig.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Expanding,0,0,self.lvConfig.sizePolicy().hasHeightForWidth()))
        self.lvConfig.setMargin(0)
        self.lvConfig.setShowSortIndicator(1)
        self.lvConfig.setRootIsDecorated(1)
        self.lvConfig.setResizeMode(QListView.LastColumn)
        layout16.addWidget(self.lvConfig)
        spacer6 = QSpacerItem(260,31,QSizePolicy.Fixed,QSizePolicy.Minimum)
        layout16.addItem(spacer6)

        LayoutWidget_6 = QWidget(self.splitter7_2,"layout18")
        layout18 = QVBoxLayout(LayoutWidget_6,0,6,"layout18")

        self.wsConfig = QWidgetStack(LayoutWidget_6,"wsConfig")
        self.wsConfig.setFrameShape(QWidgetStack.StyledPanel)
        self.wsConfig.setFrameShadow(QWidgetStack.Raised)
        self.wsConfig.setMargin(0)

        self.sServLdap = QWidget(self.wsConfig,"sServLdap")
        sServLdapLayout = QGridLayout(self.sServLdap,1,1,8,6,"sServLdapLayout")

        self.frame8 = QFrame(self.sServLdap,"frame8")
        self.frame8.setFrameShape(QFrame.NoFrame)
        self.frame8.setFrameShadow(QFrame.Raised)
        frame8Layout = QGridLayout(self.frame8,1,1,12,6,"frame8Layout")

        self.textLabel4 = QLabel(self.frame8,"textLabel4")
        self.textLabel4.setMinimumSize(QSize(100,0))
        self.textLabel4.setMaximumSize(QSize(100,32767))

        frame8Layout.addWidget(self.textLabel4,0,0)

        self.line5 = QFrame(self.frame8,"line5")
        self.line5.setFrameShape(QFrame.HLine)
        self.line5.setFrameShadow(QFrame.Sunken)
        self.line5.setFrameShape(QFrame.HLine)

        frame8Layout.addMultiCellWidget(self.line5,1,1,0,6)

        self.tLdapUser = QLabel(self.frame8,"tLdapUser")

        frame8Layout.addWidget(self.tLdapUser,5,0)
        spacer42 = QSpacerItem(75,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame8Layout.addItem(spacer42,3,6)

        self.tLdapPass = QLabel(self.frame8,"tLdapPass")

        frame8Layout.addWidget(self.tLdapPass,6,0)

        self.tLdapName = QLabel(self.frame8,"tLdapName")

        frame8Layout.addWidget(self.tLdapName,2,0)

        self.tLdapHost = QLabel(self.frame8,"tLdapHost")

        frame8Layout.addWidget(self.tLdapHost,3,0)

        self.tLdapPort = QLabel(self.frame8,"tLdapPort")

        frame8Layout.addWidget(self.tLdapPort,3,4)
        spacer42_2 = QSpacerItem(75,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame8Layout.addItem(spacer42_2,4,6)
        spacer41 = QSpacerItem(20,140,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame8Layout.addItem(spacer41,9,1)

        self.tLdapBaseDN = QLabel(self.frame8,"tLdapBaseDN")

        frame8Layout.addWidget(self.tLdapBaseDN,4,0)

        self.cbLdapConnection = QComboBox(0,self.frame8,"cbLdapConnection")
        self.cbLdapConnection.setMinimumSize(QSize(230,0))
        self.cbLdapConnection.setMaximumSize(QSize(230,32767))

        frame8Layout.addMultiCellWidget(self.cbLdapConnection,0,0,1,2)

        self.pConfDelLdapConnection = QPushButton(self.frame8,"pConfDelLdapConnection")
        self.pConfDelLdapConnection.setMinimumSize(QSize(40,0))
        self.pConfDelLdapConnection.setMaximumSize(QSize(40,32767))

        frame8Layout.addWidget(self.pConfDelLdapConnection,0,3)

        self.iLdapConnection = QLineEdit(self.frame8,"iLdapConnection")

        frame8Layout.addMultiCellWidget(self.iLdapConnection,2,2,1,3)

        self.cbLdapMode = QComboBox(0,self.frame8,"cbLdapMode")
        self.cbLdapMode.setMaximumSize(QSize(80,32767))

        frame8Layout.addWidget(self.cbLdapMode,3,1)

        self.iLdapHost = QLineEdit(self.frame8,"iLdapHost")

        frame8Layout.addMultiCellWidget(self.iLdapHost,3,3,2,3)

        self.iLdapPort = QLineEdit(self.frame8,"iLdapPort")
        self.iLdapPort.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed,0,0,self.iLdapPort.sizePolicy().hasHeightForWidth()))
        self.iLdapPort.setMinimumSize(QSize(50,0))
        self.iLdapPort.setMaximumSize(QSize(50,32767))

        frame8Layout.addWidget(self.iLdapPort,3,5)

        self.cbLdapBaseDN = QComboBox(0,self.frame8,"cbLdapBaseDN")
        self.cbLdapBaseDN.setEditable(1)

        frame8Layout.addMultiCellWidget(self.cbLdapBaseDN,4,4,1,3)

        self.pGetBaseDN = QPushButton(self.frame8,"pGetBaseDN")
        self.pGetBaseDN.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed,0,0,self.pGetBaseDN.sizePolicy().hasHeightForWidth()))

        frame8Layout.addMultiCellWidget(self.pGetBaseDN,4,4,4,5)

        self.iLdapUser = QLineEdit(self.frame8,"iLdapUser")

        frame8Layout.addMultiCellWidget(self.iLdapUser,5,5,1,3)

        self.iLdapPass = QLineEdit(self.frame8,"iLdapPass")
        self.iLdapPass.setEchoMode(QLineEdit.Password)

        frame8Layout.addMultiCellWidget(self.iLdapPass,6,6,1,3)

        self.cLdapRef = QCheckBox(self.frame8,"cLdapRef")

        frame8Layout.addMultiCellWidget(self.cLdapRef,7,7,0,1)

        self.cLdapCert = QCheckBox(self.frame8,"cLdapCert")

        frame8Layout.addMultiCellWidget(self.cLdapCert,8,8,0,3)

        sServLdapLayout.addWidget(self.frame8,1,0)

        layout26 = QVBoxLayout(None,0,0,"layout26")

        self.textLabel3_3_3 = QLabel(self.sServLdap,"textLabel3_3_3")
        self.textLabel3_3_3.setMaximumSize(QSize(32767,21))
        layout26.addWidget(self.textLabel3_3_3)

        self.line24_2 = QFrame(self.sServLdap,"line24_2")
        self.line24_2.setFrameShape(QFrame.HLine)
        self.line24_2.setFrameShadow(QFrame.Sunken)
        self.line24_2.setFrameShape(QFrame.HLine)
        layout26.addWidget(self.line24_2)

        sServLdapLayout.addLayout(layout26,0,0)
        self.wsConfig.addWidget(self.sServLdap,0)

        self.WStackPage_8 = QWidget(self.wsConfig,"WStackPage_8")
        WStackPageLayout_7 = QGridLayout(self.WStackPage_8,1,1,8,6,"WStackPageLayout_7")

        self.frame7 = QFrame(self.WStackPage_8,"frame7")
        self.frame7.setFrameShape(QFrame.NoFrame)
        self.frame7.setFrameShadow(QFrame.Raised)
        frame7Layout = QGridLayout(self.frame7,1,1,12,6,"frame7Layout")

        self.textLabel6_2 = QLabel(self.frame7,"textLabel6_2")
        self.textLabel6_2.setMinimumSize(QSize(100,0))
        self.textLabel6_2.setMaximumSize(QSize(100,32767))

        frame7Layout.addWidget(self.textLabel6_2,0,0)

        self.tCyrusPartition_3 = QLabel(self.frame7,"tCyrusPartition_3")

        frame7Layout.addWidget(self.tCyrusPartition_3,7,0)

        self.tCyrusPartition = QLabel(self.frame7,"tCyrusPartition")

        frame7Layout.addWidget(self.tCyrusPartition,6,0)

        self.tCyrusUser = QLabel(self.frame7,"tCyrusUser")

        frame7Layout.addWidget(self.tCyrusUser,4,0)

        self.tCyrusPass = QLabel(self.frame7,"tCyrusPass")

        frame7Layout.addWidget(self.tCyrusPass,5,0)
        spacer49 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7Layout.addItem(spacer49,3,7)
        spacer69 = QSpacerItem(16,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        frame7Layout.addItem(spacer69,7,2)

        self.textLabel7_2 = QLabel(self.frame7,"textLabel7_2")

        frame7Layout.addWidget(self.textLabel7_2,2,0)
        spacer71 = QSpacerItem(180,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7Layout.addMultiCell(spacer71,7,7,3,4)

        self.tCyrusHost = QLabel(self.frame7,"tCyrusHost")

        frame7Layout.addWidget(self.tCyrusHost,3,0)

        self.tCyrusPort = QLabel(self.frame7,"tCyrusPort")

        frame7Layout.addWidget(self.tCyrusPort,3,5)

        self.line6 = QFrame(self.frame7,"line6")
        self.line6.setFrameShape(QFrame.HLine)
        self.line6.setFrameShadow(QFrame.Sunken)
        self.line6.setFrameShape(QFrame.HLine)

        frame7Layout.addMultiCellWidget(self.line6,1,1,0,7)
        spacer48 = QSpacerItem(21,240,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame7Layout.addItem(spacer48,8,3)

        self.cbCyrusConnection = QComboBox(0,self.frame7,"cbCyrusConnection")
        self.cbCyrusConnection.setMaximumSize(QSize(230,32767))

        frame7Layout.addMultiCellWidget(self.cbCyrusConnection,0,0,1,3)

        self.pConfDelImapConnection = QPushButton(self.frame7,"pConfDelImapConnection")
        self.pConfDelImapConnection.setMinimumSize(QSize(40,0))
        self.pConfDelImapConnection.setMaximumSize(QSize(40,32767))

        frame7Layout.addWidget(self.pConfDelImapConnection,0,4)

        self.iCyrusConnection = QLineEdit(self.frame7,"iCyrusConnection")

        frame7Layout.addMultiCellWidget(self.iCyrusConnection,2,2,1,4)

        self.cbCyrusMode = QComboBox(0,self.frame7,"cbCyrusMode")

        frame7Layout.addMultiCellWidget(self.cbCyrusMode,3,3,1,2)

        self.iCyrusHost = QLineEdit(self.frame7,"iCyrusHost")

        frame7Layout.addMultiCellWidget(self.iCyrusHost,3,3,3,4)

        self.iCyrusPort = QLineEdit(self.frame7,"iCyrusPort")
        self.iCyrusPort.setMinimumSize(QSize(50,0))
        self.iCyrusPort.setMaximumSize(QSize(50,32767))

        frame7Layout.addWidget(self.iCyrusPort,3,6)

        self.iCyrusUser = QLineEdit(self.frame7,"iCyrusUser")

        frame7Layout.addMultiCellWidget(self.iCyrusUser,4,4,1,4)

        self.iCyrusPass = QLineEdit(self.frame7,"iCyrusPass")
        self.iCyrusPass.setEchoMode(QLineEdit.Password)

        frame7Layout.addMultiCellWidget(self.iCyrusPass,5,5,1,4)

        self.iCyrusPart = QLineEdit(self.frame7,"iCyrusPart")

        frame7Layout.addMultiCellWidget(self.iCyrusPart,6,6,1,4)

        self.iCyrusSievePort = QLineEdit(self.frame7,"iCyrusSievePort")
        self.iCyrusSievePort.setMinimumSize(QSize(60,0))
        self.iCyrusSievePort.setMaximumSize(QSize(60,32767))

        frame7Layout.addWidget(self.iCyrusSievePort,7,1)

        WStackPageLayout_7.addWidget(self.frame7,1,0)

        layout27 = QVBoxLayout(None,0,0,"layout27")

        self.textLabel3_3_2 = QLabel(self.WStackPage_8,"textLabel3_3_2")
        self.textLabel3_3_2.setMaximumSize(QSize(32767,21))
        layout27.addWidget(self.textLabel3_3_2)

        self.line25 = QFrame(self.WStackPage_8,"line25")
        self.line25.setFrameShape(QFrame.HLine)
        self.line25.setFrameShadow(QFrame.Sunken)
        self.line25.setFrameShape(QFrame.HLine)
        layout27.addWidget(self.line25)

        WStackPageLayout_7.addLayout(layout27,0,0)
        self.wsConfig.addWidget(self.WStackPage_8,1)

        self.WStackPage_9 = QWidget(self.wsConfig,"WStackPage_9")
        WStackPageLayout_8 = QGridLayout(self.WStackPage_9,1,1,8,6,"WStackPageLayout_8")

        self.frame4 = QFrame(self.WStackPage_9,"frame4")
        self.frame4.setFrameShape(QFrame.NoFrame)
        self.frame4.setFrameShadow(QFrame.Raised)
        frame4Layout = QGridLayout(self.frame4,1,1,12,6,"frame4Layout")

        self.line7 = QFrame(self.frame4,"line7")
        self.line7.setFrameShape(QFrame.HLine)
        self.line7.setFrameShadow(QFrame.Sunken)
        self.line7.setFrameShape(QFrame.HLine)

        frame4Layout.addMultiCellWidget(self.line7,1,1,0,5)

        self.textLabel8 = QLabel(self.frame4,"textLabel8")
        self.textLabel8.setMinimumSize(QSize(100,0))

        frame4Layout.addWidget(self.textLabel8,0,0)
        spacer51 = QSpacerItem(20,220,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame4Layout.addItem(spacer51,6,1)

        self.tCyrusPass_2 = QLabel(self.frame4,"tCyrusPass_2")

        frame4Layout.addWidget(self.tCyrusPass_2,5,0)

        self.textLabel9 = QLabel(self.frame4,"textLabel9")

        frame4Layout.addWidget(self.textLabel9,2,0)

        self.tCyrusHost_2 = QLabel(self.frame4,"tCyrusHost_2")

        frame4Layout.addWidget(self.tCyrusHost_2,3,0)

        self.tCyrusPort_2 = QLabel(self.frame4,"tCyrusPort_2")

        frame4Layout.addWidget(self.tCyrusPort_2,3,3)

        self.tCyrusUser_2 = QLabel(self.frame4,"tCyrusUser_2")

        frame4Layout.addWidget(self.tCyrusUser_2,4,0)
        spacer52 = QSpacerItem(60,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame4Layout.addItem(spacer52,3,5)

        self.cbSSHConnection = QComboBox(0,self.frame4,"cbSSHConnection")
        self.cbSSHConnection.setMinimumSize(QSize(230,0))

        frame4Layout.addWidget(self.cbSSHConnection,0,1)

        self.pConfDelSshConnection = QPushButton(self.frame4,"pConfDelSshConnection")
        self.pConfDelSshConnection.setMinimumSize(QSize(40,0))
        self.pConfDelSshConnection.setMaximumSize(QSize(40,32767))

        frame4Layout.addWidget(self.pConfDelSshConnection,0,2)

        self.iSSHConnection = QLineEdit(self.frame4,"iSSHConnection")

        frame4Layout.addMultiCellWidget(self.iSSHConnection,2,2,1,2)

        self.iSshHost = QLineEdit(self.frame4,"iSshHost")

        frame4Layout.addMultiCellWidget(self.iSshHost,3,3,1,2)

        self.iSshPort = QLineEdit(self.frame4,"iSshPort")
        self.iSshPort.setMinimumSize(QSize(50,0))
        self.iSshPort.setMaximumSize(QSize(50,32767))

        frame4Layout.addWidget(self.iSshPort,3,4)

        self.iSshUser = QLineEdit(self.frame4,"iSshUser")

        frame4Layout.addMultiCellWidget(self.iSshUser,4,4,1,2)

        self.iSshPass = QLineEdit(self.frame4,"iSshPass")
        self.iSshPass.setEchoMode(QLineEdit.Password)

        frame4Layout.addMultiCellWidget(self.iSshPass,5,5,1,2)

        WStackPageLayout_8.addWidget(self.frame4,1,0)

        layout28 = QVBoxLayout(None,0,0,"layout28")

        self.textLabel3_3 = QLabel(self.WStackPage_9,"textLabel3_3")
        self.textLabel3_3.setMaximumSize(QSize(32767,21))
        layout28.addWidget(self.textLabel3_3)

        self.line26 = QFrame(self.WStackPage_9,"line26")
        self.line26.setFrameShape(QFrame.HLine)
        self.line26.setFrameShadow(QFrame.Sunken)
        self.line26.setFrameShape(QFrame.HLine)
        layout28.addWidget(self.line26)

        WStackPageLayout_8.addLayout(layout28,0,0)
        self.wsConfig.addWidget(self.WStackPage_9,2)

        self.WStackPage_10 = QWidget(self.wsConfig,"WStackPage_10")
        WStackPageLayout_9 = QGridLayout(self.WStackPage_10,1,1,8,6,"WStackPageLayout_9")
        spacer102 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_9.addItem(spacer102,7,0)

        self.frame9 = QFrame(self.WStackPage_10,"frame9")
        self.frame9.setFrameShape(QFrame.NoFrame)
        self.frame9.setFrameShadow(QFrame.Raised)
        frame9Layout = QGridLayout(self.frame9,1,1,15,6,"frame9Layout")

        self.tConfShowImapServer = QLabel(self.frame9,"tConfShowImapServer")

        frame9Layout.addWidget(self.tConfShowImapServer,0,0)

        self.tConfShowImapUser = QLabel(self.frame9,"tConfShowImapUser")

        frame9Layout.addWidget(self.tConfShowImapUser,1,0)

        self.tConfShowImapSep = QLabel(self.frame9,"tConfShowImapSep")

        frame9Layout.addWidget(self.tConfShowImapSep,2,0)

        WStackPageLayout_9.addWidget(self.frame9,2,0)

        layout21_2 = QVBoxLayout(None,0,0,"layout21_2")

        self.textLabel10 = QLabel(self.WStackPage_10,"textLabel10")
        self.textLabel10.setMaximumSize(QSize(32767,20))
        layout21_2.addWidget(self.textLabel10)

        self.line19 = QFrame(self.WStackPage_10,"line19")
        self.line19.setFrameShape(QFrame.HLine)
        self.line19.setFrameShadow(QFrame.Sunken)
        self.line19.setFrameShape(QFrame.HLine)
        layout21_2.addWidget(self.line19)

        WStackPageLayout_9.addLayout(layout21_2,1,0)

        self.frame11 = QFrame(self.WStackPage_10,"frame11")
        self.frame11.setFrameShape(QFrame.NoFrame)
        self.frame11.setFrameShadow(QFrame.Raised)
        frame11Layout = QGridLayout(self.frame11,1,1,15,6,"frame11Layout")

        self.tConfShowSshServer = QLabel(self.frame11,"tConfShowSshServer")

        frame11Layout.addWidget(self.tConfShowSshServer,0,0)

        self.tConfShowSshUser = QLabel(self.frame11,"tConfShowSshUser")

        frame11Layout.addWidget(self.tConfShowSshUser,1,0)

        WStackPageLayout_9.addWidget(self.frame11,6,0)

        self.frame10 = QFrame(self.WStackPage_10,"frame10")
        self.frame10.setFrameShape(QFrame.NoFrame)
        self.frame10.setFrameShadow(QFrame.Raised)
        frame10Layout = QGridLayout(self.frame10,1,1,15,6,"frame10Layout")

        self.tConfShowLdapServer = QLabel(self.frame10,"tConfShowLdapServer")

        frame10Layout.addWidget(self.tConfShowLdapServer,0,0)

        self.tConfShowLdapUser = QLabel(self.frame10,"tConfShowLdapUser")

        frame10Layout.addWidget(self.tConfShowLdapUser,1,0)

        self.tConfShowLdapBaseDN = QLabel(self.frame10,"tConfShowLdapBaseDN")

        frame10Layout.addWidget(self.tConfShowLdapBaseDN,2,0)

        WStackPageLayout_9.addWidget(self.frame10,4,0)

        layout22 = QVBoxLayout(None,0,0,"layout22")

        self.textLabel10_2 = QLabel(self.WStackPage_10,"textLabel10_2")
        self.textLabel10_2.setMaximumSize(QSize(32767,20))
        layout22.addWidget(self.textLabel10_2)

        self.line20 = QFrame(self.WStackPage_10,"line20")
        self.line20.setFrameShape(QFrame.HLine)
        self.line20.setFrameShadow(QFrame.Sunken)
        self.line20.setFrameShape(QFrame.HLine)
        layout22.addWidget(self.line20)

        WStackPageLayout_9.addLayout(layout22,3,0)

        layout23 = QVBoxLayout(None,0,0,"layout23")

        self.textLabel10_3 = QLabel(self.WStackPage_10,"textLabel10_3")
        self.textLabel10_3.setMaximumSize(QSize(32767,20))
        layout23.addWidget(self.textLabel10_3)

        self.line21_2 = QFrame(self.WStackPage_10,"line21_2")
        self.line21_2.setFrameShape(QFrame.HLine)
        self.line21_2.setFrameShadow(QFrame.Sunken)
        self.line21_2.setFrameShape(QFrame.HLine)
        layout23.addWidget(self.line21_2)

        WStackPageLayout_9.addLayout(layout23,5,0)
        spacer70 = QSpacerItem(461,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_9.addItem(spacer70,0,0)
        self.wsConfig.addWidget(self.WStackPage_10,3)

        self.WStackPage_11 = QWidget(self.wsConfig,"WStackPage_11")
        WStackPageLayout_10 = QGridLayout(self.WStackPage_11,1,1,8,6,"WStackPageLayout_10")

        self.frame7_2 = QFrame(self.WStackPage_11,"frame7_2")
        self.frame7_2.setFrameShape(QFrame.NoFrame)
        self.frame7_2.setFrameShadow(QFrame.Raised)
        frame7_2Layout = QGridLayout(self.frame7_2,1,1,12,6,"frame7_2Layout")
        spacer62 = QSpacerItem(41,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_2Layout.addItem(spacer62,2,4)

        self.line6_2 = QFrame(self.frame7_2,"line6_2")
        self.line6_2.setFrameShape(QFrame.HLine)
        self.line6_2.setFrameShadow(QFrame.Sunken)
        self.line6_2.setFrameShape(QFrame.HLine)

        frame7_2Layout.addMultiCellWidget(self.line6_2,3,3,0,4)

        self.textLabel1_9 = QLabel(self.frame7_2,"textLabel1_9")

        frame7_2Layout.addMultiCellWidget(self.textLabel1_9,0,0,0,3)

        self.lvConfLdap = QListView(self.frame7_2,"lvConfLdap")
        self.lvConfLdap.addColumn(self.__tr("Attributo"))
        self.lvConfLdap.addColumn(self.__tr("Valor"))
        self.lvConfLdap.setMinimumSize(QSize(0,250))
        self.lvConfLdap.setAllColumnsShowFocus(1)
        self.lvConfLdap.setRootIsDecorated(1)
        self.lvConfLdap.setResizeMode(QListView.AllColumns)

        frame7_2Layout.addMultiCellWidget(self.lvConfLdap,1,1,0,4)

        self.iConfLdapAttr = QLineEdit(self.frame7_2,"iConfLdapAttr")

        frame7_2Layout.addWidget(self.iConfLdapAttr,2,0)

        self.iConfLdapValue = QLineEdit(self.frame7_2,"iConfLdapValue")

        frame7_2Layout.addWidget(self.iConfLdapValue,2,1)

        self.pConfLdapAddItem = QPushButton(self.frame7_2,"pConfLdapAddItem")
        self.pConfLdapAddItem.setMinimumSize(QSize(30,0))
        self.pConfLdapAddItem.setMaximumSize(QSize(30,32767))

        frame7_2Layout.addWidget(self.pConfLdapAddItem,2,2)

        self.pConfLdapDelItem = QPushButton(self.frame7_2,"pConfLdapDelItem")
        self.pConfLdapDelItem.setMinimumSize(QSize(30,0))
        self.pConfLdapDelItem.setMaximumSize(QSize(30,32767))

        frame7_2Layout.addWidget(self.pConfLdapDelItem,2,3)
        spacer48_2 = QSpacerItem(21,130,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame7_2Layout.addItem(spacer48_2,4,0)

        WStackPageLayout_10.addWidget(self.frame7_2,1,0)

        layout24 = QVBoxLayout(None,0,0,"layout24")

        self.textLabel3_3_2_2 = QLabel(self.WStackPage_11,"textLabel3_3_2_2")
        self.textLabel3_3_2_2.setMaximumSize(QSize(32767,21))
        layout24.addWidget(self.textLabel3_3_2_2)

        self.line22_4 = QFrame(self.WStackPage_11,"line22_4")
        self.line22_4.setFrameShape(QFrame.HLine)
        self.line22_4.setFrameShadow(QFrame.Sunken)
        self.line22_4.setFrameShape(QFrame.HLine)
        layout24.addWidget(self.line22_4)

        WStackPageLayout_10.addLayout(layout24,0,0)
        self.wsConfig.addWidget(self.WStackPage_11,4)

        self.WStackPage_12 = QWidget(self.wsConfig,"WStackPage_12")
        WStackPageLayout_11 = QGridLayout(self.WStackPage_12,1,1,8,6,"WStackPageLayout_11")

        self.frame7_3 = QFrame(self.WStackPage_12,"frame7_3")
        self.frame7_3.setFrameShape(QFrame.NoFrame)
        self.frame7_3.setFrameShadow(QFrame.Raised)
        frame7_3Layout = QGridLayout(self.frame7_3,1,1,12,6,"frame7_3Layout")

        self.textLabel6_2_3 = QLabel(self.frame7_3,"textLabel6_2_3")
        self.textLabel6_2_3.setMinimumSize(QSize(100,0))

        frame7_3Layout.addWidget(self.textLabel6_2_3,0,0)
        spacer57 = QSpacerItem(150,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addMultiCell(spacer57,1,1,4,6)

        self.textLabel7_2_3 = QLabel(self.frame7_3,"textLabel7_2_3")

        frame7_3Layout.addWidget(self.textLabel7_2_3,3,0)
        spacer58 = QSpacerItem(171,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addMultiCell(spacer58,3,3,3,6)

        self.textLabel1_7 = QLabel(self.frame7_3,"textLabel1_7")

        frame7_3Layout.addWidget(self.textLabel1_7,3,2)

        self.tCyrusHost_4 = QLabel(self.frame7_3,"tCyrusHost_4")

        frame7_3Layout.addWidget(self.tCyrusHost_4,5,0)
        spacer49_3 = QSpacerItem(62,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addItem(spacer49_3,5,6)
        spacer48_3 = QSpacerItem(21,80,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame7_3Layout.addItem(spacer48_3,8,1)
        spacer59 = QSpacerItem(211,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addMultiCell(spacer59,7,7,2,6)

        self.tCyrusUser_4 = QLabel(self.frame7_3,"tCyrusUser_4")

        frame7_3Layout.addWidget(self.tCyrusUser_4,7,0)

        self.tCyrusPort_4_2 = QLabel(self.frame7_3,"tCyrusPort_4_2")

        frame7_3Layout.addWidget(self.tCyrusPort_4_2,5,5)

        self.tCyrusPort_4 = QLabel(self.frame7_3,"tCyrusPort_4")

        frame7_3Layout.addWidget(self.tCyrusPort_4,5,2)

        self.line6_3 = QFrame(self.frame7_3,"line6_3")
        self.line6_3.setFrameShape(QFrame.HLine)
        self.line6_3.setFrameShadow(QFrame.Sunken)
        self.line6_3.setFrameShape(QFrame.HLine)

        frame7_3Layout.addMultiCellWidget(self.line6_3,2,2,0,6)

        self.line8 = QFrame(self.frame7_3,"line8")
        self.line8.setFrameShape(QFrame.HLine)
        self.line8.setFrameShadow(QFrame.Sunken)
        self.line8.setFrameShape(QFrame.HLine)

        frame7_3Layout.addMultiCellWidget(self.line8,4,4,0,6)

        self.line9 = QFrame(self.frame7_3,"line9")
        self.line9.setFrameShape(QFrame.HLine)
        self.line9.setFrameShadow(QFrame.Sunken)
        self.line9.setFrameShape(QFrame.HLine)

        frame7_3Layout.addMultiCellWidget(self.line9,6,6,0,6)

        self.lbConfImapFolders = QListBox(self.frame7_3,"lbConfImapFolders")
        self.lbConfImapFolders.setMinimumSize(QSize(0,100))
        self.lbConfImapFolders.setMaximumSize(QSize(32767,100))

        frame7_3Layout.addMultiCellWidget(self.lbConfImapFolders,0,0,1,2)

        self.iConfImapFolder = QLineEdit(self.frame7_3,"iConfImapFolder")

        frame7_3Layout.addMultiCellWidget(self.iConfImapFolder,1,1,1,2)

        self.pConfImapFoldersDel = QPushButton(self.frame7_3,"pConfImapFoldersDel")
        self.pConfImapFoldersDel.setMinimumSize(QSize(30,0))
        self.pConfImapFoldersDel.setMaximumSize(QSize(30,32767))

        frame7_3Layout.addWidget(self.pConfImapFoldersDel,0,3)

        self.pConfImapFoldersAdd = QPushButton(self.frame7_3,"pConfImapFoldersAdd")
        self.pConfImapFoldersAdd.setMinimumSize(QSize(30,0))
        self.pConfImapFoldersAdd.setMaximumSize(QSize(30,32767))

        frame7_3Layout.addWidget(self.pConfImapFoldersAdd,1,3)

        self.iConfImapQuota = QLineEdit(self.frame7_3,"iConfImapQuota")

        frame7_3Layout.addWidget(self.iConfImapQuota,3,1)

        self.iConfImapExpire = QLineEdit(self.frame7_3,"iConfImapExpire")

        frame7_3Layout.addWidget(self.iConfImapExpire,5,1)

        self.iConfImapExpireDays = QLineEdit(self.frame7_3,"iConfImapExpireDays")
        self.iConfImapExpireDays.setMinimumSize(QSize(50,0))
        self.iConfImapExpireDays.setMaximumSize(QSize(50,32767))

        frame7_3Layout.addMultiCellWidget(self.iConfImapExpireDays,5,5,3,4)

        self.iConfImapACLp = QLineEdit(self.frame7_3,"iConfImapACLp")

        frame7_3Layout.addWidget(self.iConfImapACLp,7,1)

        WStackPageLayout_11.addWidget(self.frame7_3,1,0)

        layout25 = QVBoxLayout(None,0,0,"layout25")

        self.textLabel3_3_2_3 = QLabel(self.WStackPage_12,"textLabel3_3_2_3")
        self.textLabel3_3_2_3.setMaximumSize(QSize(32767,21))
        layout25.addWidget(self.textLabel3_3_2_3)

        self.line23 = QFrame(self.WStackPage_12,"line23")
        self.line23.setFrameShape(QFrame.HLine)
        self.line23.setFrameShadow(QFrame.Sunken)
        self.line23.setFrameShape(QFrame.HLine)
        layout25.addWidget(self.line23)

        WStackPageLayout_11.addLayout(layout25,0,0)
        self.wsConfig.addWidget(self.WStackPage_12,5)
        layout18.addWidget(self.wsConfig)

        layout17 = QHBoxLayout(None,0,6,"layout17")

        self.pSaveConfig = QPushButton(LayoutWidget_6,"pSaveConfig")
        self.pSaveConfig.setMinimumSize(QSize(135,0))
        self.pSaveConfig.setMaximumSize(QSize(135,32767))
        layout17.addWidget(self.pSaveConfig)
        spacer7 = QSpacerItem(483,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout17.addItem(spacer7)
        layout18.addLayout(layout17)

        tabConfigLayout.addWidget(self.splitter7_2,0,0)
        self.wKorreio.insertTab(self.tabConfig,QString.fromLatin1(""))

        dKorreioLayout.addWidget(self.wKorreio,0,0)



        self.languageChange()

        self.resize(QSize(922,627).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)

        self.connect(self.cbCyrusConnection,SIGNAL("activated(const QString&)"),self.config_imap_set_connection)
        self.connect(self.cbCyrusMode,SIGNAL("activated(const QString&)"),self.config_imap_set_port)
        self.connect(self.cbLdapConnection,SIGNAL("activated(const QString&)"),self.config_ldap_set_connection)
        self.connect(self.cbLdapMode,SIGNAL("activated(const QString&)"),self.config_ldap_set_port)
        self.connect(self.cbLdapStack,SIGNAL("activated(const QString&)"),self.ldap_change_widgetstack)
        self.connect(self.cbPostconf,SIGNAL("activated(const QString&)"),self.postfix_postconf_changed)
        self.connect(self.cbSieveScript,SIGNAL("activated(int)"),self.sieve_get_script)
        self.connect(self.cbSSHConnection,SIGNAL("activated(const QString&)"),self.config_ssh_set_connection)
        self.connect(self.lbSieveScripts,SIGNAL("selectionChanged()"),self.sieve_use_template)
        self.connect(self.lbSieveScripts,SIGNAL("clicked(QListBoxItem*)"),self.sieve_use_template)
        self.connect(self.lvConfig,SIGNAL("selectionChanged()"),self.config_change_widgetstack)
        self.connect(self.lvCyrus,SIGNAL("currentChanged(QListViewItem*)"),self.imap_mailbox_clicked)
        self.connect(self.lvCyrus,SIGNAL("doubleClicked(QListViewItem*)"),self.imap_mailbox_doubleclicked)
        self.connect(self.lvCyrus,SIGNAL("itemRenamed(QListViewItem*,int)"),self.imap_rename_mailbox)
        self.connect(self.lvCyrusGlobal,SIGNAL("doubleClicked(QListViewItem*)"),self.imap_gmailbox_doubleclicked)
        self.connect(self.lvCyrusGlobal,SIGNAL("currentChanged(QListViewItem*)"),self.imap_gmailbox_clicked)
        self.connect(self.lvCyrusGlobal,SIGNAL("itemRenamed(QListViewItem*,int)"),self.imap_gmailbox_rename)
        self.connect(self.lvLdap,SIGNAL("selectionChanged()"),self.ldap_dn_clicked)
        self.connect(self.lvLdap,SIGNAL("doubleClicked(QListViewItem*)"),self.ldap_dn_doubleclicked)
        self.connect(self.lvLdap,SIGNAL("itemRenamed(QListViewItem*,int)"),self.ldap_rename_rdn)
        self.connect(self.lvLdapAttr,SIGNAL("doubleClicked(QListViewItem*)"),self.ldap_rename_attr_value)
        self.connect(self.lvQueue,SIGNAL("currentChanged(QListViewItem*)"),self.queue_get_message)
        self.connect(self.lvSieve,SIGNAL("clicked(QListViewItem*)"),self.sieve_user_clicked)
        self.connect(self.pConfDelImapConnection,SIGNAL("clicked()"),self.config_imap_del_connection)
        self.connect(self.pConfDelLdapConnection,SIGNAL("clicked()"),self.config_ldap_del_connection)
        self.connect(self.pConfDelSshConnection,SIGNAL("clicked()"),self.config_ssh_del_connection)
        self.connect(self.pConfImapFoldersAdd,SIGNAL("clicked()"),self.config_imap_add_default_folder)
        self.connect(self.pConfImapFoldersDel,SIGNAL("clicked()"),self.config_imap_del_default_folder)
        self.connect(self.pConfLdapAddItem,SIGNAL("clicked()"),self.config_ldap_add_attr)
        self.connect(self.pConfLdapDelItem,SIGNAL("clicked()"),self.config_ldap_del_attr)
        self.connect(self.pCyrAdd,SIGNAL("clicked()"),self.imap_create_mailbox)
        self.connect(self.pCyrDelete,SIGNAL("clicked()"),self.imap_delete_mailbox)
        self.connect(self.pCyrReconstruct,SIGNAL("clicked()"),self.imap_reconstruct)
        self.connect(self.pGetBaseDN,SIGNAL("clicked()"),self.config_ldap_get_basedn)
        self.connect(self.pImapPartitionMove,SIGNAL("clicked()"),self.imap_partition_move)
        self.connect(self.pImapPartitionSearch,SIGNAL("clicked()"),self.imap_partition_search)
        self.connect(self.pImapSearch,SIGNAL("clicked()"),self.imap_search)
        self.connect(self.pImapSelectAll,SIGNAL("clicked()"),self.imap_selectall)
        self.connect(self.pLdapAddAttr,SIGNAL("clicked()"),self.ldap_add_attr)
        self.connect(self.pLdapAddUser,SIGNAL("clicked()"),self.ldap_form_insert_user)
        self.connect(self.pLdapDelete,SIGNAL("clicked()"),self.ldap_remove_entry)
        self.connect(self.pLdapDeleteAttr,SIGNAL("clicked()"),self.ldap_remove_attr)
        self.connect(self.pLdapModify,SIGNAL("clicked()"),self.ldap_modify_clicked)
        self.connect(self.pLdapPasswd,SIGNAL("clicked()"),self.ldap_passwd)
        self.connect(self.pLdapSearch,SIGNAL("clicked()"),self.ldap_search)
        self.connect(self.pPostFileOpen,SIGNAL("clicked()"),self.postfix_open_conf)
        self.connect(self.pPostFilePostmap,SIGNAL("clicked()"),self.postfix_postmap)
        self.connect(self.pPostFileSave,SIGNAL("clicked()"),self.postfix_save_conf)
        self.connect(self.pPostMainSave,SIGNAL("clicked()"),self.postfix_postconf_save)
        self.connect(self.pPostRestart,SIGNAL("clicked()"),self.postfix_restart)
        self.connect(self.pPostStart,SIGNAL("clicked()"),self.postfix_start)
        self.connect(self.pPostStop,SIGNAL("clicked()"),self.postfix_stop)
        self.connect(self.pQueueDel,SIGNAL("clicked()"),self.queue_del_message)
        self.connect(self.pQueueLoad,SIGNAL("clicked()"),self.queue_load)
        self.connect(self.pSaveConfig,SIGNAL("clicked()"),self.config_save)
        self.connect(self.pSieveScriptActive,SIGNAL("clicked()"),self.sieve_set_script)
        self.connect(self.pSieveScriptDisable,SIGNAL("clicked()"),self.sieve_unset_script)
        self.connect(self.pSieveScriptRemove,SIGNAL("clicked()"),self.sieve_del_script)
        self.connect(self.pSieveSearch,SIGNAL("clicked()"),self.sieve_search)
        self.connect(self.pSieveSelectAll,SIGNAL("clicked()"),self.sieve_select_all)
        self.connect(self.rbPostconfAll,SIGNAL("clicked()"),self.postfix_postconf)
        self.connect(self.rbPostconfD,SIGNAL("clicked()"),self.postfix_postconf)
        self.connect(self.rbPostconfN,SIGNAL("clicked()"),self.postfix_postconf)
        self.connect(self.wKorreio,SIGNAL("currentChanged(QWidget*)"),self.korreio_module_changed)
        self.connect(self.cbACL,SIGNAL("activated(int)"),self.imap_acl_wizard)
        self.connect(self.lvImapAcl,SIGNAL("currentChanged(QListViewItem*)"),self.imap_acl_clicked)
        self.connect(self.pImapAclAdd,SIGNAL("clicked()"),self.imap_acl_add)
        self.connect(self.pImapAclDel,SIGNAL("clicked()"),self.imap_acl_del)
        self.connect(self.pLdapAddOu,SIGNAL("clicked()"),self.ldap_insert_ou)
        self.connect(self.lvImapPartition,SIGNAL("selectionChanged()"),self.imap_partition_size)
        self.connect(self.lvImapPartitionGlobal,SIGNAL("selectionChanged()"),self.imap_partition_size)
        self.connect(self.pSetExpire,SIGNAL("clicked()"),self.imap_set_annotation_expire)
        self.connect(self.pSetQuota,SIGNAL("clicked()"),self.imap_set_quota)
        self.connect(self.cbLdapBaseDN,SIGNAL("activated(int)"),self.config_ldap_set_admin)
        self.connect(self.pLdapFormBack,SIGNAL("clicked()"),self.ldap_form_back)
        self.connect(self.pLdapFormNext,SIGNAL("clicked()"),self.ldap_form_next)
        self.connect(self.cLdapFormPosix,SIGNAL("clicked()"),self.ldap_form_enable)
        self.connect(self.iLdapFormUid,SIGNAL("textChanged(const QString&)"),self.ldap_form_homeDirectory)

        self.init()


    def languageChange(self):
        self.setCaption(self.__trUtf8("\x4b\x6f\x72\x72\x65\x69\x6f\x20\x2d\x20\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\xc3\xa7\xc3\xa3\x6f\x20\x64\x65\x20\x43\x6f\x72\x72\x65\x69\x6f\x20\x45\x6c\x65\x74\x72\xc3\xb4\x6e\x69\x63\x6f"))
        self.tlConsole.setText(self.__tr("Korreio (c) Copyleft 2008 - Reinaldo de Carvalho <reinaldoc@gmail.com>"))
        self.cbLdapFilter.clear()
        self.cbLdapFilter.insertItem(self.__tr("objectClass=*"))
        self.cbLdapFilter.insertItem(self.__tr("ou=*"))
        self.cbLdapFilter.insertItem(self.__tr("cn=*"))
        self.cbLdapFilter.insertItem(self.__tr("uid=*"))
        self.cbLdapFilter.insertItem(self.__tr("mail=*"))
        self.lvLdap.header().setLabel(0,self.__tr("Distinguished Name"))
        self.pLdapDelete.setText(self.__tr("Remover"))
        self.pLdapSearch.setText(self.__tr("Pesquisar"))
        self.cbLdapStack.clear()
        self.cbLdapStack.insertItem(self.__tr("Ldap Browser"))
        self.cbLdapStack.insertItem(self.__tr("Novo registro"))
        self.cbLdapStack.insertItem(self.__trUtf8("\x4e\x6f\x76\x6f\x20\x72\x65\x67\x69\x73\x74\x72\x6f\x20\x64\x65\x20\x55\x73\x75\xc3\xa1\x72\x69\x6f"))
        self.cbLdapStack.insertItem(self.__tr("Novo registro de Unidade"))
        self.cbLdapStack.insertItem(self.__tr("Trocar Senha"))
        self.lvLdapAttr.header().setLabel(0,self.__tr("Atributo"))
        self.lvLdapAttr.header().setLabel(1,self.__tr("Valor"))
        self.cbLdapAttr.clear()
        self.cbLdapAttr.insertItem(QString.null)
        self.cbLdapAttr.insertItem(self.__tr("objectClass"))
        self.cbLdapAttr.insertItem(self.__tr("structuralObjectClass"))
        self.cbLdapAttr.insertItem(self.__tr("uid"))
        self.cbLdapAttr.insertItem(self.__tr("cn"))
        self.cbLdapAttr.insertItem(self.__tr("sn"))
        self.cbLdapAttr.insertItem(self.__tr("mail"))
        self.cbLdapAttr.insertItem(self.__tr("gecos"))
        self.cbLdapAttr.insertItem(self.__tr("description"))
        self.cbLdapAttr.insertItem(self.__tr("homeDirectory"))
        self.cbLdapAttr.insertItem(self.__tr("loginShell"))
        self.cbLdapAttr.insertItem(self.__tr("uidNumber"))
        self.cbLdapAttr.insertItem(self.__tr("gidNumber"))
        self.cbLdapAttr.insertItem(self.__tr("userPassword"))
        self.cbLdapAttr.insertItem(self.__tr("shadowLastChange"))
        self.cbLdapAttr.insertItem(self.__tr("shadowMin"))
        self.cbLdapAttr.insertItem(self.__tr("shadowMax"))
        self.cbLdapAttr.insertItem(self.__tr("shadowWarning"))
        self.cbLdapAttr.insertItem(self.__tr("shadowInactive"))
        self.cbLdapAttr.insertItem(self.__tr("shadowExpire"))
        self.cbLdapAttr.insertItem(self.__tr("shadowFlag"))
        self.cbLdapAttr.insertItem(self.__tr("carLicense"))
        self.cbLdapAttr.insertItem(self.__tr("displayName"))
        self.cbLdapAttr.insertItem(self.__tr("homePhone"))
        self.cbLdapAttr.insertItem(self.__tr("l"))
        self.cbLdapAttr.insertItem(self.__tr("street"))
        self.cbLdapAttr.insertItem(self.__tr("postalCode"))
        self.cbLdapAttr.insertItem(self.__tr("o"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLMPassword"))
        self.cbLdapAttr.insertItem(self.__tr("sambaNTPassword"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdLastSet"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogoffTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaKickoffTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdCanChange"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdMustChange"))
        self.cbLdapAttr.insertItem(self.__tr("sambaAcctFlags"))
        self.cbLdapAttr.insertItem(self.__tr("sambaHomePath"))
        self.cbLdapAttr.insertItem(self.__tr("sambaHomeDrive"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonScript"))
        self.cbLdapAttr.insertItem(self.__tr("sambaProfilePath"))
        self.cbLdapAttr.insertItem(self.__tr("sambaUserWorkstations"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPrimaryGroupSID"))
        self.cbLdapAttr.insertItem(self.__tr("sambaDomainName"))
        self.cbLdapAttr.insertItem(self.__tr("sambaMungedDial"))
        self.cbLdapAttr.insertItem(self.__tr("sambaBadPasswordCount"))
        self.cbLdapAttr.insertItem(self.__tr("sambaBadPasswordTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPasswordHistory"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonHours"))
        self.cbLdapAttr.insertItem(self.__tr("mailAlternateAddress"))
        self.cbLdapAttr.insertItem(self.__tr("ipHostNumber"))
        self.cbLdapAttr.insertItem(self.__tr("owner"))
        self.cbLdapAttr.insertItem(self.__tr("manager"))
        self.cbLdapAttr.insertItem(self.__tr("serialNumber"))
        self.cbLdapAttr.insertItem(self.__tr("member"))
        self.cbLdapValue.clear()
        self.cbLdapValue.insertItem(QString.null)
        self.cbLdapValue.insertItem(self.__tr("inetOrgPerson"))
        self.cbLdapValue.insertItem(self.__tr("posixAccount"))
        self.cbLdapValue.insertItem(self.__tr("sambaSamAccount"))
        self.cbLdapValue.insertItem(self.__tr("shadowAccount"))
        self.cbLdapValue.insertItem(self.__tr("top"))
        self.cbLdapValue.insertItem(self.__tr("simpleSecurityObject"))
        self.cbLdapValue.insertItem(self.__tr("organization"))
        self.cbLdapValue.insertItem(self.__tr("organizationalUnit"))
        self.cbLdapValue.insertItem(self.__tr("organizationalRole"))
        self.cbLdapValue.insertItem(self.__tr("groupOfNames"))
        self.cbLdapValue.insertItem(self.__tr("device"))
        self.cbLdapValue.insertItem(self.__tr("ipHost"))
        self.cbLdapValue.insertItem(self.__tr("ipNetwork"))
        self.cbLdapValue.insertItem(self.__tr("referral"))
        self.cbLdapValue.insertItem(self.__tr("extensibleObject"))
        self.pLdapAddAttr.setText(self.__tr("+"))
        self.pLdapDeleteAttr.setText(self.__tr("-"))
        self.pLdapModify.setText(self.__tr("Aplicar"))
        self.textLabel1_2_3.setText(self.__tr("<b>inetOrgPerson</b>"))
        self.textLabel3_2.setText(self.__tr("Nome:"))
        QToolTip.add(self.textLabel3_2,self.__tr("<b>cn</b>"))
        QToolTip.add(self.iLdapFormCn,self.__tr("<b>Nome Completo</b>"))
        self.textLabel5.setText(self.__tr("E-mail:"))
        QToolTip.add(self.textLabel5,self.__tr("<b>mail</b>"))
        QToolTip.add(self.iLdapFormMail,self.__tr("<b>usuario@exemplo.com.br</b>"))
        self.textLabel5_3.setText(self.__tr("Localidade:"))
        QToolTip.add(self.textLabel5_3,self.__tr("<b>l</b>"))
        self.textLabel3_2_3.setText(self.__trUtf8("\x45\x6e\x64\x65\x72\x65\xc3\xa7\x6f\x3a"))
        QToolTip.add(self.textLabel3_2_3,self.__tr("<b>street</b>"))
        QToolTip.add(self.iLdapFormStreet,self.__tr("<b>Av. Fulano, N 123</b>"))
        QToolTip.add(self.iLdapFormL,self.__tr("<b>Bairro, Cidade, Estado</b>"))
        self.textLabel3_2_4.setText(self.__tr("CEP:"))
        QToolTip.add(self.textLabel3_2_4,self.__tr("<b>postalCode</b>"))
        QToolTip.add(self.iLdapFormPostalCode,self.__tr("<b>66000-000</b>"))
        self.textLabel5_4.setText(self.__tr("Telefone:"))
        QToolTip.add(self.textLabel5_4,self.__tr("<b>homePhone</b>"))
        QToolTip.add(self.iLdapFormHomePhone,self.__tr("<b>+55 (99) 3222-2222</b>"))
        self.textLabel1_3.setText(self.__tr("Senha:"))
        QToolTip.add(self.textLabel1_3,self.__tr("<b>userPassword</b>"))
        self.textLabel1_2_3_2.setText(self.__tr("<b>posixAccount</b>"))
        self.cLdapFormPosix.setText(QString.null)
        self.textLabel5_2_2.setText(self.__tr("uidNumber:"))
        QToolTip.add(self.textLabel5_2_2,self.__tr("<b>uidNumber</b>"))
        self.textLabel1_3_3_2.setText(self.__tr("Grupo:"))
        QToolTip.add(self.textLabel1_3_3_2,self.__tr("<b>gidNumber</b>"))
        self.iLdapFormUidNumber.setText(self.__tr("1000"))
        self.textLabel1_3_3.setText(self.__tr("Home:"))
        QToolTip.add(self.textLabel1_3_3,self.__tr("<b>homeDirectory</b>"))
        self.textLabel5_2.setText(self.__tr("Shell:"))
        QToolTip.add(self.textLabel5_2,self.__tr("<b>loginShell</b>"))
        self.iLdapFormGidNumber.setText(self.__tr("100"))
        self.textLabel3_2_2.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        QToolTip.add(self.textLabel3_2_2,self.__tr("<b>uid</b>"))
        self.iLdapFormLoginShell.setText(self.__tr("/bin/bash"))
        self.iLdapFormHomeDirectory.setText(self.__tr("/home"))
        self.textLabel1_2.setText(self.__trUtf8("\x3c\x62\x3e\x4e\x6f\x76\x6f\x20\x72\x65\x67\x69\x73\x74\x72\x6f\x20\x64\x65\x20\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3c\x2f\x62\x3e"))
        self.pLdapFormBack.setText(self.__tr("Voltar"))
        self.pLdapFormNext.setText(self.__trUtf8("\x50\x72\xc3\xb3\x78\x69\x6d\x6f"))
        self.pLdapAddUser.setText(self.__tr("Cadastrar"))
        self.textLabel1_2_4.setText(self.__tr("<b>Novo registro de Unidade</b>"))
        self.pLdapAddOu.setText(self.__tr("Cadastrar"))
        self.textLabel2_3.setText(self.__tr("Unidade (ou):"))
        self.pLdapPasswd.setText(self.__tr("Trocar"))
        self.cbUserPassword.clear()
        self.cbUserPassword.insertItem(self.__tr("{SSHA}"))
        self.cbUserPassword.insertItem(self.__tr("{SMD5}"))
        self.cbUserPassword.insertItem(self.__tr("{CRYPT}"))
        self.cbUserPassword.insertItem(self.__tr("{SHA}"))
        self.cbUserPassword.insertItem(self.__tr("{MD5}"))
        self.cbUserPassword.insertItem(self.__tr("{TEXT}"))
        self.cbLdapUserPassword.setText(self.__tr("userPassword"))
        self.textLabel1_3_2_2.setText(self.__tr("Atributo:"))
        self.textLabel1_3_2.setText(self.__tr("Senha:"))
        self.cbLdapSambaPassword.setText(self.__tr("sambaLMPassword\n"
"sambaNTPassword"))
        self.textLabel1_2_4_2.setText(self.__tr("<b>Trocar senha</b>"))
        self.wKorreio.changeTab(self.tabLdap,self.__tr("LDAP Manager"))
        self.tCyrUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.pImapSearch.setText(self.__tr("Pesquisar"))
        self.lvCyrus.header().setLabel(0,self.__tr("IMAP Mailboxes"))
        self.lvCyrusGlobal.header().setLabel(0,self.__tr("Global IMAP Mailboxes"))
        self.lvImapAcl.header().setLabel(0,self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f"))
        self.lvImapAcl.header().setLabel(1,self.__trUtf8("\x50\x65\x72\x6d\x69\x73\x73\xc3\xb5\x65\x73"))
        self.cbImapMailbox.clear()
        self.cbImapMailbox.insertItem(self.__tr("user"))
        self.cbImapMailbox.insertItem(self.__tr("global"))
        self.pCyrAdd.setText(self.__tr("+"))
        QToolTip.add(self.pCyrAdd,self.__tr("<b>Criar</b>"))
        self.pCyrDelete.setText(self.__tr("-"))
        QToolTip.add(self.pCyrDelete,self.__tr("<b>Remover</b>"))
        self.pCyrReconstruct.setText(self.__tr("R"))
        QToolTip.add(self.pCyrReconstruct,self.__tr("<b>Reconstruir</b>"))
        self.pSetQuota.setText(self.__tr("OK"))
        self.pSetExpire.setText(self.__tr("OK"))
        self.textLabel2_5.setText(self.__tr("Expirar:"))
        self.textLabel4_2_2.setText(self.__tr("<b>Annotation</b>"))
        self.textLabel4_2.setText(self.__tr("<b>Quota</b>"))
        self.textLabel1_6.setText(self.__tr("dias"))
        self.textLabel1.setText(self.__tr("Utilizado:"))
        self.textLabel2_2.setText(self.__tr("Limite:"))
        self.textLabel2.setText(self.__tr("Kbytes"))
        self.textLabel2_4.setText(self.__tr("Kbytes"))
        self.textLabel2_6.setText(self.__tr("ACL:"))
        QToolTip.add(self.iImapAclUser,self.__trUtf8("\x3c\x62\x3e\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3c\x2f\x62\x3e\x2e\x20\x55\x73\x65\x20\x61\x20\x76\xc3\xad\x72\x67\x75\x6c\x61\x20\x63\x6f\x6d\x6f\x20\x73\x65\x70\x61\x72\x61\x64\x6f\x72\x20\x70\x61\x72\x61\x20\x6d\x75\x6c\x74\x69\x70\x6c\x61\x73\x20\x41\x43\x4c\x73\x2e\x20\x4e\xc3\xa3\x6f\x20\x75\x73\x65\x20\x65\x73\x70\x61\xc3\xa7\x6f\x73\x2e"))
        self.cbACL.clear()
        self.cbACL.insertItem(QString.null)
        self.cbACL.insertItem(self.__tr("Ler"))
        self.cbACL.insertItem(self.__tr("Adicionar"))
        self.cbACL.insertItem(self.__tr("Escrever"))
        self.cbACL.insertItem(self.__tr("Entrega"))
        self.cbACL.insertItem(self.__tr("Total"))
        QToolTip.add(self.cbACL,self.__trUtf8("\x3c\x62\x3e\x4c\x3c\x2f\x62\x3e\x3a\x20\x4c\x69\x73\x74\xc3\xa1\x76\x65\x6c\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x52\x3c\x2f\x62\x3e\x3a\x20\x4c\x65\x72\x20\x6d\x65\x6e\x73\x61\x67\x65\x6e\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x53\x3c\x2f\x62\x3e\x3a\x20\x4c\x65\x72\x20\x73\x74\x61\x74\x75\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x57\x3c\x2f\x62\x3e\x3a\x20\x45\x73\x63\x72\x65\x76\x65\x72\x20\x73\x74\x61\x74\x75\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x49\x3c\x2f\x62\x3e\x3a\x20\x49\x6e\x73\x65\x72\x69\x72\x20\x6d\x65\x6e\x73\x61\x67\x65\x6d\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x43\x3c\x2f\x62\x3e\x3a\x20\x43\x72\x69\x61\x72\x20\x65\x20\x72\x65\x6d\x6f\x76\x65\x72\x20\x73\x75\x62\x2d\x70\x61\x73\x74\x61\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x44\x3c\x2f\x62\x3e\x3a\x20\x52\x65\x6d\x6f\x76\x65\x72\x20\x6d\x65\x6e\x73\x61\x67\x65\x6e\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x50\x3c\x2f\x62\x3e\x3a\x20\x53\x75\x62\x6d\x69\x73\x73\xc3\xa3\x6f\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x41\x3c\x2f\x62\x3e\x3a\x20\x41\x6c\x74\x65\x72\x61\x72\x20\x70\x65\x72\x6d\x69\x73\x73\xc3\xb5\x65\x73"))
        QWhatsThis.add(self.cbACL,QString.null)
        self.pImapAclAdd.setText(self.__tr("+"))
        QToolTip.add(self.pImapAclAdd,self.__tr("<b>Adicionar</b>"))
        self.pImapAclDel.setText(self.__tr("-"))
        QToolTip.add(self.pImapAclDel,self.__tr("<b>Remover</b>"))
        self.wKorreio.changeTab(self.tabCyrus,self.__tr("Imap Manager"))
        self.lvImapPartition.header().setLabel(0,self.__tr("IMAP Mailboxes"))
        self.lvImapPartition.header().setLabel(1,self.__tr("Partition"))
        self.lvImapPartition.header().setLabel(2,self.__tr("Tamanho"))
        self.lvImapPartitionGlobal.header().setLabel(0,self.__tr("Global IMAP Mailboxes"))
        self.lvImapPartitionGlobal.header().setLabel(1,self.__tr("Partition"))
        self.lvImapPartitionGlobal.header().setLabel(2,self.__tr("Tamanho"))
        self.tCyrUser_2.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.pImapPartitionSearch.setText(self.__tr("Pesquisar"))
        self.cImapSize.setText(self.__tr("Tamanho"))
        self.pImapSelectAll.setText(self.__tr("Selecionar todos"))
        self.textLabel1_2_2.setText(self.__tr("Partition:"))
        self.pImapPartitionMove.setText(self.__tr("Mover"))
        self.tlImapSize.setText(self.__tr("0 Mbytes"))
        self.cImapSizeUpdate.setText(QString.null)
        self.wKorreio.changeTab(self.TabPage,self.__tr("Imap Partitions"))
        self.tCyrUser_2_2.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.cSieveScript.setText(self.__tr("Script ativo"))
        self.pSieveSearch.setText(self.__tr("Pesquisar"))
        self.pSieveSelectAll.setText(self.__tr("Selecionar todos"))
        self.lvSieve.header().setLabel(0,self.__tr("IMAP Users"))
        self.lvSieve.header().setLabel(1,self.__tr("Script ativo"))
        self.textLabel1_2_2_2.setText(self.__tr("Script:"))
        self.pSieveScriptActive.setText(self.__tr("+"))
        QToolTip.add(self.pSieveScriptActive,self.__tr("<b>Ativar</b>"))
        self.pSieveScriptDisable.setText(self.__tr("-"))
        QToolTip.add(self.pSieveScriptDisable,self.__tr("<b>Desativar</b>"))
        self.pSieveScriptRemove.setText(self.__tr("x"))
        QToolTip.add(self.pSieveScriptRemove,self.__tr("<b>Remover</b>"))
        self.lbSieveScripts.clear()
        self.lbSieveScripts.insertItem(self.__tr("Encaminhar"))
        self.lbSieveScripts.insertItem(self.__tr("Encaminhar e salvar"))
        self.lbSieveScripts.insertItem(self.__tr("Mover por remetente"))
        self.lbSieveScripts.insertItem(self.__tr("Mover por remetentes"))
        self.lbSieveScripts.insertItem(self.__tr("Descartar Spam"))
        self.lbSieveScripts.insertItem(self.__tr("Mover Spam"))
        self.lbSieveScripts.insertItem(self.__trUtf8("\x46\xc3\xa9\x72\x69\x61\x73\x2c\x20\x73\x65\x20\x6e\xc3\xa3\x6f\x2d\x53\x70\x61\x6d"))
        self.lbSieveScripts.insertItem(self.__trUtf8("\x46\xc3\xa9\x72\x69\x61\x73"))
        self.textLabel1_8.setText(self.__tr("<b>Modelos:</b>"))
        self.wKorreio.changeTab(self.TabPage_2,self.__tr("Sieve Manager"))
        self.pPostStart.setText(self.__tr("Start Postfix"))
        self.pPostStop.setText(self.__tr("Stop Postfix"))
        self.pPostRestart.setText(self.__tr("Restart Postfix"))
        self.buttonGroup2.setTitle(self.__tr("main.cf"))
        self.pPostMainSave.setText(self.__tr("Salvar"))
        self.textLabel6.setText(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xa3\x6f\x3a"))
        self.rbPostconfD.setText(self.__trUtf8("\x56\x61\x6c\x6f\x72\x65\x73\x20\x70\x61\x64\x72\xc3\xb5\x65\x73"))
        self.rbPostconfAll.setText(self.__trUtf8("\x54\x6f\x64\x61\x73\x20\x6f\x70\xc3\xa7\xc3\xb5\x65\x73"))
        self.textLabel1_4.setText(self.__tr("Modo:"))
        self.rbPostconfN.setText(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xb5\x65\x73\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x64\x61\x73"))
        self.groupBox10.setTitle(self.__tr("Editor de arquivos"))
        self.textLabel7.setText(self.__tr("Arquivo:"))
        self.pPostFileOpen.setText(self.__tr("Abrir"))
        self.iPostFileOpen.setText(self.__tr("/etc/postfix/"))
        self.pPostFileSave.setText(self.__tr("Salvar"))
        self.pPostFilePostmap.setText(self.__tr("Postmap"))
        self.wKorreio.changeTab(self.TabPage_3,self.__tr("Postfix Manager"))
        self.pQueueLoad.setText(self.__tr("Atualizar"))
        self.pQueueDel.setText(self.__tr("Remover"))
        self.lvQueue.header().setLabel(0,self.__tr("Remetente"))
        self.lvQueue.header().setLabel(1,self.__tr("Items"))
        self.wKorreio.changeTab(self.TabPage_4,self.__tr("Queue Manager"))
        self.lvConfig.header().setLabel(0,self.__tr("Menu"))
        self.lvConfig.clear()
        item_2 = QListViewItem(self.lvConfig,None)
        item_2.setOpen(1)
        item = QListViewItem(item_2,None)
        item.setText(0,self.__tr("LDAP"))
        item_2.setOpen(1)
        item = QListViewItem(item_2,item)
        item.setText(0,self.__tr("IMAP"))
        item_2.setOpen(1)
        item = QListViewItem(item_2,item)
        item.setText(0,self.__tr("SSH"))
        item_2.setText(0,self.__tr("Servidores"))

        item_3 = QListViewItem(self.lvConfig,item_2)
        item_3.setOpen(1)
        item = QListViewItem(item_3,item_2)
        item.setText(0,self.__tr("LDAP"))
        item_3.setOpen(1)
        item = QListViewItem(item_3,item)
        item.setText(0,self.__tr("IMAP"))
        item_3.setText(0,self.__trUtf8("\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73"))

        self.textLabel4.setText(self.__trUtf8("\x43\x6f\x6e\x65\x78\xc3\xa3\x6f\x3a"))
        self.tLdapUser.setText(self.__tr("User Admin:"))
        self.tLdapPass.setText(self.__tr("Senha:"))
        self.tLdapName.setText(self.__tr("Nome:"))
        self.tLdapHost.setText(self.__tr("Host:"))
        self.tLdapPort.setText(self.__tr("Port:"))
        self.tLdapBaseDN.setText(self.__tr("BaseDN:"))
        self.pConfDelLdapConnection.setText(self.__tr("Del"))
        self.cbLdapMode.clear()
        self.cbLdapMode.insertItem(self.__tr("ldap://"))
        self.cbLdapMode.insertItem(self.__tr("ldaps://"))
        self.iLdapPort.setText(self.__tr("389"))
        self.pGetBaseDN.setText(self.__tr("Get It"))
        self.cLdapRef.setText(self.__tr("Consultar referrals"))
        self.cLdapCert.setText(self.__trUtf8("\x4e\xc3\xa3\x6f\x20\x76\x65\x72\x69\x66\x69\x63\x61\x72\x20\x63\x65\x72\x74\x69\x66\x69\x63\x61\x64\x6f\x20\x53\x53\x4c\x20\x28\x72\x65\x69\x6e\x69\x63\x69\x65\x20\x6f\x20\x6b\x6f\x72\x72\x65\x69\x6f\x29"))
        self.textLabel3_3_3.setText(self.__tr("<b>Servidor LDAP</b>"))
        self.textLabel6_2.setText(self.__trUtf8("\x43\x6f\x6e\x65\x78\xc3\xa3\x6f\x3a"))
        self.tCyrusPartition_3.setText(self.__tr("Sieve port:"))
        self.tCyrusPartition.setText(self.__tr("Partition:"))
        self.tCyrusUser.setText(self.__tr("User Admin:"))
        self.tCyrusPass.setText(self.__tr("Senha:"))
        self.textLabel7_2.setText(self.__tr("Nome:"))
        self.tCyrusHost.setText(self.__tr("Host:"))
        self.tCyrusPort.setText(self.__tr("Port:"))
        self.pConfDelImapConnection.setText(self.__tr("Del"))
        self.cbCyrusMode.clear()
        self.cbCyrusMode.insertItem(self.__tr("imap://"))
        self.cbCyrusMode.insertItem(self.__tr("imaps://"))
        self.iCyrusPort.setText(self.__tr("143"))
        self.iCyrusPart.setText(QString.null)
        self.iCyrusSievePort.setText(self.__tr("2000"))
        self.textLabel3_3_2.setText(self.__tr("<b>Servidor IMAP</b>"))
        self.textLabel8.setText(self.__trUtf8("\x43\x6f\x6e\x65\x78\xc3\xa3\x6f\x3a"))
        self.tCyrusPass_2.setText(self.__tr("Senha:"))
        self.textLabel9.setText(self.__tr("Nome:"))
        self.tCyrusHost_2.setText(self.__tr("Host:"))
        self.tCyrusPort_2.setText(self.__tr("Port:"))
        self.tCyrusUser_2.setText(self.__tr("User:"))
        self.pConfDelSshConnection.setText(self.__tr("Del"))
        self.iSshPort.setText(self.__tr("22"))
        self.textLabel3_3.setText(self.__tr("<b>Servidor SSH</b>"))
        self.tConfShowImapServer.setText(self.__tr("Host:"))
        self.tConfShowImapUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.tConfShowImapSep.setText(self.__tr("Imap delimiter: desconectado"))
        self.textLabel10.setText(self.__tr("<b>Servidor IMAP</b>"))
        self.tConfShowSshServer.setText(self.__tr("Host:"))
        self.tConfShowSshUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.tConfShowLdapServer.setText(self.__tr("Host:"))
        self.tConfShowLdapUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.tConfShowLdapBaseDN.setText(self.__tr("Base:"))
        self.textLabel10_2.setText(self.__tr("<b>Servidor LDAP</b>"))
        self.textLabel10_3.setText(self.__tr("<b>Servidor SSH</b>"))
        self.textLabel1_9.setText(self.__tr("Adicionar atributos automaticamente a objectClass's:"))
        self.lvConfLdap.header().setLabel(0,self.__tr("Attributo"))
        self.lvConfLdap.header().setLabel(1,self.__tr("Valor"))
        self.lvConfLdap.clear()
        item_4 = QListViewItem(self.lvConfLdap,None)
        item_4.setOpen(1)
        item_5 = QListViewItem(item_4,None)
        item_5.setOpen(1)
        item = QListViewItem(item_5,None)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("extensibleObject"))
        item_5.setText(0,self.__tr("referral"))
        item_4.setOpen(1)
        item_6 = QListViewItem(item_4,item_5)
        item_6.setOpen(1)
        item = QListViewItem(item_6,item_5)
        item.setText(0,self.__tr("displayName"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaSID"))
        item.setText(1,self.__tr("S-0-0-00-0000000000-0000000000-0000000000-0000"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaPwdMustChange"))
        item.setText(1,self.__tr("2147483647"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaPwdLastSet"))
        item.setText(1,self.__tr("1"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaPwdCanChange"))
        item.setText(1,self.__tr("0"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaProfilePath"))
        item.setText(1,self.__tr("\\\\PDC\\profiles\\#UID#"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaPrimaryGroupSID"))
        item.setText(1,self.__tr("S-0-0-00-0000000000-0000000000-0000000000-514"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaNTPassword"))
        item.setText(1,self.__tr("XXX"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaLogonTime"))
        item.setText(1,self.__tr("0"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaLogonScript"))
        item.setText(1,self.__tr("logon.bat"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaLogoffTime"))
        item.setText(1,self.__tr("2147483647"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaLMPassword"))
        item.setText(1,self.__tr("XXX"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaKickoffTime"))
        item.setText(1,self.__tr("2147483647"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaHomePath"))
        item.setText(1,self.__tr("\\\\PDC-SRV\\#UID#"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaHomeDrive"))
        item.setText(1,self.__tr("H:"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaAccFlags"))
        item.setText(1,self.__tr("[UX]"))
        item_6.setText(0,self.__tr("sambaSamAccount"))
        item_4.setOpen(1)
        item_7 = QListViewItem(item_4,item_6)
        item_7.setOpen(1)
        item = QListViewItem(item_7,item_6)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("shadowAccount"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("sn"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("cn"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("inetOrgPerson"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("loginShell"))
        item.setText(1,self.__tr("/bin/bash"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("homeDirectory"))
        item.setText(1,self.__tr("/home/"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("gidNumber"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("uidNumber"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("uid"))
        item_7.setText(0,self.__tr("posixAccount"))
        item_4.setOpen(1)
        item_8 = QListViewItem(item_4,item_7)
        item_8.setOpen(1)
        item = QListViewItem(item_8,item_7)
        item.setText(0,self.__tr("cn"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sn"))
        item_8.setText(0,self.__tr("inetOrgPerson"))
        item_4.setText(0,self.__tr("objectClass"))

        self.pConfLdapAddItem.setText(self.__tr("+"))
        self.pConfLdapDelItem.setText(self.__tr("-"))
        self.textLabel3_3_2_2.setText(self.__trUtf8("\x3c\x62\x3e\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73\x20\x4c\x44\x41\x50\x3c\x2f\x62\x3e"))
        self.textLabel6_2_3.setText(self.__trUtf8("\x50\x61\x73\x74\x61\x73\x20\x70\x61\x64\x72\xc3\xb5\x65\x73\x3a"))
        self.textLabel7_2_3.setText(self.__trUtf8("\x51\x75\x6f\x74\x61\x20\x70\x61\x64\x72\xc3\xa3\x6f\x3a"))
        self.textLabel1_7.setText(self.__tr("KB"))
        self.tCyrusHost_4.setText(self.__tr("Auto expire:"))
        self.tCyrusUser_4.setText(self.__tr("Permitir submission:"))
        self.tCyrusPort_4_2.setText(self.__tr("dias"))
        self.tCyrusPort_4.setText(self.__tr("em"))
        self.lbConfImapFolders.clear()
        self.lbConfImapFolders.insertItem(self.__tr("Drafts"))
        self.lbConfImapFolders.insertItem(self.__tr("Sent"))
        self.lbConfImapFolders.insertItem(self.__tr("Spam"))
        self.lbConfImapFolders.insertItem(self.__tr("Trash"))
        self.pConfImapFoldersDel.setText(self.__tr("-"))
        self.pConfImapFoldersAdd.setText(self.__tr("+"))
        self.iConfImapExpire.setText(self.__tr("Spam"))
        self.iConfImapExpireDays.setText(self.__tr("30"))
        self.iConfImapACLp.setText(self.__tr("Spam"))
        self.textLabel3_3_2_3.setText(self.__trUtf8("\x3c\x62\x3e\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73\x20\x49\x4d\x41\x50\x3c\x2f\x62\x3e"))
        self.pSaveConfig.setText(self.__tr("Salvar"))
        self.wKorreio.changeTab(self.tabConfig,self.__trUtf8("\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\xc3\xa7\xc3\xb5\x65\x73"))


    def init(self):
        
        global iso2utf, utf2iso
        
        def iso2utf(string):
            return str(self.__tr(string))
        
        def utf2iso(string):
            return string.encode('iso8859-1')
        
        try:
            global sys, re, datetime, os
            import sys, re, datetime, os.path
        
            reload(sys)
            sys.setdefaultencoding("utf-8")
        
            global  sha, md5, b2a_base64, choice, letters, digits
            import sha, md5
            from binascii import b2a_base64
            from random import choice
            from string import letters, digits
        except:
            print "Error importing core modules."
            sys.exit()
        
        modfailed = []
        
        try:
            global ldap, modlist
            import ldap, ldap.modlist as modlist
        except:
            self.wKorreio.page(0).setEnabled(False)
            self.pGetBaseDN.setEnabled(False)
            modfailed.append("ldap")
        
        try:
            global  smbpasswd
            import smbpasswd
        except:
            self.cbLdapSambaPassword.setEnabled(False)
            modfailed.append("smbpasswd")
        
        try:
            global cyruslib
            import cyruslib
        except:
            self.wKorreio.page(1).setEnabled(False)
            self.wKorreio.page(2).setEnabled(False)
            modfailed.append("cyrus")
        
        try:
            global sievelib
            import sievelib
        except:
            self.wKorreio.page(3).setEnabled(False)
            modfailed.append("sieve")
        
        try:
            global pexpect, pxssh
            import pexpect, pxssh
        except:
            self.wKorreio.page(4).setEnabled(False)
            self.wKorreio.page(5).setEnabled(False)
            modfailed.append("pexpect")
        
        if modfailed:
            msg = ""
            for mod in modfailed:
                msg = "%s%s\n" % (msg, "    - python-%s" % mod)
            QMessageBox.warning(None, "Modulos falharam", utf2iso("Os seguintes módulos não foram carregados:\n%s" % msg))
        
        global active_conn
        active_conn = {}
        
        

    def customEvent(self,a0):
        event = a0
        if event.type() == "set_console_text":
            self.console(event.data())
        

    def statusBar(self):
        pass
        

    def console(self,a0):
        
        text = datetime.datetime.now().strftime("%d %b %Y %H:%M:%S :/# ")+a0
        self.tlConsole.setText(utf2iso(text))
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.log"), 'a')
            f.write(text+'\n')
            f.close()
        except OSError, e:
            print e
        
        

    def parse_exception(self,a0,a1):
        
        if a0 == "LDAPError":
            if a1[0]["desc"] == "Size limit exceeded":
                self.console("Atenção: quantidade de registros excedido, utilize um filtro mais restritivo.")
            elif a1[0]["desc"] == "Already exists":
                self.console("Erro: o registro já existe.")
            elif a1[0]['desc'] == "Object class violation":
                self.console(a1[0]['info'])
            elif a1[0]['desc'] == "Naming violation":
                self.console(a1[0]['info'])
            elif a1[0]['desc'] == "Can't contact LDAP server":
                self.console("Erro: conexão ao host %s recusada." % self.iLdapHost.text().ascii())
            elif a1[0]['info'] == "no write access to parent":
                self.console("Erro: sem permissão de escrita no referral, autentique-se na raiz %s." % self.ldap_get_dn())
            elif a1[0]['info'] == "modifications require authentication":
                user = self.iLdapUser.text().ascii()
                if not user: user = "anonymous"
                self.console("Erro: usuário %s sem permissão de escrita ou senha incorreta." % user)
            elif a1[0]['desc'] == "No such attribute":
                self.console(a1[0]['info'])
            else:
                self.console(str(a1))
        else:
            self.console(str(a1))
        
        

    def korreio_module_clear(self,a0):
        
        if a0 == "ldap":
            self.lvLdap.clear()
            self.lvLdapAttr.clear()
        elif a0 == "imap":
            self.lvCyrus.clear()
            self.lvCyrusGlobal.clear()
            self.iImapMailbox.clear()
            self.lvImapAcl.clear()
            self.iImapAclUser.clear()
            self.cbACL.setCurrentText("")
            self.iQuota.clear()
            self.iQuotaUsed.clear()
            self.iAnnotationExpire.clear()
        elif a0 == "imap-partition":
            self.lvImapPartition.clear()
            self.lvImapPartitionGlobal.clear()
            self.cbImapPartition.clear()
        elif a0 == "sieve":
            self.lvSieve.clear()
            self.cbSieveScript.clear()
            self.teSieveScript.clear()
        elif a0 == "ssh":
            self.cbPostconf.clear()
            self.tePostconf.clear()
            self.tePostFileOpen.clear()
            self.lvQueue.clear()
            self.iQueueMessage.clear()
        
        

    def korreio_module_changed(self):
        page = self.wKorreio.currentPageIndex()
        if page == 0:
            try:
                self.loadconfig
            except:
                self.loadconfig = 1
                self.config_load()
        elif page == 6:
            self.config_change_widgetstack()
        
        

    def config_load(self):
        
        try:
            os.mkdir(os.path.expanduser("~/.korreio"),0700)
        except OSError, e:
            if e[0] != 17:
                self.console("Erro: não foi possível criar ~/.korreio. %s" % e)
                print "Error creating ~/.korreio "+e
                return False
        
        try:
            if not os.path.isfile(os.path.expanduser("~/.korreio/korreio.conf")):
                self.config_save()
        except OSError, e:
            pass
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
            conf=f.read()
            f.close()
        except IOError, e:
            return True
        
        confList = conf.split("\n")
        confList.pop()
        self.confDict = {}
        
        for line in confList:
           key=line.split("=")
           self.confDict[key[0]] = "=".join(key[1:])
        
        #
        # LDAP Connection
        #
        
        i=0
        self.cbLdapConnection.clear()
        while self.confDict.get("ldap%s.name" % i):
            self.cbLdapConnection.insertItem(self.confDict.get("ldap%s.name" % i))
            i=i+1
        
        lastConn=self.confDict.get("ldap.last")
        if lastConn:
            self.cbLdapConnection.setCurrentText(self.confDict.get("%s.name" % lastConn))
            self.iLdapConnection.setText(self.confDict.get("%s.name" % lastConn))
            self.cbLdapMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
            self.iLdapHost.setText(self.confDict.get("%s.host" % lastConn))
            self.iLdapPort.setText(self.confDict.get("%s.port" % lastConn))
            self.cbLdapBaseDN.clear()
            self.cbLdapBaseDN.insertItem(self.confDict.get("%s.basedn" % lastConn))
            self.iLdapUser.setText(self.confDict.get("%s.user" % lastConn))
            self.iLdapPass.setText(self.confDict.get("%s.pass" % lastConn))
            if self.confDict.get("%s.ref" % lastConn) == "True":
                self.cLdapRef.setChecked(True)
            if self.confDict.get("%s.cert" % lastConn) == "True":
                self.cLdapCert.setChecked(True)
        
        #
        # IMAP Connection
        #
        
        i=0
        self.cbCyrusConnection.clear()
        while self.confDict.get("imap%s.name" % i):
            self.cbCyrusConnection.insertItem(self.confDict.get("imap%s.name" % i))
            i=i+1
        
        lastConn=self.confDict.get("imap.last")
        if lastConn:
            self.cbCyrusConnection.setCurrentText(self.confDict.get("%s.name" % lastConn))
            self.iCyrusConnection.setText(self.confDict.get("%s.name" % lastConn))
            self.cbCyrusMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
            self.iCyrusHost.setText(self.confDict.get("%s.host" % lastConn))
            self.iCyrusPort.setText(self.confDict.get("%s.port" % lastConn))
            self.iCyrusSievePort.setText(self.confDict.get("%s.sieport" % lastConn))
            self.iCyrusUser.setText(self.confDict.get("%s.user" % lastConn))
            self.iCyrusPass.setText(self.confDict.get("%s.pass" % lastConn))
            self.iCyrusPart.setText(self.confDict.get("%s.part" % lastConn))
        
        #
        # SSH Connection
        #
        
        i=0
        self.cbSSHConnection.clear()
        while self.confDict.get("ssh%s.name" % i):
            self.cbSSHConnection.insertItem(self.confDict.get("ssh%s.name" % i))
            i=i+1
        
        lastConn=self.confDict.get("ssh.last")
        if lastConn:
            self.cbSSHConnection.setCurrentText(self.confDict.get("%s.name" % lastConn))
            self.iSSHConnection.setText(self.confDict.get("%s.name" % lastConn))
            self.iSshHost.setText(self.confDict.get("%s.host" % lastConn))
            self.iSshPort.setText(self.confDict.get("%s.port" % lastConn))
            self.iSshUser.setText(self.confDict.get("%s.user" % lastConn))
            self.iSshPass.setText(self.confDict.get("%s.pass" % lastConn))
        
        #
        # IMAP Prefs
        #
        
        self.lbConfImapFolders.clear()
        for folder in self.confDict.get("imap.dflfolders").split(","):
            self.lbConfImapFolders.insertItem(folder)
        self.iConfImapQuota.setText(self.confDict.get("imap.dflquota"))
        self.iConfImapExpire.setText(self.confDict.get("imap.dflexpirefolder"))
        self.iConfImapExpireDays.setText(self.confDict.get("imap.dflexpiredays"))
        self.iConfImapACLp.setText(self.confDict.get("imap.addaclp"))
        
        #
        # LDAP Prefs
        #
        
        self.lvConfLdap.clear()
        item = QListViewItem(self.lvConfLdap)
        item.setText(0,'objectClass')
        item.setOpen(True)
        objnodes = {}
        i=0
        while self.confDict.get("ldap.objectclass%s" % i):
            objclass = self.confDict.get("ldap.objectclass%s" % i).split(".")
            if not objnodes.get(objclass[0]):
                objnodes[objclass[0]] = QListViewItem(item)
                objnodes[objclass[0]].setText(0,objclass[0])
            subitem=QListViewItem(objnodes[objclass[0]])
            subitem.setText(0,objclass[1])
            subitem.setText(1,".".join(objclass[2:]))
            i=i+1
        
        

    def config_save(self):
        
        try:
            try:
                self.confDict
            except AttributeError, e:
                self.confDict = {}
        
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')
        
        #
        # LDAP Connection
        #
        
            if not self.iLdapConnection.text().ascii():
                self.console("Atenção: preencha o nome da conexão LDAP.")
            else:
                i=0
                while self.confDict.get("ldap%s.name" % i):
                    if self.confDict.get("ldap%s.name" % i) == self.iLdapConnection.text().ascii():
                        break
                    i=i+1
                tmpLast=i
                f.write('ldap.last=ldap%s\n' % i)
        
                self.confDict["ldap%s.name" % i]=self.iLdapConnection.text().ascii()
                self.confDict["ldap%s.mode" % i]=self.cbLdapMode.currentText().ascii()
                self.confDict["ldap%s.host" % i]=self.iLdapHost.text().ascii()
                self.confDict["ldap%s.port" % i]=self.iLdapPort.text().ascii()
                self.confDict["ldap%s.basedn" % i]=self.cbLdapBaseDN.currentText().ascii()
                self.confDict["ldap%s.user" % i]=self.iLdapUser.text().ascii()
                self.confDict["ldap%s.pass" % i]=self.iLdapPass.text().ascii()
                self.confDict["ldap%s.ref" % i]=str(self.cLdapRef.isChecked())
                self.confDict["ldap%s.cert" % i]=str(self.cLdapCert.isChecked())
        
                i=0
                self.cbLdapConnection.clear()
                while self.confDict.get("ldap%s.name" % i):
                    self.cbLdapConnection.insertItem(self.confDict.get("ldap%s.name" % i))
                    for j in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                        opt = "ldap%s.%s" % (i, j)
                        f.write("%s=%s\n" % (opt, self.confDict.get(opt)))
                    i=i+1
                self.cbLdapConnection.setCurrentItem(tmpLast)
        
        #
        # IMAP Connection
        #
        
            if not self.iCyrusConnection.text().ascii():
                self.console("Atenção: preencha o nome da conexão IMAP.")
            else:
                i=0
                while self.confDict.get("imap%s.name" % i):
                    if self.confDict.get("imap%s.name" % i) == self.iCyrusConnection.text().ascii():
                        break
                    i=i+1
                tmpLast=i
                f.write("imap.last=imap%s\n" % i)
        
                self.confDict["imap%s.name" % i]=self.iCyrusConnection.text().ascii()
                self.confDict["imap%s.mode" % i]=self.cbCyrusMode.currentText().ascii()
                self.confDict["imap%s.host" % i]=self.iCyrusHost.text().ascii()
                self.confDict["imap%s.port" % i]=self.iCyrusPort.text().ascii()
                self.confDict["imap%s.sieport" % i]=self.iCyrusSievePort.text().ascii()
                self.confDict["imap%s.user" % i]=self.iCyrusUser.text().ascii()
                self.confDict["imap%s.pass" % i]=self.iCyrusPass.text().ascii()
                self.confDict["imap%s.part" % i]=self.iCyrusPart.text().ascii()
        
                i=0
                self.cbCyrusConnection.clear()
                while self.confDict.get("imap%s.name" % i):
                    self.cbCyrusConnection.insertItem(self.confDict.get("imap%s.name" % i))
                    for j in ['name','mode','host','port','sieport','user','pass','part']:
                        opt = "imap%s.%s" % (i, j)
                        f.write("%s=%s\n" % (opt, self.confDict.get(opt)))
                    i=i+1
                self.cbCyrusConnection.setCurrentItem(tmpLast)
        
        #
        # SSH Connection
        #
        
            if not self.iSSHConnection.text().ascii():
                self.console("Atenção: preencha o nome da conexão SSH.")
            else:
                i=0
                while self.confDict.get("ssh%s.name" % i):
                    if self.confDict.get("ssh%s.name" % i) == self.iSSHConnection.text().ascii():
                        break
                    i=i+1
                tmpLast=i
                f.write("ssh.last=ssh%s\n" % i)
        
                self.confDict["ssh%s.name" % i]=self.iSSHConnection.text().ascii()
                self.confDict["ssh%s.host" % i]=self.iSshHost.text().ascii()
                self.confDict["ssh%s.port" % i]=self.iSshPort.text().ascii()
                self.confDict["ssh%s.user" % i]=self.iSshUser.text().ascii()
                self.confDict["ssh%s.pass" % i]=self.iSshPass.text().ascii()
        
                i=0
                self.cbSSHConnection.clear()
                while self.confDict.get("ssh%s.name" % i):
                    self.cbSSHConnection.insertItem(self.confDict.get("ssh%s.name" % i))
                    for j in ['name','host','port','user','pass']:
                        opt="ssh%s.%s" % (i, j)
                        f.write("%s=%s\n" % (opt, self.confDict.get(opt)))
                    i=i+1
                self.cbSSHConnection.setCurrentItem(tmpLast)
        
        #
        # IMAP Prefs
        #
        
            folders=[]
            for folder in range(0,self.lbConfImapFolders.count()):
                folders.extend([self.lbConfImapFolders.item(folder).text().ascii()])
            f.write("imap.dflfolders=%s\n" % ",".join(folders))
            f.write("imap.dflquota=%s\n" % self.iConfImapQuota.text().ascii())
            f.write("imap.dflexpirefolder=%s\n" % self.iConfImapExpire.text().ascii())
            f.write("imap.dflexpiredays=%s\n" % self.iConfImapExpireDays.text().ascii())
            f.write("imap.addaclp=%s\n" % self.iConfImapACLp.text().ascii())
        
        
        #
        # LDAP Prefs
        #
            item=self.lvConfLdap.firstChild()
            item=item.firstChild()
            i=0
            while item is not None:
                subitem=item.firstChild()
                while subitem is not None:
                    if subitem.text(1).ascii() is None: value=""
                    else: value=subitem.text(1).ascii()
                    f.write("ldap.objectclass%s=%s.%s.%s\n" % (i, item.text(0).ascii(), subitem.text(0).ascii(), value))
                    subitem=subitem.nextSibling()
                    i=i+1
                item=item.nextSibling()
        #
        # End
        #
            f.close()
            os.chmod(os.path.expanduser("~/.korreio/korreio.conf"), 0600)
            self.console("Configuração salva.")
        except OSError, e:
            self.parse_exception("OSError", e)
        
        

    def config_change_widgetstack(self):
        item=self.lvConfig.currentItem()
        if item.parent() is None:
           if  item.text(0).ascii() == "Servidores":
                self.wsConfig.raiseWidget(3)
                self.tConfShowLdapServer.setText("Host: %s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii()))
                self.tConfShowLdapUser.setText("User: %s" % self.iLdapUser.text().ascii())
                self.tConfShowLdapBaseDN.setText("Base: %s" % self.cbLdapBaseDN.currentText().ascii())
                self.tConfShowImapServer.setText("Host: %s%s:%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii()))
                self.tConfShowImapUser.setText("User: %s" % self.iCyrusUser.text().ascii())
                self.tConfShowSshServer.setText("Host: ssh://%s:%s" % (self.iSshHost.text().ascii(), self.iSshPort.text().ascii()))
                self.tConfShowSshUser.setText("User: %s" % self.iSshUser.text().ascii())
        elif "%s.%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) == "Servidores.LDAP":
            self.wsConfig.raiseWidget(0)
        elif "%s.%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) == "Servidores.IMAP":
            self.wsConfig.raiseWidget(1)
        elif "%s.%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) == "Servidores.SSH":
            self.wsConfig.raiseWidget(2)
        elif "%s.%s" % (iso2utf(item.parent().text(0).ascii()), item.text(0).ascii()) == "Preferências.LDAP":
            self.wsConfig.raiseWidget(4)
        elif "%s.%s" % (iso2utf(item.parent().text(0).ascii()), item.text(0).ascii()) == "Preferências.IMAP":
            self.wsConfig.raiseWidget(5)
        

    def config_imap_set_port(self):
        
        if self.cbCyrusMode.currentText().ascii() == "imap://":
            self.iCyrusPort.setText("143")
        else:
            self.iCyrusPort.setText("993")
        
        

    def config_ldap_set_port(self):
        if self.cbLdapMode.currentText().ascii() == "ldap://":
            self.iLdapPort.setText("389")
        else:
            self.iLdapPort.setText("636")
        

    def config_ldap_get_basedn(self):
        
        try:
            l = self.ldap_connect()
            ldap_result_id = l.search("", ldap.SCOPE_BASE, "objectclass=*", ["namingContexts"])
            self.cbLdapBaseDN.clear()
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                if (result_data == []):
                    break
                else:
                    if result_type == ldap.RES_SEARCH_ENTRY:
                        for j in result_data:
                             for root in j[1]["namingContexts"]:
                                 self.cbLdapBaseDN.insertItem(root)
        
            bases = self.cbLdapBaseDN.count()
            if bases > 1:
                    self.cbLdapBaseDN.popup()
            elif bases != 0:
                    self.iLdapUser.setText("cn=admin,%s" % root)
        
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
        
        

    def config_ldap_set_admin(self):
        
            self.iLdapUser.setText("cn=admin,%s" % self.cbLdapBaseDN.currentText().ascii())
        
        

    def config_imap_add_default_folder(self):
        
        self.lbConfImapFolders.insertItem(self.iConfImapFolder.text().ascii())
        self.iConfImapFolder.clear()
        
        

    def config_imap_del_default_folder(self):
        
        self.lbConfImapFolders.removeItem(self.lbConfImapFolders.currentItem())
        
        

    def config_ldap_add_attr(self):
        
        itemroot=self.lvConfLdap.firstChild()
        if itemroot.isSelected():
            newitem=QListViewItem(itemroot)
            newitem.setText(0,self.iConfLdapAttr.text().ascii())
            newitem.setText(1,self.iConfLdapValue.text().ascii())
            return True
        item=itemroot.firstChild()
        while item is not None:
            if item.isSelected():
                item.setOpen(True)
                newitem=QListViewItem(item)
                newitem.setText(0,self.iConfLdapAttr.text().ascii())
                newitem.setText(1,self.iConfLdapValue.text().ascii())
                return True
            subitem=item.firstChild()
            while subitem is not None:
                if subitem.isSelected():
                    subitem.setOpen(True)
                    newitem=QListViewItem(item)
                    newitem.setText(0,self.iConfLdapAttr.text().ascii())
                    newitem.setText(1,self.iConfLdapValue.text().ascii())
                    return True
                subitem=subitem.nextSibling()
            item=item.nextSibling()
        
        

    def config_ldap_del_attr(self):
        
        itemroot=self.lvConfLdap.firstChild()
        item=itemroot.firstChild()
        while item is not None:
            if item.isSelected():
                itemroot.takeItem(item)
                self.lvConfLdap.currentItem().setSelected(True)
                return True
            subitem=item.firstChild()
            while subitem is not None:
                if subitem.isSelected():
                    item.takeItem(subitem)
                    self.lvConfLdap.currentItem().setSelected(True)
                    return True
                subitem=subitem.nextSibling()
            item=item.nextSibling()
        
        

    def config_ldap_set_connection(self):
        
        i=0
        while self.confDict.get("ldap%s.name" % i):
            if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
                lastConn="ldap%s" % i
            i=i+1
        
        self.iLdapConnection.setText(self.confDict.get("%s.name" % lastConn))
        self.cbLdapMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
        self.iLdapHost.setText(self.confDict.get("%s.host" % lastConn))
        self.iLdapPort.setText(self.confDict.get("%s.port" % lastConn))
        self.cbLdapBaseDN.clear()
        self.cbLdapBaseDN.insertItem(self.confDict.get("%s.basedn" % lastConn))
        self.iLdapUser.setText(self.confDict.get("%s.user" % lastConn))
        self.iLdapPass.setText(self.confDict.get("%s.pass" % lastConn))
        if self.confDict.get("%s.ref" % lastConn) == "True":
            self.cLdapRef.setChecked(True)
        else:
            self.cLdapRef.setChecked(False)
        if self.confDict.get("%s.cert" % lastConn) == "True":
            self.cLdapCert.setChecked(True)
        else:
            self.cLdapCert.setChecked(False)
        
        self.korreio_module_clear("ldap")
        
        

    def config_imap_set_connection(self):
        
        i=0
        while self.confDict.get("imap%s.name" % i):
            if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
                lastConn="imap%s" % i
            i=i+1
        
        self.iCyrusConnection.setText(self.confDict.get("%s.name" % lastConn))
        self.cbCyrusMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
        self.iCyrusHost.setText(self.confDict.get("%s.host" % lastConn))
        self.iCyrusPort.setText(self.confDict.get("%s.port" % lastConn))
        self.iCyrusSievePort.setText(self.confDict.get("%s.sieport" % lastConn))
        self.iCyrusUser.setText(self.confDict.get("%s.user" % lastConn))
        self.iCyrusPass.setText(self.confDict.get("%s.pass" % lastConn))
        self.iCyrusPart.setText(self.confDict.get("%s.part" % lastConn))
        
        self.korreio_module_clear("imap")
        self.korreio_module_clear("imap-partition")
        self.korreio_module_clear("sieve")
        
        

    def config_ssh_set_connection(self):
        
        i=0
        while self.confDict.get("ssh%s.name" % i):
            if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
                lastConn="ssh%s" % i
            i=i+1
        self.iSSHConnection.setText(self.confDict.get("%s.name" % lastConn))
        self.iSshHost.setText(self.confDict.get("%s.host" % lastConn))
        self.iSshPort.setText(self.confDict.get("%s.port" % lastConn))
        self.iSshUser.setText(self.confDict.get("%s.user" % lastConn))
        self.iSshPass.setText(self.confDict.get("%s.pass" % lastConn))
        
        self.korreio_module_clear("ssh")
        
        

    def config_ldap_del_connection(self):
        
        if not self.cbLdapConnection.currentText().ascii():
            return True
        
        i=0
        while self.confDict.get("ldap%s.name" % i):
            if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
                j=i+1
                while self.confDict.get("ldap%s.name" % j):
                    for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                        self.confDict["ldap%s.%s" % ((j-1), opt)]=self.confDict.get("ldap%s.%s" % (j, opt))
                    j=j+1
            i=i+1
        
        for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
            del self.confDict["ldap%s.%s" % ((i-1), opt)]
        
        i=self.cbLdapConnection.currentItem()
        self.cbLdapConnection.removeItem(i)
        if i > 0:
            self.cbLdapConnection.setCurrentItem(i-1)
            self.config_ldap_set_connection()
        elif self.cbLdapConnection.count() > 0:
            self.cbLdapConnection.setCurrentItem(0)
            self.config_ldap_set_connection()
        else:
            self.iLdapConnection.clear()
            self.cbLdapMode.setCurrentText("ldap://")
            self.iLdapHost.clear()
            self.iLdapPort.setText("389")
            self.cbLdapBaseDN.clear()
            self.iLdapUser.clear()
            self.iLdapPass.clear()
            self.cLdapRef.setChecked(False)
            self.cLdapCert.setChecked(False)
        
        

    def config_imap_del_connection(self):
        
        if not self.cbCyrusConnection.currentText().ascii():
            return True
        
        i=0
        while self.confDict.get("imap%s.name" % i):
            if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
                j=i+1
                while self.confDict.get("imap%s.name" % j):
                    for opt in ['name','mode','host','port','sieport','user','pass','part']:
                        self.confDict["imap%s.%s" % ((j-1), opt)]=self.confDict.get("imap%s.%s" % (j, opt))
                    j=j+1
            i=i+1
        
        for opt in ['name','mode','host','port','sieport','user','pass','part']:
            del self.confDict["imap%s.%s" % ((i-1), opt)]
        
        i=self.cbCyrusConnection.currentItem()
        self.cbCyrusConnection.removeItem(i)
        if i > 0:
            self.cbCyrusConnection.setCurrentItem(i-1)
            self.config_imap_set_connection()
        elif self.cbCyrusConnection.count() > 0:
            self.cbCyrusConnection.setCurrentItem(0)
            self.config_imap_set_connection()
        else:
            self.iCyrusConnection.clear()
            self.cbCyrusMode.setCurrentText("imap://")
            self.iCyrusHost.clear()
            self.iCyrusPort.setText("143")
            self.iCyrusSievePort.setText("2000")
            self.iCyrusUser.clear()
            self.iCyrusPass.clear()
            self.iCyrusPart.clear()
        
        

    def config_ssh_del_connection(self):
        
        if not self.cbSSHConnection.currentText().ascii():
            return True
        i=0
        while self.confDict.get("ssh%s.name" % i):
            if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
                j=i+1
                while self.confDict.get("ssh%s.name" % j):
                    for opt in ['name','host','port','user','pass']:
                        self.confDict["ssh%s.%s" % ((j-1), opt)]=self.confDict.get("ssh%s.%s" % (j, opt))
                    j=j+1
            i=i+1
        
        for opt in ['name','host','port','user','pass']:
            del self.confDict["ssh%s.%s" % ((i-1), opt)]
        
        i=self.cbSSHConnection.currentItem()
        self.cbSSHConnection.removeItem(i)
        if i > 0:
            self.cbSSHConnection.setCurrentItem(i-1)
            self.config_ssh_set_connection()
        elif self.cbSSHConnection.count() > 0:
            self.cbSSHConnection.setCurrentItem(0)
            self.config_ssh_set_connection()
        else:
            self.iSSHConnection.clear()
            self.iSshHost.clear()
            self.iSshPort.setText("22")
            self.iSshUser.clear()
            self.iSshPass.clear()
        
        

    def imap_connect(self):
        
        def imap_connect_now():
            ssl = False
            if self.cbCyrusMode.currentText().ascii() == "imaps://":
                ssl = True
            self.m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),ssl)
            msg = "%s%s:%s/%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii(), self.iCyrusUser.text().ascii())
            if self.m.ALIVE:
                if self.m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii()):
                    if self.m.ADMIN is not None:
                        self.console("Servidor %s conectado com sucesso." % msg)
                    else:
                        self.m.logout()
                        self.console("Erro de conexão: %s (Usuário não é administrador)." % msg)
                else:
                    self.console("Erro de conexão: %s (Usuário ou senha inválidos)." % msg)
            else:
                self.console("Erro de conexão: %s (Conexão recusada)." % msg)
        
        def server_changed():
            if active_conn["imap.mode"] != self.cbCyrusMode.currentText().ascii() or active_conn["imap.host"] != self.iCyrusHost.text().ascii() or active_conn["imap.port"] != self.iCyrusPort.text().ascii() or active_conn["imap.user"] != self.iCyrusUser.text().ascii() or active_conn["imap.pass"] != self.iCyrusPass.text().ascii():
                return True
            return False
        
        try:
            # Is connected?
            if self.m.m.isadmin():
                if server_changed():
                    imap_connect_now()
            else:
                imap_connect_now()
        except AttributeError, e:
            # First connection
            imap_connect_now()
        
        active_conn["imap.mode"] = self.cbCyrusMode.currentText().ascii()
        active_conn["imap.host"] = self.iCyrusHost.text().ascii()
        active_conn["imap.port"] = self.iCyrusPort.text().ascii()
        active_conn["imap.user"] = self.iCyrusUser.text().ascii()
        active_conn["imap.pass"] = self.iCyrusPass.text().ascii()
        
        self.tConfShowImapSep.setText("Imap delimiter: "+self.m.SEP)
        
        return self.m
        

    def imap_search(self):
        
        # Save current selection
        oldmailbox=['','']
        if self.lvCyrus.childCount() > 1:
            item=self.lvCyrus.currentItem()
            oldmailbox[0]=item.text(0).ascii()
            while item.parent() is not None:
                oldmailbox[0]=item.parent().text(0).ascii()
                item=item.parent()
        
        if self.lvCyrusGlobal.childCount() > 1:
            item=self.lvCyrusGlobal.currentItem()
            oldmailbox[1]=item.text(0).ascii()
            while item.parent() is not None:
                oldmailbox[1]=item.parent().text(0).ascii()
                item=item.parent()
        
        self.korreio_module_clear("imap")
        
        # Imap query
        imap = self.imap_connect()
        if self.iImapSearch.text().ascii():
            pattern = "user%s%s*" % (imap.SEP, self.iImapSearch.text().ascii())
        else:
            pattern = "*"
        mailboxes = imap.lm(pattern)
        
        def create_nodes(dn):
            dnlist = dn.split(imap.SEP)
            dnnode = imap.SEP.join(dnlist[:-1])
            if not self.tree.get(dnnode):
                create_nodes(dnnode)
            self.tree[dn] = QListViewItem(self.tree.get(dnnode))
            self.tree[dn].setText(0,dnlist[-1])
        
        try:
            self.tree = {}
            for id in mailboxes:
                idlist = id.split(imap.SEP)
                if re.search("^user",id):
                    id = imap.SEP.join(idlist[1:])
                    if len(idlist) == 2:
                        self.tree[id] = QListViewItem(self.lvCyrus)
                        self.tree[id].setText(0, id)
                        continue
                elif len(idlist) == 1:
                    self.tree[id] = QListViewItem(self.lvCyrusGlobal)
                    self.tree[id].setText(0, idlist[0])
                    continue
                idlist = id.split(imap.SEP)
                if not self.tree.get(id):
                    create_nodes(id)
                else:
                    print "Erro obtendo "+ idlist[-1]
        except KeyError, e:
            pass
        
        try:
            def selectItem(item):
                self.lvCyrus.setCurrentItem(item)
                item.setOpen(True)
                item.setSelected(True)
        
            item=self.lvCyrus.firstChild()
            if not oldmailbox[0]:
                selectItem(item)
            else:
                while item is not None:
                    if item.text(0).ascii() == oldmailbox[0]:
                        selectItem(item)
                        self.lvCyrus.scrollBy(0,item.itemPos())
                        break
                    item=item.nextSibling()
                if item is None:
                    selectItem(self.lvCyrus.firstChild())
        except AttributeError, e:
            pass
        
        try:
            def selectItem(item):
                self.lvCyrusGlobal.setCurrentItem(item)
                item.setOpen(True)
                item.setSelected(True)
        
            item=self.lvCyrusGlobal.firstChild()
            if not oldmailbox[1]:
                selectItem(item)
            else:
                item=self.lvCyrusGlobal.firstChild()
                while item is not None:
                    if item.text(0).ascii() == oldmailbox[1]:
                        selectItem(item)
                        self.lvCyrusGlobal.scrollBy(0,item.itemPos())
                        break
                    item=item.nextSibling()
                if item is None:
                    selectItem(self.lvCyrusGlobal.firstChild())
        
        except AttributeError, e:
            pass
        
        if self.lvCyrus.childCount() > 0:
            self.imap_mailbox_clicked()
        
        

    def imap_create_mailbox(self):
        
        def create_mailbox(mailbox, partition=None):
            if imap.cm(mailbox, partition):
                self.console("Mailbox %s criada com sucesso." % mailbox)
            else:
                self.console("Erro: não foi possível criar mailbox %s." % mailbox)
                raise "Error creating mailbox %s" % mailbox
            
        mailbox = self.iImapMailbox.text().ascii()
        
        if not mailbox:
            self.console("Atenção: informe a mailbox para ser criada.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        if self.iCyrusPart.text().ascii():
            create_mailbox("%s%s" % (mbtype, mailbox), self.iCyrusPart.text().ascii())
        else:
            create_mailbox("%s%s" % (mbtype, mailbox))
        
        if self.iConfImapQuota.text().ascii():
            imap.sq("%s%s" % (mbtype, mailbox), self.iConfImapQuota.text().ascii())
        
        if self.cbImapMailbox.currentItem() == 0:
            if len(mailbox.split(imap.SEP)) == 1:
                folders=self.confDict.get("imap.dflfolders").split(",")
                for folder in folders:
                    if len(folder) == 0: continue
                    create_mailbox("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, folder))
                    if folder == self.iConfImapACLp.text().ascii():
                        imap.sam("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, folder), "anyone", "p")
                    if folder == self.iConfImapExpire.text().ascii():
                        imap.setannotation("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, folder), "/vendor/cmu/cyrus-imapd/expire", self.iConfImapExpireDays.text().ascii())
        
        self.imap_search()
        
        if self.cbImapMailbox.currentItem() == 1:
            self.imap_gmailbox_clicked()
            self.lvCyrusGlobal.currentItem().setSelected(True)
        
        

    def imap_delete_mailbox(self):
        
        def delete_mailbox(mailbox):
            imap.sam(mailbox, self.iCyrusUser.text().ascii(), "c")
            if imap.dm(mailbox):
                self.console("Mailbox %s removida com sucesso." % mailbox)
            else:
                self.console("Erro: não foi possível remover Mailbox %s." % mailbox)
                raise "Error deleting mailbox %s" % mailbox
        
        mailbox = self.iImapMailbox.text().ascii()
        
        if not mailbox:
            self.console("Atenção: selecione a mailbox para exclusão.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        if QMessageBox.information( None, "Confirme!",
                                                       utf2iso("Confirme a remoção da caixa postal:\n\n    - %s%s\n\n" % (mbtype, mailbox)),
                                                       "Sim",
                                                       utf2iso("Não") ) != 0:
            self.console("Atenção: a remoção da mailbox %s%s foi cancelada." % (mbtype, mailbox) )
            return True
        
        # Cyrus is not recursive for subfolders
        if len(mailbox.split(imap.SEP)) > 1:
            for mbox in imap.lm(mbtype+mailbox+imap.SEP+"*"):
                delete_mailbox(mbox)
        delete_mailbox(mbtype+mailbox)
        
        if self.cbImapMailbox.currentItem() == 0:
            if self.lvCyrus.currentItem().parent() is None:
                self.lvCyrus.takeItem(self.lvCyrus.currentItem())
            else:
                self.lvCyrus.currentItem().parent().takeItem(self.lvCyrus.currentItem())
            self.lvCyrus.currentItem().setSelected(True)
            self.imap_mailbox_clicked()
        else:
            if self.lvCyrusGlobal.currentItem().parent() is None:
                self.lvCyrusGlobal.takeItem(self.lvCyrusGlobal.currentItem())
            else:
                self.lvCyrusGlobal.currentItem().parent().takeItem(self.lvCyrusGlobal.currentItem())
            self.lvCyrusGlobal.currentItem().setSelected(True)
            self.imap_gmailbox_clicked()
        
        

    def imap_set_quota(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("Atenção: selecione a mailbox para aplicar a quota.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        if imap.sq(mbtype+self.iImapMailbox.text().ascii(),self.iQuota.text().ascii()):
            self.console("Quota de %s Kbytes configurada para o usuário %s." % (self.iQuota.text().ascii(), self.iImapMailbox.text().ascii()))
        else:
            self.console("Erro: não foi possível configurar quota para o usuário %s" % self.iImapMailbox.text().ascii())
        
        

    def imap_reconstruct(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("Atenção: selecione a mailbox para reconstruir.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        if imap.reconstruct(mbtype+self.iImapMailbox.text().ascii()):
            self.console("Mailbox %s esta sendo reconstruida." % self.iImapMailbox.text().ascii())
        else:
            self.console("Erro: não foi possível reconstruir mailbox %s." % self.iImapMailbox.text().ascii())
        
        

    def imap_set_annotation_expire(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("Atenção: selecione a mailbox para aplica o auto-expire.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        if imap.setannotation(mbtype+self.iImapMailbox.text().ascii(),"/vendor/cmu/cyrus-imapd/expire",self.iAnnotationExpire.text().ascii()):
            self.console("Auto-expire de %s dias configurado para mailbox %s." % (self.iAnnotationExpire.text().ascii(), self.iImapMailbox.text().ascii()))
        else:
            self.console("Erro: não foi possível configurar auto-expire para mailbox %s." % self.iImapMailbox.text().ascii())
        
        

    def imap_partition_search(self):
        
        self.lvImapPartition.clear()
        self.lvImapPartitionGlobal.clear()
        self.cbImapPartition.clear()
        
        partitions = {}
        
        imap = self.imap_connect()
        
        mailboxes = imap.getannotation("user%s%s%%" % (imap.SEP, self.iImapPartitionSearch.text().ascii()), "/vendor/cmu/cyrus-imapd/partition")
        if mailboxes[0] == True:
            for mailbox in mailboxes[1]:
                idlist = mailbox.split(imap.SEP)
                item = QListViewItem(self.lvImapPartition)
                item.setText(0, imap.SEP.join(idlist[1:]))
                item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
                if self.cImapSize.isChecked():
                    item.setText(2, "%s" % imap.lq(mailbox)[0])
                else:
                    item.setText(2, "0")
                partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""
        
        mailboxes = imap.getannotation("%s%%" % self.iImapPartitionSearch.text().ascii(), "/vendor/cmu/cyrus-imapd/partition")
        if mailboxes[0] == True:
            for mailbox in mailboxes[1]:
                item = QListViewItem(self.lvImapPartitionGlobal)
                item.setText(0, mailbox)
                item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
                if self.cImapSize.isChecked():
                    item.setText(2, "%s" % imap.lq(mailbox)[0])
                else:
                    item.setText(2, "0")
                partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""
        
        for i in partitions:
            self.cbImapPartition.insertItem(i)
        
        

    def imap_partition_move(self):
        
        imap = self.imap_connect()
        item = self.lvImapPartition.firstChild()
        while item is not None:
            if item.isSelected():
                self.console("Mailbox %s movida para partição IMAP %s." % (item.text(0).ascii(), self.cbImapPartition.currentText().ascii()))
                mailbox="user%s%s" % (imap.SEP, item.text(0).ascii())
                imap.rename(mailbox, mailbox, self.cbImapPartition.currentText().ascii())
            item=item.nextSibling()
        
        item = self.lvImapPartitionGlobal.firstChild()
        while item is not None:
            if item.isSelected():
                self.console("Mailbox %s movida para partição IMAP %s." % (item.text(0).ascii(), self.cbImapPartition.currentText().ascii()))
                imap.rename(item.text(0).ascii(), item.text(0).ascii(), self.cbImapPartition.currentText().ascii())
            item=item.nextSibling()
        
        self.imap_partition_search()
        
        

    def imap_partition_size(self):
        
        if not self.cImapSizeUpdate.isChecked():
            self.tlImapSize.setText("0 Mbytes")
            return True
        
        size = 0
        item = self.lvImapPartition.firstChild()
        while item is not None:
            if item.isSelected():
                size += int(item.text(2).ascii())
            item=item.nextSibling()
        
        item = self.lvImapPartitionGlobal.firstChild()
        while item is not None:
            if item.isSelected():
                size += int(item.text(2).ascii())
            item=item.nextSibling()
        
        self.tlImapSize.setText("%s Mbytes" % (size / 1024))
        
        

    def imap_rename(self,a0,a1):
        
        currentItem = a0
        
        imap = self.imap_connect()
        item = a0
        new = item.text(0).ascii()
        while item.parent() is not None:
            item=item.parent()        
            new = item.text(0).ascii()+imap.SEP+new
        
        if self.mailboxold != new:
            if len(imap.lm(a1+new)) > 0:
                self.console("Atenção: mailbox %s já existe." % new)
                currentItem.setText(0,self.mailboxold.split(m.SEP)[-1])
                return True
            if imap.rename(a1+self.mailboxold,a1+new):
                self.console("Mailbox %s renomeada para %s." % (self.mailboxold, new))
            else:
                self.console("Erro: não foi possível renomear %s para %s." % (self.mailboxold, new))
                currentItem.setText(0,self.mailboxold.split(imap.SEP)[-1])
        
        

    def imap_rename_mailbox(self):
        
            self.imap_rename(self.lvCyrus.currentItem(), "user%s" % self.m.SEP)
        
        

    def imap_gmailbox_rename(self):
        
            self.imap_rename(self.lvCyrusGlobal.currentItem(),"")
        
        

    def imap_acl_wizard(self):
        
        if self.cbACL.currentItem() == 1:
            self.cbACL.setCurrentText("lrsw")
        elif self.cbACL.currentItem() == 2:
            self.cbACL.setCurrentText("lrswi")
        elif self.cbACL.currentItem() == 3:
            self.cbACL.setCurrentText("lrswicd")
        elif self.cbACL.currentItem() == 4:
            self.cbACL.setCurrentText("p")
        elif self.cbACL.currentItem() == 5:
            self.cbACL.setCurrentText("lrswipcda")
        
        

    def imap_acl_del(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("Atenção: selecione a mailbox para remover a ACL.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        def acl_del(user):
            if imap.sam(mbtype+self.iImapMailbox.text().ascii(), user, ""):
                self.console("Mailbox %s: ACL de %s removida." % (self.iImapMailbox.text().ascii(), user))
                return True
            else:
                self.console("Erro: não foi possível remover ACL de %s em %s." % (user, self.iImapMailbox.text().ascii()))
                return False
        
        itemDel = []
        item = self.lvImapAcl.firstChild()
        while item is not None:
            if item.isSelected():
                if acl_del(item.text(0).ascii()):
                    itemDel.append(item)
            item = item.nextSibling()
        
        for item in itemDel:
            self.lvImapAcl.takeItem(item)
        
        

    def imap_acl_add(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("Atenção: selecione a mailbox para aplicar a ACL.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        AclUser = self.iImapAclUser.text().ascii()
        Acl = self.cbACL.currentText().ascii()
        
        for user in AclUser.split(","):
            if imap.sam(mbtype+self.iImapMailbox.text().ascii(), user, Acl):
                item = self.lvImapAcl.firstChild()
                while item is not None:
                    if item.text(0).ascii() == user:
                        self.lvImapAcl.takeItem(item)
                        break
                    item = item.nextSibling()
                item = QListViewItem(self.lvImapAcl)
                item.setText(0,user)
                item.setText(1,Acl)
                self.lvImapAcl.setCurrentItem(item)
                self.console("Mailbox %s: ACL %s -> %s " % (self.iImapMailbox.text().ascii(), Acl, AclUser))
            else:
                self.console("Erro: não foi possível aplicar ACL %s -> %s em %s." % (Acl, AclUser, self.iImapMailbox.text().ascii()))
        
        

    def imap_acl_clicked(self):
        
        item = self.lvImapAcl.currentItem()
        self.iImapAclUser.setText(item.text(0).ascii())
        self.cbACL.setCurrentText(item.text(1).ascii())
        
        

    def imap_selectall(self):
        
        if self.lvImapPartition.hasFocus():
            self.lvImapPartition.selectAll(True)
            self.lvImapPartitionGlobal.selectAll(False)
        else:
            self.lvImapPartitionGlobal.selectAll(True)
            self.lvImapPartition.selectAll(False)
        
        

    def imap_mailbox_clicked(self):
        
        self.cbImapMailbox.setCurrentItem(0)
        self.imap_mailbox_get_info(self.lvCyrus.currentItem(),"user")
        
        

    def imap_gmailbox_clicked(self):
        
        self.cbImapMailbox.setCurrentItem(1)
        self.imap_mailbox_get_info(self.lvCyrusGlobal.currentItem(),"")
        
        

    def imap_mailbox_get_info(self,a0,a1):
        
        imap = self.imap_connect()
        item = a0
        if a1:
            mbtype = a1+imap.SEP
        else:
            mbtype = a1
        
        mailbox=item.text(0).ascii()
        while item.parent() is not None:
            mailbox=item.parent().text(0).ascii()+imap.SEP+mailbox
            item=item.parent()
        
        self.iImapMailbox.setText(mailbox)
        
        if len(mailbox.split(imap.SEP)) == 1:
            self.pSetQuota.setEnabled(True)
        else:
            self.pSetQuota.setEnabled(False)
        
        quota = imap.lq(mbtype+mailbox.split(imap.SEP)[0])
        self.iQuotaUsed.setText("%s" % quota[0])
        self.iQuota.setText("%s" % quota[1])
        
        self.lvImapAcl.clear()
        for user,acl in imap.lam(mbtype+mailbox).items():
            item = QListViewItem(self.lvImapAcl)
            item.setText(0, user)
            item.setText(1, acl)
        
        self.lvImapAcl.setCurrentItem(self.lvImapAcl.firstChild())
        self.lvImapAcl.currentItem().setSelected(False)
        self.imap_acl_clicked()
        
        expire = imap.getannotation(mbtype+mailbox, "/vendor/cmu/cyrus-imapd/expire")
        if expire[0]:
            self.iAnnotationExpire.setText(expire[1][mbtype+mailbox]["/vendor/cmu/cyrus-imapd/expire"])
        else:
            self.iAnnotationExpire.setText("")
        
        

    def imap_mailbox_doubleclicked(self):
        
        if self.lvCyrus.currentItem().parent() is not None:
            item = self.lvCyrus.currentItem()
            self.mailboxold = item.text(0).ascii()
            while item.parent() is not None:
                item=item.parent()        
                self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
            self.lvCyrus.currentItem().setRenameEnabled(0,True)
            self.lvCyrus.currentItem().startRename(0)
        
        

    def imap_gmailbox_doubleclicked(self):
        
        item = self.lvCyrusGlobal.currentItem()
        self.mailboxold = item.text(0).ascii()
        while item.parent() is not None:
            item=item.parent()        
            self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
        self.lvCyrusGlobal.currentItem().setRenameEnabled(0,True)
        self.lvCyrusGlobal.currentItem().startRename(0)
        
        

    def ldap_connect(self):
        
        try:
            if self.cLdapCert.isChecked():
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
            else:
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,2)
            if self.cLdapRef.isChecked():
                ldap.set_option(ldap.OPT_REFERRALS,1)
            else:
                ldap.set_option(ldap.OPT_REFERRALS,0)
            server = "%s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii())
            l = ldap.initialize(server)
            l.protocol_version = ldap.VERSION3
            if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
                l.simple_bind(self.iLdapUser.text().ascii(), self.iLdapPass.text().ascii())
            else:
                l.simple_bind()
            self.console("Servidor %s/%s conectado com sucesso." % (server, self.iLdapUser.text().ascii()))
            return l
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
        
        

    def ldap_search(self):
        
        def create_nodes(dn):
            dnlist = dn.split(",")
            dnnode = ",".join(dnlist[1:])
            if not self.nodes.get(dnnode):
                if not dnnode == dnnode.split(",")[0]:
                    create_nodes(dnnode)
                else:
                    print "Erro fatal: servidor ldap retonou basedn diferente da consulta."
                    print "            O servidor exige basedn case sensitive. Verifique."
            self.nodes[dn] = QListViewItem(self.nodes.get(dnnode))
            self.nodes[dn].setText(0,dnlist[0])
        
        if self.cbLdapFilter.count() == 10:
            self.cbLdapFilter.removeItem(4)
        self.cbLdapFilter.insertItem(self.cbLdapFilter.currentText().ascii())
        
        basedn = self.cbLdapBaseDN.currentText().ascii()
        try:
            olddn = self.ldap_get_dn()
        except AttributeError, e:
            olddn = basedn
        
        self.lvLdap.clear()
        self.nodes = {}
        self.nodes[basedn] = QListViewItem(self.lvLdap)
        self.nodes[basedn].setText(0,basedn)
        self.nodes[basedn].setOpen(True)
        
        if not self.cbLdapFilter.currentText().ascii():
            filter = "(objectClass=*)"
        else:
            filter = "(%s)" % iso2utf(self.cbLdapFilter.currentText().ascii())
        self.ldap_cache_attr = self.ldap_query(filter)
        if self.ldap_cache_attr is None:
            return
        
        try:
            basednattrs = self.ldap_cache_attr.get(basedn)
            del self.ldap_cache_attr[basedn]
        except KeyError, e:
            pass
        
        for dn in self.ldap_cache_attr:
            if not self.nodes.get(dn):
                create_nodes(dn)
        
        try:
            self.ldap_cache_attr[basedn] = basednattrs
        except KeyError, e:
            pass
        
        try:
            self.lvLdap.setCurrentItem(self.nodes[olddn])
            self.lvLdap.currentItem().setSelected(True)
        except KeyError, e:
            pass
        
        while olddn != basedn:
            try:
                self.nodes[olddn].setOpen(True)
            except KeyError, e:
                pass
            olddn = ",".join(olddn.split(",")[1:])
            if len(olddn) == 0:
                break
        
        self.lvLdap.scrollBy(0,self.lvLdap.currentItem().itemPos())
        self.ldap_dn_clicked()
        
        

    def ldap_query(self,a0):
        
        try:
            l = self.ldap_connect()
            if l is None:
                return
            searchScope = ldap.SCOPE_SUBTREE
            searchFilter = a0
            retrieveAttributes = None
            ldap_result_id = l.search(self.cbLdapBaseDN.currentText().ascii(), searchScope, searchFilter, retrieveAttributes)
            ldap_result = {}
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                if result_type == ldap.RES_SEARCH_RESULT:
                    break
                elif result_type == ldap.RES_SEARCH_ENTRY:
                    ldap_result[utf2iso(result_data[0][0])] = result_data[0][1]
                elif result_type == ldap.RES_SEARCH_REFERENCE:
                    ldap_result[result_data[0][1][0].split("/")[3].split("?")[0]] = {'ref': [result_data[0][1][0]]}
                else:
                    print "Result type not implemented. "+str(result_type)
        
            return ldap_result
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            if e[0]["desc"] == "Size limit exceeded":
                return ldap_result
        
        

    def ldap_dn_clicked(self):
        
        self.lvLdapAttr.clear()
        self.wsLdap.raiseWidget(0)
        self.cbLdapStack.setCurrentItem(0)
        dn = self.ldap_get_dn()
        try:
            for attribute,values in self.ldap_cache_attr.get(dn).items():
                for value in values:
                    item = QListViewItem(self.lvLdapAttr)
                    item.setText(0,attribute)
                    try:
                        item.setText(1,utf2iso(value))
                    except UnicodeDecodeError, e:
                        item.setText(1,value)
        except AttributeError, e:
            pass
        item = self.lvLdap.currentItem()
        if item.parent() is None or item.childCount() != 0:
            self.pLdapDelete.setEnabled(False)
        else:
            self.pLdapDelete.setEnabled(True)
        
        if self.lvLdapAttr.childCount() > 0:
            self.lvLdapAttr.setCurrentItem(self.lvLdapAttr.firstChild())
            self.lvLdapAttr.currentItem().setSelected(True)
        
        

    def ldap_dn_doubleclicked(self):
        
        if self.lvLdap.currentItem().childCount() == 0:
            self.rdnold = iso2utf(self.ldap_get_dn())
            self.lvLdap.currentItem().setRenameEnabled(0,True)
            self.lvLdap.currentItem().startRename(0)
        
        

    def ldap_form_next(self):
        
            self.wsLdapForm.raiseWidget(self.wsLdapForm.id(self.wsLdapForm.visibleWidget()) + 1)
        
        

    def ldap_form_back(self):
        
            self.wsLdapForm.raiseWidget(self.wsLdapForm.id(self.wsLdapForm.visibleWidget()) - 1)
        
        

    def ldap_form_enable(self):
        
            if self.cLdapFormPosix.isChecked():
                self.fLdapFormPosix.setEnabled(True)
            else:
                self.fLdapFormPosix.setEnabled(False)
        
        

    def ldap_form_homeDirectory(self):
        
            self.iLdapFormHomeDirectory.setText("/home/%s" % self.iLdapFormUid.text().ascii())
        
        

    def ldap_form_insert_user(self):
        
        if not self.iLdapFormCn.text().ascii():
            self.console("Atenção: informe o nome do usuário.")
            self.iLdapFormCn.setFocus()
            return False
        
        cn = iso2utf(self.iLdapFormCn.text().ascii())
        dn = iso2utf("cn=%s,%s" % (self.iLdapFormCn.text().ascii(), self.ldap_get_dn()))
        
        attrs = {}
        attrs['objectClass'] = ['inetOrgPerson']
        attrs['cn'] = [cn]
        attrs['sn'] = [cn.split(" ")[-1]]
        if self.iLdapFormMail.text().ascii():
            attrs['mail'] = [self.iLdapFormMail.text().ascii()]
        
        if self.iLdapFormStreet.text().ascii():
            attrs['street'] = [iso2utf(self.iLdapFormStreet.text().ascii())]
        
        if self.iLdapFormL.text().ascii():
            attrs['l'] = [iso2utf(self.iLdapFormL.text().ascii())]
        
        if self.iLdapFormPostalCode.text().ascii():
            attrs['postalCode'] = [self.iLdapFormPostalCode.text().ascii()]
        
        if self.iLdapFormHomePhone.text().ascii():
            attrs['homePhone'] = [self.iLdapFormHomePhone.text().ascii()]
        
        if self.iLdapFormUserP.text().ascii():
            salt = ''
            for i in range(16):
                salt += choice(letters+digits)
            attrs['userPassword'] = ["{SSHA}%s"  % b2a_base64(sha.new(self.iLdapFormUserP.text().ascii() + salt).digest() + salt)[:-1]]
        
        if self.cLdapFormPosix.isChecked():
            attrs['objectClass'].extend(['posixAccount', 'shadowAccount'])
        
            if not self.iLdapFormUid.text().ascii():
                self.console("Atenção: informe o login do usuário.")
                self.iLdapFormUid.setFocus()
                return False
            attrs['uid'] = [iso2utf(self.iLdapFormUid.text().ascii())]
        
            if not self.iLdapFormUidNumber.text().ascii():
                self.console("Atenção: informe o uidNumber do usuário.")
                self.iLdapFormUidNumber.setFocus()
                return False
            attrs['uidNumber'] = [self.iLdapFormUidNumber.text().ascii()]
        
            if not self.iLdapFormGidNumber.text().ascii():
                self.console("Atenção: informe o gidNumber do usuário.")
                self.iLdapFormGidNumber.setFocus()
                return False
            attrs['gidNumber'] = [self.iLdapFormGidNumber.text().ascii()]
        
            if self.iLdapFormLoginShell.text().ascii():
                attrs['loginShell'] = [iso2utf(self.iLdapFormLoginShell.text().ascii())]
        
            if not self.iLdapFormHomeDirectory.text().ascii():
                self.console("Atenção: informe o diretório home do usuário.")
                self.iLdapFormHomeDirectory.setFocus()
                return False
            attrs['homeDirectory'] = [iso2utf(self.iLdapFormHomeDirectory.text().ascii())]
        
        if self.ldap_add(dn,attrs):
            self.iLdapFormCn.clear()
            self.iLdapFormMail.clear()
            self.iLdapFormStreet.clear()
            self.iLdapFormL.clear()
            self.iLdapFormPostalCode.clear()
            self.iLdapFormHomePhone.clear()
            self.iLdapFormUserP.clear()
            self.cLdapFormPosix.setChecked(False)
            self.fLdapFormPosix.setEnabled(False)
            self.iLdapFormUid.clear()
            self.iLdapFormUidNumber.setText("1000")
            self.iLdapFormGidNumber.setText("100")
            self.iLdapFormLoginShell.setText("/bin/bash")
            self.iLdapFormHomeDirectory.setText("/home")
            self.wsLdapForm.raiseWidget(0)
        
        

    def ldap_add(self,a0,a1):
        # a0 = DN, a1 = attrs
        
        try:
            ldif = modlist.addModlist(a1)
            l = self.ldap_connect()
            l.add_s(a0,ldif)
            l.unbind_s()
            self.ldap_cache_attr[utf2iso(a0)] = {}
            for tuple in ldif:
                self.ldap_cache_attr[utf2iso(a0)][tuple[0]] = tuple[1]
            item = QListViewItem(self.lvLdap.currentItem())
            item.setText(0, utf2iso(a0.split(',')[0]))
            self.console("Registro %s adicionado com sucesso." % a0)
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_modify_clicked(self):
        
        stack = self.cbLdapStack.currentItem()
        if stack == 0:
            old = {}
            for attribute,values in self.ldap_cache_attr.get(self.ldap_get_dn()).items():
                if old.get(attribute):
                   old[attribute].extend(values)
                else:
                   old[attribute] = values
        
            new = {}
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if new.get(item.text(0).ascii()):
                    new[item.text(0).ascii()].extend([iso2utf(item.text(1).ascii())])
                else:
                    new[item.text(0).ascii()] = [iso2utf(item.text(1).ascii())]
                item = item.nextSibling()
        
            self.ldap_modify(self.ldap_get_dn(),old,new)
        
        else:
            new = {}
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if item.isSelected():
                    dn=iso2utf("%s=%s,%s" % (item.text(0).ascii(), item.text(1).ascii(), self.ldap_get_dn()))
                if new.get(item.text(0).ascii()):
                    new[item.text(0).ascii()].extend([iso2utf(item.text(1).ascii())])
                else:
                    new[item.text(0).ascii()] = [iso2utf(item.text(1).ascii())]
                item = item.nextSibling()
            try:
                self.ldap_add(dn,new)
            except UnboundLocalError, e:
                self.console("Atenção: selecione o DN entre os atributos.")
        
        

    def ldap_insert_ou(self):
        
        dn = iso2utf("ou=%s,%s" % (self.iLdapOu.text().ascii(), self.ldap_get_dn()))
        attrs = {}
        attrs['objectClass'] = ['organizationalUnit']
        attrs['ou'] = [iso2utf(self.iLdapOu.text().ascii())]
        if self.ldap_add(dn,attrs):
            self.iLdapOu.clear()
        
        

    def ldap_remove_entry(self):
        
        dn =  iso2utf(self.ldap_get_dn())
        if dn is not None:
            ok = QMessageBox.information( None, "Confirme!", utf2iso("Confirme a remoção do registro:\n\n    - %s\n\n" % dn), "Sim", utf2iso("Não") )
            if ok == 0:
                if self.ldap_del_entry(dn):
                    self.console("Registro %s removido com sucesso." % dn)
                    del self.ldap_cache_attr[utf2iso(dn)]
                    self.lvLdap.currentItem().parent().takeItem(self.lvLdap.currentItem())
                    self.lvLdap.currentItem().setSelected(True)
                    self.ldap_dn_clicked()
            else:
                self.console("Atenção: a remoção do registro %s foi cancelada." % dn)
        
        

    def ldap_del_entry(self,a0):
        
        l = self.ldap_connect()
        try:
            l.delete_s(a0)
            return True
        except ldap.STRONG_AUTH_REQUIRED, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_remove_attr(self):
        
        self.lvLdapAttr.takeItem(self.lvLdapAttr.currentItem())
        try:
            self.lvLdapAttr.currentItem().setSelected(True)
        except AttributeError, e:
            pass
        
        

    def ldap_rename_attr_value(self):
        
        if not self.lvLdap.currentItem().text(0).ascii() == "=".join([self.lvLdapAttr.currentItem().text(0).ascii(),self.lvLdapAttr.currentItem().text(1).ascii()]):
            self.lvLdapAttr.currentItem().setRenameEnabled(1,True)
            self.lvLdapAttr.currentItem().startRename(1)
        
        

    def ldap_add_attr(self):
        
        attr=self.cbLdapAttr.currentText().ascii()
        value=self.cbLdapValue.currentText().ascii()
        if not attr:
            return True
        
        attrs = [(attr,value)]
        
        if attr.lower() == 'objectclass':
            if not value:
                return True
            item=self.lvConfLdap.firstChild()
            item=item.firstChild()
            while item is not None:
                subitem=item.firstChild()
                if item.text(0).ascii().lower() == value.lower():
                    while subitem is not None:
                        if subitem.text(1).ascii() is None: newvalue=""
                        else: newvalue=subitem.text(1).ascii()
                        attrs.extend([(subitem.text(0).ascii(),newvalue)])
                        subitem=subitem.nextSibling()
                item=item.nextSibling()
        
        for attr,value in attrs:
            item=self.lvLdapAttr.firstChild()
            jump=False
            while item is not None:
                if item.text(0).ascii() == attr and (item.text(1).ascii() == value or value == ''):
                    jump=True
                    break
                item=item.nextSibling()
            if jump:
                continue
            item = QListViewItem(self.lvLdapAttr)
            item.setText(0,attr)
            item.setText(1,value)
        if self.cbLdapStack.currentItem() == 1:
            self.console("Atenção: ao criar o registro, pré-selecione um atributo como Distinguish Name.")
        
        

    def ldap_rename_rdn(self):
        
        rdnnew=iso2utf(self.lvLdap.currentItem().text(0).ascii())
        if self.rdnold.split(",")[0] == rdnnew:
            return True
        dnexist = 1
        item = self.lvLdapAttr.firstChild()
        while item is not None:
            if "%s=%s" % (item.text(0).ascii(), iso2utf(item.text(1).ascii())) == rdnnew:
                dnexist = 0
            item = item.nextSibling()
        if self.ldap_modify_rdn(self.rdnold, rdnnew,dnexist):
            self.console("Registro %s alterado com sucesso." % self.rdnold)
            self.lvLdapAttr.clear()
            return True
        else:
            self.lvLdap.currentItem().setText(0, self.rdnold.split(",")[0])
            return False
        
        

    def ldap_modify_rdn(self,a0,a1,a2):
        #a0 = oldDN, a1 = newDN, a2 = newDNexist
        
        try:
            l = self.ldap_connect()
            l.rename_s(a0,a1,None,a2)
            del self.ldap_cache_attr[utf2iso(a0)]
            l.unbind_s()
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_get_dn(self):
        
        item = self.lvLdap.currentItem()
        dn = item.text(0).ascii()
        while item.parent() is not None:
            dn = dn+","+item.parent().text(0).ascii()
            item = item.parent()
        return dn
        
        

    def ldap_change_widgetstack(self):
        
        selected_stack = self.cbLdapStack.currentItem()
        
        if self.lvLdap.currentItem() is None:
            if selected_stack != 0:
                self.cbLdapStack.setCurrentItem(0)
                self.console("Atenção: selecione o registro para executar esta ação.")
            return True
        
        if selected_stack == 1:
            self.lvLdapAttr.clear()
            self.wsLdap.raiseWidget(0)
            self.console("Atenção: o registro será inserido na base %s." % self.ldap_get_dn())
        else:
            self.wsLdap.raiseWidget(selected_stack)
            if selected_stack == 0:
                self.ldap_dn_clicked()
            elif selected_stack == 2 or selected_stack == 3:
                self.console("Atenção: o registro será inserido na base %s." % self.ldap_get_dn())
            elif selected_stack == 4:
                self.console("Atenção: o registro selecionado é %s." % self.ldap_get_dn())
        
        

    def ldap_passwd(self):
        
        if not self.cbLdapUserPassword.isChecked() and not self.cbLdapSambaPassword.isChecked():
            self.console("Atenção: selecione ao menos uma opção.")
            return False
        
        old={}
        new={}
        
        if self.cbLdapUserPassword.isChecked():
        
            salt = ''
            for i in range(16):
                salt += choice(letters+digits)
        
            old["userPassword"] = 'None'
            hash = self.cbUserPassword.currentText().ascii()
            if hash == "{SSHA}":
                new["userPassword"] = ["{SSHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]]
            elif hash == "{SHA}":
                new["userPassword"] = ["{SHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii()).digest())[:-1]]
            elif hash == "{SMD5}":
                new["userPassword"] = ["{SMD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]]
            elif hash == "{MD5}":
                new["userPassword"] = ["{MD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii()).digest())[:-1]]
            elif hash == "{CRYPT}":
                salt = ''
                for i in [0,1]:
                    salt += choice(letters+digits)
                new["userPassword"] = ["{CRYPT}" + crypt.crypt(str(self.iLdapPasswd.text().ascii()),salt)]
            elif hash == "{PLAINTEXT}":
                new["userPassword"] = [self.iLdapPasswd.text().ascii()]
            else:
                self.console("Algoritmo não implementando.")
                return False
        
        if self.cbLdapSambaPassword.isChecked():
            old["sambaNTPassword"] = 'None'
            new["sambaNTPassword"] = [smbpasswd.nthash(self.iLdapPasswd.text().ascii())]
            old["sambaLMPassword"] = 'None'
            new["sambaLMPassword"] = [smbpasswd.lmhash(self.iLdapPasswd.text().ascii())]
        
        if self.ldap_modify(self.ldap_get_dn(),old,new):
            self.iLdapPasswd.clear()
        
        self.ldap_dn_clicked()
        
        

    def ldap_modify(self,a0,a1,a2):
        
        dn=iso2utf(a0)
        old=a1
        new=a2
        try:
            ldif = modlist.modifyModlist(old,new)
            l = self.ldap_connect()
            l.modify_s(dn,ldif)
            l.unbind_s()
            for tuple in ldif:
                if tuple[2] is not None:
                    self.ldap_cache_attr[self.ldap_get_dn()][tuple[1]] = tuple[2]
            self.console("Registro %s alterado com sucesso." % dn)
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ssh_open(self,a0):
        
        print_cmd=[]
        try:
            self.console("Executando comando remoto: %s." % a0)
            child = pexpect.spawn('ssh -p%s %s@%s "%s"' % (self.iSshPort.text().ascii(), self.iSshUser.text().ascii(), self.iSshHost.text().ascii(), a0))
            i = child.expect(['assword','want to continue connecting'], timeout=5)
            if i==0:
                child.sendline(self.iSshPass.text().ascii())
            elif i==1:
                child.sendline('yes')
                child.expect('assword', timeout=2)
                child.sendline(self.iSshPass.text().ascii())
            for line in child:
                line = re.sub("(\n|\r)","",line)
                print_cmd.append(line)
            child.kill(0)
        except pexpect.EOF, t:
            self.console("Erro: conexão com %s terminada." % self.iSshHost.text().ascii())
        except pexpect.TIMEOUT, t:
            self.console("Erro: conexão com %s sofreu timeout." % self.iSshHost.text().ascii())
        return print_cmd
        
        

    def ssh_connect(self):
        
        try:
            if self.ssh_connect_active_host != self.iSshHost.text().ascii() or self.ssh_connect_active_port != self.iSshPort.text().ascii() or self.ssh_connect_active_user != self.iSshUser.text().ascii():
                pass
            elif self.ssh:
                return self.ssh
        except:
            pass
        
        self.ssh = pxssh.pxssh()
        if self.ssh.login ("-p%s %s" % (self.iSshPort.text().ascii(), self.iSshHost.text().ascii()), self.iSshUser.text().ascii(), self.iSshPass.text().ascii()):
            self.ssh_connect_active_host = self.iSshHost.text().ascii()
            self.ssh_connect_active_port = self.iSshPort.text().ascii()
            self.ssh_connect_active_user = self.iSshUser.text().ascii()
            return self.ssh
        else:
            raise "Authentication error."
        
        

    def ssh_exec(self,a0):
        
        s = self.ssh_connect()
        s.sendline ("%s > /dev/null 2>&1 && echo OK" % a0)
        s.prompt()
        if re.search("\nOK", s.before):
            return True
        else:
            return False
        
        

    def scp_exec(self,a0):
        
        try:
            self.console("Salvando arquivo remoto: %s" % a0)
            child = pexpect.spawn('scp -P%s /tmp/korreio.tmp %s@%s:"%s"' % (self.iSshPort.text().ascii(), self.iSshUser.text().ascii(), self.iSshHost.text().ascii(), a0))
            i = child.expect(['assword','want to continue connecting'], timeout=5)
            if i==0:
                child.sendline(self.iSshPass.text().ascii())
            elif i==1:
                child.sendline('yes')
                child.expect('assword', timeout=2)
                child.sendline(self.iSshPass.text().ascii())
            print_cmd=[]
            for line in child:
                print_cmd.append(line)
            child.kill(0)
        except pexpect.EOF, t:
            self.console("Erro: conexão com %s terminada." % self.iSshHost.text().ascii())
        except pexpect.TIMEOUT, t:
            self.console("Erro: conexão com %s sofreu timeout." % self.iSshHost.text().ascii())
        
        

    def postfix_postconf(self):
        
        if self.rbPostconfN.isChecked():
            cmd = "postconf -n"
        elif self.rbPostconfAll.isChecked():
            cmd = "postconf"
        if self.rbPostconfD.isChecked():
            cmd = "postconf -d"
        cmd = self.ssh_open(cmd)
        self.postconf = {}
        lastOpt = self.cbPostconf.currentText().ascii()
        self.cbPostconf.clear()
        i = 0
        for config in cmd:
            if re.search("=",config):
                configlist = config.strip().split("=")
                configlist[0]=configlist[0].strip(" ")
                self.postconf[configlist[0]] = configlist[1]
                self.cbPostconf.insertItem(configlist[0])
                if configlist[0] == lastOpt:
                    lastItem = i
                i = i + 1
        try:
            self.cbPostconf.setCurrentItem(lastItem)
        except UnboundLocalError, e:
            pass
        self.postfix_postconf_changed()
        
        

    def postfix_postconf_changed(self):
        
        value = self.postconf.get(self.cbPostconf.currentText().ascii())
        value = re.sub("( )+"," ",value)
        value = re.sub(", ",",",value)
        value = re.sub(",",",\n",value)
        value = re.sub("^ ","",value)
        self.tePostconf.setText(value)
        
        

    def postfix_postconf_save(self):
        
        value = re.sub(",",", ",self.tePostconf.text().ascii())
        value = re.sub("( )+"," ",value)
        value = re.sub("\n","",value)
        value = re.sub("\r","",value)
        option = self.cbPostconf.currentText().ascii()
        if self.ssh_exec("postconf -e %s=%s" % (option, value) ):
            self.console("Opção %s configurada com sucesso." % option )
        else:
            self.console("Erro: não foi possível configurar %s." % option )
        
        

    def postfix_open_conf(self):
        
        value = self.ssh_open("cat "+self.iPostFileOpen.text().ascii())
        values = ""
        for line in value[1:]:
            values = values+line+"\n"
        if re.search("^cat:",values):
            self.console("Erro: arquivo %s nao encontrado." % self.iPostFileOpen.text().ascii())
            return True
        self.tePostFileOpen.setText(values)
        
        

    def postfix_save_conf(self):
        
        if self.tePostFileOpen.length () == 0:
            self.ssh_exec("rm -f "+self.iPostFileOpen.text().ascii())
            return True
        f = open("/tmp/korreio.tmp", 'w')
        for line in self.tePostFileOpen.text().ascii():
            f.write(line)
        f.close()
        self.scp_exec(self.iPostFileOpen.text().ascii())
        
        

    def postfix_postmap(self):
        
        file = self.iPostFileOpen.text().ascii()
        if self.ssh_exec("postmap %s" % file):
            self.console("Database %s.db gerada com sucesso." % file )
        else:
            self.console("Erro: não foi possível gerar database %s.db." % file )
        
        

    def postfix_stop(self):
        
        if self.ssh_exec("/etc/init.d/postfix stop"):
            self.console("Postfix parado com sucesso.")
        else:
            self.console("Erro ao parar Postfix.")
        
        

    def postfix_start(self):
        
        if self.ssh_exec("/etc/init.d/postfix start"):
            self.console("Postfix iniciado com sucesso.")
        else:
            self.console("Erro ao iniciar Postfix.")
        
        

    def postfix_restart(self):
        
        if self.ssh_exec("/etc/init.d/postfix restart"):
            self.console("Postfix reiniciado com sucesso.")
        else:
            self.console("Erro ao reiniciar Postfix.")
        
        

    def sieve_search(self):
        
        self.lvSieve.clear()
        imap = self.imap_connect()
        for user in imap.lm("user%s%s%%" % (imap.SEP, self.iSieveSearch.text().ascii())):
            user=user.split(imap.SEP)[1]
            item = QListViewItem(self.lvSieve)
            item.setText(0, user)
            if self.cSieveScript.isChecked():
                s = self.sieve_connect(user)
                scripts = s.listscripts()
                s.logout()
                if scripts[0] == 'OK':
                    for script,active in scripts[1]:
                        if active:
                            item.setText(1, script)
                            break
        
        

    def sieve_connect(self,a0):
        
        admin = self.iCyrusUser.text().ascii().split("@")
        if admin[0] != self.iCyrusUser.text().ascii():
            user = "%s@%s" % (a0, admin[1])
        else:
            user = a0
        
        msg = "sieve://%s:%s/%s" % (self.iCyrusHost.text().ascii(), self.iCyrusSievePort.text().ascii(), user)
        
        s = sievelib.MANAGESIEVE(self.iCyrusHost.text().ascii(),int(self.iCyrusSievePort.text().ascii()))
        if s.alive:
            if s.login('PLAIN',user,self.iCyrusPass.text().ascii(),self.iCyrusUser.text().ascii()):
                self.console("Servidor %s conectado com sucesso." % msg)
                return s
            else:
                self.console("Erro de conexão: %s (Usuário ou senha inválidos)." % msg)
        else:
            self.console("Erro de conexão: %s (Conexão recusada)." % msg)
        
        return False
        
        

    def sieve_user_clicked(self):
        
        self.teSieveScript.clear()
        self.cbSieveScript.clear()
        
        item = self.lvSieve.currentItem()
        if item is None:
            return True
        
        s = self.sieve_connect(item.text(0).ascii())
        scripts = s.listscripts()
        s.logout()
        
        if scripts[0] == 'OK':
            for script,active in scripts[1]:
                self.cbSieveScript.insertItem(script)
                if self.lvSieve.currentItem().text(1).ascii() == script:
                    self.cbSieveScript.setCurrentText(script)
        
        if self.cbSieveScript.count() > 0:
            self.sieve_get_script()
        
        

    def sieve_get_script(self):
        
        s = self.sieve_connect(self.lvSieve.currentItem().text(0).ascii())
        script = s.getscript(self.cbSieveScript.currentText().ascii())
        s.logout()
        
        self.teSieveScript.clear()
        if script[0] == 'OK':
            self.teSieveScript.setText(script[1])
        
        

    def sieve_set_script(self):
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                if self.cbSieveScript.currentText().ascii():
                    status = s.putscript(self.cbSieveScript.currentText().ascii(),self.teSieveScript.text().ascii().replace("#USER#",item.text(0).ascii()))
                    if status == 'OK':
                        item.setText(1,self.cbSieveScript.currentText().ascii())
                        s.setactive(self.cbSieveScript.currentText().ascii())
                else:
                    item.setText(1,"")
                    s.setactive()
                s.logout()
            item=item.nextSibling()
        
        self.sieve_get_script()
        
        

    def sieve_unset_script(self):
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                s.setactive()
                s.logout()
                item.setText(1,"")
            item=item.nextSibling()
        
        

    def sieve_del_script(self):
        
        if not self.cbSieveScript.currentText().ascii():
            self.console("Atenção: digite o nome do script.")
            return True
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                if s.deletescript(self.cbSieveScript.currentText().ascii()) == 'OK':
                    if self.cbSieveScript.currentText().ascii() == item.text(1).ascii():
                        item.setText(1,"")
                s.logout()
            item=item.nextSibling()
        
        self.sieve_get_script()
        
        

    def sieve_select_all(self):
        
        self.lvSieve.selectAll(True)
        
        

    def sieve_use_template(self):
        
        try:
            sep = self.m.SEP
        except AttributeError, e:
            sep = "/"
        
        self.cbSieveScript.setCurrentText("script.siv")
        template = self.lbSieveScripts.currentItem()
        if template == 0:
            self.teSieveScript.setText("redirect \"destinatario@exemplo.com.br\";\n")
        
        elif template == 1:
            self.teSieveScript.setText("""redirect "destinatario@exemplo.com.br";
        keep;
        """.replace("        ",""))
        
        elif template == 2:
            self.teSieveScript.setText("""require "fileinto";
        if address :contains "from" "remetente1@exemplo.com.br" {
           fileinto "INBOX%(sep)sPasta1";
        }
        """.replace("        ","") % {'sep':sep})
        
        elif template == 3:
            self.teSieveScript.setText("""require "fileinto";
        if address :contains "from" ["from1@dom1.com","from2@dom2.com"] {
            fileinto "INBOX%(sep)sPasta1";
        }
        elsif address :contains "from" ["from3@dom3.com","from4@dom4.com"] {
            fileinto "INBOX%(sep)sPasta2";
        }
        """.replace("        ","") % {'sep':sep})
        
        elif template == 4:
            self.teSieveScript.setText("""if header :contains "X-Spam-Flag" "YES" {
            discard;
        }
        """.replace("        ",""))
        
        elif template == 5:
            self.teSieveScript.setText("""require "fileinto";
        if header :contains "X-Spam-Flag" "YES" {
            fileinto "INBOX%(sep)sSpam";
        }
        """.replace("        ","") % {'sep':sep})
        
        elif template == 6:
            self.console("Atenção: a macro #USER# será substituida pelo respectivo usuário.")
            if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
                domain="dominio.com.br"
            else:
                domain=self.iCyrusUser.text().ascii().split("@")[1]
            self.teSieveScript.setText("""require ["vacation","fileinto"];
        
        if header :contains "X-Spam-Flag" "YES" {
            fileinto "INBOX%(sep)sSpam";
            stop;
        }
        
        vacation :days 5
        :subject "Estou ausente"
        :addresses ["#USER#@%(domain)s"]
         "Estarei ausente entre os dias ....
        
         Obrigado,
        
         --
         xxxxxxxxxxxx";
        """.replace("        ","") % {'sep':sep,'domain':domain})
        
        elif template == 7:
            if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
                domain="exemplo.com.br"
            else:
                domain=self.iCyrusUser.text().ascii().split("@")[1]
            self.console("Atenção: a macro #USER# será substituida pelo respectivo usuário.")
            self.teSieveScript.setText("""require "vacation";
        vacation :days 5
        :subject "Estou ausente."
        :addresses ["#USER#@%s"]
         "Estarei ausente entre os dias ....
        
         Obrigado,
        
         --
         xxxxxxxxxxxx";
        """.replace("        ","") % domain)
        

    def queue_load(self):
        
        re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)\s+(\d+)\s([A-Z][a-z][a-z])\s([A-Z][a-z][a-z])\s+(\d+)\s(\d\d:\d\d:\d\d)\s+(.*)')
        re_rcpt  = re.compile(r'\s+(.*@.*)\b')
        re_log  = re.compile(r'(\s+)?\(.*\)')
        
        self.iQueueMessage.clear()
        self.lvQueue.clear()
        
        itemFrom = {}
        itemQueueID = {}
        self.itemLog = {}
        
        for line in self.ssh_open("postqueue -p"):
            match = re_queueid.match(line)
            if match is not None:
                tmp = ""
                #print "regexp: %s %s %s %s %s %s %s" % (match.group(1), match.group(2), match.group(3), match.group(4), match.group(5), match.group(6), match.group(7))
                mailFrom = match.group(7)
                if not itemFrom.get(mailFrom):
                    itemFrom[mailFrom] = QListViewItem(self.lvQueue)
                    itemFrom[mailFrom].setText(0,match.group(7))
                queueid = match.group(1)
                itemQueueID[queueid] = QListViewItem(itemFrom[mailFrom])
                itemQueueID[queueid].setText(0,"%s - %s Kb" % (queueid, int(match.group(2)) / 1024) )
                itemQueueID[queueid].setOpen(True)
                continue
            match = re_log.match(line)
            if match is not None:
                tmp = line
                continue
            match = re_rcpt.match(line)
            if match is not None:
                self.itemLog["%s:%s" % ( queueid, match.group(1) )] = tmp
                tmp = ""
                itemRcpt = QListViewItem(itemQueueID[queueid])
                itemRcpt.setText(0,match.group(1))
        
        item = self.lvQueue.firstChild()
        total = [0, 0]
        while item is not None:
            count = item.childCount()
            subcount = 0
            if count > 0:
                subitem = item.firstChild()
                while subitem is not None:
                    subcount = subcount + subitem.childCount()
                    subitem.setText(1,"%s" % subitem.childCount())
                    subitem = subitem.nextSibling()
            item.setText(1,"%s/%s" % (count, subcount))
            item = item.nextSibling()
            total[0] = total[0] + count
            total[1] = total[1] + subcount
        
        self.console("A fila contém %s mensagens para %s destinatários." % (total[0], total[1]))
        self.lvQueue.setColumnWidth(0, 300)
        self.lvQueue.setColumnWidth(1, 70)
        
        

    def queue_get_message(self):
        
        item = self.lvQueue.currentItem()
        
        if item is None:
            self.pQueueDel.setEnabled(False)
            return True
        
        if item.parent() is None:
            self.pQueueDel.setEnabled(True)
            return True
        
        if item.childCount() == 0:
            self.pQueueDel.setEnabled(False)
            re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)')
            match = re_queueid.match(item.parent().text(0).ascii())
            self.iQueueMessage.setText(self.itemLog.get("%s:%s" % (match.group(1), item.text(0).ascii()) ) )
            return True
        
        queueid = item.text(0).ascii()
        re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
        match = re_queueid.match(queueid)
        if match is not None:
            self.pQueueDel.setEnabled(True)
            self.iQueueMessage.setText("\n".join(self.ssh_open("postcat -q %s" % match.group(1))[1:]))
        
        

    def queue_del_message(self):
        
        self.iQueueMessage.clear()
        
        item = self.lvQueue.currentItem()
        re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
        
        if item.parent() is None:
            subitem = item.firstChild()
            success = False
            queuelist = []
            while subitem is not None:
                queuelist.append(re_queueid.match(subitem.text(0).ascii()).group(1))
                if len(queuelist) == 50 or subitem.nextSibling() is None:
                    if self.ssh_exec("cat <<< \"%s\" | postsuper -d - " % "\n".join(queuelist)):
                        success = True
                    queuelist = []
                subitem = subitem.nextSibling()
            if success:
                self.console("%s mensagen(s) removida(s) com sucesso." % item.childCount())
            self.lvQueue.takeItem(item)
            return True
        
        match = re_queueid.match(item.text(0).ascii())
        if match is not None:
            if self.ssh_exec("postsuper -d %s" % match.group(1)):
                self.console("Mensagem %s removida com sucesso." % match.group(1))
            else:
                self.console("Erro: não foi possível remover a mensagem %s." % match.group(1))
            count = item.parent().text(1).ascii().split("/")
            if int(count[0]) == 1:
                self.lvQueue.takeItem(item.parent())
            else:
                item.parent().setText(1 ,"%s/%s" % (str(int(count[0]) - 1), str(int(count[1]) - int(item.childCount()))))
                item.parent().takeItem(item)
        
        

    def __tr(self,s,c = None):
        return qApp.translate("dKorreio",s,c)

    def __trUtf8(self,s,c = None):
        return qApp.translate("dKorreio",s,c,QApplication.UnicodeUTF8)
