# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'korreio.ui'
#
# Created: Qua Set 12 07:52:38 2007
#      by: The PyQt User Interface Compiler (pyuic) 3.16
#
# WARNING! All changes made in this file will be lost!


from qt import *


class dKorreio(QDialog):
    def __init__(self,parent = None,name = None,modal = 0,fl = 0):
        QDialog.__init__(self,parent,name,modal,fl)

        if not name:
            self.setName("dKorreio")

        self.setSizeGripEnabled(1)

        dKorreioLayout = QGridLayout(self,1,1,11,6,"dKorreioLayout")

        self.wKorreio = QTabWidget(self,"wKorreio")
        self.wKorreio.setMinimumSize(QSize(770,570))

        self.tabLdap = QWidget(self.wKorreio,"tabLdap")
        tabLdapLayout = QGridLayout(self.tabLdap,1,1,11,6,"tabLdapLayout")

        self.groupBox12 = QGroupBox(self.tabLdap,"groupBox12")
        self.groupBox12.setColumnLayout(0,Qt.Vertical)
        self.groupBox12.layout().setSpacing(6)
        self.groupBox12.layout().setMargin(11)
        groupBox12Layout = QGridLayout(self.groupBox12.layout())
        groupBox12Layout.setAlignment(Qt.AlignTop)

        self.textLabel2_3 = QLabel(self.groupBox12,"textLabel2_3")

        groupBox12Layout.addWidget(self.textLabel2_3,0,0)

        self.iLdapOu = QLineEdit(self.groupBox12,"iLdapOu")

        groupBox12Layout.addMultiCellWidget(self.iLdapOu,0,0,1,2)

        self.pLdapAddOu = QPushButton(self.groupBox12,"pLdapAddOu")

        groupBox12Layout.addWidget(self.pLdapAddOu,1,1)
        spacer33 = QSpacerItem(71,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox12Layout.addItem(spacer33,1,0)
        spacer31 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox12Layout.addItem(spacer31,0,3)
        spacer32 = QSpacerItem(90,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox12Layout.addMultiCell(spacer32,1,1,2,3)

        tabLdapLayout.addWidget(self.groupBox12,1,1)

        self.KorreioAdd = QGroupBox(self.tabLdap,"KorreioAdd")
        self.KorreioAdd.setColumnLayout(0,Qt.Vertical)
        self.KorreioAdd.layout().setSpacing(6)
        self.KorreioAdd.layout().setMargin(11)
        KorreioAddLayout = QGridLayout(self.KorreioAdd.layout())
        KorreioAddLayout.setAlignment(Qt.AlignTop)
        spacer10 = QSpacerItem(170,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        KorreioAddLayout.addItem(spacer10,3,0)

        self.pLdapAddUser = QPushButton(self.KorreioAdd,"pLdapAddUser")

        KorreioAddLayout.addWidget(self.pLdapAddUser,3,1)
        spacer11 = QSpacerItem(130,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        KorreioAddLayout.addMultiCell(spacer11,3,3,2,3)
        spacer28 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        KorreioAddLayout.addMultiCell(spacer28,1,2,3,3)

        self.iLdapCn = QLineEdit(self.KorreioAdd,"iLdapCn")
        self.iLdapCn.setMinimumSize(QSize(220,0))

        KorreioAddLayout.addMultiCellWidget(self.iLdapCn,0,0,1,2)

        self.iLdapMail = QLineEdit(self.KorreioAdd,"iLdapMail")
        self.iLdapMail.setMinimumSize(QSize(220,0))

        KorreioAddLayout.addMultiCellWidget(self.iLdapMail,1,1,1,2)

        self.iLdapUserP = QLineEdit(self.KorreioAdd,"iLdapUserP")
        self.iLdapUserP.setMinimumSize(QSize(220,0))
        self.iLdapUserP.setEchoMode(QLineEdit.Password)

        KorreioAddLayout.addMultiCellWidget(self.iLdapUserP,2,2,1,2)

        self.textLabel3_2 = QLabel(self.KorreioAdd,"textLabel3_2")

        KorreioAddLayout.addWidget(self.textLabel3_2,0,0)

        self.textLabel5 = QLabel(self.KorreioAdd,"textLabel5")

        KorreioAddLayout.addWidget(self.textLabel5,1,0)

        self.textLabel1_3 = QLabel(self.KorreioAdd,"textLabel1_3")

        KorreioAddLayout.addWidget(self.textLabel1_3,2,0)

        tabLdapLayout.addWidget(self.KorreioAdd,1,0)

        self.KorreioSearch = QGroupBox(self.tabLdap,"KorreioSearch")
        self.KorreioSearch.setColumnLayout(0,Qt.Vertical)
        self.KorreioSearch.layout().setSpacing(6)
        self.KorreioSearch.layout().setMargin(11)
        KorreioSearchLayout = QGridLayout(self.KorreioSearch.layout())
        KorreioSearchLayout.setAlignment(Qt.AlignTop)

        self.lvLdapAttr = QListView(self.KorreioSearch,"lvLdapAttr")
        self.lvLdapAttr.addColumn(self.__tr("Atributo"))
        self.lvLdapAttr.addColumn(self.__tr("Valor"))
        self.lvLdapAttr.setAllColumnsShowFocus(1)

        KorreioSearchLayout.addMultiCellWidget(self.lvLdapAttr,1,1,3,5)

        self.cKorDnAttr = QComboBox(0,self.KorreioSearch,"cKorDnAttr")

        KorreioSearchLayout.addMultiCellWidget(self.cKorDnAttr,0,0,0,1)
        spacer26_2 = QSpacerItem(190,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        KorreioSearchLayout.addItem(spacer26_2,0,5)

        self.pLdapSearch = QPushButton(self.KorreioSearch,"pLdapSearch")

        KorreioSearchLayout.addWidget(self.pLdapSearch,0,4)

        self.iKorDnAttr = QLineEdit(self.KorreioSearch,"iKorDnAttr")
        self.iKorDnAttr.setMinimumSize(QSize(190,0))

        KorreioSearchLayout.addMultiCellWidget(self.iKorDnAttr,0,0,2,3)

        self.lvLdap = QListView(self.KorreioSearch,"lvLdap")
        self.lvLdap.addColumn(self.__tr("Distinguished Name"))
        self.lvLdap.setMinimumSize(QSize(310,0))
        self.lvLdap.setMaximumSize(QSize(310,32767))
        self.lvLdap.setRootIsDecorated(1)

        KorreioSearchLayout.addMultiCellWidget(self.lvLdap,1,1,0,2)
        spacer27_2 = QSpacerItem(120,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        KorreioSearchLayout.addItem(spacer27_2,2,0)

        self.pLdapDelete = QPushButton(self.KorreioSearch,"pLdapDelete")

        KorreioSearchLayout.addMultiCellWidget(self.pLdapDelete,2,2,1,2)
        spacer2 = QSpacerItem(420,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        KorreioSearchLayout.addMultiCell(spacer2,2,2,3,5)

        tabLdapLayout.addMultiCellWidget(self.KorreioSearch,0,0,0,1)
        self.wKorreio.insertTab(self.tabLdap,QString.fromLatin1(""))

        self.tabCyrus = QWidget(self.wKorreio,"tabCyrus")
        tabCyrusLayout = QGridLayout(self.tabCyrus,1,1,11,6,"tabCyrusLayout")

        self.tCyrUser = QLabel(self.tabCyrus,"tCyrUser")

        tabCyrusLayout.addWidget(self.tCyrUser,0,0)

        self.iCyrUser = QLineEdit(self.tabCyrus,"iCyrUser")

        tabCyrusLayout.addWidget(self.iCyrUser,0,1)

        self.pCyrSearch = QPushButton(self.tabCyrus,"pCyrSearch")

        tabCyrusLayout.addWidget(self.pCyrSearch,0,2)
        spacer1 = QSpacerItem(30,31,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabCyrusLayout.addItem(spacer1,0,3)

        self.textLabel1_2 = QLabel(self.tabCyrus,"textLabel1_2")

        tabCyrusLayout.addWidget(self.textLabel1_2,0,4)

        self.iCyrMailbox = QLineEdit(self.tabCyrus,"iCyrMailbox")
        self.iCyrMailbox.setEnabled(1)
        self.iCyrMailbox.setMinimumSize(QSize(250,0))
        self.iCyrMailbox.setMaximumSize(QSize(250,32767))

        tabCyrusLayout.addWidget(self.iCyrMailbox,0,5)

        self.gbACL = QGroupBox(self.tabCyrus,"gbACL")
        self.gbACL.setColumnLayout(0,Qt.Vertical)
        self.gbACL.layout().setSpacing(6)
        self.gbACL.layout().setMargin(11)
        gbACLLayout = QGridLayout(self.gbACL.layout())
        gbACLLayout.setAlignment(Qt.AlignTop)

        layout9 = QVBoxLayout(None,0,0,"layout9")

        self.cCyrPermL = QCheckBox(self.gbACL,"cCyrPermL")
        layout9.addWidget(self.cCyrPermL)

        self.cCyrPermR = QCheckBox(self.gbACL,"cCyrPermR")
        layout9.addWidget(self.cCyrPermR)

        self.cCyrPermS = QCheckBox(self.gbACL,"cCyrPermS")
        layout9.addWidget(self.cCyrPermS)

        self.cCyrPermW = QCheckBox(self.gbACL,"cCyrPermW")
        layout9.addWidget(self.cCyrPermW)

        self.cCyrPermI = QCheckBox(self.gbACL,"cCyrPermI")
        layout9.addWidget(self.cCyrPermI)

        gbACLLayout.addLayout(layout9,1,0)

        layout8 = QGridLayout(None,1,1,0,0,"layout8")

        layout7 = QHBoxLayout(None,0,6,"layout7")
        spacer7_2 = QSpacerItem(41,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        layout7.addItem(spacer7_2)

        self.pCyrSetAcl = QPushButton(self.gbACL,"pCyrSetAcl")
        self.pCyrSetAcl.setMinimumSize(QSize(131,0))
        self.pCyrSetAcl.setMaximumSize(QSize(130,25))
        layout7.addWidget(self.pCyrSetAcl)
        spacer8 = QSpacerItem(71,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout7.addItem(spacer8)

        layout8.addLayout(layout7,4,0)

        self.cCyrPermD = QCheckBox(self.gbACL,"cCyrPermD")

        layout8.addWidget(self.cCyrPermD,2,0)

        self.cCyrPermA = QCheckBox(self.gbACL,"cCyrPermA")

        layout8.addWidget(self.cCyrPermA,3,0)

        self.cCyrPermP = QCheckBox(self.gbACL,"cCyrPermP")

        layout8.addWidget(self.cCyrPermP,0,0)

        self.cCyrPermC = QCheckBox(self.gbACL,"cCyrPermC")

        layout8.addWidget(self.cCyrPermC,1,0)

        gbACLLayout.addLayout(layout8,1,1)

        layout6 = QHBoxLayout(None,0,6,"layout6")

        self.textLabel3 = QLabel(self.gbACL,"textLabel3")
        layout6.addWidget(self.textLabel3)

        self.cbUserACL = QComboBox(0,self.gbACL,"cbUserACL")
        self.cbUserACL.setMinimumSize(QSize(270,0))
        self.cbUserACL.setEditable(1)
        layout6.addWidget(self.cbUserACL)
        spacer5 = QSpacerItem(130,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout6.addItem(spacer5)

        gbACLLayout.addMultiCellLayout(layout6,0,0,0,1)

        tabCyrusLayout.addMultiCellWidget(self.gbACL,3,3,0,4)

        self.gbQuota = QGroupBox(self.tabCyrus,"gbQuota")
        self.gbQuota.setEnabled(0)
        self.gbQuota.setColumnLayout(0,Qt.Vertical)
        self.gbQuota.layout().setSpacing(6)
        self.gbQuota.layout().setMargin(11)
        gbQuotaLayout = QGridLayout(self.gbQuota.layout())
        gbQuotaLayout.setAlignment(Qt.AlignTop)
        spacer9 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        gbQuotaLayout.addItem(spacer9,0,6)

        self.pSetQuota = QPushButton(self.gbQuota,"pSetQuota")

        gbQuotaLayout.addWidget(self.pSetQuota,0,5)

        self.textLabel2 = QLabel(self.gbQuota,"textLabel2")

        gbQuotaLayout.addWidget(self.textLabel2,0,4)

        self.textLabel1 = QLabel(self.gbQuota,"textLabel1")

        gbQuotaLayout.addWidget(self.textLabel1,0,0)

        self.iQuotaUsed = QLineEdit(self.gbQuota,"iQuotaUsed")
        self.iQuotaUsed.setEnabled(0)
        self.iQuotaUsed.setMinimumSize(QSize(90,25))
        self.iQuotaUsed.setMaximumSize(QSize(90,25))

        gbQuotaLayout.addWidget(self.iQuotaUsed,0,1)

        self.textLabel2_2 = QLabel(self.gbQuota,"textLabel2_2")

        gbQuotaLayout.addWidget(self.textLabel2_2,0,2)

        self.iQuota = QLineEdit(self.gbQuota,"iQuota")
        self.iQuota.setMinimumSize(QSize(90,0))
        self.iQuota.setMaximumSize(QSize(90,32767))

        gbQuotaLayout.addWidget(self.iQuota,0,3)

        tabCyrusLayout.addMultiCellWidget(self.gbQuota,2,2,0,4)

        self.gbAction = QGroupBox(self.tabCyrus,"gbAction")
        self.gbAction.setColumnLayout(0,Qt.Vertical)
        self.gbAction.layout().setSpacing(6)
        self.gbAction.layout().setMargin(11)
        gbActionLayout = QGridLayout(self.gbAction.layout())
        gbActionLayout.setAlignment(Qt.AlignTop)

        self.pCyrReconstruct = QPushButton(self.gbAction,"pCyrReconstruct")

        gbActionLayout.addWidget(self.pCyrReconstruct,2,0)

        self.pCyrAdd = QPushButton(self.gbAction,"pCyrAdd")

        gbActionLayout.addWidget(self.pCyrAdd,0,0)

        self.pCyrDelete = QPushButton(self.gbAction,"pCyrDelete")
        self.pCyrDelete.setEnabled(1)

        gbActionLayout.addWidget(self.pCyrDelete,1,0)

        tabCyrusLayout.addMultiCellWidget(self.gbAction,2,3,5,5)

        self.lvCyrus = QListView(self.tabCyrus,"lvCyrus")
        self.lvCyrus.addColumn(self.__tr("IMAP Mailboxes"))
        self.lvCyrus.setRootIsDecorated(1)
        self.lvCyrus.setResizeMode(QListView.AllColumns)

        tabCyrusLayout.addMultiCellWidget(self.lvCyrus,1,1,0,5)
        self.wKorreio.insertTab(self.tabCyrus,QString.fromLatin1(""))

        self.TabPage = QWidget(self.wKorreio,"TabPage")
        TabPageLayout = QGridLayout(self.TabPage,1,1,11,6,"TabPageLayout")

        self.groupBox9 = QGroupBox(self.TabPage,"groupBox9")
        self.groupBox9.setMaximumSize(QSize(32767,250))
        self.groupBox9.setColumnLayout(0,Qt.Vertical)
        self.groupBox9.layout().setSpacing(6)
        self.groupBox9.layout().setMargin(11)
        groupBox9Layout = QGridLayout(self.groupBox9.layout())
        groupBox9Layout.setAlignment(Qt.AlignTop)

        self.textLabel6 = QLabel(self.groupBox9,"textLabel6")

        groupBox9Layout.addMultiCellWidget(self.textLabel6,0,1,0,1)

        self.tePostconf = QTextEdit(self.groupBox9,"tePostconf")

        groupBox9Layout.addMultiCellWidget(self.tePostconf,2,2,2,5)
        spacer18 = QSpacerItem(81,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox9Layout.addMultiCell(spacer18,2,2,0,1)
        spacer19 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox9Layout.addItem(spacer19,1,1)
        spacer20 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox9Layout.addMultiCell(spacer20,0,1,3,3)

        self.cbPostconf = QComboBox(0,self.groupBox9,"cbPostconf")
        self.cbPostconf.setMinimumSize(QSize(340,0))

        groupBox9Layout.addMultiCellWidget(self.cbPostconf,0,1,2,2)
        spacer21 = QSpacerItem(120,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox9Layout.addMultiCell(spacer21,0,1,5,5)

        self.pPostMainSave = QPushButton(self.groupBox9,"pPostMainSave")

        groupBox9Layout.addMultiCellWidget(self.pPostMainSave,0,1,4,4)

        TabPageLayout.addWidget(self.groupBox9,0,0)

        layout7_2 = QHBoxLayout(None,0,6,"layout7_2")

        self.pPostStart = QPushButton(self.TabPage,"pPostStart")
        layout7_2.addWidget(self.pPostStart)

        self.pPostStop = QPushButton(self.TabPage,"pPostStop")
        layout7_2.addWidget(self.pPostStop)

        self.pPostRestart = QPushButton(self.TabPage,"pPostRestart")
        layout7_2.addWidget(self.pPostRestart)
        spacer27 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout7_2.addItem(spacer27)

        TabPageLayout.addLayout(layout7_2,2,0)

        self.groupBox10 = QGroupBox(self.TabPage,"groupBox10")
        self.groupBox10.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,0,0,self.groupBox10.sizePolicy().hasHeightForWidth()))
        self.groupBox10.setMinimumSize(QSize(0,280))
        self.groupBox10.setColumnLayout(0,Qt.Vertical)
        self.groupBox10.layout().setSpacing(6)
        self.groupBox10.layout().setMargin(11)
        groupBox10Layout = QGridLayout(self.groupBox10.layout())
        groupBox10Layout.setAlignment(Qt.AlignTop)

        self.textLabel7 = QLabel(self.groupBox10,"textLabel7")

        groupBox10Layout.addWidget(self.textLabel7,0,0)
        spacer14 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer14,0,1)

        self.iPostFileOpen = QLineEdit(self.groupBox10,"iPostFileOpen")
        self.iPostFileOpen.setMinimumSize(QSize(270,0))
        self.iPostFileOpen.setMaximumSize(QSize(270,32767))

        groupBox10Layout.addWidget(self.iPostFileOpen,0,2)
        spacer15 = QSpacerItem(91,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addMultiCell(spacer15,1,1,0,1)

        self.tePostFileOpen = QTextEdit(self.groupBox10,"tePostFileOpen")

        groupBox10Layout.addMultiCellWidget(self.tePostFileOpen,1,1,2,7)
        spacer12 = QSpacerItem(31,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer12,0,3)

        self.pPostFileOpen = QPushButton(self.groupBox10,"pPostFileOpen")

        groupBox10Layout.addWidget(self.pPostFileOpen,0,4)
        spacer13 = QSpacerItem(20,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer13,0,5)

        self.pPostFileSave = QPushButton(self.groupBox10,"pPostFileSave")

        groupBox10Layout.addWidget(self.pPostFileSave,0,6)
        spacer17 = QSpacerItem(51,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer17,0,7)

        TabPageLayout.addWidget(self.groupBox10,1,0)
        self.wKorreio.insertTab(self.TabPage,QString.fromLatin1(""))

        self.tabConfig = QWidget(self.wKorreio,"tabConfig")
        tabConfigLayout = QGridLayout(self.tabConfig,1,1,11,6,"tabConfigLayout")

        self.gConfigLdap = QGroupBox(self.tabConfig,"gConfigLdap")

        self.tLdapHost = QLabel(self.gConfigLdap,"tLdapHost")
        self.tLdapHost.setGeometry(QRect(30,29,70,21))

        self.tLdapUser = QLabel(self.gConfigLdap,"tLdapUser")
        self.tLdapUser.setGeometry(QRect(30,89,98,21))

        self.tLdapPass = QLabel(self.gConfigLdap,"tLdapPass")
        self.tLdapPass.setGeometry(QRect(30,119,60,21))

        self.tLdapBaseDN = QLabel(self.gConfigLdap,"tLdapBaseDN")
        self.tLdapBaseDN.setGeometry(QRect(30,59,83,21))

        self.tLdapPort = QLabel(self.gConfigLdap,"tLdapPort")
        self.tLdapPort.setGeometry(QRect(480,33,37,20))

        self.cbLdapMode = QComboBox(0,self.gConfigLdap,"cbLdapMode")
        self.cbLdapMode.setGeometry(QRect(150,29,85,24))

        self.iLdapHost = QLineEdit(self.gConfigLdap,"iLdapHost")
        self.iLdapHost.setGeometry(QRect(241,29,220,25))

        self.iLdapPort = QLineEdit(self.gConfigLdap,"iLdapPort")
        self.iLdapPort.setGeometry(QRect(519,30,50,25))

        self.pGetBaseDN = QPushButton(self.gConfigLdap,"pGetBaseDN")
        self.pGetBaseDN.setGeometry(QRect(480,60,91,24))

        self.iLdapBaseDN = QLineEdit(self.gConfigLdap,"iLdapBaseDN")
        self.iLdapBaseDN.setGeometry(QRect(152,59,310,25))

        self.iLdapUser = QLineEdit(self.gConfigLdap,"iLdapUser")
        self.iLdapUser.setGeometry(QRect(152,89,310,25))

        self.iLdapPass = QLineEdit(self.gConfigLdap,"iLdapPass")
        self.iLdapPass.setGeometry(QRect(152,119,310,25))
        self.iLdapPass.setEchoMode(QLineEdit.Password)

        tabConfigLayout.addMultiCellWidget(self.gConfigLdap,1,1,0,2)

        self.gConfigCyrus = QGroupBox(self.tabConfig,"gConfigCyrus")

        self.tCyrusHost = QLabel(self.gConfigCyrus,"tCyrusHost")
        self.tCyrusHost.setGeometry(QRect(30,30,50,21))

        self.tCyrusUser = QLabel(self.gConfigCyrus,"tCyrusUser")
        self.tCyrusUser.setGeometry(QRect(30,60,98,21))

        self.tCyrusPass = QLabel(self.gConfigCyrus,"tCyrusPass")
        self.tCyrusPass.setGeometry(QRect(30,90,90,21))

        self.tCyrusPartition = QLabel(self.gConfigCyrus,"tCyrusPartition")
        self.tCyrusPartition.setGeometry(QRect(30,120,113,20))

        self.tCyrusPort = QLabel(self.gConfigCyrus,"tCyrusPort")
        self.tCyrusPort.setGeometry(QRect(471,30,37,21))

        self.cbCyrusMode = QComboBox(0,self.gConfigCyrus,"cbCyrusMode")
        self.cbCyrusMode.setGeometry(QRect(150,30,85,24))

        self.iCyrusHost = QLineEdit(self.gConfigCyrus,"iCyrusHost")
        self.iCyrusHost.setGeometry(QRect(240,30,220,25))

        self.iCyrusPort = QLineEdit(self.gConfigCyrus,"iCyrusPort")
        self.iCyrusPort.setGeometry(QRect(510,27,50,25))

        self.iCyrusUser = QLineEdit(self.gConfigCyrus,"iCyrusUser")
        self.iCyrusUser.setGeometry(QRect(150,60,310,25))

        self.iCyrusPass = QLineEdit(self.gConfigCyrus,"iCyrusPass")
        self.iCyrusPass.setGeometry(QRect(150,90,310,25))
        self.iCyrusPass.setEchoMode(QLineEdit.Password)

        self.iCyrusPart = QLineEdit(self.gConfigCyrus,"iCyrusPart")
        self.iCyrusPart.setGeometry(QRect(150,120,310,24))

        tabConfigLayout.addMultiCellWidget(self.gConfigCyrus,0,0,0,2)

        self.gConfigCyrus_2 = QGroupBox(self.tabConfig,"gConfigCyrus_2")

        self.tCyrusPass_2 = QLabel(self.gConfigCyrus_2,"tCyrusPass_2")
        self.tCyrusPass_2.setGeometry(QRect(30,90,90,21))

        self.tCyrusHost_2 = QLabel(self.gConfigCyrus_2,"tCyrusHost_2")
        self.tCyrusHost_2.setGeometry(QRect(30,30,50,21))

        self.tCyrusUser_2 = QLabel(self.gConfigCyrus_2,"tCyrusUser_2")
        self.tCyrusUser_2.setGeometry(QRect(30,60,98,21))

        self.tCyrusPort_2 = QLabel(self.gConfigCyrus_2,"tCyrusPort_2")
        self.tCyrusPort_2.setGeometry(QRect(482,30,37,21))

        self.iSshHost = QLineEdit(self.gConfigCyrus_2,"iSshHost")
        self.iSshHost.setGeometry(QRect(150,30,310,25))

        self.iSshPort = QLineEdit(self.gConfigCyrus_2,"iSshPort")
        self.iSshPort.setGeometry(QRect(521,30,50,25))

        self.iSshUser = QLineEdit(self.gConfigCyrus_2,"iSshUser")
        self.iSshUser.setGeometry(QRect(151,60,310,25))

        self.iSshPass = QLineEdit(self.gConfigCyrus_2,"iSshPass")
        self.iSshPass.setGeometry(QRect(151,90,310,25))
        self.iSshPass.setEchoMode(QLineEdit.Password)

        tabConfigLayout.addMultiCellWidget(self.gConfigCyrus_2,2,2,0,2)
        spacer7 = QSpacerItem(470,31,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabConfigLayout.addItem(spacer7,3,2)

        self.pSaveConfig = QPushButton(self.tabConfig,"pSaveConfig")
        self.pSaveConfig.setMinimumSize(QSize(151,0))
        self.pSaveConfig.setMaximumSize(QSize(151,32767))

        tabConfigLayout.addWidget(self.pSaveConfig,3,1)
        spacer6 = QSpacerItem(140,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        tabConfigLayout.addItem(spacer6,3,0)
        self.wKorreio.insertTab(self.tabConfig,QString.fromLatin1(""))

        dKorreioLayout.addWidget(self.wKorreio,0,0)

        self.languageChange()

        self.resize(QSize(804,592).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)

        self.connect(self.pCyrSearch,SIGNAL("clicked()"),self.cyrus_search)
        self.connect(self.wKorreio,SIGNAL("currentChanged(QWidget*)"),self.tab_changed)
        self.connect(self.pSaveConfig,SIGNAL("clicked()"),self.save_config)
        self.connect(self.lvCyrus,SIGNAL("selectionChanged(QListViewItem*)"),self.mailbox_clicked)
        self.connect(self.pCyrDelete,SIGNAL("clicked()"),self.delete_mailbox)
        self.connect(self.pCyrAdd,SIGNAL("clicked()"),self.create_mailbox)
        self.connect(self.pSetQuota,SIGNAL("clicked()"),self.set_quota)
        self.connect(self.cbUserACL,SIGNAL("activated(const QString&)"),self.check_permissions)
        self.connect(self.pCyrSetAcl,SIGNAL("clicked()"),self.set_cyracl)
        self.connect(self.pCyrReconstruct,SIGNAL("clicked()"),self.reconstruct_mailbox)
        self.connect(self.pGetBaseDN,SIGNAL("clicked()"),self.get_ldap_basedn)
        self.connect(self.cbCyrusMode,SIGNAL("activated(const QString&)"),self.set_imap_port)
        self.connect(self.pLdapSearch,SIGNAL("clicked()"),self.ldap_search)
        self.connect(self.lvLdap,SIGNAL("selectionChanged()"),self.ldap_dn_clicked)
        self.connect(self.pLdapAddUser,SIGNAL("clicked()"),self.ldap_insert_user)
        self.connect(self.pLdapAddOu,SIGNAL("clicked()"),self.ldap_insert_ou)
        self.connect(self.pLdapDelete,SIGNAL("clicked()"),self.ldap_remove)
        self.connect(self.cbPostconf,SIGNAL("activated(const QString&)"),self.postconf_changed)
        self.connect(self.pPostMainSave,SIGNAL("clicked()"),self.postconf_save)
        self.connect(self.pPostFileOpen,SIGNAL("clicked()"),self.postfix_open_conf)
        self.connect(self.pPostFileSave,SIGNAL("clicked()"),self.postfix_save_conf)
        self.connect(self.pPostStart,SIGNAL("clicked()"),self.postfix_start)
        self.connect(self.pPostStop,SIGNAL("clicked()"),self.postfix_stop)
        self.connect(self.pPostRestart,SIGNAL("clicked()"),self.postfix_restart)


    def languageChange(self):
        self.setCaption(self.__trUtf8("\x4b\x6f\x72\x72\x65\x69\x6f\x20\x2d\x20\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\xc3\xa7\xc3\xa3\x6f\x20\x64\x65\x20\x43\x6f\x72\x72\x65\x69\x6f\x20\x45\x6c\x65\x74\x72\xc3\xb4\x6e\x69\x63\x6f"))
        self.groupBox12.setTitle(self.__tr("Cadastrar Grupo"))
        self.textLabel2_3.setText(self.__tr("Nome (ou):"))
        self.pLdapAddOu.setText(self.__tr("Cadastrar"))
        self.KorreioAdd.setTitle(self.__trUtf8("\x43\x61\x64\x61\x73\x74\x72\x61\x72\x20\x55\x73\x75\xc3\xa1\x72\x69\x6f"))
        self.pLdapAddUser.setText(self.__tr("Cadastrar"))
        self.textLabel3_2.setText(self.__tr("Nome (cn):"))
        self.textLabel5.setText(self.__tr("E-mail (mail):"))
        self.textLabel1_3.setText(self.__tr("Senha (userPassword):"))
        self.KorreioSearch.setTitle(self.__tr("Pesquisar"))
        self.lvLdapAttr.header().setLabel(0,self.__tr("Atributo"))
        self.lvLdapAttr.header().setLabel(1,self.__tr("Valor"))
        self.cKorDnAttr.clear()
        self.cKorDnAttr.insertItem(self.__tr("Nome::cn"))
        self.cKorDnAttr.insertItem(self.__tr("E-mail::mail"))
        self.pLdapSearch.setText(self.__tr("Pesquisar"))
        self.lvLdap.header().setLabel(0,self.__tr("Distinguished Name"))
        self.pLdapDelete.setText(self.__tr("Remover"))
        self.wKorreio.changeTab(self.tabLdap,self.__tr("LDAP Manager"))
        self.tCyrUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.pCyrSearch.setText(self.__tr("Pesquisar"))
        self.textLabel1_2.setText(self.__tr("Mailbox:"))
        self.gbACL.setTitle(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xb5\x65\x73\x20\x64\x65\x20\x61\x63\x65\x73\x73\x6f\x20\x61\x20\x4d\x61\x69\x6c\x62\x6f\x78"))
        self.cCyrPermL.setText(self.__tr("Listar (L)"))
        self.cCyrPermR.setText(self.__trUtf8("\x4c\x65\x72\x20\x63\x6f\x6e\x74\x65\xc3\xba\x64\x6f\x20\x28\x52\x29"))
        self.cCyrPermS.setText(self.__tr("Preservar estado (S)"))
        self.cCyrPermW.setText(self.__tr("Alterar estado (W)"))
        self.cCyrPermI.setText(self.__tr("Inserir mensagem (I)"))
        self.pCyrSetAcl.setText(self.__tr("Aplicar"))
        self.cCyrPermD.setText(self.__tr("Remover mailbox ou mensagens (D)"))
        self.cCyrPermA.setText(self.__trUtf8("\x41\x6c\x74\x65\x72\x61\x72\x20\x6f\x70\xc3\xa7\xc3\xb5\x65\x73\x20\x64\x65\x20\x61\x63\x65\x73\x73\x6f\x20\x28\x41\x29"))
        self.cCyrPermP.setText(self.__tr("Inserir mensagem por + (P)"))
        self.cCyrPermC.setText(self.__tr("Criar mailbox filhas (C)"))
        self.textLabel3.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.gbQuota.setTitle(self.__tr("Quota"))
        self.pSetQuota.setText(self.__tr("Aplicar"))
        self.textLabel2.setText(self.__tr("KB"))
        self.textLabel1.setText(self.__tr("Utilizado:"))
        self.textLabel2_2.setText(self.__tr("Limite:"))
        self.gbAction.setTitle(self.__trUtf8("\x41\xc3\xa7\xc3\xb5\x65\x73"))
        self.pCyrReconstruct.setText(self.__tr("Reindexar Mailbox"))
        self.pCyrAdd.setText(self.__tr("Criar Mailbox"))
        self.pCyrDelete.setText(self.__tr("Remover Mailbox"))
        self.lvCyrus.header().setLabel(0,self.__tr("IMAP Mailboxes"))
        self.wKorreio.changeTab(self.tabCyrus,self.__tr("Cyrus Manager"))
        self.groupBox9.setTitle(self.__tr("main.cf"))
        self.textLabel6.setText(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xa3\x6f\x3a"))
        self.pPostMainSave.setText(self.__tr("Salvar"))
        self.pPostStart.setText(self.__tr("Start Postfix"))
        self.pPostStop.setText(self.__tr("Stop Postfix"))
        self.pPostRestart.setText(self.__tr("Restart Postfix"))
        self.groupBox10.setTitle(self.__tr("Arquivos"))
        self.textLabel7.setText(self.__tr("Arquivo:"))
        self.iPostFileOpen.setText(self.__tr("/etc/postfix/"))
        self.pPostFileOpen.setText(self.__tr("Abrir"))
        self.pPostFileSave.setText(self.__tr("Salvar"))
        self.wKorreio.changeTab(self.TabPage,self.__tr("Postfix Manager"))
        self.gConfigLdap.setTitle(self.__tr("Ldap Config"))
        self.tLdapHost.setText(self.__tr("Host:"))
        self.tLdapUser.setText(self.__tr("User Admin:"))
        self.tLdapPass.setText(self.__tr("Senha:"))
        self.tLdapBaseDN.setText(self.__tr("BaseDN:"))
        self.tLdapPort.setText(self.__tr("Port:"))
        self.cbLdapMode.clear()
        self.cbLdapMode.insertItem(self.__tr("ldap://"))
        self.cbLdapMode.insertItem(self.__tr("ldaps://"))
        self.pGetBaseDN.setText(self.__tr("Get It"))
        self.gConfigCyrus.setTitle(self.__tr("Cyrus Config"))
        self.tCyrusHost.setText(self.__tr("Host:"))
        self.tCyrusUser.setText(self.__tr("User Admin:"))
        self.tCyrusPass.setText(self.__tr("Senha:"))
        self.tCyrusPartition.setText(self.__tr("Cyrus-partition:"))
        self.tCyrusPort.setText(self.__tr("Port:"))
        self.cbCyrusMode.clear()
        self.cbCyrusMode.insertItem(self.__tr("imap://"))
        self.cbCyrusMode.insertItem(self.__tr("imaps://"))
        self.iCyrusPart.setText(QString.null)
        self.gConfigCyrus_2.setTitle(self.__tr("SSH Config"))
        self.tCyrusPass_2.setText(self.__tr("Senha:"))
        self.tCyrusHost_2.setText(self.__tr("Host:"))
        self.tCyrusUser_2.setText(self.__tr("User:"))
        self.tCyrusPort_2.setText(self.__tr("Port:"))
        self.pSaveConfig.setText(self.__tr("Salvar"))
        self.wKorreio.changeTab(self.tabConfig,self.__trUtf8("\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\xc3\xa7\xc3\xb5\x65\x73"))


    def cyrus_search(self):
        m = self.cyrus_connect()
        mailboxes = m.lm("user",self.iCyrUser.text().ascii()+"*")
        print m.lm(None)
        m.logout()
        self.lvCyrus.clear()
        mailbox = []
        if self.iCyrMailbox.text().ascii():
            mailbox = self.iCyrMailbox.text().ascii().split("/")
        lastlen=99
        tree = {}
        i=True
        for group in mailboxes:
            for id in mailboxes[group]:
              print group+"::"+id
              idlist = id.split("/")
              if idlist[0] == "INBOX":
                idlist[0] = self.iCyrusUser.text().ascii()
              elif idlist[0] == "user":
                idlist = idlist[1:]
              newlen = len(idlist)
              if newlen == 1:
                tree[1] = QListViewItem(self.lvCyrus)
                tree[1].setText(0,idlist[-1])
              elif newlen == 2:
                tree[2] = QListViewItem(tree[1])
                tree[2].setText(0,idlist[-1])
              else:
                tree[newlen] = QListViewItem(tree[newlen-1])
                tree[newlen].setText(0,idlist[-1])
              if len(mailbox) > newlen:
                if tree[newlen].text(0).ascii() == mailbox[newlen-1]:
                  tree[newlen].setOpen(True)
        

    def save_config(self):
        import os.path
        
        try:
            os.mkdir(os.path.expanduser("~/.korreio"),0755)
        except OSError, e:
            pass
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')
            f.write('cyrus.mode='+self.cbCyrusMode.currentText().ascii()+'\n')
            f.write('cyrus.host='+self.iCyrusHost.text().ascii()+'\n')
            f.write('cyrus.port='+self.iCyrusPort.text().ascii()+'\n')
            f.write('cyrus.user='+self.iCyrusUser.text().ascii()+'\n')
            f.write('cyrus.pass='+self.iCyrusPass.text().ascii()+'\n')
            f.write('cyrus.part='+self.iCyrusPart.text().ascii()+'\n')
            f.write('ldap.mode='+self.cbLdapMode.currentText().ascii()+'\n')
            f.write('ldap.host='+self.iLdapHost.text().ascii()+'\n')
            f.write('ldap.port='+self.iLdapPort.text().ascii()+'\n')
            f.write('ldap.basedn='+self.iLdapBaseDN.text().ascii()+'\n')
            f.write('ldap.user='+self.iLdapUser.text().ascii()+'\n')
            f.write('ldap.pass='+self.iLdapPass.text().ascii()+'\n')
            f.write('ssh.host='+self.iSshHost.text().ascii()+'\n')
            f.write('ssh.port='+self.iSshPort.text().ascii()+'\n')
            f.write('ssh.user='+self.iSshUser.text().ascii()+'\n')
            f.write('ssh.pass='+self.iSshPass.text().ascii()+'\n')
            f.close()
        except OSError, e:
            print "Debug::conf() Info: "+e.filename+" "+e.strerror
        
        print "Debug::save_config() Configuration saved."
        
        
        

    def load_config(self):
        import os.path
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
            conf=f.read()
            f.close()
        except IOError, e:
            print "Debug::conf() Info: "+e.filename+" "+e.strerror
            return True
        
        confList = conf.split("\n")
        confList.pop()
        confDict = {}
        
        for line in confList:
           key=line.split("=")
           confDict[key[0]] = "=".join(key[1:])
        
        self.cbCyrusMode.setCurrentText(confDict.get("cyrus.mode"))
        self.iCyrusHost.setText(confDict.get("cyrus.host"))
        self.iCyrusPort.setText(confDict.get("cyrus.port"))
        self.iCyrusUser.setText(confDict.get("cyrus.user"))
        self.iCyrusPass.setText(confDict.get("cyrus.pass"))
        self.iCyrusPart.setText(confDict.get("cyrus.part"))
        self.cbLdapMode.setCurrentText(confDict.get("ldap.mode"))
        self.iLdapHost.setText(confDict.get("ldap.host"))
        self.iLdapPort.setText(confDict.get("ldap.port"))
        self.iLdapBaseDN.setText(confDict.get("ldap.basedn"))
        self.iLdapUser.setText(confDict.get("ldap.user"))
        self.iLdapPass.setText(confDict.get("ldap.pass"))
        self.iSshHost.setText(confDict.get("ssh.host"))
        self.iSshPort.setText(confDict.get("ssh.port"))
        self.iSshUser.setText(confDict.get("ssh.user"))
        self.iSshPass.setText(confDict.get("ssh.pass"))
        
        print "Debug::load_config() Configuration loaded."
        
        

    def tab_changed(self):
        import sys
        reload(sys)
        sys.setdefaultencoding("utf-8")
        menu=str(self.wKorreio.tabLabel(self.wKorreio.currentPage()))
        print "Debug::menu_click() Menu: "+menu
        if menu == "LDAP Manager":
            self.load_config()
        elif menu == "Postfix Manager":
            self.postfix_postconf()
        

    def mailbox_clicked(self):
        
        item=self.lvCyrus.currentItem()
        if item.childCount() == 0:
            self.pCyrDelete.setEnabled(True)
        else:
            self.pCyrDelete.setEnabled(False)
        mailbox=item.text(0).ascii()
        while item.parent() is not None:
            mailbox=item.parent().text(0).ascii()+"/"+mailbox
            item=item.parent()
        self.iCyrMailbox.setText(mailbox)
        
        if len(mailbox.split("/")) == 1:
            self.gbQuota.setEnabled(True)
            self.iQuotaUsed.setEnabled(False)
        else:
            self.gbQuota.setEnabled(False)
        
        m = self.cyrus_connect()
        quota = m.lq("user",self.iCyrMailbox.text().ascii())
        self.iQuotaUsed.setText(str(quota[0]))
        self.iQuota.setText(str(quota[1]))
        self.permissions = m.lam("user",mailbox);
        self.cbUserACL.clear();
        for user in self.permissions:
            self.cbUserACL.insertItem(user)
        self.check_permissions();
        

    def create_mailbox(self):
        m = self.cyrus_connect()
        if self.iCyrusPart.text().ascii():
            m.cm("user", self.iCyrMailbox.text().ascii(),self.iCyrusPart.text().ascii())
        else:
            m.cm("user", self.iCyrMailbox.text().ascii())
        m.sam("user", self.iCyrMailbox.text().ascii(), self.iCyrusUser.text().ascii(), " ")
        m.logout()
        self.cyrus_search()
        

    def delete_mailbox(self):
        m = self.cyrus_connect()
        m.sam("user", self.iCyrMailbox.text().ascii(), self.iCyrusUser.text().ascii(), "c")
        m.dm("user", self.iCyrMailbox.text().ascii())
        m.logout()
        self.cyrus_search()
        

    def set_quota(self):
        m = self.cyrus_connect()
        m.sq("user",self.iCyrMailbox.text().ascii(),self.iQuota.text().ascii())
        m.logout()
        

    def check_permissions(self):
        mailbox_perm = self.permissions[self.cbUserACL.currentText().ascii()]
        import re
        if re.search("l",mailbox_perm): self.cCyrPermL.setChecked(True)
        else: self.cCyrPermL.setChecked(False)
        if re.search("r",mailbox_perm): self.cCyrPermR.setChecked(True)
        else: self.cCyrPermR.setChecked(False)
        if re.search("s",mailbox_perm): self.cCyrPermS.setChecked(True)
        else: self.cCyrPermS.setChecked(False)
        if re.search("w",mailbox_perm): self.cCyrPermW.setChecked(True)
        else: self.cCyrPermW.setChecked(False)
        if re.search("i",mailbox_perm): self.cCyrPermI.setChecked(True)
        else: self.cCyrPermI.setChecked(False)
        if re.search("p",mailbox_perm): self.cCyrPermP.setChecked(True)
        else: self.cCyrPermP.setChecked(False)
        if re.search("c",mailbox_perm): self.cCyrPermC.setChecked(True)
        else: self.cCyrPermC.setChecked(False)
        if re.search("d",mailbox_perm): self.cCyrPermD.setChecked(True)
        else: self.cCyrPermD.setChecked(False)
        if re.search("a",mailbox_perm): self.cCyrPermA.setChecked(True)
        else: self.cCyrPermA.setChecked(False)
        

    def set_cyracl(self):
        perm=""
        if self.cCyrPermL.isChecked():
            perm="l"
        if self.cCyrPermR.isChecked():
            perm=perm+"r"
        if self.cCyrPermS.isChecked():
            perm=perm+"s"
        if self.cCyrPermW.isChecked():
            perm=perm+"w"
        if self.cCyrPermI.isChecked():
            perm=perm+"i"
        if self.cCyrPermP.isChecked():
            perm=perm+"p"
        if self.cCyrPermC.isChecked():
            perm=perm+"c"
        if self.cCyrPermD.isChecked():
            perm=perm+"d"
        if self.cCyrPermA.isChecked():
            perm=perm+"a"
        
        import cyruslib
        if self.cbCyrusMode.currentText().ascii() == "imaps://":
            cyrmode = 1
        else:
            cyrmode = 0
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),cyrmode)
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        m.sam("user",self.iCyrMailbox.text().ascii(),self.cbUserACL.currentText().ascii(),perm)
        

    def reconstruct_mailbox(self):
        import cyruslib
        if self.cbCyrusMode.currentText().ascii() == "imaps://":
            cyrmode = 1
        else:
            cyrmode = 0
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),cyrmode)
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        m.reconstruct("user",self.iCyrMailbox.text().ascii())
        
        

    def get_ldap_basedn(self):
        import ldap
        try:
            l = ldap.open(self.iLdapHost.text().ascii(),int(self.iLdapPort.text().ascii()))
            l.protocol_version = ldap.VERSION3
            if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
                l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
            else:
                l.simple_bind()
            searchScope = ldap.SCOPE_BASE
            searchFilter = "objectclass=*"
            retrieveAttributes = ["namingContexts"]
            ldap_result_id = l.search("", searchScope, searchFilter, retrieveAttributes)
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                if (result_data == []):
                    break
                else:
                    if result_type == ldap.RES_SEARCH_ENTRY:
                        for j in result_data:
                             self.iLdapBaseDN.setText(j[1]["namingContexts"][0])
                             self.iLdapUser.setText("cn=admin,"+j[1]["namingContexts"][0])
                             return True
        except ldap.LDAPError, e:
            print e
        
        

    def set_imap_port(self):
        if self.cbCyrusMode.currentText().ascii() == "imap://":
            self.iCyrusPort.setText("143")
        else:
            self.iCyrusPort.setText("993")
        

    def cyrus_connect(self):
        import cyruslib
        if self.cbCyrusMode.currentText().ascii() == "imaps://":
            cyrmode = 1
        else:
            cyrmode = 0
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),cyrmode)
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        return m
        

    def ldap_search(self):
            def create_nodes(dn):
                dnlist = dn.split(",")
                dnnode = ",".join(dnlist[1:])
                if not self.nodes.get(dnnode):
                    create_nodes(dnnode)            
                self.nodes[dn] = QListViewItem(self.nodes.get(dnnode))
                self.nodes[dn].setText(0,dnlist[0])
                
            import re
            basedn = self.iLdapBaseDN.text().ascii()
            try:
                olddn = self.get_full_dn()
            except AttributeError, e:
                olddn = basedn
            self.lvLdap.clear()
            self.nodes = {}
            self.nodes[basedn] = QListViewItem(self.lvLdap)
            self.nodes[basedn].setText(0,basedn)
            self.nodes[basedn].setOpen(True)
            if not self.iKorDnAttr.text().ascii():
                filter = "(objectClass=*)"
            else:
                filter = "("+self.cKorDnAttr.currentText().ascii().split(":")[2]+"="+self.iKorDnAttr.text().ascii()+"*)"
            self.ldap_attr = self.ldap_result(filter)
            try:
                root = self.ldap_attr.get(basedn)
                del self.ldap_attr[basedn]
            except KeyError, e:
                pass
            for dn in self.ldap_attr:
                if not self.nodes.get(dn):
                    create_nodes(dn)
            try:
                self.ldap_attr[basedn] = root
            except KeyError, e:
                pass
            i = 0
            while olddn != basedn:
                try:
                    self.nodes[olddn].setOpen(True)
                    if i == 0:
                        self.lvLdap.setSelected(self.nodes[olddn], True)
                        i = 1
                except KeyError, e:
                    pass
                dnlist = olddn.split(",")
                olddn = ",".join(dnlist[1:])
                
        

    def ldap_connect(self):
        try:
            import ldap
            l = ldap.open(self.iLdapHost.text().ascii(),int(self.iLdapPort.text().ascii()))
            l.protocol_version = ldap.VERSION3
            l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
            return l
        except ldap.LDAPError, e:
            print e
        

    def ldap_result(self,a0):
        import ldap
        try:
            l = self.ldap_connect()
            searchScope = ldap.SCOPE_SUBTREE
            searchFilter = a0
            retrieveAttributes = None
            ldap_result_id = l.search(self.iLdapBaseDN.text().ascii(), searchScope, searchFilter, retrieveAttributes)
            ldap_result = {}
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                if (result_data == []):
                    break
                elif result_type == ldap.RES_SEARCH_ENTRY:
                    ldap_result[result_data[0][0]] = result_data[0][1]
            return ldap_result
        except ldap.LDAPError, e:
            print e
        

    def ldap_dn_clicked(self):
        self.lvLdapAttr.clear()
        dn = self.get_full_dn()
        try:
            for attribute,values in self.ldap_attr.get(dn).items():
                for value in values:
                   item = QListViewItem(self.lvLdapAttr)
                   item.setText(0,attribute)
                   item.setText(1,value)
        except AttributeError, e:
            pass
        item = self.lvLdap.currentItem()
        if item.parent() is None or item.childCount() != 0:
            self.pLdapDelete.setEnabled(False)
        else:
            self.pLdapDelete.setEnabled(True)
        

    def ldap_insert_user(self):
        import md5
        import base64
        dn = "cn="+self.iLdapCn.text().ascii()+","+self.get_full_dn()
        attrs = {}
        attrs['objectclass'] = ['inetOrgPerson']
        attrs['cn'] = self.iLdapCn.text().ascii()
        attrs['sn'] = self.iLdapCn.text().ascii().split(" ")[-1]
        emails = self.iLdapMail.text().ascii().split(",")
        attrs['mail'] = emails[0]
        if len(emails) > 0:
            attrs['l'] = emails[1:]
        m = md5.new(self.iLdapUserP.text().ascii())
        attrs['userPassword'] = '{md5}'+base64.encodestring(m.digest())
        self.ldap_add(dn,attrs)
        self.ldap_search()
        

    def ldap_add(self,a0,a1):
        #a0 = DN, a1 = attrs
        import ldap
        import ldap.modlist as modlist
        try:
            ldif = modlist.addModlist(a1)
            l = self.ldap_connect()
            l.add_s(a0,ldif)
            l.unbind_s()
        except ldap.LDAPError, e:
            print e
        

    def ldap_insert_ou(self):
        dn = "ou="+self.iLdapOu.text().ascii()+","+self.get_full_dn()
        attrs = {}
        attrs['objectclass'] = ['organizationalUnit']
        attrs['ou'] = self.iLdapOu.text().ascii()
        self.ldap_add(dn,attrs)
        self.ldap_search()
        

    def ldap_remove(self):
        dn = self.get_full_dn()
        if dn is not None:
            self.ldap_del(dn)
            self.ldap_search()
            self.lvLdapAttr.clear()
        

    def ldap_del(self,a0):
        l = self.ldap_connect()
        l.delete_s(a0)
        

    def postfix_postconf(self):
        import re
        cmd = self.ssh_cmd("postconf")
        self.postconf = {}
        self.cbPostconf.clear()
        for config in cmd:
            if re.search("=",config):
                configlist = config.strip().split("=")
                configlist[0]=configlist[0].strip(" ")
                self.postconf[configlist[0]] = configlist[1]
                self.cbPostconf.insertItem(configlist[0])
        self.postconf_changed()
        

    def ssh_cmd(self,a0):
        import pexpect
        import re
        try:
            print a0
            child = pexpect.spawn('ssh -p'+self.iSshPort.text().ascii()+' '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+' "'+a0+'"')
            i = child.expect(['assword','want to continue connecting'], timeout=5)
            if i==0:
                print "Sending password"
                child.sendline(self.iSshPass.text().ascii())
            elif i==1:
                print "Accepting fingerprint"
                child.sendline('yes')
                child.expect('assword', timeout=2)
                print "Sending password"
                child.sendline(self.iSshPass.text().ascii())
            print_cmd=[]
            for line in child:
                line = re.sub("(\n|\r)","",line)
                print_cmd.append(line)
            child.kill(0)
        except pexpect.EOF, t:
            print "Cant connect to: "+self.iSshHost.text().ascii()
        except pexpect.TIMEOUT, t:
            print "Timeout connection to: "+self.iSshHost.text().ascii()
        return print_cmd
        

    def postconf_changed(self):
        import re
        value = self.postconf.get(self.cbPostconf.currentText().ascii())
        value = re.sub("( )+"," ",value)
        value = re.sub(", ",",",value)
        value = re.sub(",",",\n",value)
        value = re.sub("^ ","",value)
        self.tePostconf.setText(value)
        

    def postconf_save(self):
        import re
        value = re.sub("( )+"," ",self.tePostconf.text().ascii())
        value = re.sub(",",", ",value)
        value = re.sub("\n","",value)
        value = re.sub("\r","",value)
        print self.ssh_cmd("postconf -e "+self.cbPostconf.currentText().ascii()+"='"+value+"'")
        

    def postfix_open_conf(self):
        import re
        value = self.ssh_cmd("cat "+self.iPostFileOpen.text().ascii())
        values = ""
        for line in value[1:]:
            values = values+line+"\n"
        if re.search("^cat:",values):
            print "Arquivo "+self.iPostFileOpen.text().ascii()+" nao encontrado."
            return True
        self.tePostFileOpen.setText(values)
        

    def postfix_save_conf(self):
        if self.tePostFileOpen.length () == 0:
            self.ssh_cmd("rm -f "+self.iPostFileOpen.text().ascii())
            return True
        f = open("/tmp/korreio.tmp", 'w')
        for line in self.tePostFileOpen.text().ascii():
            f.write(line)
        f.close()
        self.scp_cmd(self.iPostFileOpen.text().ascii())
        

    def scp_cmd(self,a0):
        import pexpect
        import re
        try:
            print a0
            child = pexpect.spawn('scp -P'+self.iSshPort.text().ascii()+' /tmp/korreio.tmp '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+':"'+a0+'"')
            i = child.expect(['assword','want to continue connecting'], timeout=5)
            if i==0:
                print "Sending password"
                child.sendline(self.iSshPass.text().ascii())
            elif i==1:
                print "Accepting fingerprint"
                child.sendline('yes')
                child.expect('assword', timeout=2)
                print "Sending password"
                child.sendline(self.iSshPass.text().ascii())
            print_cmd=[]
            for line in child:
                print_cmd.append(line)
            child.kill(0)
        except pexpect.EOF, t:
            print "Cant connect to: "+self.iSshHost.text().ascii()
        except pexpect.TIMEOUT, t:
            print "Timeout connection to: "+self.iSshHost.text().ascii()
        
        

    def postfix_stop(self):
        value = self.ssh_cmd("/etc/init.d/postfix stop")
        for line in value[1:]:
            print line
        

    def postfix_start(self):
        value = self.ssh_cmd("/etc/init.d/postfix start")
        for line in value[1:]:
            print line
        

    def postfix_restart(self):
        value = self.ssh_cmd("/etc/init.d/postfix restart")
        for line in value[1:]:
            print line
        

    def get_full_dn(self):
        item = self.lvLdap.currentItem()
        dn = item.text(0).ascii()
        while item.parent() is not None:
            dn = dn+","+item.parent().text(0).ascii()
            item = item.parent()
        return dn
        

    def __tr(self,s,c = None):
        return qApp.translate("dKorreio",s,c)

    def __trUtf8(self,s,c = None):
        return qApp.translate("dKorreio",s,c,QApplication.UnicodeUTF8)
