# Copyright (c) 2007 -  Reinaldo Carvalho <reinaldoc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.

void dKorreio::imap_connect() {
import cyruslib

def imap_connect_now():
    self.m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),ssl)
    if self.m.alive:
        if self.m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii()):
            if self.m.m.isadmin():
                self.console("Servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+" conectado com sucesso.")
            else:
                self.m.logout()
                self.console("Erro ao conectar no servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+". (Usuário não possui direito de administrador)".encode('iso-8859-1'))
        else:
            self.console("Erro ao conectar no servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+". (Usuário ou senha inválidos)".encode('iso-8859-1'))
    else:
        self.console("Erro ao conectar no servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+". (Conexão recusada)".encode('iso-8859-1'))

if self.cbCyrusMode.currentText().ascii() == "imaps://": ssl = 1
else: ssl = 0

try:
    if self.m.m.isadmin():
        if self.imap_connect_active_host != self.iCyrusHost.text().ascii() or self.imap_connect_active_port != self.iCyrusPort.text().ascii() or self.imap_connect_active_user != self.iCyrusUser.text().ascii():
            # Server changed
            imap_connect_now()
    else:
        # Not connected
        imap_connect_now()
except AttributeError, e:
    # First connection
    imap_connect_now()

self.imap_connect_active_host = self.iCyrusHost.text().ascii()
self.imap_connect_active_port = self.iCyrusPort.text().ascii()
self.imap_connect_active_user = self.iCyrusUser.text().ascii()

self.tConfShowImapSep.setText("Imap delimiter: "+self.m.sep)

return self.m
}

void dKorreio::imap_search() {
import re
m = self.imap_connect()

if self.iImapSearch.text().ascii() == '':
    user = "*"
else:
    user = "user"+m.sep+self.iImapSearch.text().ascii()+"*"

mailboxes = m.lm("",user)

oldmailbox=['','']
if self.lvCyrus.childCount() > 0:
    item=self.lvCyrus.currentItem()
    oldmailbox[0]=item.text(0).ascii()
    while item.parent() is not None:
        oldmailbox[0]=item.parent().text(0).ascii()
        item=item.parent()

if self.lvCyrusGlobal.childCount() > 0:
    item=self.lvCyrusGlobal.currentItem()
    oldmailbox[1]=item.text(0).ascii()
    while item.parent() is not None:
        oldmailbox[1]=item.parent().text(0).ascii()
        item=item.parent()

self.lvCyrus.clear()
self.lvCyrusGlobal.clear()
self.iImapMailbox.clear()
self.cbUserACL.clear()
self.iQuota.clear()
self.iQuotaUsed.clear()
self.iAnnotationExpire.clear()

def create_nodes(dn):
    dnlist = dn.split(m.sep)
    dnnode = m.sep.join(dnlist[:-1])
    if not self.tree.get(dnnode):
        create_nodes(dnnode)
    self.tree[dn] = QListViewItem(self.tree.get(dnnode))
    self.tree[dn].setText(0,dnlist[-1])

try:
    self.tree = {}
    for id in mailboxes["all"]:
        idlist = id.split(m.sep)
        if re.search("^user",id):
            id = m.sep.join(idlist[1:])
            if len(idlist) == 2:
                self.tree[id] = QListViewItem(self.lvCyrus)
                self.tree[id].setText(0, id)
                continue
        elif len(idlist) == 1:
            self.tree[id] = QListViewItem(self.lvCyrusGlobal)
            self.tree[id].setText(0, idlist[0])
            continue
        idlist = id.split(m.sep)
        if not self.tree.get(id):
            create_nodes(id)
        else:
            print "Erro obtendo "+ idlist[-1]
except KeyError, e:
    pass

try:
    def selectItem(item):
        self.lvCyrus.setCurrentItem(item)
        item.setOpen(True)
        item.setSelected(True)

    item=self.lvCyrus.firstChild()
    if oldmailbox[0] == '':
        selectItem(item)
    else:
        while item is not None:
            if item.text(0).ascii() == oldmailbox[0]:
                selectItem(item)
                self.lvCyrus.scrollBy(0,item.itemPos())
                break
            item=item.nextSibling()
        if item is None:
            selectItem(self.lvCyrus.firstChild())
except AttributeError, e:
    pass

try:
    def selectItem(item):
        self.lvCyrusGlobal.setCurrentItem(item)
        item.setOpen(True)
        item.setSelected(True)

    item=self.lvCyrusGlobal.firstChild()
    if oldmailbox[1] == '':
        selectItem(item)
    else:
        item=self.lvCyrusGlobal.firstChild()
        while item is not None:
            if item.text(0).ascii() == oldmailbox[1]:
                selectItem(item)
                self.lvCyrusGlobal.scrollBy(0,item.itemPos())
                break
            item=item.nextSibling()
        if item is None:
            selectItem(self.lvCyrusGlobal.firstChild())

except AttributeError, e:
    pass

if self.lvCyrus.childCount() > 0:
    self.view_imap_mailbox_clicked()
}

void dKorreio::imap_create_mailbox() {
import re

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Informe a mailbox para ser criada.")
    return True

if self.cbImapMailbox.currentItem() == 0:
    user = "user"
else:
    user = ""
m = self.imap_connect()
if self.iCyrusPart.text().ascii():
    if m.cm(user, self.iImapMailbox.text().ascii(),self.iCyrusPart.text().ascii()):
        self.console("Mailbox "+self.iImapMailbox.text().ascii()+" criada com sucesso.")
    else:
        self.console("Erro ao criar Mailbox "+self.iImapMailbox.text().ascii()+".")
else:
    if m.cm(user, self.iImapMailbox.text().ascii()):
        self.console("Mailbox "+self.iImapMailbox.text().ascii()+" criada com sucesso.")
    else:
        self.console("Erro ao criar Mailbox "+self.iImapMailbox.text().ascii()+".")
m.sam(user, self.iImapMailbox.text().ascii(), self.iCyrusUser.text().ascii(), " ")

if user == "user":
    if self.iImapMailbox.text().ascii() == self.iImapMailbox.text().ascii().split(m.sep)[0]:
        folders=self.confDict.get("imap.dflfolders").split(",")
        if folders[0] != '':
            for folder in folders:
                m.cm(user, self.iImapMailbox.text().ascii()+m.sep+folder)
                if folder == self.iConfImapACLp.text().ascii():
                    m.sam(user, self.iImapMailbox.text().ascii()+m.sep+self.iConfImapACLp.text().ascii(), "anyone", "p")
                if folder == self.iConfImapExpire.text().ascii():
                    m.m.setannotation("user"+m.sep+self.iImapMailbox.text().ascii()+m.sep+self.iConfImapExpire.text().ascii(),"/vendor/cmu/cyrus-imapd/expire",self.iConfImapExpireDays.text().ascii())
if self.iConfImapQuota.text().ascii():
    m.sq(user,self.iImapMailbox.text().ascii(),self.iConfImapQuota.text().ascii())

self.imap_search()

if user == "user":
    self.view_imap_mailbox_clicked()
    self.lvCyrus.currentItem().setSelected(True)
else:
    self.view_imap_gmailbox_clicked()
    self.lvCyrusGlobal.currentItem().setSelected(True)
}

void dKorreio::imap_delete_mailbox() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para exclusão.".encode('iso-8859-1'))
    return True

if self.cbImapMailbox.currentItem() == 0:
    user = "user"
else:
    user = ""

m = self.imap_connect()
mailboxes = m.lm("",self.iImapMailbox.text().ascii()+m.sep+"*")

try:
    for mbox in mailboxes["all"]:
        if user == "user":
            mboxlist = mbox.split(m.sep)
            mbox = m.sep.join(mboxlist[1:])
        m.sam(user, mbox, self.iCyrusUser.text().ascii(), "c")
        m.dm(user, mbox)
except KeyError, e:
    pass

m.sam(user, self.iImapMailbox.text().ascii(), self.iCyrusUser.text().ascii(), "c")
if m.dm(user, self.iImapMailbox.text().ascii()):
    self.console("Mailbox "+self.iImapMailbox.text().ascii()+" removida com sucesso.")
else:
    self.console("Erro ao remover Mailbox "+self.iImapMailbox.text().ascii()+".")

self.imap_search()
if user == "":
    self.view_imap_gmailbox_clicked()

}

void dKorreio::imap_set_quota() {
if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplicar a quota.")
    return True

if self.cbImapMailbox.currentItem() == 0:
    user = "user"
else:
    user = ""
m = self.imap_connect()
m.sq(user,self.iImapMailbox.text().ascii(),self.iQuota.text().ascii())
}

void dKorreio::imap_set_acl() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplicar a ACL.")
    return True

perm=""
if self.cCyrPermL.isChecked():
    perm="l"
if self.cCyrPermR.isChecked():
    perm=perm+"r"
if self.cCyrPermS.isChecked():
    perm=perm+"s"
if self.cCyrPermW.isChecked():
    perm=perm+"w"
if self.cCyrPermI.isChecked():
    perm=perm+"i"
if self.cCyrPermP.isChecked():
    perm=perm+"p"
if self.cCyrPermC.isChecked():
    perm=perm+"c"
if self.cCyrPermD.isChecked():
    perm=perm+"d"
if self.cCyrPermA.isChecked():
    perm=perm+"a"

if self.cbImapMailbox.currentItem() == 0:
    user = "user"
else:
    user = ""
m = self.imap_connect()
if m.sam(user,self.iImapMailbox.text().ascii(),self.cbUserACL.currentText().ascii(),perm):
    self.console("Mailbox "+self.iImapMailbox.text().ascii()+": ACL "+perm+" aplicada para usuário ".encode('iso-8859-1')+self.cbUserACL.currentText().ascii())
else:
    self.console("Mailbox "+self.iImapMailbox.text().ascii()+": erro ao aplicar ACL "+perm+" para usuário "+self.cbUserACL.currentText().ascii())
}

void dKorreio::imap_new_acl() {
self.cbUserACL.setCurrentText("")
self.cbUserACL.setFocus()
self.cCyrPermL.setChecked(True)
self.cCyrPermR.setChecked(True)
self.cCyrPermS.setChecked(True)
self.cCyrPermW.setChecked(True)
self.cCyrPermI.setChecked(False)
self.cCyrPermP.setChecked(False)
self.cCyrPermC.setChecked(False)
self.cCyrPermD.setChecked(False)
self.cCyrPermA.setChecked(False)
}

void dKorreio::imap_reconstruct() {
if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para reconstruir.")
    return True

if self.cbImapMailbox.currentItem() == 0:
    user = "user"
else:
    user = ""
m = self.imap_connect()
m.reconstruct(user,self.iImapMailbox.text().ascii())

}

void dKorreio::imap_set_annotation_expire() {
if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplica o auto-expire.")
    return True

m = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    user = "user"+m.sep+self.iImapMailbox.text().ascii()
else:
    user = self.iImapMailbox.text().ascii()
m.m.setannotation(user,"/vendor/cmu/cyrus-imapd/expire",self.iAnnotationExpire.text().ascii())
}

void dKorreio::imap_partition_search() {
import re

self.lvImapPartition.clear()
self.lvImapPartitionGlobal.clear()

m = self.imap_connect()

user = "user"+m.sep+self.iImapPartitionSearch.text().ascii()+"%"
mailboxes = m.getannotation("",user,"/vendor/cmu/cyrus-imapd/partition")
partitions = {}
if mailboxes[0] == True:
    for id in mailboxes[1]["all"]:
        idlist = id.split(m.sep)
        item = QListViewItem(self.lvImapPartition)
        item.setText(0, m.sep.join(idlist[1:]))
        item.setText(1, mailboxes[1]["all"][id]["/vendor/cmu/cyrus-imapd/partition"])
        partitions[mailboxes[1]["all"][id]["/vendor/cmu/cyrus-imapd/partition"]] = ""

user = self.iImapPartitionSearch.text().ascii()+"%"
mailboxes = m.getannotation("",user,"/vendor/cmu/cyrus-imapd/partition")
partitions = {}
if mailboxes[0] == True:
    for id in mailboxes[1]["all"]:
        item = QListViewItem(self.lvImapPartitionGlobal)
        item.setText(0, id)
        item.setText(1, mailboxes[1]["all"][id]["/vendor/cmu/cyrus-imapd/partition"])
        partitions[mailboxes[1]["all"][id]["/vendor/cmu/cyrus-imapd/partition"]] = ""

self.cbImapPartition.clear()
for i in partitions:
    self.cbImapPartition.insertItem(i)
}

void dKorreio::imap_partition_move() {
m = self.imap_connect()
item = self.lvImapPartition.firstChild()
while item is not None:
    if item.isSelected():
        self.console("Movendo "+item.text(0).ascii()+" para imap-partition: "+self.cbImapPartition.currentText().ascii())
        m.rename("user",item.text(0).ascii(),"user",item.text(0).ascii(),self.cbImapPartition.currentText().ascii())
    item=item.nextSibling()

item = self.lvImapPartitionGlobal.firstChild()
while item is not None:
    if item.isSelected():
        self.console("Movendo "+item.text(0).ascii()+" para imap-partition: "+self.cbImapPartition.currentText().ascii())
        m.rename("",item.text(0).ascii(),"",item.text(0).ascii(),self.cbImapPartition.currentText().ascii())
    item=item.nextSibling()

self.imap_partition_search()

}

void dKorreio::imap_rename_mailbox() {
item = self.lvCyrus.currentItem()
new = item.text(0).ascii()
while item.parent() is not None:
    item=item.parent()        
    new = item.text(0).ascii()+self.m.sep+new

if self.mailboxold != new:
    m = self.imap_connect()
    mailboxes = m.lm("","user"+m.sep+new)
    try:
        mailboxes["all"]
        self.console("Mailbox "+new+" já existe.".encode('iso-8859-1'))
        self.lvCyrus.currentItem().setText(0,self.mailboxold.split(m.sep)[-1])
        return True
    except KeyError, e:
        pass
    self.console("Renomeando "+self.mailboxold+" para "+new)
    m.rename("user",self.mailboxold,"user",new)
 
}

void dKorreio::save_config() {
import os.path

try:
    try:
        self.confDict
    except AttributeError, e:
        self.confDict = {}

    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')

#
# LDAP Connection
#

    if not self.iLdapConnection.text().ascii():
        self.console("Preencha o nome da conexão LDAP.")
    else:
        i=0
        while self.confDict.get("ldap"+str(i)+".name"):
            if self.confDict.get("ldap"+str(i)+".name") == self.iLdapConnection.text().ascii():
                break
            i=i+1
        tmpLast=i
        f.write('ldap.last=ldap'+str(i)+'\n')

        self.confDict["ldap"+str(i)+".name"]=self.iLdapConnection.text().ascii()
        self.confDict["ldap"+str(i)+".mode"]=self.cbLdapMode.currentText().ascii()
        self.confDict["ldap"+str(i)+".host"]=self.iLdapHost.text().ascii()
        self.confDict["ldap"+str(i)+".port"]=self.iLdapPort.text().ascii()
        self.confDict["ldap"+str(i)+".basedn"]=self.cbLdapBaseDN.currentText().ascii()
        self.confDict["ldap"+str(i)+".user"]=self.iLdapUser.text().ascii()
        self.confDict["ldap"+str(i)+".pass"]=self.iLdapPass.text().ascii()
        self.confDict["ldap"+str(i)+".ref"]=str(self.cLdapRef.isChecked())
        self.confDict["ldap"+str(i)+".cert"]=str(self.cLdapCert.isChecked())

        i=0
        self.cbLdapConnection.clear()
        while self.confDict.get("ldap"+str(i)+".name"):
            self.cbLdapConnection.insertItem(self.confDict.get("ldap"+str(i)+".name"))
            for j in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                opt='ldap'+str(i)+'.'+j
                f.write(opt+"="+self.confDict.get(opt)+'\n')
            i=i+1
        self.cbLdapConnection.setCurrentItem(tmpLast)

#
# IMAP Connection
#

    if not self.iCyrusConnection.text().ascii():
        self.console("Preencha o nome da conexão IMAP.")
    else:
        i=0
        while self.confDict.get("imap"+str(i)+".name"):
            if self.confDict.get("imap"+str(i)+".name") == self.iCyrusConnection.text().ascii():
                break
            i=i+1
        tmpLast=i
        f.write('imap.last=imap'+str(i)+'\n')

        self.confDict["imap"+str(i)+".name"]=self.iCyrusConnection.text().ascii()
        self.confDict["imap"+str(i)+".mode"]=self.cbCyrusMode.currentText().ascii()
        self.confDict["imap"+str(i)+".host"]=self.iCyrusHost.text().ascii()
        self.confDict["imap"+str(i)+".port"]=self.iCyrusPort.text().ascii()
        self.confDict["imap"+str(i)+".sieport"]=self.iCyrusSievePort.text().ascii()
        self.confDict["imap"+str(i)+".user"]=self.iCyrusUser.text().ascii()
        self.confDict["imap"+str(i)+".pass"]=self.iCyrusPass.text().ascii()
        self.confDict["imap"+str(i)+".part"]=self.iCyrusPart.text().ascii()

        i=0
        self.cbCyrusConnection.clear()
        while self.confDict.get("imap"+str(i)+".name"):
            self.cbCyrusConnection.insertItem(self.confDict.get("imap"+str(i)+".name"))
            for j in ['name','mode','host','port','sieport','user','pass','part']:
                opt='imap'+str(i)+'.'+j
                f.write(opt+"="+self.confDict.get(opt)+'\n')
            i=i+1
        self.cbCyrusConnection.setCurrentItem(tmpLast)

#
# SSH Connection
#

    if not self.iSSHConnection.text().ascii():
        self.console("Preencha o nome da conexão SSH.")
    else:
        i=0
        while self.confDict.get("ssh"+str(i)+".name"):
            if self.confDict.get("ssh"+str(i)+".name") == self.iSSHConnection.text().ascii():
                break
            i=i+1
        tmpLast=i
        f.write('ssh.last=ssh'+str(i)+'\n')

        self.confDict["ssh"+str(i)+".name"]=self.iSSHConnection.text().ascii()
        self.confDict["ssh"+str(i)+".host"]=self.iSshHost.text().ascii()
        self.confDict["ssh"+str(i)+".port"]=self.iSshPort.text().ascii()
        self.confDict["ssh"+str(i)+".user"]=self.iSshUser.text().ascii()
        self.confDict["ssh"+str(i)+".pass"]=self.iSshPass.text().ascii()

        i=0
        self.cbSSHConnection.clear()
        while self.confDict.get("ssh"+str(i)+".name"):
            self.cbSSHConnection.insertItem(self.confDict.get("ssh"+str(i)+".name"))
            for j in ['name','host','port','user','pass']:
                opt='ssh'+str(i)+'.'+j
                f.write(opt+"="+self.confDict.get(opt)+'\n')
            i=i+1
        self.cbSSHConnection.setCurrentItem(tmpLast)

#
# IMAP Prefs
#

    folders=[]
    for folder in range(0,self.lbConfImapFolders.count()):
        folders.extend([self.lbConfImapFolders.item(folder).text().ascii()])
    f.write('imap.dflfolders='+",".join(folders)+'\n')
    f.write('imap.dflquota='+self.iConfImapQuota.text().ascii()+'\n')
    f.write('imap.dflexpirefolder='+self.iConfImapExpire.text().ascii()+'\n')
    f.write('imap.dflexpiredays='+self.iConfImapExpireDays.text().ascii()+'\n')
    f.write('imap.addaclp='+self.iConfImapACLp.text().ascii()+'\n')


#
# LDAP Prefs
#
    item=self.lvConfLdap.firstChild()
    item=item.firstChild()
    i=0
    while item is not None:
        subitem=item.firstChild()
        while subitem is not None:
            if subitem.text(1).ascii() is None: value=""
            else: value=subitem.text(1).ascii()
            f.write("ldap.objectclass"+str(i)+"="+item.text(0).ascii()+"."+subitem.text(0).ascii()+"."+value+'\n')
            subitem=subitem.nextSibling()
            i=i+1
        item=item.nextSibling()
#
# End
#
    f.close()
    os.chmod(os.path.expanduser("~/.korreio/korreio.conf"), 0600)
    self.console("Configuração salva.".encode('iso-8859-1'))
except OSError, e:
    self.parse_exception("OSError", e)

}


void dKorreio::load_config() {
import os.path, sys

try:
    os.mkdir(os.path.expanduser("~/.korreio"),0700)
except OSError, e:
    if e[0] != 17:
        self.console("Error creating ~/.korreio "+e)
        print "Error creating ~/.korreio "+e
        return False

try:
    if not os.path.isfile(os.path.expanduser("~/.korreio/korreio.conf")):
        self.save_config()
except OSError, e:
    pass

try:
    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
    conf=f.read()
    f.close()
except IOError, e:
    return True

confList = conf.split("\n")
confList.pop()
self.confDict = {}

for line in confList:
   key=line.split("=")
   self.confDict[key[0]] = "=".join(key[1:])

#
# LDAP Connection
#

i=0
self.cbLdapConnection.clear()
while self.confDict.get("ldap"+str(i)+".name"):
    self.cbLdapConnection.insertItem(self.confDict.get("ldap"+str(i)+".name"))
    i=i+1

lastConn=self.confDict.get("ldap.last")
if lastConn:
    self.cbLdapConnection.setCurrentText(self.confDict.get(lastConn+".name"))
    self.iLdapConnection.setText(self.confDict.get(lastConn+".name"))
    self.cbLdapMode.setCurrentText(self.confDict.get(lastConn+".mode"))
    self.iLdapHost.setText(self.confDict.get(lastConn+".host"))
    self.iLdapPort.setText(self.confDict.get(lastConn+".port"))
    self.cbLdapBaseDN.clear()
    self.cbLdapBaseDN.insertItem(self.confDict.get(lastConn+".basedn"))
    self.iLdapUser.setText(self.confDict.get(lastConn+".user"))
    self.iLdapPass.setText(self.confDict.get(lastConn+".pass"))
    if self.confDict.get(lastConn+".ref") == "True":
        self.cLdapRef.setChecked(True)
    if self.confDict.get(lastConn+".cert") == "True":
        self.cLdapCert.setChecked(True)

#
# IMAP Connection
#

i=0
self.cbCyrusConnection.clear()
while self.confDict.get("imap"+str(i)+".name"):
    self.cbCyrusConnection.insertItem(self.confDict.get("imap"+str(i)+".name"))
    i=i+1

lastConn=self.confDict.get("imap.last")
if lastConn:
    self.cbCyrusConnection.setCurrentText(self.confDict.get(lastConn+".name"))
    self.iCyrusConnection.setText(self.confDict.get(lastConn+".name"))
    self.cbCyrusMode.setCurrentText(self.confDict.get(lastConn+".mode"))
    self.iCyrusHost.setText(self.confDict.get(lastConn+".host"))
    self.iCyrusPort.setText(self.confDict.get(lastConn+".port"))
    self.iCyrusSievePort.setText(self.confDict.get(lastConn+".sieport"))
    self.iCyrusUser.setText(self.confDict.get(lastConn+".user"))
    self.iCyrusPass.setText(self.confDict.get(lastConn+".pass"))
    self.iCyrusPart.setText(self.confDict.get(lastConn+".part"))

#
# SSH Connection
#

i=0
self.cbSSHConnection.clear()
while self.confDict.get("ssh"+str(i)+".name"):
    self.cbSSHConnection.insertItem(self.confDict.get("ssh"+str(i)+".name"))
    i=i+1

lastConn=self.confDict.get("ssh.last")
if lastConn:
    self.cbSSHConnection.setCurrentText(self.confDict.get(lastConn+".name"))
    self.iSSHConnection.setText(self.confDict.get(lastConn+".name"))
    self.iSshHost.setText(self.confDict.get(lastConn+".host"))
    self.iSshPort.setText(self.confDict.get(lastConn+".port"))
    self.iSshUser.setText(self.confDict.get(lastConn+".user"))
    self.iSshPass.setText(self.confDict.get(lastConn+".pass"))

#
# IMAP Prefs
#

self.lbConfImapFolders.clear()
for folder in self.confDict.get("imap.dflfolders").split(","):
    self.lbConfImapFolders.insertItem(folder)
self.iConfImapQuota.setText(self.confDict.get("imap.dflquota"))
self.iConfImapExpire.setText(self.confDict.get("imap.dflexpirefolder"))
self.iConfImapExpireDays.setText(self.confDict.get("imap.dflexpiredays"))
self.iConfImapACLp.setText(self.confDict.get("imap.addaclp"))

#
# LDAP Prefs
#

self.lvConfLdap.clear()
item = QListViewItem(self.lvConfLdap)
item.setText(0,'objectClass')
item.setOpen(True)
objnodes = {}
i=0
while self.confDict.get("ldap.objectclass"+str(i)):
    objclass = self.confDict.get("ldap.objectclass"+str(i)).split(".")
    if not objnodes.get(objclass[0]):
        objnodes[objclass[0]] = QListViewItem(item)
        objnodes[objclass[0]].setText(0,objclass[0])
    subitem=QListViewItem(objnodes[objclass[0]])
    subitem.setText(0,objclass[1])
    subitem.setText(1,".".join(objclass[2:]))
    i=i+1

}

void dKorreio::view_module_changed() {
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
menu=str(self.wKorreio.tabLabel(self.wKorreio.currentPage()))
if menu == "LDAP Manager":
    try:
        self.loadconfig
    except:
        self.loadconfig = 1
        self.load_config()
elif menu == "Configurações":
    self.view_config_change_widgetstack()
}


void dKorreio::view_imap_mailbox_clicked() {

self.cbImapMailbox.setCurrentItem(0)
self.view_imap_mailbox_get_info(self.lvCyrus.currentItem(),"user")

}

void dKorreio::view_imap_gmailbox_clicked() {

self.cbImapMailbox.setCurrentItem(1)
self.view_imap_mailbox_get_info(self.lvCyrusGlobal.currentItem(),"")

}

void dKorreio::view_imap_mailbox_get_info( a0, a1 ) {
item = a0
user = a1

mailbox=item.text(0).ascii()
while item.parent() is not None:
    mailbox=item.parent().text(0).ascii()+self.m.sep+mailbox
    item=item.parent()

self.iImapMailbox.setText(mailbox)

if len(mailbox.split(self.m.sep)) == 1:
    self.pSetQuota.setEnabled(True)
else:
    self.pSetQuota.setEnabled(False)

m = self.imap_connect()

quota = m.lq(user,self.iImapMailbox.text().ascii())
if quota[0] == -1: quotavalue=['','']
else: quotavalue=[str(quota[0]),str(quota[1])]
self.iQuotaUsed.setText(quotavalue[0])
self.iQuota.setText(quotavalue[1])

self.permissions = m.lam(user,mailbox)
self.cbUserACL.clear()
i=0
for acl in self.permissions:
    self.cbUserACL.insertItem(acl)
    i=i+1
self.tlImapACl.setText("("+str(i)+")")
self.view_imap_show_permissions()

expire = m.getannotation(user,self.iImapMailbox.text().ascii(),"/vendor/cmu/cyrus-imapd/expire")
if expire[0]:
    if user == '': user="all"
    self.iAnnotationExpire.setText(expire[1][user][self.iImapMailbox.text().ascii()]["/vendor/cmu/cyrus-imapd/expire"])
else:
    self.iAnnotationExpire.setText("")

}

void dKorreio::view_imap_show_permissions() {
mailbox_perm = self.permissions[self.cbUserACL.currentText().ascii()]
import re
if re.search("l",mailbox_perm): self.cCyrPermL.setChecked(True)
else: self.cCyrPermL.setChecked(False)
if re.search("r",mailbox_perm): self.cCyrPermR.setChecked(True)
else: self.cCyrPermR.setChecked(False)
if re.search("s",mailbox_perm): self.cCyrPermS.setChecked(True)
else: self.cCyrPermS.setChecked(False)
if re.search("w",mailbox_perm): self.cCyrPermW.setChecked(True)
else: self.cCyrPermW.setChecked(False)
if re.search("i",mailbox_perm): self.cCyrPermI.setChecked(True)
else: self.cCyrPermI.setChecked(False)
if re.search("p",mailbox_perm): self.cCyrPermP.setChecked(True)
else: self.cCyrPermP.setChecked(False)
if re.search("c",mailbox_perm): self.cCyrPermC.setChecked(True)
else: self.cCyrPermC.setChecked(False)
if re.search("d",mailbox_perm): self.cCyrPermD.setChecked(True)
else: self.cCyrPermD.setChecked(False)
if re.search("a",mailbox_perm): self.cCyrPermA.setChecked(True)
else: self.cCyrPermA.setChecked(False)
}

void dKorreio::get_ldap_basedn() {
import ldap
try:
    if self.cLdapCert.isChecked():
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
    l = ldap.initialize(self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
    if self.cLdapRef.isChecked():
        ldap.set_option(ldap.OPT_REFERRALS,1)
    else:
        ldap.set_option(ldap.OPT_REFERRALS,0)
    l.protocol_version = ldap.VERSION3
    if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
        l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
    else:
        l.simple_bind()
    searchScope = ldap.SCOPE_BASE
    searchFilter = "objectclass=*"
    retrieveAttributes = ["namingContexts"]
    ldap_result_id = l.search("", searchScope, searchFilter, retrieveAttributes)
    self.cbLdapBaseDN.clear()
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if (result_data == []):
            break
        else:
            if result_type == ldap.RES_SEARCH_ENTRY:
                for j in result_data:
                     for root in j[1]["namingContexts"]:
                         self.cbLdapBaseDN.insertItem(root)
                         if not self.iLdapUser.text().ascii():
                             self.iLdapUser.setText("cn=admin,"+root)
    if self.cbLdapBaseDN.count() > 1:
            self.cbLdapBaseDN.popup()
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
}


void dKorreio::view_imap_set_port() {
if self.cbCyrusMode.currentText().ascii() == "imap://":
    self.iCyrusPort.setText("143")
else:
    self.iCyrusPort.setText("993")
}

void dKorreio::ldap_connect() {
try:
    import ldap
    if self.cLdapCert.isChecked():
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
    else:
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,2)
    if self.cLdapRef.isChecked():
        ldap.set_option(ldap.OPT_REFERRALS,1)
    else:
        ldap.set_option(ldap.OPT_REFERRALS,0)
    l = ldap.initialize(self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
    l.protocol_version = ldap.VERSION3
    l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
    return l
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
}

void dKorreio::ldap_search() {
    def create_nodes(dn):
        dnlist = dn.split(",")
        dnnode = ",".join(dnlist[1:])
        if not self.nodes.get(dnnode):
            if not dnnode == dnnode.split(",")[0]:
                create_nodes(dnnode)
            else:
                print "Erro fatal: servidor ldap retonou basedn diferente da consulta."
                print "            O servidor exigi basedn case sensitive. Verifique."
        self.nodes[dn] = QListViewItem(self.nodes.get(dnnode))
        self.nodes[dn].setText(0,dnlist[0])

    if self.cbLdapFilter.count() == 10:
        self.cbLdapFilter.removeItem(4)
    self.cbLdapFilter.insertItem(self.cbLdapFilter.currentText().ascii())

    import re
    basedn = self.cbLdapBaseDN.currentText().ascii()
    try:
        olddn = self.ldap_get_dn()
    except AttributeError, e:
        olddn = basedn
    self.lvLdap.clear()
    self.nodes = {}
    self.nodes[basedn] = QListViewItem(self.lvLdap)
    self.nodes[basedn].setText(0,basedn)
    self.nodes[basedn].setOpen(True)
    if self.cbLdapFilter.currentText().ascii() == '':
        filter = "(objectClass=*)"
    else:
        filter = "("+str(self.__tr(self.cbLdapFilter.currentText().ascii()))+")"
    self.ldap_attr = self.ldap_result(filter)
#    return False
    try:
        basednattrs = self.ldap_attr.get(basedn)
        del self.ldap_attr[basedn]
    except KeyError, e:
        pass

    for dn in self.ldap_attr:
        if not self.nodes.get(dn):
            create_nodes(dn)
    try:
        self.ldap_attr[basedn] = basednattrs
    except KeyError, e:
        pass
    i = 0
    while olddn != basedn:
        try:
            self.nodes[olddn].setOpen(True)
            if i == 0:
                self.lvLdap.setSelected(self.nodes[olddn], True)
                i = 1
        except KeyError, e:
            pass
        dnlist = olddn.split(",")
        olddn = ",".join(dnlist[1:])
        if len(olddn) == 0:
            break
    if i == 0:
        self.lvLdap.currentItem().setSelected(True)
    self.ldap_dn_clicked()
}

void dKorreio::ldap_result( a0 ) {
import ldap
try:
    l = self.ldap_connect()
    searchScope = ldap.SCOPE_SUBTREE
    searchFilter = a0
    retrieveAttributes = None
    ldap_result_id = l.search(self.cbLdapBaseDN.currentText().ascii(), searchScope, searchFilter, retrieveAttributes)
    ldap_result = {}
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if result_type == ldap.RES_SEARCH_RESULT:
            break
        elif result_type == ldap.RES_SEARCH_ENTRY:
            ldap_result[result_data[0][0].encode('iso-8859-1')] = result_data[0][1]
        elif result_type == ldap.RES_SEARCH_REFERENCE:
            ldap_result[result_data[0][1][0].split("/")[3].split("?")[0]] = {'ref': [result_data[0][1][0]]}
        else:
            print "Result type not implemented. "+str(result_type)

    return ldap_result
except ldap.LDAPError, e:
    if e[0]["desc"] == "Size limit exceeded":
        self.console("Quantidade de registros excedido. Utilize um filtro mais restritivo.")
        return ldap_result
    else:
        self.parse_exception("LDAPError", e)
}

void dKorreio::ldap_dn_clicked() {
self.lvLdapAttr.clear()
self.wsLdap.raiseWidget(0)
self.cbLdapStack.setCurrentItem(0)
dn = self.ldap_get_dn()
try:
    for attribute,values in self.ldap_attr.get(dn).items():
        for value in values:
            item = QListViewItem(self.lvLdapAttr)
            item.setText(0,attribute)
            try:
                item.setText(1,value.encode('iso-8859-1'))
            except UnicodeDecodeError, e:
                item.setText(1,value)
except AttributeError, e:
    pass
item = self.lvLdap.currentItem()
if item.parent() is None or item.childCount() != 0:
    self.pLdapDelete.setEnabled(False)
else:
    self.pLdapDelete.setEnabled(True)

if self.lvLdapAttr.childCount() > 0:
    self.lvLdapAttr.setCurrentItem(self.lvLdapAttr.firstChild())
    self.lvLdapAttr.currentItem().setSelected(True)
}

void dKorreio::ldap_dn_doubleclicked() {
if self.lvLdap.currentItem().childCount() == 0:
    self.rdnold = str(self.__tr(self.ldap_get_dn()))
    self.lvLdap.currentItem().setRenameEnabled(0,True)
    self.lvLdap.currentItem().startRename(0)
}

void dKorreio::ldap_insert_user() {
import md5
import base64
cn=str(self.__tr(self.iLdapCn.text().ascii()))
dn = str(self.__tr("cn="+self.iLdapCn.text().ascii()+","+self.ldap_get_dn()))
attrs = {}
attrs['objectclass'] = ['inetOrgPerson']
attrs['cn'] = cn
attrs['sn'] = cn.split(" ")[-1]
emails = self.iLdapMail.text().ascii().split(",")
attrs['mail'] = emails[0]
if len(emails) > 0:
    attrs['l'] = emails[1:]
m = md5.new(self.iLdapUserP.text().ascii())
attrs['userPassword'] = '{md5}'+base64.encodestring(m.digest())
self.ldap_add(dn,attrs)
self.ldap_search()
self.wsLdap.raiseWidget(1)
}


void dKorreio::ldap_add( a0, a1 ) {
# a0 = DN, a1 = attrs
import ldap
import ldap.modlist as modlist
try:
    ldif = modlist.addModlist(a1)
    l = self.ldap_connect()
    l.add_s(a0,ldif)
    l.unbind_s()
    self.console("Registro "+a0.encode('iso-8859-1')+" adicionado com sucesso.")
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False
}

void dKorreio::view_ldap_modify() {
stack = self.cbLdapStack.currentItem()
if stack == 0:
    old = {}
    for attribute,values in self.ldap_attr.get(self.ldap_get_dn()).items():
        if old.get(attribute):
           old[attribute].extend(values)
        else:
           old[attribute] = values

    new = {}
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if new.get(item.text(0).ascii()):
            new[item.text(0).ascii()].extend([str(self.__tr(item.text(1).ascii()))])
        else:
            new[item.text(0).ascii()] = [str(self.__tr(item.text(1).ascii()))]
        item = item.nextSibling()

    if not self.ldap_modify(self.ldap_get_dn(),old,new):
        return False
else:
    new = {}
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if item.isSelected():
            dn=item.text(0).ascii()+"="+item.text(1).ascii()+","+self.ldap_get_dn()
        if new.get(item.text(0).ascii()):
            new[item.text(0).ascii()].extend([item.text(1).ascii()])
        else:
            new[item.text(0).ascii()] = [item.text(1).ascii()]
        item = item.nextSibling()
    try:
        if not self.ldap_add(dn,new):
            return False
    except UnboundLocalError, e:
        self.console("Selecione o DN entre os atributos.")
        return False

self.ldap_search()
}

void dKorreio::ldap_insert_ou() {
dn = "ou="+self.iLdapOu.text().ascii()+","+self.ldap_get_dn()
attrs = {}
attrs['objectclass'] = ['organizationalUnit']
attrs['ou'] = self.iLdapOu.text().ascii()
self.ldap_add(dn,attrs)
self.ldap_search()
self.wsLdap.raiseWidget(2)
}


void dKorreio::ldap_remove_entry() {
dn = str(self.__tr(self.ldap_get_dn()))
if dn is not None:
    if self.ldap_del_entry(dn):
        self.console("Registro "+dn.encode('iso-8859-1')+" removido com sucesso.")
    self.ldap_search()
    self.ldap_dn_clicked()
}

void dKorreio::ldap_remove_attr() {
self.lvLdapAttr.takeItem(self.lvLdapAttr.currentItem())
try:
    self.lvLdapAttr.currentItem().setSelected(True)
except AttributeError, e:
    pass
}

void dKorreio::ldap_rename_attr_value() {
if not self.lvLdap.currentItem().text(0).ascii() == "=".join([self.lvLdapAttr.currentItem().text(0).ascii(),self.lvLdapAttr.currentItem().text(1).ascii()]):
    self.lvLdapAttr.currentItem().setRenameEnabled(1,True)
    self.lvLdapAttr.currentItem().startRename(1)
}

void dKorreio::ldap_add_attr() {
attr=self.cbLdapAttr.currentText().ascii()
value=self.cbLdapValue.currentText().ascii()
if attr == '':
    return True

attrs = [(attr,value)]

if attr.lower() == 'objectclass':
    if value == '':
        return True
    item=self.lvConfLdap.firstChild()
    item=item.firstChild()
    while item is not None:
        subitem=item.firstChild()
        if item.text(0).ascii().lower() == value.lower():
            while subitem is not None:
                if subitem.text(1).ascii() is None: newvalue=""
                else: newvalue=subitem.text(1).ascii()
                attrs.extend([(subitem.text(0).ascii(),newvalue)])
                subitem=subitem.nextSibling()
        item=item.nextSibling()

for attr,value in attrs:
    item=self.lvLdapAttr.firstChild()
    jump=False
    while item is not None:
        if item.text(0).ascii() == attr and (item.text(1).ascii() == value or value == ''):
            jump=True
            break
        item=item.nextSibling()
    if jump:
        continue
    item = QListViewItem(self.lvLdapAttr)
    item.setText(0,attr)
    item.setText(1,value)
if self.cbLdapStack.currentItem() == 4:
    self.console("Por favor, selecione um dos atributos para ser o DN do novo registro antes de criá-lo.".encode('iso-8859-1'))

}

void dKorreio::ldap_rename_rdn() {
rdnnew=str(self.__tr(self.lvLdap.currentItem().text(0).ascii()))
if self.rdnold.split(",")[0] == rdnnew:
    return True
dnexist = 1
item = self.lvLdapAttr.firstChild()
while item is not None:
    if item.text(0).ascii()+"="+str(self.__tr(item.text(1).ascii())) == rdnnew:
        dnexist = 0
    item = item.nextSibling()
if self.ldap_modify_rdn(self.rdnold, rdnnew,dnexist):
    self.console("Registro "+self.rdnold.encode('iso-8859-1')+" alterado com sucesso.")
    self.lvLdapAttr.clear()
    return True
else:
    self.lvLdap.currentItem().setText(0, self.rdnold.split(",")[0])
    return False
}


void dKorreio::ldap_modify_rdn( a0, a1, a2 ) {
#a0 = oldDN, a1 = newDN, a2 = newDNexist
import ldap
try:
    l = self.ldap_connect()
    l.rename_s(a0,a1,None,a2)
    l.unbind_s()
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False
}

void dKorreio::ldap_del_entry( a0 ) {
import ldap
l = self.ldap_connect()
try:
    l.delete_s(a0)
    return True
except ldap.STRONG_AUTH_REQUIRED, e:
    self.console("Permissão negada para remover registro: ".encode('iso-8859-1')+a0)
    return False
}

void dKorreio::postfix_postconf() {
import re
if self.rbPostconfN.isChecked():
    cmd = "postconf -n"
elif self.rbPostconfAll.isChecked():
    cmd = "postconf"
if self.rbPostconfD.isChecked():
    cmd = "postconf -d"
cmd = self.ssh_cmd(cmd)
self.postconf = {}
lastOpt = self.cbPostconf.currentText().ascii()
self.cbPostconf.clear()
i = 0
for config in cmd:
    if re.search("=",config):
        configlist = config.strip().split("=")
        configlist[0]=configlist[0].strip(" ")
        self.postconf[configlist[0]] = configlist[1]
        self.cbPostconf.insertItem(configlist[0])
        if configlist[0] == lastOpt:
            lastItem = i
        i = i + 1
try:
    self.cbPostconf.setCurrentItem(lastItem)
except UnboundLocalError, e:
    pass
self.postconf_changed()
}


void dKorreio::ssh_cmd(a0) {
import pexpect
import re
try:
    self.console("Executando comando remoto: "+a0)
    child = pexpect.spawn('ssh -p'+self.iSshPort.text().ascii()+' '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+' "'+a0+'"')
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        self.console("Aceitando SSH fingerprint")
        child.sendline('yes')
        child.expect('assword', timeout=2)
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    print_cmd=[]
    for line in child:
        line = re.sub("(\n|\r)","",line)
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    self.console("Erro na conexão: "+self.iSshHost.text().ascii())
except pexpect.TIMEOUT, t:
   self.console("Timeout na conexão: "+self.iSshHost.text().ascii())
return print_cmd
}


void dKorreio::postconf_changed() {
import re
value = self.postconf.get(self.cbPostconf.currentText().ascii())
value = re.sub("( )+"," ",value)
value = re.sub(", ",",",value)
value = re.sub(",",",\n",value)
value = re.sub("^ ","",value)
self.tePostconf.setText(value)
}


void dKorreio::postconf_save() {
import re
value = re.sub(",",", ",self.tePostconf.text().ascii())
value = re.sub("( )+"," ",value)
value = re.sub("\n","",value)
value = re.sub("\r","",value)
print self.ssh_cmd("postconf -e "+self.cbPostconf.currentText().ascii()+"='"+value+"'")
}


void dKorreio::postfix_open_conf() {
import re
value = self.ssh_cmd("cat "+self.iPostFileOpen.text().ascii())
values = ""
for line in value[1:]:
    values = values+line+"\n"
if re.search("^cat:",values):
    self.console("Arquivo "+self.iPostFileOpen.text().ascii()+" nao encontrado.")
    return True
self.tePostFileOpen.setText(values)
}


void dKorreio::postfix_save_conf() {
if self.tePostFileOpen.length () == 0:
    self.ssh_cmd("rm -f "+self.iPostFileOpen.text().ascii())
    return True
f = open("/tmp/korreio.tmp", 'w')
for line in self.tePostFileOpen.text().ascii():
    f.write(line)
f.close()
self.scp_cmd(self.iPostFileOpen.text().ascii())
}

void dKorreio::scp_cmd( a0 ) {
import pexpect
import re
try:
    self.console("Salvando arquivo remoto: "+a0)
    child = pexpect.spawn('scp -P'+self.iSshPort.text().ascii()+' /tmp/korreio.tmp '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+':"'+a0+'"')
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        self.console("Aceitando SSH fingerprint")
        child.sendline('yes')
        child.expect('assword', timeout=2)
        self.console("Realizando login no SSH.")
        child.sendline(self.iSshPass.text().ascii())
    print_cmd=[]
    for line in child:
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    self.console("Erro na conexão: "+self.iSshHost.text().ascii())
except pexpect.TIMEOUT, t:
    self.console("Timeout na conexão: "+self.iSshHost.text().ascii())

}

void dKorreio::postfix_postmap() {
value = self.ssh_cmd("postmap "+self.iPostFileOpen.text().ascii())
for line in value[1:]:
   self.console(line)
}

void dKorreio::postfix_stop() {
value = self.ssh_cmd("/etc/init.d/postfix stop")
for line in value[1:]:
   self.console(line)
}


void dKorreio::postfix_start() {
value = self.ssh_cmd("/etc/init.d/postfix start")
for line in value[1:]:
    self.console(line)
}


void dKorreio::postfix_restart() {
value = self.ssh_cmd("/etc/init.d/postfix restart")
for line in value[1:]:
    self.console(line)
}


void dKorreio::ldap_get_dn() {
item = self.lvLdap.currentItem()
dn = item.text(0).ascii()
while item.parent() is not None:
    dn = dn+","+item.parent().text(0).ascii()
    item = item.parent()
return dn
}

void dKorreio::view_ldap_set_port() {
if self.cbLdapMode.currentText().ascii() == "ldap://":
    self.iLdapPort.setText("389")
else:
    self.iLdapPort.setText("636")
}

void dKorreio::view_ldap_change_widgetstack() {
selected_stack = self.cbLdapStack.currentItem()
if selected_stack < 4:
    self.wsLdap.raiseWidget(selected_stack)
    if selected_stack == 0:
        self.ldap_dn_clicked()
else:
    self.lvLdapAttr.clear()
    self.wsLdap.raiseWidget(0)
    self.console("O novo registro será inserido na base: ".encode('iso8859-1')+self.ldap_get_dn()+".")
}


void dKorreio::ldap_passwd() {

if not self.cbLdapUserPassword.isChecked() and not self.cbLdapSambaPassword.isChecked():
    self.console("Selecione ao menos uma opção.".encode('iso-8859-1'))
    return False

old={}
new={}

if self.cbLdapUserPassword.isChecked():
    from binascii import b2a_base64, a2b_base64
    from random import choice
    from string import letters,digits

    salt = ''
    for i in range(16):
        salt += choice(letters+digits)

    old["userPassword"] = 'None'
    hash = self.cbUserPassword.currentText().ascii()
    if hash == "{SSHA}":
        import sha
        new["userPassword"] = "{SSHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]
    elif hash == "{SHA}":
        import sha
        new["userPassword"] = "{SHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii()).digest())[:-1]
    elif hash == "{SMD5}":
        import md5
        new["userPassword"] = "{SMD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]
    elif hash == "{MD5}":
        import md5
        new["userPassword"] = "{MD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii()).digest())[:-1]
    elif hash == "{CRYPT}":
        salt = ''
        for i in [0,1]:
            salt += choice(letters+digits)
        import crypt
        new["userPassword"] = "{CRYPT}" + crypt.crypt(str(self.iLdapPasswd.text().ascii()),salt)
    elif hash == "{PLAINTEXT}":
        new["userPassword"] = self.iLdapPasswd.text().ascii()
    else:
        self.console("Algoritmo não implementando.".encode('iso-8859-1'))
        return False

if self.cbLdapSambaPassword.isChecked():
    try:
        from smbpasswd import nthash,lmhash
    except ImportError, e:
        self.console("Instale o pacote python-smbpasswd.")
        return False
    old["sambaNTPassword"] = 'None'
    new["sambaNTPassword"] = nthash(self.iLdapPasswd.text().ascii())
    old["sambaLMPassword"] = 'None'
    new["sambaLMPassword"] = lmhash(self.iLdapPasswd.text().ascii())

self.ldap_modify(self.ldap_get_dn(),old,new)
}


void dKorreio::ldap_modify( a0, a1, a2 ) {
dn=str(self.__tr(a0))
old=a1
new=a2
import ldap
import ldap.modlist as modlist
try:
    ldif = modlist.modifyModlist(old,new)
    l = self.ldap_connect()
    l.modify_s(dn,ldif)
    l.unbind_s()
    self.console("Registro "+dn.encode('iso-8859-1')+" alterado com sucesso.")
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False
}


void dKorreio::console( a0 ) {
import datetime
text=datetime.datetime.now().strftime("%d %b %Y %H:%M:%S ")+a0
self.tlConsole.setText(text)

import os.path

try:
    f = open(os.path.expanduser("~/.korreio/korreio.log"), 'a')
    f.write(text+'\n')
    f.close()
except OSError, e:
    print e
}


void dKorreio::parse_exception( a0, a1 ) {
if a0 == "LDAPError":
    if a1[0]['desc'] == "Object class violation":
        self.console(a1[0]['info'])
    elif a1[0]['desc'] == "Naming violation":
        self.console(a1[0]['info'])
    elif a1[0]['desc'] == "Can't contact LDAP server":
        self.console("Erro ao conectar host "+self.iLdapHost.text().ascii())
    elif a1[0]['info'] == "no write access to parent":
        self.console("Sem permissão de escrita no referral, autentique-se nesta raiz: ".encode('iso-8859-1')+self.ldap_get_dn())
    elif a1[0]['desc'] == "No such attribute":
        self.console(a1[0]['info'])
    else:
        self.console(str(a1))
else:
    self.console(str(a1))

}

void dKorreio::view_mailbox_doubleclicked() {
if self.lvCyrus.currentItem().parent() is not None:
    item = self.lvCyrus.currentItem()
    self.mailboxold = item.text(0).ascii()
    while item.parent() is not None:
        item=item.parent()        
        self.mailboxold = item.text(0).ascii()+self.m.sep+self.mailboxold
    self.lvCyrus.currentItem().setRenameEnabled(0,True)
    self.lvCyrus.currentItem().startRename(0)
if self.cbUserACL.count() > 1:
    self.cbUserACL.popup()

}

void dKorreio::view_gmailbox_doubleclicked() {
item = self.lvCyrusGlobal.currentItem()
self.mailboxold = item.text(0).ascii()
while item.parent() is not None:
    item=item.parent()        
    self.mailboxold = item.text(0).ascii()+self.m.sep+self.mailboxold
self.lvCyrusGlobal.currentItem().setRenameEnabled(0,True)
self.lvCyrusGlobal.currentItem().startRename(0)

}

void dKorreio::imap_gmailbox_rename() {
item = self.lvCyrusGlobal.currentItem()
new = item.text(0).ascii()
while item.parent() is not None:
    item=item.parent()        
    new = item.text(0).ascii()+self.m.sep+new

if self.mailboxold != new:
    m = self.imap_connect()
    mailboxes = m.lm("",new)
    try:
        mailboxes["all"]
        self.console("Mailbox "+new+" já existe.".encode('iso-8859-1'))
        self.lvCyrusGlobal.currentItem().setText(0,self.mailboxold.split(m.sep)[-1])
        return True
    except KeyError, e:
        pass
    self.console("Renomeando "+self.mailboxold+" para "+new)
    m.rename("",self.mailboxold,"",new)
}


void dKorreio::view_config_change_widgetstack() {
item=self.lvConfig.currentItem()
if item.parent() is None:
   if  item.text(0).ascii() == "Servidores":
        self.wsConfig.raiseWidget(3)
        self.tConfShowLdapServer.setText("Host: "+self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
        self.tConfShowLdapUser.setText("User: "+self.iLdapUser.text().ascii())
        self.tConfShowLdapBaseDN.setText("Base: "+self.cbLdapBaseDN.currentText().ascii())
        self.tConfShowImapServer.setText("Host: "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii())
        self.tConfShowImapUser.setText("User: "+self.iCyrusUser.text().ascii())
        self.tConfShowSshServer.setText("Host: ssh://"+self.iSshHost.text().ascii()+":"+self.iSshPort.text().ascii())
        self.tConfShowSshUser.setText("User: "+self.iSshUser.text().ascii())
elif item.parent().text(0).ascii()+"."+item.text(0).ascii() == "Servidores.LDAP":
    self.wsConfig.raiseWidget(0)
elif item.parent().text(0).ascii()+"."+item.text(0).ascii() == "Servidores.IMAP":
    self.wsConfig.raiseWidget(1)
elif item.parent().text(0).ascii()+"."+item.text(0).ascii() == "Servidores.SSH":
    self.wsConfig.raiseWidget(2)
elif str(self.__tr(item.parent().text(0).ascii()))+"."+item.text(0).ascii() == "Preferências.LDAP":
    self.wsConfig.raiseWidget(4)
elif str(self.__tr(item.parent().text(0).ascii()))+"."+item.text(0).ascii() == "Preferências.IMAP":
    self.wsConfig.raiseWidget(5)
}


void dKorreio::view_config_ldap_connection() {
i=0
while self.confDict.get("ldap"+str(i)+".name"):
    if self.confDict.get("ldap"+str(i)+".name") == self.cbLdapConnection.currentText().ascii():
        lastConn="ldap"+str(i)
    i=i+1

self.iLdapConnection.setText(self.confDict.get(lastConn+".name"))
self.cbLdapMode.setCurrentText(self.confDict.get(lastConn+".mode"))
self.iLdapHost.setText(self.confDict.get(lastConn+".host"))
self.iLdapPort.setText(self.confDict.get(lastConn+".port"))
self.cbLdapBaseDN.clear()
self.cbLdapBaseDN.insertItem(self.confDict.get(lastConn+".basedn"))
self.iLdapUser.setText(self.confDict.get(lastConn+".user"))
self.iLdapPass.setText(self.confDict.get(lastConn+".pass"))
if self.confDict.get(lastConn+".ref") == "True":
    self.cLdapRef.setChecked(True)
else:
    self.cLdapRef.setChecked(False)
if self.confDict.get(lastConn+".cert") == "True":
    self.cLdapCert.setChecked(True)
else:
    self.cLdapCert.setChecked(False)

}


void dKorreio::view_config_imap_connection() {
i=0
while self.confDict.get("imap"+str(i)+".name"):
    if self.confDict.get("imap"+str(i)+".name") == self.cbCyrusConnection.currentText().ascii():
        lastConn="imap"+str(i)
    i=i+1

self.iCyrusConnection.setText(self.confDict.get(lastConn+".name"))
self.cbCyrusMode.setCurrentText(self.confDict.get(lastConn+".mode"))
self.iCyrusHost.setText(self.confDict.get(lastConn+".host"))
self.iCyrusPort.setText(self.confDict.get(lastConn+".port"))
self.iCyrusSievePort.setText(self.confDict.get(lastConn+".sieport"))
self.iCyrusUser.setText(self.confDict.get(lastConn+".user"))
self.iCyrusPass.setText(self.confDict.get(lastConn+".pass"))
self.iCyrusPart.setText(self.confDict.get(lastConn+".part"))
}


void dKorreio::view_config_ssh_connection() {
i=0
while self.confDict.get("ssh"+str(i)+".name"):
    if self.confDict.get("ssh"+str(i)+".name") == self.cbSSHConnection.currentText().ascii():
        lastConn="ssh"+str(i)
    i=i+1
self.iSSHConnection.setText(self.confDict.get(lastConn+".name"))
self.iSshHost.setText(self.confDict.get(lastConn+".host"))
self.iSshPort.setText(self.confDict.get(lastConn+".port"))
self.iSshUser.setText(self.confDict.get(lastConn+".user"))
self.iSshPass.setText(self.confDict.get(lastConn+".pass"))
}

void dKorreio::view_del_ldap_connection() {
    if not self.cbLdapConnection.currentText().ascii():
        return True
    i=0
    while self.confDict.get("ldap"+str(i)+".name"):
        if self.confDict.get("ldap"+str(i)+".name") == self.cbLdapConnection.currentText().ascii():
            j=i+1
            while self.confDict.get("ldap"+str(j)+".name"):
                for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                    self.confDict["ldap"+str(j-1)+"."+opt]=self.confDict.get("ldap"+str(j)+"."+opt)
                j=j+1
        i=i+1
    for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
        del self.confDict["ldap"+str(i-1)+"."+opt]

    i=self.cbLdapConnection.currentItem()
    self.cbLdapConnection.removeItem(i)
    if i > 0:
        self.cbLdapConnection.setCurrentItem(i-1)
        self.view_config_ldap_connection()
    elif self.cbLdapConnection.count() > 0:
        self.cbLdapConnection.setCurrentItem(0)
        self.view_config_ldap_connection()
    else:
        self.iLdapConnection.clear()
        self.cbLdapMode.setCurrentText("ldap://")
        self.iLdapHost.clear()
        self.iLdapPort.setText("389")
        self.cbLdapBaseDN.clear()
        self.iLdapUser.clear()
        self.iLdapPass.clear()
        self.cLdapRef.setChecked(False)
        self.cLdapCert.setChecked(False)

}

void dKorreio::view_del_imap_connection() {
    if not self.cbCyrusConnection.currentText().ascii():
        return True
    i=0
    while self.confDict.get("imap"+str(i)+".name"):
        if self.confDict.get("imap"+str(i)+".name") == self.cbCyrusConnection.currentText().ascii():
            j=i+1
            while self.confDict.get("imap"+str(j)+".name"):
                for opt in ['name','mode','host','port','sieport','user','pass','part']:
                    self.confDict["imap"+str(j-1)+"."+opt]=self.confDict.get("imap"+str(j)+"."+opt)
                j=j+1
        i=i+1
    for opt in ['name','mode','host','port','sieport','user','pass','part']:
        del self.confDict["imap"+str(i-1)+"."+opt]

    i=self.cbCyrusConnection.currentItem()
    self.cbCyrusConnection.removeItem(i)
    if i > 0:
        self.cbCyrusConnection.setCurrentItem(i-1)
        self.view_config_imap_connection()
    elif self.cbCyrusConnection.count() > 0:
        self.cbCyrusConnection.setCurrentItem(0)
        self.view_config_imap_connection()
    else:
        self.iCyrusConnection.clear()
        self.cbCyrusMode.setCurrentText("imap://")
        self.iCyrusHost.clear()
        self.iCyrusPort.setText("143")
        self.iCyrusSievePort.setText("2000")
        self.iCyrusUser.clear()
        self.iCyrusPass.clear()
        self.iCyrusPart.clear()
}


void dKorreio::view_del_ssh_connection() {
    if not self.cbSSHConnection.currentText().ascii():
        return True
    i=0
    while self.confDict.get("ssh"+str(i)+".name"):
        if self.confDict.get("ssh"+str(i)+".name") == self.cbSSHConnection.currentText().ascii():
            j=i+1
            while self.confDict.get("ssh"+str(j)+".name"):
                for opt in ['name','host','port','user','pass']:
                    self.confDict["ssh"+str(j-1)+"."+opt]=self.confDict.get("ssh"+str(j)+"."+opt)
                j=j+1
        i=i+1
    for opt in ['name','host','port','user','pass']:
        del self.confDict["ssh"+str(i-1)+"."+opt]

    i=self.cbSSHConnection.currentItem()
    self.cbSSHConnection.removeItem(i)
    if i > 0:
        self.cbSSHConnection.setCurrentItem(i-1)
        self.view_config_ssh_connection()
    elif self.cbSSHConnection.count() > 0:
        self.cbSSHConnection.setCurrentItem(0)
        self.view_config_ssh_connection()
    else:
        self.iSSHConnection.clear()
        self.iSshHost.clear()
        self.iSshPort.setText("22")
        self.iSshUser.clear()
        self.iSshPass.clear()

}


void dKorreio::view_conf_imap_add_default_folder() {
self.lbConfImapFolders.insertItem(self.iConfImapFolder.text().ascii())
self.iConfImapFolder.clear()
}


void dKorreio::view_conf_imap_del_default_folder() {
self.lbConfImapFolders.removeItem(self.lbConfImapFolders.currentItem())
}


void dKorreio::sieve_search() {

self.lvSieve.clear()
m = self.imap_connect()
mailboxes = m.lm("user",self.iSieveSearch.text().ascii()+"%")
try:
    for user in mailboxes["user"]:
        item = QListViewItem(self.lvSieve)
        item.setText(0, user)
        if self.cSieveScript.isChecked():
            s = self.sieve_connect(user)
            scripts = s.listscripts()
            s.logout()
            if scripts[0] == 'OK':
                for script,active in scripts[1]:
                    if active:
                        item.setText(1, script)
                        break
except KeyError, e:
    pass
}

void dKorreio::sieve_connect( a0 ) {
import sievelib
admin = self.iCyrusUser.text().ascii().split("@")
if admin[0] != self.iCyrusUser.text().ascii():
    user = a0+"@"+admin[1]
else:
    user = a0

s = sievelib.MANAGESIEVE(self.iCyrusHost.text().ascii(),int(self.iCyrusSievePort.text().ascii()))
if s.alive:
    if s.login('PLAIN',user,self.iCyrusPass.text().ascii(),self.iCyrusUser.text().ascii()):
        self.console("Servidor sieve://"+self.iCyrusHost.text().ascii()+":"+self.iCyrusSievePort.text().ascii()+" conectado com sucesso.")
    else:
        self.console("Erro ao conectar no servidor sieve://"+self.iCyrusHost.text().ascii()+":"+self.iCyrusSievePort.text().ascii()+". (Usuário ou senha inválidos)".encode('iso-8859-1'))
else:
    self.console("Erro ao conectar no servidor sieve://"+self.iCyrusHost.text().ascii()+":"+self.iCyrusSievePort.text().ascii()+". (Conexão recusada)".encode('iso-8859-1'))
    
return s

}


void dKorreio::sieve_user_clicked() {
s = self.sieve_connect(self.lvSieve.currentItem().text(0).ascii())
scripts = s.listscripts()
s.logout()

self.cbSieveScript.clear()
if scripts[0] == 'OK':
    for script,active in scripts[1]:
        self.cbSieveScript.insertItem(script)
        if self.lvSieve.currentItem().text(1).ascii() == script:
            self.cbSieveScript.setCurrentText(script)

if self.cbSieveScript.count() > 0:
    self.sieve_get_script()
else:
    self.teSieveScript.clear()
}


void dKorreio::sieve_get_script() {
s = self.sieve_connect(self.lvSieve.currentItem().text(0).ascii())
script = s.getscript(self.cbSieveScript.currentText().ascii())
s.logout()

self.teSieveScript.clear()
if script[0] == 'OK':
    self.teSieveScript.setText(script[1])
}


void dKorreio::sieve_set_script() {

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        if self.cbSieveScript.currentText().ascii():
            status = s.putscript(self.cbSieveScript.currentText().ascii(),self.teSieveScript.text().ascii().replace("#USER#",item.text(0).ascii()))
            if status == 'OK':
                item.setText(1,self.cbSieveScript.currentText().ascii())
                s.setactive(self.cbSieveScript.currentText().ascii())
        else:
            item.setText(1,"")
            s.setactive()
        s.logout()
    item=item.nextSibling()

self.sieve_get_script()
}


void dKorreio::sieve_del_script() {
if not self.cbSieveScript.currentText().ascii():
    self.console("Digite o nome do script.")
    return True

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        if s.deletescript(self.cbSieveScript.currentText().ascii()) == 'OK':
            if self.cbSieveScript.currentText().ascii() == item.text(1).ascii():
                item.setText(1,"")
        s.logout()
    item=item.nextSibling()

self.sieve_get_script()

}


void dKorreio::sieve_select_all() {
self.lvSieve.selectAll(True)
}


void dKorreio::sieve_use_template() {

try:
    sep = self.m.sep
except AttributeError, e:
    sep = "/"

self.cbSieveScript.setCurrentText("script.siv")
template = self.lbSieveScripts.currentItem()
if template == 0:
    self.teSieveScript.setText("redirect \"destinatario@dominio.com\";\n")

elif template == 1:
    self.teSieveScript.setText("""redirect "destinatario@dominio.com";
keep;
""".replace("        ",""))

elif template == 2:
    self.teSieveScript.setText("""require "fileinto";
if address :contains "from" "remetente1@dominio1.com.br" {
   fileinto "INBOX%(sep)sPasta1";
}
""".replace("        ","") % {'sep':sep})

elif template == 3:
    self.teSieveScript.setText("""require "fileinto";
if address :contains "from" ["from1@dom1.com","from2@dom2.com"] {
    fileinto "INBOX%(sep)sPasta1";
}
elsif address :contains "from" ["from3@dom3.com","from4@dom4.com"] {
    fileinto "INBOX%(sep)sPasta2";
}
""".replace("        ","") % {'sep':sep})

elif template == 4:
    self.teSieveScript.setText("""if header :contains "X-Spam-Flag" "YES" {
    discard;
}
""".replace("        ",""))

elif template == 5:
    self.teSieveScript.setText("""require "fileinto";
if header :contains "X-Spam-Flag" "YES" {
    fileinto "INBOX%(sep)sSpam";
}
""".replace("        ","") % {'sep':sep})

elif template == 6:
    self.console("A macro #USER# será substituida pelo respectivo usuário.".encode('iso-8859-1'))
    if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
        domain="dominio.com.br"
    else:
        domain=self.iCyrusUser.text().ascii().split("@")[1]
    self.teSieveScript.setText("""require ["vacation","fileinto"];

if header :contains "X-Spam-Flag" "YES" {
    fileinto "INBOX%(sep)sSpam";
    stop;
}

vacation :days 5
:subject "Estou ausente"
:addresses ["#USER#@%(domain)s"]
 "Estarei ausente entre os dias ....

 Obrigado,

 --
 xxxxxxxxxxxx";
""".replace("        ","") % {'sep':sep,'domain':domain})

elif template == 7:
    if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
        domain="dominio.com.br"
    else:
        domain=self.iCyrusUser.text().ascii().split("@")[1]
    self.console("A macro #USER# será substituida pelo respectivo usuário.".encode('iso-8859-1'))
    self.teSieveScript.setText("""require "vacation";
vacation :days 5
:subject "Estou ausente."
:addresses ["#USER#@%(domain)s"]
 "Estarei ausente entre os dias ....

 Obrigado,

 --
 xxxxxxxxxxxx";
""".replace("        ","") % {'domain':domain})
}


void dKorreio::view_conf_ldap_add_attr() {

itemroot=self.lvConfLdap.firstChild()
if itemroot.isSelected():
    newitem=QListViewItem(itemroot)
    newitem.setText(0,self.iConfLdapAttr.text().ascii())
    newitem.setText(1,self.iConfLdapValue.text().ascii())
    return True
item=itemroot.firstChild()
while item is not None:
    if item.isSelected():
        item.setOpen(True)
        newitem=QListViewItem(item)
        newitem.setText(0,self.iConfLdapAttr.text().ascii())
        newitem.setText(1,self.iConfLdapValue.text().ascii())
        return True
    subitem=item.firstChild()
    while subitem is not None:
        if subitem.isSelected():
            subitem.setOpen(True)
            newitem=QListViewItem(item)
            newitem.setText(0,self.iConfLdapAttr.text().ascii())
            newitem.setText(1,self.iConfLdapValue.text().ascii())
            return True
        subitem=subitem.nextSibling()
    item=item.nextSibling()

}


void dKorreio::view_conf_ldap_del_attr() {

itemroot=self.lvConfLdap.firstChild()
item=itemroot.firstChild()
while item is not None:
    if item.isSelected():
        itemroot.takeItem(item)
        self.lvConfLdap.currentItem().setSelected(True)
        return True
    subitem=item.firstChild()
    while subitem is not None:
        if subitem.isSelected():
            item.takeItem(subitem)
            self.lvConfLdap.currentItem().setSelected(True)
            return True
        subitem=subitem.nextSibling()
    item=item.nextSibling()
}


void dKorreio::view_imap_selectall() {
if self.cbImapPartitionUser.currentText().ascii() == 'user':
    self.lvImapPartition.selectAll(True)
else:
    self.lvImapPartitionGlobal.selectAll(True)

}
