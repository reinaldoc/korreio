# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'korreiolib.ui'
#
# Created: Qua Fev 25 21:48:44 2009
#      by: The PyQt User Interface Compiler (pyuic) 3.16
#
# WARNING! All changes made in this file will be lost!


from qt import *

image0_data = \
    "\x89\x50\x4e\x47\x0d\x0a\x1a\x0a\x00\x00\x00\x0d" \
    "\x49\x48\x44\x52\x00\x00\x00\x20\x00\x00\x00\x20" \
    "\x08\x06\x00\x00\x00\x73\x7a\x7a\xf4\x00\x00\x08" \
    "\x05\x49\x44\x41\x54\x58\x85\x9d\x97\x7b\x8c\x54" \
    "\xf5\x15\xc7\x3f\xbf\x7b\xef\x3c\x76\x1e\xfb\x7e" \
    "\x0c\xfb\x84\xe5\xb1\x0f\x70\x05\x17\xba\x46\x48" \
    "\x45\xac\x54\x7c\x60\xb1\x14\x53\xb5\xad\xaf\x14" \
    "\xa3\x69\xeb\x1f\xa6\x9a\xc6\x18\x13\x8d\x35\xd6" \
    "\x2a\x69\x9a\xb6\x21\x69\xc4\xd6\x54\x4b\xa8\x55" \
    "\x0b\xb1\xae\x84\x20\x6c\xc4\x56\x40\x64\x11\x97" \
    "\x65\x17\xd8\xd7\xec\xec\xcc\xbe\x66\x66\x67\xf6" \
    "\xde\x3b\x73\xef\xaf\x7f\xcc\xce\xb2\x0f\x79\xd4" \
    "\x93\x9c\x64\x92\x39\xe7\x7c\xbf\xe7\xfc\xce\xef" \
    "\x9c\xfb\x13\x5c\xa5\x1c\xdc\x86\xcf\xad\xf2\x2d" \
    "\xcd\x45\xf3\x1d\xbb\x4e\xac\xf5\xa2\xb5\x38\x50" \
    "\x72\xc0\x26\x89\x3d\xf0\xe2\x9d\x4d\x07\xbb\x86" \
    "\x38\xd6\x15\xe2\xd3\x37\x7b\x39\x7d\xb5\x71\xc5" \
    "\x95\x0c\x5e\xb8\x9e\x9a\x8d\x75\x3c\xf2\xd8\x1b" \
    "\x5d\xf7\x34\xe0\x5b\x52\x89\x4f\x14\xe3\xc4\x8d" \
    "\x86\x73\xca\xc6\xc0\x66\x14\x18\xc6\xe4\x02\x21" \
    "\xfd\x73\x4e\xb6\xdd\xb8\xf4\x7b\x7f\x7e\xf3\x2c" \
    "\xff\x00\x52\xdf\x88\xc0\xce\x66\x1c\xc5\x15\x3c" \
    "\xfe\x9b\xf7\xcf\x3d\xb5\x9e\xd2\xc0\x62\xe1\xa5" \
    "\xb4\x11\x8a\x5a\x24\xfe\x45\x02\x4f\x95\x44\x75" \
    "\x83\xb4\x21\x15\x15\xc4\xbb\x25\xd1\xaf\x04\x23" \
    "\x47\x61\x38\x0c\x9f\xc9\x38\x1f\xf1\xef\xc3\x95" \
    "\x05\xdb\x7e\xf5\xe9\x18\x6d\xff\x17\x81\xf7\x6f" \
    "\x67\xcd\xe3\xfb\x8e\xbe\xb4\x89\x25\x1b\xd6\x89" \
    "\x3c\x2a\x6e\x85\xda\x9f\x48\x8a\x9a\x05\x32\x2f" \
    "\x85\xa2\xc5\x31\xd2\x2e\xa4\x3d\xe5\xa0\x40\x8e" \
    "\x43\x27\x91\x70\xa3\x87\x21\xb2\xd7\x49\xdf\x1b" \
    "\x0e\x7a\xce\xc1\xbf\xe4\xd9\xc9\xba\xfa\x65\x2f" \
    "\xfe\xa1\x83\xd7\x80\xc4\x15\x09\x7c\xb2\x95\x1b" \
    "\x9f\xdc\xd3\xbb\xe7\x4e\x02\xc5\x4b\xab\x1c\xac" \
    "\x78\x1a\xca\x6f\x05\xa1\x80\xa5\xc3\x90\x8c\x90" \
    "\xef\xf1\xe1\x14\x0e\xe4\x1c\x5f\x45\x81\x09\x39" \
    "\x89\x00\x9c\x21\x1f\x9d\x7f\x82\xee\xd7\x05\x07" \
    "\xe5\x24\xef\xb2\xeb\x83\x51\x1e\xbb\x17\x18\xbf" \
    "\x24\x81\x75\x65\x34\x19\x43\xbd\xfb\x1f\xa0\xb2" \
    "\x64\xe1\x1a\xc1\xb5\xcf\x81\xaf\x16\xd2\x09\x89" \
    "\xb4\xc1\x20\x4d\x22\x27\x4a\x45\x6e\x31\x52\xce" \
    "\x86\x17\x42\x90\xb6\x6d\x06\xc6\x47\x29\x4a\x15" \
    "\xe0\x70\xa8\xa8\x6e\xe8\xd9\x0d\xed\x2f\x40\x7b" \
    "\xca\xa2\x64\x83\xf6\xcf\x27\x0f\xf0\x43\xc0\xc8" \
    "\xfa\xa9\x33\x63\xa4\x12\xef\xbc\xf1\xb0\x68\x69" \
    "\x5a\xba\x4a\xb0\xfa\xb7\x12\x67\x21\xa4\x62\x02" \
    "\x99\x16\x48\x4b\x10\x4f\x27\x71\x79\x55\x72\x34" \
    "\x17\xd2\x16\x20\x67\xa8\x90\x04\xa3\x63\xa8\x71" \
    "\x17\x39\x96\x1b\xdb\x04\x5b\x87\xfc\x15\xa0\x79" \
    "\x24\xea\x31\x85\x8f\xbb\x7e\xd6\x50\x5d\xf6\x72" \
    "\xef\xd9\x04\xc7\xa7\xab\x96\xfd\xf1\x48\x23\x0f" \
    "\xdc\xc6\x6d\xdf\x5d\x14\x80\xe5\x4f\x49\x10\x02" \
    "\x63\x14\x2c\x43\x62\x19\x92\xf4\xa4\x64\xc2\xd4" \
    "\x71\xab\x33\xce\x3e\xcb\x5c\x81\x70\x3c\xce\x68" \
    "\x58\xc7\xab\xfb\xa6\x7d\x52\x09\x89\x31\x22\xa9" \
    "\xde\x22\x58\xb6\x5d\x72\xb3\x28\xa2\x77\xa8\xf5" \
    "\xb9\x7c\x58\x38\xab\x02\xd5\x50\x10\x8d\x9c\x7a" \
    "\xeb\x6e\xb1\x20\x7f\xc5\x2f\x24\x79\x8d\x99\xce" \
    "\x96\x29\x81\x6d\x66\xd4\x4c\x49\xa2\xae\x38\xe5" \
    "\xc5\x79\x88\x39\xad\x63\x5a\x69\xba\x2f\x8c\xb0" \
    "\x20\xb9\x00\xc5\x52\xb0\x8d\x8c\x4f\xd6\xdf\x32" \
    "\x20\xaf\x4e\x30\xd9\x0d\xde\xfe\x6a\xff\x92\x6b" \
    "\x9e\x77\x7f\x16\x66\xdf\x74\x05\x36\xaf\xe4\x47" \
    "\xeb\x69\xac\x59\xb0\x1a\x0a\x57\x09\x8c\xe1\x8b" \
    "\x99\x67\x75\x6c\x22\x89\xcb\xa5\xa2\xaa\x02\xa1" \
    "\x70\x51\x35\xe8\xe8\x0d\xe3\x1a\xf2\x23\x93\x0a" \
    "\x46\x5c\xce\xf3\x4d\x27\x24\xe9\x24\x54\x6f\x85" \
    "\x86\x1c\x07\xc7\xdb\x3f\xb9\xaf\x10\x1a\xb2\x04" \
    "\xd4\x8f\x4e\xb4\xde\xdb\x28\x04\x81\x9b\xa6\x1c" \
    "\x92\xcc\xd3\x31\x33\x49\x7e\x41\xce\x6c\x70\x05" \
    "\xd2\x96\x45\x85\xe7\x28\x49\x5f\x92\x7e\x4f\x88" \
    "\x0b\x39\x03\x0c\x26\xa2\xf3\xfc\xcd\xa8\x24\x67" \
    "\x81\xa4\xf0\x3a\x58\x43\x93\x7f\x7d\x0d\x5b\x01" \
    "\x94\x95\x3e\xea\x96\xb2\xe2\xba\xfc\x72\x70\x55" \
    "\x08\xf4\x31\x81\x99\x98\xad\x7a\x5c\x62\x38\x0c" \
    "\x4a\x0a\xbc\x08\x0d\x14\x67\x26\x73\xa1\x81\xd3" \
    "\xa5\x52\x5c\x75\x27\xcd\xd7\x97\xb2\x7a\x6d\x19" \
    "\x0d\xb5\xdd\x4c\x4c\xd8\xa4\x13\xf3\xe3\x98\x09" \
    "\x41\xee\xb5\x92\xc5\xc2\xcb\xa1\x9e\x57\x36\x02" \
    "\x39\x5a\x63\x39\xcd\x9e\xce\x62\x87\x77\x21\xd8" \
    "\x40\x2a\x39\xbb\xc1\x54\x20\x6a\x9a\x34\xac\xfa" \
    "\x8c\x94\x5a\x8a\x99\x06\x21\x05\x0e\x45\xc3\xa1" \
    "\x29\x53\x9d\x2c\x50\x9c\x2a\xe3\x31\x9d\xc3\x6d" \
    "\x35\xd4\xe9\x85\xe8\x0a\xf3\x44\x98\xe0\x2c\x13" \
    "\x78\xdc\x50\x36\xb9\xa2\x7e\x18\x02\x5a\xa1\x9f" \
    "\x45\x7e\xe1\x40\x2b\x06\xd3\xcc\x0c\x9b\xb9\x04" \
    "\x1c\x38\x39\xde\xb6\x96\xf4\x91\x08\x2a\x0a\x11" \
    "\x33\xc6\x0f\xb6\x46\x71\x57\xb6\x20\xd3\x19\x3b" \
    "\x1b\x9b\x89\xee\xf7\xc9\x8d\x6c\xc2\x76\x80\x35" \
    "\x1f\x3f\x13\x4f\x01\x7f\x31\x94\xf4\x05\x0a\x4a" \
    "\xa1\x5c\xdb\x7d\xac\x75\xf9\x76\x2c\xa2\x31\x15" \
    "\x4f\x12\x48\xc9\x4c\x29\xa6\x24\x0d\xa0\x08\xaa" \
    "\xec\xd2\x4c\xc7\x9b\x30\x59\x66\xe2\x0c\xd4\xa2" \
    "\x3a\x41\x6a\xa0\xba\x21\x78\xfc\x10\x07\xf6\xdd" \
    "\xc0\x35\x2e\x1f\x46\x7a\xee\x8c\xcc\x88\xe2\x04" \
    "\x33\x09\xb6\x29\x70\xe3\x53\xf3\xdd\x54\x6b\x0a" \
    "\xb9\x01\x80\xf3\x87\x32\x60\x81\x35\x99\x05\x33" \
    "\xf7\xae\x03\x28\x36\x7c\x61\xf4\xb1\xed\x96\x20" \
    "\x79\xf9\x0b\x91\x76\x66\xfc\xc6\x83\x7d\xfc\xed" \
    "\x2f\x95\xd4\xeb\xa5\xc4\x53\x36\xaa\x36\xbf\xfe" \
    "\xaa\x13\xf4\x10\x9c\xff\x40\x60\x87\x41\xa0\xa0" \
    "\x48\xbc\x9a\x4d\x2c\x66\x92\x01\xec\x3a\x08\x63" \
    "\x41\x41\x79\x8b\xc4\x9d\x0f\x76\xfa\x22\x11\x15" \
    "\x08\xeb\x3a\x9b\xb6\xbc\x47\x49\xe3\xa3\x99\x33" \
    "\x9d\xc2\x31\x63\x61\x8a\x96\x16\x62\x7a\x22\x74" \
    "\x9d\x37\xa8\x09\x56\xe3\x76\xa8\xd3\x37\x45\xda" \
    "\x10\x3d\x23\xe8\xff\x04\xf4\x71\xf0\x01\x12\x1b" \
    "\x04\xb6\xf6\xd3\x1b\x36\x9e\x8d\x1e\x91\xf8\xc9" \
    "\x2c\xee\x50\x27\x8c\xf4\x0b\x0a\x97\x40\x41\x2d" \
    "\xb8\x0b\x24\x1a\x60\xa6\x24\xe1\xdc\x11\xaa\xd6" \
    "\x3f\x84\xea\x70\xcc\xca\xae\xa8\xbe\x99\x07\xeb" \
    "\x21\x11\x19\xe5\xf7\x2f\x9a\x58\x26\xd8\x02\x0c" \
    "\x13\xe2\x03\x82\xe1\x0e\x88\x07\x2f\xda\x9b\x40" \
    "\x9c\x24\xe3\x29\xc6\xb5\x53\x21\x3a\xdd\xd2\xa0" \
    "\x4c\xb8\xa6\x0d\x52\x49\xe8\x3b\x09\x91\xd3\xe0" \
    "\x2f\x17\xe4\x56\x82\x92\x67\x13\x2f\xd6\x19\x39" \
    "\xd1\x8a\xe2\x80\xbc\xa6\xcd\x78\xbc\x17\x57\x89" \
    "\x11\x8b\x32\xb0\xff\x15\x0a\xba\x9f\x65\xd2\xd4" \
    "\x88\x84\x20\xd6\x0f\x93\xa3\xf3\x8f\x32\x01\x0c" \
    "\x13\x4c\x0c\x5b\x04\xb5\x73\x61\x4e\x15\x32\x4c" \
    "\x1d\x15\x98\x73\x0c\xf5\x34\xe8\xbd\x10\xe9\x05" \
    "\xcd\xad\x62\x7d\x59\xce\xcb\xef\x15\x10\x29\x0f" \
    "\xb3\x6b\x5f\x02\xc8\x9d\xb6\xed\xdd\xfb\x2a\xaf" \
    "\x3d\xf3\x04\xb5\x49\x37\x3d\xc3\x5f\xdf\x43\x33" \
    "\x2b\x30\x42\x47\x28\x0d\x43\xca\xc9\x09\xbe\xec" \
    "\xa7\xab\xc7\x9c\xfa\xe3\x52\x9a\xd4\x41\xf6\x7a" \
    "\xb0\xcf\x15\xe2\xf3\x3b\xd0\xbc\xfe\xe9\x80\xa1" \
    "\xb6\x77\xd9\xfe\xe3\x07\x29\xb8\x50\xca\x50\x18" \
    "\x0c\xfb\xd2\x71\x00\x06\xa4\xc1\xc6\x25\x4f\xb4" \
    "\x03\x83\x0a\x30\xb6\xb9\x79\xfd\xde\x1e\xf9\xf5" \
    "\x57\x67\x2e\xf3\x2e\x86\x79\xe6\xe1\xdd\x28\x6a" \
    "\x66\x21\x25\x06\xce\x73\xdf\xb6\x15\x2c\xb7\x6a" \
    "\xe6\x55\xf0\x52\x72\x86\x0e\x0e\x5e\xe0\x43\x98" \
    "\x9a\x57\x7b\xbe\xe2\xf5\x76\x3a\xf4\x2c\xc8\xe5" \
    "\x74\x90\x18\xb9\x75\xdf\x06\xc0\x32\x52\x3c\xfa" \
    "\x10\x94\x0c\x56\x20\x84\xb8\xa2\x2f\x40\x8f\x94" \
    "\xdc\xde\xb2\xf2\x74\x30\x4d\x2b\x4c\x6d\xc3\xde" \
    "\x24\xc7\x6e\x5a\xd5\xf8\xd7\x4e\x69\x71\x39\x12" \
    "\x31\x69\x11\x68\x52\xc8\x5d\xb6\x1a\x80\xe1\xd6" \
    "\x97\x18\x6c\xcd\xa7\x54\xe4\x5c\x11\x3c\xab\x47" \
    "\x39\xca\xae\xcf\x79\x1d\x38\x07\x33\xbe\x88\xbe" \
    "\x08\x71\x72\x8c\x95\x9b\x03\xa2\xa1\xc0\x39\x65" \
    "\x6c\xcd\x50\x15\x08\x31\xc9\x96\xa7\x35\x56\xaf" \
    "\xf5\x33\x71\x6a\x3f\x77\x7d\xe7\x0e\xea\xed\x22" \
    "\x26\xe7\xd8\x7e\x9d\xaa\x40\xbb\x1c\x61\x51\xcd" \
    "\xd2\xd6\xff\x8c\xf2\x3c\x30\x31\x5d\x01\x00\x1d" \
    "\x7a\xf2\x7c\x77\xff\xf2\xb8\x3c\x33\x5d\xae\xb9" \
    "\xec\x27\x14\x93\xfb\xef\xea\xc3\x36\x4d\xee\xf9" \
    "\xfe\x72\x02\x66\xf1\x55\x65\xed\x04\x82\xd2\x62" \
    "\xd3\xba\xe2\xe0\x3b\x3d\xbc\x0c\x0c\x66\x71\x67" \
    "\xcd\xcc\x8e\x09\xde\xbd\x76\x71\xfd\x8e\x13\x72" \
    "\x70\xda\x31\x2b\x26\xe0\xa9\xb0\x70\x55\x36\xb1" \
    "\xe3\xd7\x71\x12\x9d\xb9\xb8\xa6\xce\xfd\x72\xe2" \
    "\x04\x2e\xc8\x14\x47\x78\x67\xf2\x77\xff\x65\x07" \
    "\xcc\x7e\x23\xcc\x1d\xda\xd6\xdb\xdd\x3c\x5d\x55" \
    "\x53\xfe\xca\xc7\xf2\x88\x3e\x38\xe3\x66\xc4\xa4" \
    "\xc5\xca\x5b\x04\x63\x6d\x3b\x79\xfb\x05\xa8\x14" \
    "\xde\x2b\x36\x1c\xc0\x69\x39\xc4\xda\x16\x67\x9f" \
    "\xe6\xdc\xf6\x5c\xc8\xe4\x8f\xcc\xf8\x22\x86\x4b" \
    "\xbf\x8c\x94\x72\x27\xb7\xff\xbc\x85\x67\xff\x7e" \
    "\x38\xb8\xba\x5a\x2c\xc0\x90\x12\xef\xda\x41\xc2" \
    "\xed\x2e\x0a\xe3\x45\x64\xfb\x64\x66\xa6\x33\x65" \
    "\x58\xa6\xe8\xa4\xcd\x5e\x55\xb5\xe1\xc3\xbd\x7d" \
    "\xbc\x0a\x1c\x9e\x0b\x7e\x39\x02\x59\x29\x5f\x57" \
    "\xc2\xf6\xd3\x91\x9d\xf7\x97\xb1\xa1\xd6\x41\x29" \
    "\x15\xc2\x3f\x0f\x8c\x19\x99\x8f\xc9\x31\x86\x38" \
    "\x91\xbe\xeb\x9a\x0d\x27\xf7\x9c\xe1\xed\xb0\xc9" \
    "\x5b\x40\xff\xa5\x00\xae\xf8\x38\x9d\x92\xba\x25" \
    "\x7e\x6e\x5d\x57\xcd\xcd\xf5\x25\xd4\xed\x38\xb8" \
    "\xa7\x44\x23\x90\xeb\xc0\xa9\x82\x8d\x41\xcc\xd4" \
    "\x39\x37\xfe\xc8\x9a\x47\x87\x4e\x0c\xd2\xf1\x69" \
    "\x90\x03\x31\x9b\x03\xc0\x59\x98\xf7\x80\xfa\x46" \
    "\x04\xb2\xe2\x01\x2a\x80\x80\x13\x4a\x00\x17\x80" \
    "\x0d\x46\x1a\x22\x40\x88\x4c\x87\x4f\x5c\x6d\xc0" \
    "\xff\x01\x40\x97\xd7\x73\x7c\xff\x71\xa3\x00\x00" \
    "\x00\x00\x49\x45\x4e\x44\xae\x42\x60\x82"

class dKorreio(QMainWindow):
    def __init__(self,parent = None,name = None,fl = 0,korreioConfigDict = {}):
        self.korreioConfigDict = korreioConfigDict
        QMainWindow.__init__(self,parent,name,fl)
        self.statusBar()

        self.image0 = QPixmap()
        self.image0.loadFromData(image0_data,"PNG")
        if not name:
            self.setName("dKorreio")

        self.setIcon(self.image0)

        self.setCentralWidget(QWidget(self,"qt_central_widget"))
        dKorreioLayout = QGridLayout(self.centralWidget(),1,1,6,6,"dKorreioLayout")

        self.tlConsole = QLabel(self.centralWidget(),"tlConsole")
        self.tlConsole.setMinimumSize(QSize(0,24))
        self.tlConsole.setMaximumSize(QSize(32767,24))
        self.tlConsole.setFrameShape(QLabel.StyledPanel)
        self.tlConsole.setFrameShadow(QLabel.Sunken)
        self.tlConsole.setAlignment(QLabel.WordBreak | QLabel.AlignTop)
        self.tlConsole.setIndent(2)

        dKorreioLayout.addWidget(self.tlConsole,1,0)

        self.wsKorreio = QWidgetStack(self.centralWidget(),"wsKorreio")
        self.wsKorreio.setFrameShape(QWidgetStack.StyledPanel)
        self.wsKorreio.setFrameShadow(QWidgetStack.Sunken)

        self.WStackPage = QWidget(self.wsKorreio,"WStackPage")
        WStackPageLayout = QGridLayout(self.WStackPage,1,1,6,6,"WStackPageLayout")

        self.bgLog = QButtonGroup(self.WStackPage,"bgLog")
        self.bgLog.setFrameShape(QButtonGroup.NoFrame)
        self.bgLog.setColumnLayout(0,Qt.Vertical)
        self.bgLog.layout().setSpacing(6)
        self.bgLog.layout().setMargin(3)
        bgLogLayout = QGridLayout(self.bgLog.layout())
        bgLogLayout.setAlignment(Qt.AlignTop)

        self.rbConfLogModeRecent = QRadioButton(self.bgLog,"rbConfLogModeRecent")
        self.rbConfLogModeRecent.setChecked(1)

        bgLogLayout.addWidget(self.rbConfLogModeRecent,0,0)

        self.rbConfLogModeFull = QRadioButton(self.bgLog,"rbConfLogModeFull")

        bgLogLayout.addWidget(self.rbConfLogModeFull,0,1)
        spacer89 = QSpacerItem(241,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        bgLogLayout.addItem(spacer89,0,2)

        WStackPageLayout.addWidget(self.bgLog,1,0)

        self.lbLog = QListBox(self.WStackPage,"lbLog")

        WStackPageLayout.addWidget(self.lbLog,2,0)

        layout24_2 = QVBoxLayout(None,0,0,"layout24_2")

        self.textLabel3_3_2_2_2 = QLabel(self.WStackPage,"textLabel3_3_2_2_2")
        self.textLabel3_3_2_2_2.setMaximumSize(QSize(32767,21))
        layout24_2.addWidget(self.textLabel3_3_2_2_2)

        self.line22_4_2 = QFrame(self.WStackPage,"line22_4_2")
        self.line22_4_2.setFrameShape(QFrame.HLine)
        self.line22_4_2.setFrameShadow(QFrame.Sunken)
        self.line22_4_2.setFrameShape(QFrame.HLine)
        layout24_2.addWidget(self.line22_4_2)

        WStackPageLayout.addLayout(layout24_2,0,0)
        self.wsKorreio.addWidget(self.WStackPage,0)

        self.WStackPage_2 = QWidget(self.wsKorreio,"WStackPage_2")
        WStackPageLayout_2 = QGridLayout(self.WStackPage_2,1,1,6,6,"WStackPageLayout_2")

        self.splitter11 = QSplitter(self.WStackPage_2,"splitter11")
        self.splitter11.setOrientation(QSplitter.Horizontal)

        LayoutWidget = QWidget(self.splitter11,"layout7")
        layout7 = QVBoxLayout(LayoutWidget,0,6,"layout7")

        self.cbLdapFilter = QComboBox(0,LayoutWidget,"cbLdapFilter")
        self.cbLdapFilter.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed,0,0,self.cbLdapFilter.sizePolicy().hasHeightForWidth()))
        self.cbLdapFilter.setMinimumSize(QSize(280,0))
        self.cbLdapFilter.setAcceptDrops(1)
        self.cbLdapFilter.setEditable(1)
        self.cbLdapFilter.setAutoCompletion(1)
        self.cbLdapFilter.setDuplicatesEnabled(0)
        layout7.addWidget(self.cbLdapFilter)

        self.lvLdap = QListView(LayoutWidget,"lvLdap")
        self.lvLdap.addColumn(self.__tr("Distinguished Name"))
        self.lvLdap.setShowSortIndicator(1)
        self.lvLdap.setRootIsDecorated(1)
        self.lvLdap.setResizeMode(QListView.AllColumns)
        layout7.addWidget(self.lvLdap)

        self.pLdapDelete = QPushButton(LayoutWidget,"pLdapDelete")
        self.pLdapDelete.setMinimumSize(QSize(120,0))
        self.pLdapDelete.setMaximumSize(QSize(120,26))
        layout7.addWidget(self.pLdapDelete)

        LayoutWidget_2 = QWidget(self.splitter11,"layout521")
        layout521 = QVBoxLayout(LayoutWidget_2,0,6,"layout521")

        layout9 = QHBoxLayout(None,0,6,"layout9")

        self.pLdapSearch = QPushButton(LayoutWidget_2,"pLdapSearch")
        self.pLdapSearch.setMaximumSize(QSize(32767,26))
        layout9.addWidget(self.pLdapSearch)
        spacer26_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout9.addItem(spacer26_2)
        layout521.addLayout(layout9)

        self.wsLdap = QWidgetStack(LayoutWidget_2,"wsLdap")
        self.wsLdap.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Minimum,0,0,self.wsLdap.sizePolicy().hasHeightForWidth()))
        self.wsLdap.setMargin(-8)

        self.WStackPage_3 = QWidget(self.wsLdap,"WStackPage_3")
        WStackPageLayout_3 = QGridLayout(self.WStackPage_3,1,1,8,6,"WStackPageLayout_3")
        spacer2 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_3.addItem(spacer2,1,4)

        self.cbLdapAttr = QComboBox(0,self.WStackPage_3,"cbLdapAttr")
        self.cbLdapAttr.setEditable(1)
        self.cbLdapAttr.setAutoCompletion(1)

        WStackPageLayout_3.addWidget(self.cbLdapAttr,1,0)

        self.cbLdapValue = QComboBox(0,self.WStackPage_3,"cbLdapValue")
        self.cbLdapValue.setEditable(1)
        self.cbLdapValue.setAutoCompletion(1)

        WStackPageLayout_3.addWidget(self.cbLdapValue,1,1)

        self.pLdapAddAttr = QPushButton(self.WStackPage_3,"pLdapAddAttr")
        self.pLdapAddAttr.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pLdapAddAttr.sizePolicy().hasHeightForWidth()))
        self.pLdapAddAttr.setMaximumSize(QSize(30,32767))

        WStackPageLayout_3.addWidget(self.pLdapAddAttr,1,2)

        self.pLdapDeleteAttr = QPushButton(self.WStackPage_3,"pLdapDeleteAttr")
        self.pLdapDeleteAttr.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pLdapDeleteAttr.sizePolicy().hasHeightForWidth()))
        self.pLdapDeleteAttr.setMaximumSize(QSize(30,32767))

        WStackPageLayout_3.addWidget(self.pLdapDeleteAttr,1,3)

        self.pLdapModify = QPushButton(self.WStackPage_3,"pLdapModify")

        WStackPageLayout_3.addWidget(self.pLdapModify,1,5)

        self.lvLdapAttr = QListView(self.WStackPage_3,"lvLdapAttr")
        self.lvLdapAttr.addColumn(self.__tr("Attribute"))
        self.lvLdapAttr.addColumn(self.__tr("Value"))
        self.lvLdapAttr.setLineWidth(2)
        self.lvLdapAttr.setAllColumnsShowFocus(1)
        self.lvLdapAttr.setShowSortIndicator(1)
        self.lvLdapAttr.setResizeMode(QListView.LastColumn)
        self.lvLdapAttr.setDefaultRenameAction(QListView.Accept)

        WStackPageLayout_3.addMultiCellWidget(self.lvLdapAttr,0,0,0,5)
        self.wsLdap.addWidget(self.WStackPage_3,0)

        self.WStackPage_4 = QWidget(self.wsLdap,"WStackPage_4")
        WStackPageLayout_4 = QGridLayout(self.WStackPage_4,1,1,8,6,"WStackPageLayout_4")
        spacer159_2 = QSpacerItem(20,150,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_4.addItem(spacer159_2,2,0)

        self.pLdapAddDhcp = QPushButton(self.WStackPage_4,"pLdapAddDhcp")
        self.pLdapAddDhcp.setMaximumSize(QSize(110,26))

        WStackPageLayout_4.addWidget(self.pLdapAddDhcp,4,1)

        layout51_2_3 = QGridLayout(None,1,1,0,0,"layout51_2_3")

        self.line22_3_3 = QFrame(self.WStackPage_4,"line22_3_3")
        self.line22_3_3.setFrameShape(QFrame.HLine)
        self.line22_3_3.setFrameShadow(QFrame.Sunken)
        self.line22_3_3.setFrameShape(QFrame.HLine)

        layout51_2_3.addMultiCellWidget(self.line22_3_3,1,1,0,1)

        self.textLabel1_2_4_3 = QLabel(self.WStackPage_4,"textLabel1_2_4_3")
        self.textLabel1_2_4_3.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4_3.setMaximumSize(QSize(32767,26))

        layout51_2_3.addWidget(self.textLabel1_2_4_3,0,0)
        spacer148_2_3 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2_3.addItem(spacer148_2_3,0,1)

        WStackPageLayout_4.addMultiCellLayout(layout51_2_3,0,0,0,1)

        self.line27_2 = QFrame(self.WStackPage_4,"line27_2")
        self.line27_2.setFrameShape(QFrame.HLine)
        self.line27_2.setFrameShadow(QFrame.Sunken)
        self.line27_2.setFrameShape(QFrame.HLine)

        WStackPageLayout_4.addMultiCellWidget(self.line27_2,3,3,0,1)

        self.frame24_2 = QFrame(self.WStackPage_4,"frame24_2")
        self.frame24_2.setFrameShape(QFrame.NoFrame)
        self.frame24_2.setFrameShadow(QFrame.Raised)
        frame24_2Layout = QGridLayout(self.frame24_2,1,1,8,6,"frame24_2Layout")

        self.textLabel2_3_2_2 = QLabel(self.frame24_2,"textLabel2_3_2_2")
        self.textLabel2_3_2_2.setMinimumSize(QSize(150,0))
        self.textLabel2_3_2_2.setMaximumSize(QSize(150,32767))

        frame24_2Layout.addWidget(self.textLabel2_3_2_2,0,0)
        spacer31_3 = QSpacerItem(150,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame24_2Layout.addItem(spacer31_3,0,2)

        self.cbLdapFormDhcpType = QComboBox(0,self.frame24_2,"cbLdapFormDhcpType")

        frame24_2Layout.addWidget(self.cbLdapFormDhcpType,0,1)

        self.wsLdapDhcp = QWidgetStack(self.frame24_2,"wsLdapDhcp")
        self.wsLdapDhcp.setMargin(-8)

        self.WStackPage_5 = QWidget(self.wsLdapDhcp,"WStackPage_5")
        WStackPageLayout_5 = QGridLayout(self.WStackPage_5,1,1,8,6,"WStackPageLayout_5")
        spacer95 = QSpacerItem(371,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_5.addMultiCell(spacer95,5,5,0,1)

        self.iLdapFormDhcpIPaddress = QLineEdit(self.WStackPage_5,"iLdapFormDhcpIPaddress")

        WStackPageLayout_5.addWidget(self.iLdapFormDhcpIPaddress,2,1)

        self.textLabel3_2_3_2_2 = QLabel(self.WStackPage_5,"textLabel3_2_3_2_2")

        WStackPageLayout_5.addWidget(self.textLabel3_2_3_2_2,2,0)

        self.iLdapFormDhcpMACaddress = QLineEdit(self.WStackPage_5,"iLdapFormDhcpMACaddress")

        WStackPageLayout_5.addWidget(self.iLdapFormDhcpMACaddress,3,1)

        self.textLabel3_2_4_2_2 = QLabel(self.WStackPage_5,"textLabel3_2_4_2_2")

        WStackPageLayout_5.addWidget(self.textLabel3_2_4_2_2,4,0)

        self.textLabel5_3_2_2 = QLabel(self.WStackPage_5,"textLabel5_3_2_2")

        WStackPageLayout_5.addWidget(self.textLabel5_3_2_2,3,0)

        self.iLdapFormDhcpComments = QLineEdit(self.WStackPage_5,"iLdapFormDhcpComments")

        WStackPageLayout_5.addWidget(self.iLdapFormDhcpComments,4,1)

        self.iLdapFormDhcpName = QLineEdit(self.WStackPage_5,"iLdapFormDhcpName")

        WStackPageLayout_5.addWidget(self.iLdapFormDhcpName,1,1)

        self.iLdapFormDhcpGroupName = QLineEdit(self.WStackPage_5,"iLdapFormDhcpGroupName")

        WStackPageLayout_5.addWidget(self.iLdapFormDhcpGroupName,0,1)

        self.textLabel2_3_3 = QLabel(self.WStackPage_5,"textLabel2_3_3")
        self.textLabel2_3_3.setMinimumSize(QSize(150,0))

        WStackPageLayout_5.addWidget(self.textLabel2_3_3,1,0)

        self.tlLdapFormDhcpGroupName = QLabel(self.WStackPage_5,"tlLdapFormDhcpGroupName")
        self.tlLdapFormDhcpGroupName.setMinimumSize(QSize(150,0))

        WStackPageLayout_5.addWidget(self.tlLdapFormDhcpGroupName,0,0)
        self.wsLdapDhcp.addWidget(self.WStackPage_5,0)

        self.WStackPage_6 = QWidget(self.wsLdapDhcp,"WStackPage_6")
        WStackPageLayout_6 = QGridLayout(self.WStackPage_6,1,1,8,6,"WStackPageLayout_6")

        self.tlLdapFormDhcpInterface = QLabel(self.WStackPage_6,"tlLdapFormDhcpInterface")
        self.tlLdapFormDhcpInterface.setMinimumSize(QSize(150,0))

        WStackPageLayout_6.addWidget(self.tlLdapFormDhcpInterface,0,0)

        self.cbLdapFormDhcpInterface = QComboBox(0,self.WStackPage_6,"cbLdapFormDhcpInterface")
        self.cbLdapFormDhcpInterface.setEditable(1)

        WStackPageLayout_6.addWidget(self.cbLdapFormDhcpInterface,0,1)

        self.textLabel1_3_2_2_2_3_2_3_4 = QLabel(self.WStackPage_6,"textLabel1_3_2_2_2_3_2_3_4")

        WStackPageLayout_6.addWidget(self.textLabel1_3_2_2_2_3_2_3_4,1,0)

        self.iLdapFormDhcpNetwork = QLineEdit(self.WStackPage_6,"iLdapFormDhcpNetwork")

        WStackPageLayout_6.addWidget(self.iLdapFormDhcpNetwork,1,1)

        self.textLabel1_3_2_2_2_3_2_3_3_4 = QLabel(self.WStackPage_6,"textLabel1_3_2_2_2_3_2_3_3_4")

        WStackPageLayout_6.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_4,2,0)

        self.iLdapFormDhcpBroadcast = QLineEdit(self.WStackPage_6,"iLdapFormDhcpBroadcast")

        WStackPageLayout_6.addWidget(self.iLdapFormDhcpBroadcast,2,1)

        self.textLabel1_3_2_2_2_3_2_3_2_2 = QLabel(self.WStackPage_6,"textLabel1_3_2_2_2_3_2_3_2_2")

        WStackPageLayout_6.addWidget(self.textLabel1_3_2_2_2_3_2_3_2_2,3,0)

        self.iLdapFormDhcpGateway = QLineEdit(self.WStackPage_6,"iLdapFormDhcpGateway")

        WStackPageLayout_6.addWidget(self.iLdapFormDhcpGateway,5,1)

        self.iLdapFormDhcpRange = QLineEdit(self.WStackPage_6,"iLdapFormDhcpRange")
        self.iLdapFormDhcpRange.setCursorPosition(0)

        WStackPageLayout_6.addWidget(self.iLdapFormDhcpRange,3,1)

        self.textLabel1_3_2_2_2_3_2_3_3_2_2 = QLabel(self.WStackPage_6,"textLabel1_3_2_2_2_3_2_3_3_2_2")

        WStackPageLayout_6.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_2_2,4,0)

        self.cbLdapFormDhcpNetmask = QComboBox(0,self.WStackPage_6,"cbLdapFormDhcpNetmask")

        WStackPageLayout_6.addWidget(self.cbLdapFormDhcpNetmask,4,1)

        self.textLabel1_3_2_2_2_3_2_3_3_3_2 = QLabel(self.WStackPage_6,"textLabel1_3_2_2_2_3_2_3_3_3_2")

        WStackPageLayout_6.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_3_2,5,0)
        self.wsLdapDhcp.addWidget(self.WStackPage_6,1)

        frame24_2Layout.addMultiCellWidget(self.wsLdapDhcp,1,1,0,1)

        WStackPageLayout_4.addMultiCellWidget(self.frame24_2,1,1,0,1)
        self.wsLdap.addWidget(self.WStackPage_4,1)

        self.WStackPage_7 = QWidget(self.wsLdap,"WStackPage_7")
        WStackPageLayout_7 = QGridLayout(self.WStackPage_7,1,1,8,6,"WStackPageLayout_7")

        layout51 = QGridLayout(None,1,1,0,0,"layout51")

        self.line22 = QFrame(self.WStackPage_7,"line22")
        self.line22.setFrameShape(QFrame.HLine)
        self.line22.setFrameShadow(QFrame.Sunken)
        self.line22.setFrameShape(QFrame.HLine)

        layout51.addMultiCellWidget(self.line22,1,1,0,1)

        self.textLabel1_2 = QLabel(self.WStackPage_7,"textLabel1_2")
        self.textLabel1_2.setMinimumSize(QSize(250,0))
        self.textLabel1_2.setMaximumSize(QSize(32767,26))

        layout51.addWidget(self.textLabel1_2,0,0)
        spacer148 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51.addItem(spacer148,0,1)

        WStackPageLayout_7.addMultiCellLayout(layout51,0,0,0,1)

        self.line24 = QFrame(self.WStackPage_7,"line24")
        self.line24.setFrameShape(QFrame.HLine)
        self.line24.setFrameShadow(QFrame.Sunken)
        self.line24.setFrameShape(QFrame.HLine)

        WStackPageLayout_7.addMultiCellWidget(self.line24,3,3,0,1)

        layout173 = QHBoxLayout(None,0,6,"layout173")

        self.pLdapFormBack = QPushButton(self.WStackPage_7,"pLdapFormBack")
        self.pLdapFormBack.setMinimumSize(QSize(100,0))
        self.pLdapFormBack.setMaximumSize(QSize(110,26))
        layout173.addWidget(self.pLdapFormBack)

        self.pLdapFormNext = QPushButton(self.WStackPage_7,"pLdapFormNext")
        self.pLdapFormNext.setMinimumSize(QSize(100,0))
        self.pLdapFormNext.setMaximumSize(QSize(110,26))
        layout173.addWidget(self.pLdapFormNext)
        spacer76 = QSpacerItem(190,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout173.addItem(spacer76)

        self.pLdapAddUser = QPushButton(self.WStackPage_7,"pLdapAddUser")
        self.pLdapAddUser.setMinimumSize(QSize(110,26))
        self.pLdapAddUser.setMaximumSize(QSize(110,26))
        layout173.addWidget(self.pLdapAddUser)

        WStackPageLayout_7.addMultiCellLayout(layout173,4,4,0,1)
        spacer75 = QSpacerItem(70,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_7.addItem(spacer75,1,1)
        spacer348 = QSpacerItem(20,50,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_7.addItem(spacer348,2,0)

        self.wsLdapForm = QWidgetStack(self.WStackPage_7,"wsLdapForm")

        self.WStackPage_8 = QWidget(self.wsLdapForm,"WStackPage_8")
        WStackPageLayout_8 = QGridLayout(self.WStackPage_8,1,1,8,6,"WStackPageLayout_8")

        layout46_2 = QVBoxLayout(None,0,0,"layout46_2")

        self.textLabel1_2_3 = QLabel(self.WStackPage_8,"textLabel1_2_3")
        layout46_2.addWidget(self.textLabel1_2_3)

        self.line22_2 = QFrame(self.WStackPage_8,"line22_2")
        self.line22_2.setFrameShape(QFrame.HLine)
        self.line22_2.setFrameShadow(QFrame.Sunken)
        self.line22_2.setFrameShape(QFrame.HLine)
        layout46_2.addWidget(self.line22_2)

        WStackPageLayout_8.addLayout(layout46_2,0,0)
        spacer146 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_8.addItem(spacer146,2,0)

        self.frame23 = QFrame(self.WStackPage_8,"frame23")
        self.frame23.setFrameShape(QFrame.NoFrame)
        self.frame23.setFrameShadow(QFrame.Raised)
        frame23Layout = QGridLayout(self.frame23,1,1,8,6,"frame23Layout")

        self.textLabel3_2 = QLabel(self.frame23,"textLabel3_2")
        self.textLabel3_2.setMinimumSize(QSize(120,0))

        frame23Layout.addWidget(self.textLabel3_2,0,0)

        self.iLdapFormCn = QLineEdit(self.frame23,"iLdapFormCn")
        self.iLdapFormCn.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormCn,0,1)

        self.textLabel5 = QLabel(self.frame23,"textLabel5")

        frame23Layout.addWidget(self.textLabel5,1,0)

        self.iLdapFormMail = QLineEdit(self.frame23,"iLdapFormMail")
        self.iLdapFormMail.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormMail,1,1)

        self.textLabel5_3 = QLabel(self.frame23,"textLabel5_3")

        frame23Layout.addWidget(self.textLabel5_3,3,0)

        self.textLabel3_2_3 = QLabel(self.frame23,"textLabel3_2_3")

        frame23Layout.addWidget(self.textLabel3_2_3,2,0)

        self.iLdapFormStreet = QLineEdit(self.frame23,"iLdapFormStreet")
        self.iLdapFormStreet.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormStreet,2,1)

        self.iLdapFormL = QLineEdit(self.frame23,"iLdapFormL")
        self.iLdapFormL.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormL,3,1)

        self.textLabel3_2_4 = QLabel(self.frame23,"textLabel3_2_4")

        frame23Layout.addWidget(self.textLabel3_2_4,4,0)

        self.iLdapFormPostalCode = QLineEdit(self.frame23,"iLdapFormPostalCode")
        self.iLdapFormPostalCode.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormPostalCode,4,1)

        self.textLabel5_4 = QLabel(self.frame23,"textLabel5_4")

        frame23Layout.addWidget(self.textLabel5_4,5,0)

        self.iLdapFormHomePhone = QLineEdit(self.frame23,"iLdapFormHomePhone")
        self.iLdapFormHomePhone.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormHomePhone,5,1)
        spacer28 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame23Layout.addItem(spacer28,0,2)

        self.iLdapFormUserP = QLineEdit(self.frame23,"iLdapFormUserP")
        self.iLdapFormUserP.setMinimumSize(QSize(270,0))
        self.iLdapFormUserP.setEchoMode(QLineEdit.Password)

        frame23Layout.addWidget(self.iLdapFormUserP,6,1)

        self.iLdapFormUserP2 = QLineEdit(self.frame23,"iLdapFormUserP2")
        self.iLdapFormUserP2.setMinimumSize(QSize(270,0))
        self.iLdapFormUserP2.setEchoMode(QLineEdit.Password)

        frame23Layout.addWidget(self.iLdapFormUserP2,7,1)

        self.textLabel1_3 = QLabel(self.frame23,"textLabel1_3")

        frame23Layout.addWidget(self.textLabel1_3,6,0)

        self.textLabel1_3_4 = QLabel(self.frame23,"textLabel1_3_4")

        frame23Layout.addWidget(self.textLabel1_3_4,7,0)

        WStackPageLayout_8.addWidget(self.frame23,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_8,0)

        self.WStackPage_9 = QWidget(self.wsLdapForm,"WStackPage_9")
        WStackPageLayout_9 = QGridLayout(self.WStackPage_9,1,1,8,6,"WStackPageLayout_9")

        layout53 = QGridLayout(None,1,1,0,0,"layout53")

        self.textLabel1_2_3_2 = QLabel(self.WStackPage_9,"textLabel1_2_3_2")

        layout53.addWidget(self.textLabel1_2_3_2,0,0)
        spacer156 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout53.addItem(spacer156,0,2)

        self.line22_2_2 = QFrame(self.WStackPage_9,"line22_2_2")
        self.line22_2_2.setFrameShape(QFrame.HLine)
        self.line22_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_2_2.setFrameShape(QFrame.HLine)

        layout53.addMultiCellWidget(self.line22_2_2,1,1,0,2)

        self.cLdapFormPosix = QCheckBox(self.WStackPage_9,"cLdapFormPosix")

        layout53.addWidget(self.cLdapFormPosix,0,1)

        WStackPageLayout_9.addLayout(layout53,0,0)

        self.fLdapFormPosix = QFrame(self.WStackPage_9,"fLdapFormPosix")
        self.fLdapFormPosix.setEnabled(0)
        self.fLdapFormPosix.setFrameShape(QFrame.NoFrame)
        self.fLdapFormPosix.setFrameShadow(QFrame.Raised)
        fLdapFormPosixLayout = QGridLayout(self.fLdapFormPosix,1,1,8,6,"fLdapFormPosixLayout")

        self.textLabel5_2_2 = QLabel(self.fLdapFormPosix,"textLabel5_2_2")

        fLdapFormPosixLayout.addWidget(self.textLabel5_2_2,1,0)

        self.textLabel1_3_3_2 = QLabel(self.fLdapFormPosix,"textLabel1_3_3_2")

        fLdapFormPosixLayout.addWidget(self.textLabel1_3_3_2,2,0)

        self.textLabel1_3_3 = QLabel(self.fLdapFormPosix,"textLabel1_3_3")
        self.textLabel1_3_3.setMinimumSize(QSize(0,0))

        fLdapFormPosixLayout.addWidget(self.textLabel1_3_3,4,0)

        self.textLabel5_2 = QLabel(self.fLdapFormPosix,"textLabel5_2")

        fLdapFormPosixLayout.addWidget(self.textLabel5_2,3,0)

        self.iLdapFormGidNumber = QLineEdit(self.fLdapFormPosix,"iLdapFormGidNumber")
        self.iLdapFormGidNumber.setMinimumSize(QSize(200,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormGidNumber,2,1)

        self.textLabel3_2_2 = QLabel(self.fLdapFormPosix,"textLabel3_2_2")
        self.textLabel3_2_2.setMinimumSize(QSize(120,0))

        fLdapFormPosixLayout.addWidget(self.textLabel3_2_2,0,0)

        self.iLdapFormLoginShell = QLineEdit(self.fLdapFormPosix,"iLdapFormLoginShell")
        self.iLdapFormLoginShell.setMinimumSize(QSize(200,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormLoginShell,3,1)

        self.iLdapFormHomeDirectory = QLineEdit(self.fLdapFormPosix,"iLdapFormHomeDirectory")
        self.iLdapFormHomeDirectory.setMinimumSize(QSize(200,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormHomeDirectory,4,1)
        spacer28_3 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormPosixLayout.addMultiCell(spacer28_3,4,4,2,3)

        self.iLdapFormUid = QLineEdit(self.fLdapFormPosix,"iLdapFormUid")
        self.iLdapFormUid.setMinimumSize(QSize(200,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormUid,0,1)

        self.iLdapFormUidNumber = QLineEdit(self.fLdapFormPosix,"iLdapFormUidNumber")
        self.iLdapFormUidNumber.setMinimumSize(QSize(200,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormUidNumber,1,1)

        self.pLdapGetUidNumber = QPushButton(self.fLdapFormPosix,"pLdapGetUidNumber")
        self.pLdapGetUidNumber.setMaximumSize(QSize(32767,25))

        fLdapFormPosixLayout.addWidget(self.pLdapGetUidNumber,1,2)
        spacer90 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormPosixLayout.addItem(spacer90,1,3)

        WStackPageLayout_9.addWidget(self.fLdapFormPosix,1,0)
        spacer146_2 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_9.addItem(spacer146_2,2,0)
        self.wsLdapForm.addWidget(self.WStackPage_9,1)

        self.WStackPage_10 = QWidget(self.wsLdapForm,"WStackPage_10")
        WStackPageLayout_10 = QGridLayout(self.WStackPage_10,1,1,8,6,"WStackPageLayout_10")

        layout53_2 = QGridLayout(None,1,1,0,0,"layout53_2")

        self.textLabel1_2_3_2_2 = QLabel(self.WStackPage_10,"textLabel1_2_3_2_2")

        layout53_2.addWidget(self.textLabel1_2_3_2_2,0,0)
        spacer156_2 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout53_2.addItem(spacer156_2,0,2)

        self.line22_2_2_2 = QFrame(self.WStackPage_10,"line22_2_2_2")
        self.line22_2_2_2.setFrameShape(QFrame.HLine)
        self.line22_2_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_2_2_2.setFrameShape(QFrame.HLine)

        layout53_2.addMultiCellWidget(self.line22_2_2_2,1,1,0,2)

        self.cLdapFormSamba = QCheckBox(self.WStackPage_10,"cLdapFormSamba")

        layout53_2.addWidget(self.cLdapFormSamba,0,1)

        WStackPageLayout_10.addLayout(layout53_2,0,0)
        spacer152 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_10.addItem(spacer152,2,0)

        self.fLdapFormSamba = QFrame(self.WStackPage_10,"fLdapFormSamba")
        self.fLdapFormSamba.setEnabled(0)
        self.fLdapFormSamba.setFrameShape(QFrame.NoFrame)
        self.fLdapFormSamba.setFrameShadow(QFrame.Raised)
        fLdapFormSambaLayout = QGridLayout(self.fLdapFormSamba,1,1,8,6,"fLdapFormSambaLayout")

        self.textLabel3_2_2_2 = QLabel(self.fLdapFormSamba,"textLabel3_2_2_2")
        self.textLabel3_2_2_2.setMinimumSize(QSize(120,0))

        fLdapFormSambaLayout.addWidget(self.textLabel3_2_2_2,0,0)
        spacer28_3_2 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormSambaLayout.addItem(spacer28_3_2,0,2)

        self.cbLdapFormSambaDomain = QComboBox(0,self.fLdapFormSamba,"cbLdapFormSambaDomain")

        fLdapFormSambaLayout.addWidget(self.cbLdapFormSambaDomain,0,1)

        self.iLdapFormLogonScript = QLineEdit(self.fLdapFormSamba,"iLdapFormLogonScript")
        self.iLdapFormLogonScript.setMinimumSize(QSize(270,0))

        fLdapFormSambaLayout.addWidget(self.iLdapFormLogonScript,8,1)

        self.textLabel1_3_3_3 = QLabel(self.fLdapFormSamba,"textLabel1_3_3_3")

        fLdapFormSambaLayout.addWidget(self.textLabel1_3_3_3,7,0)

        self.textLabel5_2_2_2 = QLabel(self.fLdapFormSamba,"textLabel5_2_2_2")
        self.textLabel5_2_2_2.setMinimumSize(QSize(120,0))

        fLdapFormSambaLayout.addWidget(self.textLabel5_2_2_2,4,0)

        self.textLabel1_3_3_3_2 = QLabel(self.fLdapFormSamba,"textLabel1_3_3_3_2")

        fLdapFormSambaLayout.addWidget(self.textLabel1_3_3_3_2,8,0)

        self.iLdapFormProfilePath = QLineEdit(self.fLdapFormSamba,"iLdapFormProfilePath")
        self.iLdapFormProfilePath.setMinimumSize(QSize(270,0))

        fLdapFormSambaLayout.addWidget(self.iLdapFormProfilePath,5,1)

        self.textLabel5_2_3 = QLabel(self.fLdapFormSamba,"textLabel5_2_3")

        fLdapFormSambaLayout.addWidget(self.textLabel5_2_3,6,0)

        self.iLdapFormDrivePath = QLineEdit(self.fLdapFormSamba,"iLdapFormDrivePath")
        self.iLdapFormDrivePath.setMinimumSize(QSize(270,0))

        fLdapFormSambaLayout.addWidget(self.iLdapFormDrivePath,7,1)

        self.iLdapFormHomeDrive = QLineEdit(self.fLdapFormSamba,"iLdapFormHomeDrive")
        self.iLdapFormHomeDrive.setMinimumSize(QSize(270,0))

        fLdapFormSambaLayout.addWidget(self.iLdapFormHomeDrive,6,1)

        self.cbLdapFormProfileType = QComboBox(0,self.fLdapFormSamba,"cbLdapFormProfileType")

        fLdapFormSambaLayout.addWidget(self.cbLdapFormProfileType,4,1)

        self.cbLdapFormPrimaryGroup = QComboBox(0,self.fLdapFormSamba,"cbLdapFormPrimaryGroup")

        fLdapFormSambaLayout.addWidget(self.cbLdapFormPrimaryGroup,3,1)

        self.textLabel1_3_3_2_2 = QLabel(self.fLdapFormSamba,"textLabel1_3_3_2_2")

        fLdapFormSambaLayout.addWidget(self.textLabel1_3_3_2_2,3,0)

        self.iLdapFormSambaPwdMustChange = QCheckBox(self.fLdapFormSamba,"iLdapFormSambaPwdMustChange")
        self.iLdapFormSambaPwdMustChange.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapFormSambaPwdMustChange.sizePolicy().hasHeightForWidth()))
        self.iLdapFormSambaPwdMustChange.setChecked(1)

        fLdapFormSambaLayout.addMultiCellWidget(self.iLdapFormSambaPwdMustChange,2,2,1,2)

        self.line62 = QFrame(self.fLdapFormSamba,"line62")
        self.line62.setFrameShape(QFrame.HLine)
        self.line62.setFrameShadow(QFrame.Sunken)
        self.line62.setFrameShape(QFrame.HLine)

        fLdapFormSambaLayout.addMultiCellWidget(self.line62,1,1,0,2)

        WStackPageLayout_10.addWidget(self.fLdapFormSamba,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_10,2)

        self.WStackPage_11 = QWidget(self.wsLdapForm,"WStackPage_11")
        WStackPageLayout_11 = QGridLayout(self.WStackPage_11,1,1,8,6,"WStackPageLayout_11")

        layout53_3 = QGridLayout(None,1,1,0,0,"layout53_3")

        self.textLabel1_2_3_2_3 = QLabel(self.WStackPage_11,"textLabel1_2_3_2_3")

        layout53_3.addWidget(self.textLabel1_2_3_2_3,0,0)
        spacer156_3 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout53_3.addItem(spacer156_3,0,2)

        self.line22_2_2_3 = QFrame(self.WStackPage_11,"line22_2_2_3")
        self.line22_2_2_3.setFrameShape(QFrame.HLine)
        self.line22_2_2_3.setFrameShadow(QFrame.Sunken)
        self.line22_2_2_3.setFrameShape(QFrame.HLine)

        layout53_3.addMultiCellWidget(self.line22_2_2_3,1,1,0,2)

        self.cLdapFormAst = QCheckBox(self.WStackPage_11,"cLdapFormAst")

        layout53_3.addWidget(self.cLdapFormAst,0,1)

        WStackPageLayout_11.addLayout(layout53_3,0,0)
        spacer146_2_3 = QSpacerItem(20,80,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_11.addItem(spacer146_2_3,2,0)

        self.fLdapFormAst = QFrame(self.WStackPage_11,"fLdapFormAst")
        self.fLdapFormAst.setEnabled(0)
        self.fLdapFormAst.setFrameShape(QFrame.NoFrame)
        self.fLdapFormAst.setFrameShadow(QFrame.Raised)
        fLdapFormAstLayout = QGridLayout(self.fLdapFormAst,1,1,8,6,"fLdapFormAstLayout")

        self.textLabel3_2_2_3 = QLabel(self.fLdapFormAst,"textLabel3_2_2_3")
        self.textLabel3_2_2_3.setMinimumSize(QSize(120,0))

        fLdapFormAstLayout.addWidget(self.textLabel3_2_2_3,0,0)

        self.cLdapFormAstSecret = QCheckBox(self.fLdapFormAst,"cLdapFormAstSecret")
        self.cLdapFormAstSecret.setChecked(1)

        fLdapFormAstLayout.addWidget(self.cLdapFormAstSecret,3,1)

        self.textLabel5_2_2_3 = QLabel(self.fLdapFormAst,"textLabel5_2_2_3")

        fLdapFormAstLayout.addWidget(self.textLabel5_2_2_3,1,0)

        self.iLdapFormAstName = QLineEdit(self.fLdapFormAst,"iLdapFormAstName")
        self.iLdapFormAstName.setMinimumSize(QSize(270,0))

        fLdapFormAstLayout.addWidget(self.iLdapFormAstName,1,1)
        spacer28_3_3 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormAstLayout.addItem(spacer28_3_3,0,2)

        self.textLabel5_2_2_3_2 = QLabel(self.fLdapFormAst,"textLabel5_2_2_3_2")

        fLdapFormAstLayout.addWidget(self.textLabel5_2_2_3_2,2,0)

        self.iLdapFormAstPort = QLineEdit(self.fLdapFormAst,"iLdapFormAstPort")
        self.iLdapFormAstPort.setMinimumSize(QSize(270,0))

        fLdapFormAstLayout.addWidget(self.iLdapFormAstPort,2,1)

        self.iLdapFormAstUsername = QLineEdit(self.fLdapFormAst,"iLdapFormAstUsername")
        self.iLdapFormAstUsername.setMinimumSize(QSize(270,0))

        fLdapFormAstLayout.addWidget(self.iLdapFormAstUsername,0,1)

        WStackPageLayout_11.addWidget(self.fLdapFormAst,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_11,3)

        self.WStackPage_12 = QWidget(self.wsLdapForm,"WStackPage_12")
        WStackPageLayout_12 = QGridLayout(self.WStackPage_12,1,1,8,6,"WStackPageLayout_12")

        layout53_4 = QGridLayout(None,1,1,0,0,"layout53_4")

        self.textLabel1_2_3_2_4 = QLabel(self.WStackPage_12,"textLabel1_2_3_2_4")

        layout53_4.addWidget(self.textLabel1_2_3_2_4,0,0)
        spacer156_4 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout53_4.addItem(spacer156_4,0,2)

        self.line22_2_2_4 = QFrame(self.WStackPage_12,"line22_2_2_4")
        self.line22_2_2_4.setFrameShape(QFrame.HLine)
        self.line22_2_2_4.setFrameShadow(QFrame.Sunken)
        self.line22_2_2_4.setFrameShape(QFrame.HLine)

        layout53_4.addMultiCellWidget(self.line22_2_2_4,1,1,0,2)

        self.cLdapFormRadius = QCheckBox(self.WStackPage_12,"cLdapFormRadius")

        layout53_4.addWidget(self.cLdapFormRadius,0,1)

        WStackPageLayout_12.addLayout(layout53_4,0,0)
        spacer146_2_4 = QSpacerItem(20,112,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_12.addItem(spacer146_2_4,2,0)

        self.fLdapFormRadius = QFrame(self.WStackPage_12,"fLdapFormRadius")
        self.fLdapFormRadius.setEnabled(0)
        self.fLdapFormRadius.setFrameShape(QFrame.NoFrame)
        self.fLdapFormRadius.setFrameShadow(QFrame.Raised)
        fLdapFormRadiusLayout = QGridLayout(self.fLdapFormRadius,1,1,8,6,"fLdapFormRadiusLayout")

        self.iLdapFormRadiusGroup = QLineEdit(self.fLdapFormRadius,"iLdapFormRadiusGroup")
        self.iLdapFormRadiusGroup.setMinimumSize(QSize(270,0))

        fLdapFormRadiusLayout.addWidget(self.iLdapFormRadiusGroup,0,1)

        self.textLabel3_2_2_4 = QLabel(self.fLdapFormRadius,"textLabel3_2_2_4")
        self.textLabel3_2_2_4.setMinimumSize(QSize(120,0))

        fLdapFormRadiusLayout.addWidget(self.textLabel3_2_2_4,0,0)
        spacer28_3_4 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormRadiusLayout.addItem(spacer28_3_4,0,2)

        WStackPageLayout_12.addWidget(self.fLdapFormRadius,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_12,4)

        WStackPageLayout_7.addWidget(self.wsLdapForm,1,0)
        self.wsLdap.addWidget(self.WStackPage_7,2)

        self.WStackPage_13 = QWidget(self.wsLdap,"WStackPage_13")
        WStackPageLayout_13 = QGridLayout(self.WStackPage_13,1,1,8,6,"WStackPageLayout_13")

        layout51_2 = QGridLayout(None,1,1,0,0,"layout51_2")

        self.line22_3 = QFrame(self.WStackPage_13,"line22_3")
        self.line22_3.setFrameShape(QFrame.HLine)
        self.line22_3.setFrameShadow(QFrame.Sunken)
        self.line22_3.setFrameShape(QFrame.HLine)

        layout51_2.addMultiCellWidget(self.line22_3,1,1,0,1)

        self.textLabel1_2_4 = QLabel(self.WStackPage_13,"textLabel1_2_4")
        self.textLabel1_2_4.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4.setMaximumSize(QSize(32767,26))

        layout51_2.addWidget(self.textLabel1_2_4,0,0)
        spacer148_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2.addItem(spacer148_2,0,1)

        WStackPageLayout_13.addMultiCellLayout(layout51_2,0,0,0,1)

        self.frame24 = QFrame(self.WStackPage_13,"frame24")
        self.frame24.setFrameShape(QFrame.NoFrame)
        self.frame24.setFrameShadow(QFrame.Raised)
        frame24Layout = QGridLayout(self.frame24,1,1,8,6,"frame24Layout")

        self.textLabel3_2_3_2 = QLabel(self.frame24,"textLabel3_2_3_2")

        frame24Layout.addWidget(self.textLabel3_2_3_2,2,0)

        self.textLabel5_3_2 = QLabel(self.frame24,"textLabel5_3_2")

        frame24Layout.addWidget(self.textLabel5_3_2,3,0)

        self.textLabel5_4_2 = QLabel(self.frame24,"textLabel5_4_2")

        frame24Layout.addWidget(self.textLabel5_4_2,5,0)

        self.textLabel3_2_4_2 = QLabel(self.frame24,"textLabel3_2_4_2")

        frame24Layout.addWidget(self.textLabel3_2_4_2,4,0)

        self.textLabel2_3 = QLabel(self.frame24,"textLabel2_3")

        frame24Layout.addWidget(self.textLabel2_3,1,0)

        self.textLabel2_3_2 = QLabel(self.frame24,"textLabel2_3_2")

        frame24Layout.addWidget(self.textLabel2_3_2,0,0)
        spacer31 = QSpacerItem(150,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame24Layout.addItem(spacer31,0,2)

        self.cbLdapFormUnit = QComboBox(0,self.frame24,"cbLdapFormUnit")

        frame24Layout.addWidget(self.cbLdapFormUnit,0,1)

        self.iLdapFormUnit = QLineEdit(self.frame24,"iLdapFormUnit")
        self.iLdapFormUnit.setMinimumSize(QSize(270,0))

        frame24Layout.addWidget(self.iLdapFormUnit,1,1)

        self.iLdapFormUnitStreet = QLineEdit(self.frame24,"iLdapFormUnitStreet")
        self.iLdapFormUnitStreet.setMinimumSize(QSize(270,0))

        frame24Layout.addWidget(self.iLdapFormUnitStreet,2,1)

        self.iLdapFormUnitL = QLineEdit(self.frame24,"iLdapFormUnitL")
        self.iLdapFormUnitL.setMinimumSize(QSize(270,0))

        frame24Layout.addWidget(self.iLdapFormUnitL,3,1)

        self.iLdapFormUnitPostalCode = QLineEdit(self.frame24,"iLdapFormUnitPostalCode")
        self.iLdapFormUnitPostalCode.setMinimumSize(QSize(270,0))

        frame24Layout.addWidget(self.iLdapFormUnitPostalCode,4,1)

        self.iLdapFormUnitTelephoneNumber = QLineEdit(self.frame24,"iLdapFormUnitTelephoneNumber")
        self.iLdapFormUnitTelephoneNumber.setMinimumSize(QSize(270,0))

        frame24Layout.addWidget(self.iLdapFormUnitTelephoneNumber,5,1)

        WStackPageLayout_13.addMultiCellWidget(self.frame24,1,1,0,1)
        spacer159 = QSpacerItem(20,150,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_13.addItem(spacer159,2,0)

        self.line27 = QFrame(self.WStackPage_13,"line27")
        self.line27.setFrameShape(QFrame.HLine)
        self.line27.setFrameShadow(QFrame.Sunken)
        self.line27.setFrameShape(QFrame.HLine)

        WStackPageLayout_13.addMultiCellWidget(self.line27,3,3,0,1)

        self.pLdapAddOu = QPushButton(self.WStackPage_13,"pLdapAddOu")
        self.pLdapAddOu.setMaximumSize(QSize(110,26))

        WStackPageLayout_13.addWidget(self.pLdapAddOu,4,1)
        self.wsLdap.addWidget(self.WStackPage_13,3)

        self.WStackPage_14 = QWidget(self.wsLdap,"WStackPage_14")
        WStackPageLayout_14 = QGridLayout(self.WStackPage_14,1,1,8,6,"WStackPageLayout_14")

        layout51_2_2 = QGridLayout(None,1,1,0,0,"layout51_2_2")

        self.line22_3_2 = QFrame(self.WStackPage_14,"line22_3_2")
        self.line22_3_2.setFrameShape(QFrame.HLine)
        self.line22_3_2.setFrameShadow(QFrame.Sunken)
        self.line22_3_2.setFrameShape(QFrame.HLine)

        layout51_2_2.addMultiCellWidget(self.line22_3_2,1,1,0,1)

        self.textLabel1_2_4_2 = QLabel(self.WStackPage_14,"textLabel1_2_4_2")
        self.textLabel1_2_4_2.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4_2.setMaximumSize(QSize(32767,26))

        layout51_2_2.addWidget(self.textLabel1_2_4_2,0,0)
        spacer148_2_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2_2.addItem(spacer148_2_2,0,1)

        WStackPageLayout_14.addMultiCellLayout(layout51_2_2,0,0,0,1)

        self.line29 = QFrame(self.WStackPage_14,"line29")
        self.line29.setFrameShape(QFrame.HLine)
        self.line29.setFrameShadow(QFrame.Sunken)
        self.line29.setFrameShape(QFrame.HLine)

        WStackPageLayout_14.addMultiCellWidget(self.line29,3,3,0,1)

        layout48 = QHBoxLayout(None,0,6,"layout48")
        spacer92 = QSpacerItem(551,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout48.addItem(spacer92)

        self.pLdapPasswd = QPushButton(self.WStackPage_14,"pLdapPasswd")
        self.pLdapPasswd.setMinimumSize(QSize(110,0))
        self.pLdapPasswd.setMaximumSize(QSize(110,26))
        layout48.addWidget(self.pLdapPasswd)

        WStackPageLayout_14.addMultiCellLayout(layout48,4,4,0,1)

        self.frame25 = QFrame(self.WStackPage_14,"frame25")
        self.frame25.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.frame25.sizePolicy().hasHeightForWidth()))
        self.frame25.setFrameShape(QFrame.NoFrame)
        self.frame25.setFrameShadow(QFrame.Raised)
        frame25Layout = QGridLayout(self.frame25,1,1,8,6,"frame25Layout")

        layout46_2_2 = QVBoxLayout(None,0,0,"layout46_2_2")

        self.textLabel1_2_3_3 = QLabel(self.frame25,"textLabel1_2_3_3")
        layout46_2_2.addWidget(self.textLabel1_2_3_3)

        self.line22_2_3 = QFrame(self.frame25,"line22_2_3")
        self.line22_2_3.setFrameShape(QFrame.HLine)
        self.line22_2_3.setFrameShadow(QFrame.Sunken)
        self.line22_2_3.setFrameShape(QFrame.HLine)
        layout46_2_2.addWidget(self.line22_2_3)

        frame25Layout.addMultiCellLayout(layout46_2_2,0,0,0,1)

        self.cbLdapAstPassword = QCheckBox(self.frame25,"cbLdapAstPassword")

        frame25Layout.addWidget(self.cbLdapAstPassword,3,1)

        self.iLdapPasswd = QLineEdit(self.frame25,"iLdapPasswd")
        self.iLdapPasswd.setMinimumSize(QSize(270,0))
        self.iLdapPasswd.setMaximumSize(QSize(270,32767))
        self.iLdapPasswd.setEchoMode(QLineEdit.Password)

        frame25Layout.addWidget(self.iLdapPasswd,7,1)

        self.iLdapPasswd2 = QLineEdit(self.frame25,"iLdapPasswd2")
        self.iLdapPasswd2.setMinimumSize(QSize(270,0))
        self.iLdapPasswd2.setMaximumSize(QSize(270,32767))
        self.iLdapPasswd2.setEchoMode(QLineEdit.Password)

        frame25Layout.addWidget(self.iLdapPasswd2,8,1)

        layout46_2_2_2 = QVBoxLayout(None,0,0,"layout46_2_2_2")

        self.textLabel1_2_3_3_2 = QLabel(self.frame25,"textLabel1_2_3_3_2")
        layout46_2_2_2.addWidget(self.textLabel1_2_3_3_2)

        self.line22_2_3_2 = QFrame(self.frame25,"line22_2_3_2")
        self.line22_2_3_2.setFrameShape(QFrame.HLine)
        self.line22_2_3_2.setFrameShadow(QFrame.Sunken)
        self.line22_2_3_2.setFrameShape(QFrame.HLine)
        layout46_2_2_2.addWidget(self.line22_2_3_2)

        frame25Layout.addMultiCellLayout(layout46_2_2_2,6,6,0,1)

        self.textLabel1_3_2_4 = QLabel(self.frame25,"textLabel1_3_2_4")

        frame25Layout.addWidget(self.textLabel1_3_2_4,8,0)

        self.textLabel1_3_2 = QLabel(self.frame25,"textLabel1_3_2")

        frame25Layout.addWidget(self.textLabel1_3_2,7,0)

        layout46_2_2_2_2 = QVBoxLayout(None,0,0,"layout46_2_2_2_2")

        self.textLabel1_2_3_3_2_2 = QLabel(self.frame25,"textLabel1_2_3_3_2_2")
        layout46_2_2_2_2.addWidget(self.textLabel1_2_3_3_2_2)

        self.line22_2_3_2_2 = QFrame(self.frame25,"line22_2_3_2_2")
        self.line22_2_3_2_2.setFrameShape(QFrame.HLine)
        self.line22_2_3_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_2_3_2_2.setFrameShape(QFrame.HLine)
        layout46_2_2_2_2.addWidget(self.line22_2_3_2_2)

        frame25Layout.addMultiCellLayout(layout46_2_2_2_2,4,4,0,1)

        self.cLdapSambaPasswordPwdMustChange = QCheckBox(self.frame25,"cLdapSambaPasswordPwdMustChange")

        frame25Layout.addWidget(self.cLdapSambaPasswordPwdMustChange,5,1)

        layout74 = QHBoxLayout(None,0,6,"layout74")

        self.cbLdapUserPassword = QCheckBox(self.frame25,"cbLdapUserPassword")
        self.cbLdapUserPassword.setChecked(1)
        layout74.addWidget(self.cbLdapUserPassword)

        self.cbUserPassword = QComboBox(0,self.frame25,"cbUserPassword")
        self.cbUserPassword.setEnabled(1)
        self.cbUserPassword.setMinimumSize(QSize(0,24))
        self.cbUserPassword.setMaximumSize(QSize(100,32767))
        layout74.addWidget(self.cbUserPassword)
        spacer91 = QSpacerItem(51,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        layout74.addItem(spacer91)

        frame25Layout.addLayout(layout74,1,1)

        self.cbLdapSambaPassword = QCheckBox(self.frame25,"cbLdapSambaPassword")

        frame25Layout.addWidget(self.cbLdapSambaPassword,2,1)

        WStackPageLayout_14.addWidget(self.frame25,1,0)
        spacer30_2_2 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_14.addItem(spacer30_2_2,1,1)
        spacer161 = QSpacerItem(21,30,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_14.addItem(spacer161,2,0)
        self.wsLdap.addWidget(self.WStackPage_14,4)

        self.WStackPage_15 = QWidget(self.wsLdap,"WStackPage_15")
        WStackPageLayout_15 = QGridLayout(self.WStackPage_15,1,1,8,6,"WStackPageLayout_15")

        layout51_2_2_2 = QGridLayout(None,1,1,0,0,"layout51_2_2_2")

        self.line22_3_2_2 = QFrame(self.WStackPage_15,"line22_3_2_2")
        self.line22_3_2_2.setFrameShape(QFrame.HLine)
        self.line22_3_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_3_2_2.setFrameShape(QFrame.HLine)

        layout51_2_2_2.addMultiCellWidget(self.line22_3_2_2,1,1,0,1)

        self.textLabel1_2_4_2_2 = QLabel(self.WStackPage_15,"textLabel1_2_4_2_2")
        self.textLabel1_2_4_2_2.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4_2_2.setMaximumSize(QSize(32767,26))

        layout51_2_2_2.addWidget(self.textLabel1_2_4_2_2,0,0)
        spacer148_2_2_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2_2_2.addItem(spacer148_2_2_2,0,1)

        WStackPageLayout_15.addMultiCellLayout(layout51_2_2_2,0,0,0,1)
        spacer161_2 = QSpacerItem(21,15,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_15.addItem(spacer161_2,2,0)

        layout130 = QHBoxLayout(None,0,6,"layout130")
        spacer266 = QSpacerItem(760,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout130.addItem(spacer266)

        self.pLdapSambaPopulate = QPushButton(self.WStackPage_15,"pLdapSambaPopulate")
        self.pLdapSambaPopulate.setMinimumSize(QSize(110,0))
        self.pLdapSambaPopulate.setMaximumSize(QSize(110,26))
        layout130.addWidget(self.pLdapSambaPopulate)

        WStackPageLayout_15.addMultiCellLayout(layout130,4,4,0,1)

        self.line29_2 = QFrame(self.WStackPage_15,"line29_2")
        self.line29_2.setFrameShape(QFrame.HLine)
        self.line29_2.setFrameShadow(QFrame.Sunken)
        self.line29_2.setFrameShape(QFrame.HLine)

        WStackPageLayout_15.addMultiCellWidget(self.line29_2,3,3,0,1)
        spacer86 = QSpacerItem(20,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_15.addItem(spacer86,1,1)

        self.frame25_2 = QFrame(self.WStackPage_15,"frame25_2")
        self.frame25_2.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.frame25_2.sizePolicy().hasHeightForWidth()))
        self.frame25_2.setFrameShape(QFrame.NoFrame)
        self.frame25_2.setFrameShadow(QFrame.Raised)
        frame25_2Layout = QGridLayout(self.frame25_2,1,1,6,4,"frame25_2Layout")

        self.textLabel1_3_2_3_2_2_3_3_2 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_3_3_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_3_3_2,11,0)

        self.textLabel1_3_2_3_2_2_3_3 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_3_3")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_3_3,10,0)

        self.textLabel1_3_2_3_2_2_2 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_2,5,0)

        self.textLabel1_3_2_3_2 = QLabel(self.frame25_2,"textLabel1_3_2_3_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2,3,0)

        self.textLabel1_3_2_3_2_2_2_3 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_2_3")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_2_3,9,0)

        self.textLabel1_3_2_3_2_2_3 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_3")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_3,6,0)

        self.textLabel1_3_2_3_2_2 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2,4,0)

        self.textLabel1_3_2_3_2_2_5 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_5")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_5,8,0)

        self.textLabel1_3_2_3_2_2_4 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_4")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_4,7,0)

        self.textLabel1_3_2_3 = QLabel(self.frame25_2,"textLabel1_3_2_3")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3,2,0)

        self.textLabel1_3_2_2_2 = QLabel(self.frame25_2,"textLabel1_3_2_2_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_2_2,0,0)

        self.textLabel1_3_2_2_2_2 = QLabel(self.frame25_2,"textLabel1_3_2_2_2_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_2_2_2,1,0)

        self.iLdapSMBpassword = QLineEdit(self.frame25_2,"iLdapSMBpassword")
        self.iLdapSMBpassword.setEchoMode(QLineEdit.Password)

        frame25_2Layout.addMultiCellWidget(self.iLdapSMBpassword,2,2,1,2)

        self.iLdapSMBSID = QLineEdit(self.frame25_2,"iLdapSMBSID")

        frame25_2Layout.addMultiCellWidget(self.iLdapSMBSID,1,1,1,2)

        self.iLdapSMBdomain = QLineEdit(self.frame25_2,"iLdapSMBdomain")

        frame25_2Layout.addMultiCellWidget(self.iLdapSMBdomain,0,0,1,2)

        self.iLdapSMBgidNumber = QLineEdit(self.frame25_2,"iLdapSMBgidNumber")
        self.iLdapSMBgidNumber.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBgidNumber.sizePolicy().hasHeightForWidth()))
        self.iLdapSMBgidNumber.setMaximumSize(QSize(90,32767))

        frame25_2Layout.addWidget(self.iLdapSMBgidNumber,4,1)

        self.iLdapSMBminPwdLength = QLineEdit(self.frame25_2,"iLdapSMBminPwdLength")
        self.iLdapSMBminPwdLength.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBminPwdLength.sizePolicy().hasHeightForWidth()))
        self.iLdapSMBminPwdLength.setMaximumSize(QSize(90,32767))

        frame25_2Layout.addWidget(self.iLdapSMBminPwdLength,5,1)

        self.iLdapSMBpwdHistLenght = QLineEdit(self.frame25_2,"iLdapSMBpwdHistLenght")
        self.iLdapSMBpwdHistLenght.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBpwdHistLenght.sizePolicy().hasHeightForWidth()))
        self.iLdapSMBpwdHistLenght.setMaximumSize(QSize(90,32767))

        frame25_2Layout.addWidget(self.iLdapSMBpwdHistLenght,6,1)

        self.iLdapSMBminPwdAge = QLineEdit(self.frame25_2,"iLdapSMBminPwdAge")
        self.iLdapSMBminPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBminPwdAge.sizePolicy().hasHeightForWidth()))
        self.iLdapSMBminPwdAge.setMaximumSize(QSize(90,32767))

        frame25_2Layout.addWidget(self.iLdapSMBminPwdAge,8,1)

        self.iLdapSMBlockout = QLineEdit(self.frame25_2,"iLdapSMBlockout")
        self.iLdapSMBlockout.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBlockout.sizePolicy().hasHeightForWidth()))
        self.iLdapSMBlockout.setMaximumSize(QSize(90,32767))

        frame25_2Layout.addWidget(self.iLdapSMBlockout,9,1)

        self.iLdapSMBlockoutWindow = QLineEdit(self.frame25_2,"iLdapSMBlockoutWindow")
        self.iLdapSMBlockoutWindow.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBlockoutWindow.sizePolicy().hasHeightForWidth()))
        self.iLdapSMBlockoutWindow.setMaximumSize(QSize(90,32767))

        frame25_2Layout.addWidget(self.iLdapSMBlockoutWindow,11,1)

        self.iLdapSMBlockoutDuration = QLineEdit(self.frame25_2,"iLdapSMBlockoutDuration")
        self.iLdapSMBlockoutDuration.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBlockoutDuration.sizePolicy().hasHeightForWidth()))
        self.iLdapSMBlockoutDuration.setMaximumSize(QSize(90,32767))

        frame25_2Layout.addWidget(self.iLdapSMBlockoutDuration,10,1)

        self.cbLdapSMBmaxPwdAge = QComboBox(0,self.frame25_2,"cbLdapSMBmaxPwdAge")
        self.cbLdapSMBmaxPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapSMBmaxPwdAge.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.cbLdapSMBmaxPwdAge,7,2)

        self.cbLdapSMBminPwdAge = QComboBox(0,self.frame25_2,"cbLdapSMBminPwdAge")
        self.cbLdapSMBminPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapSMBminPwdAge.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.cbLdapSMBminPwdAge,8,2)

        self.cbLdapSMBlockoutDuration = QComboBox(0,self.frame25_2,"cbLdapSMBlockoutDuration")
        self.cbLdapSMBlockoutDuration.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapSMBlockoutDuration.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.cbLdapSMBlockoutDuration,10,2)

        self.cbLdapSMBlockoutWindow = QComboBox(0,self.frame25_2,"cbLdapSMBlockoutWindow")
        self.cbLdapSMBlockoutWindow.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapSMBlockoutWindow.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.cbLdapSMBlockoutWindow,11,2)

        self.iLdapSMBmaxPwdAge = QLineEdit(self.frame25_2,"iLdapSMBmaxPwdAge")
        self.iLdapSMBmaxPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBmaxPwdAge.sizePolicy().hasHeightForWidth()))
        self.iLdapSMBmaxPwdAge.setMaximumSize(QSize(90,32767))

        frame25_2Layout.addWidget(self.iLdapSMBmaxPwdAge,7,1)

        self.iLdapSMBuidNumber = QLineEdit(self.frame25_2,"iLdapSMBuidNumber")
        self.iLdapSMBuidNumber.setMaximumSize(QSize(90,32767))

        frame25_2Layout.addWidget(self.iLdapSMBuidNumber,3,1)

        WStackPageLayout_15.addWidget(self.frame25_2,1,0)
        self.wsLdap.addWidget(self.WStackPage_15,5)

        self.WStackPage_16 = QWidget(self.wsLdap,"WStackPage_16")
        WStackPageLayout_16 = QGridLayout(self.WStackPage_16,1,1,8,6,"WStackPageLayout_16")

        layout51_2_2_2_2 = QGridLayout(None,1,1,0,0,"layout51_2_2_2_2")

        self.line22_3_2_2_2 = QFrame(self.WStackPage_16,"line22_3_2_2_2")
        self.line22_3_2_2_2.setFrameShape(QFrame.HLine)
        self.line22_3_2_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_3_2_2_2.setFrameShape(QFrame.HLine)

        layout51_2_2_2_2.addMultiCellWidget(self.line22_3_2_2_2,1,1,0,1)

        self.textLabel1_2_4_2_2_2 = QLabel(self.WStackPage_16,"textLabel1_2_4_2_2_2")
        self.textLabel1_2_4_2_2_2.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4_2_2_2.setMaximumSize(QSize(32767,26))

        layout51_2_2_2_2.addWidget(self.textLabel1_2_4_2_2_2,0,0)
        spacer148_2_2_2_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2_2_2_2.addItem(spacer148_2_2_2_2,0,1)

        WStackPageLayout_16.addMultiCellLayout(layout51_2_2_2_2,0,0,0,1)
        spacer86_4 = QSpacerItem(90,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_16.addItem(spacer86_4,1,1)

        self.line29_2_2 = QFrame(self.WStackPage_16,"line29_2_2")
        self.line29_2_2.setFrameShape(QFrame.HLine)
        self.line29_2_2.setFrameShadow(QFrame.Sunken)
        self.line29_2_2.setFrameShape(QFrame.HLine)

        WStackPageLayout_16.addMultiCellWidget(self.line29_2_2,3,3,0,1)

        layout62 = QHBoxLayout(None,0,6,"layout62")
        spacer266_2 = QSpacerItem(457,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout62.addItem(spacer266_2)

        self.pLdapDhcpPopulate = QPushButton(self.WStackPage_16,"pLdapDhcpPopulate")
        self.pLdapDhcpPopulate.setMinimumSize(QSize(110,0))
        self.pLdapDhcpPopulate.setMaximumSize(QSize(110,26))
        layout62.addWidget(self.pLdapDhcpPopulate)

        WStackPageLayout_16.addMultiCellLayout(layout62,4,4,0,1)
        spacer161_2_2 = QSpacerItem(21,40,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_16.addItem(spacer161_2_2,2,0)

        self.frame25_2_2 = QFrame(self.WStackPage_16,"frame25_2_2")
        self.frame25_2_2.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.frame25_2_2.sizePolicy().hasHeightForWidth()))
        self.frame25_2_2.setFrameShape(QFrame.NoFrame)
        self.frame25_2_2.setFrameShadow(QFrame.Raised)
        frame25_2_2Layout = QGridLayout(self.frame25_2_2,1,1,6,4,"frame25_2_2Layout")

        self.textLabel1_3_2_2_2_2_2 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_2_2")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_2_2,1,0)

        self.textLabel1_3_2_2_2_3 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3")
        self.textLabel1_3_2_2_2_3.setMinimumSize(QSize(200,0))

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3,0,0)

        self.textLabel1_3_2_3_2_2_5_3 = QLabel(self.frame25_2_2,"textLabel1_3_2_3_2_2_5_3")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_3_2_2_5_3,2,0)

        self.textLabel1_3_2_2_2_3_2_2 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3_2_2")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3_2_2,4,0)

        self.line53_2 = QFrame(self.frame25_2_2,"line53_2")
        self.line53_2.setFrameShape(QFrame.HLine)
        self.line53_2.setFrameShadow(QFrame.Sunken)
        self.line53_2.setFrameShape(QFrame.HLine)

        frame25_2_2Layout.addMultiCellWidget(self.line53_2,6,6,0,2)

        self.textLabel1_3_2_2_2_3_2_2_2 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3_2_2_2")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3_2_2_2,5,0)

        self.textLabel1_3_2_2_2_3_2_2_2_2 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3_2_2_2_2")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3_2_2_2_2,7,0)

        self.textLabel1_3_2_2_2_3_2 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3_2")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3_2,3,0)

        self.textLabel1_3_2_2_2_3_2_3 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3_2_3")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3,8,0)

        self.textLabel1_3_2_2_2_3_2_3_2 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3_2_3_2")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3_2,10,0)

        self.textLabel1_3_2_2_2_3_2_3_3_2 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3_2_3_3_2")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_2,11,0)

        self.textLabel1_3_2_2_2_3_2_3_3 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3_2_3_3")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3_3,9,0)

        self.textLabel1_3_2_2_2_3_2_3_3_3 = QLabel(self.frame25_2_2,"textLabel1_3_2_2_2_3_2_3_3_3")

        frame25_2_2Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_3,12,0)

        self.iLdapDhcpName = QLineEdit(self.frame25_2_2,"iLdapDhcpName")

        frame25_2_2Layout.addMultiCellWidget(self.iLdapDhcpName,0,0,1,2)

        self.iLdapDhcpDefaultLeaseTime = QLineEdit(self.frame25_2_2,"iLdapDhcpDefaultLeaseTime")
        self.iLdapDhcpDefaultLeaseTime.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapDhcpDefaultLeaseTime.sizePolicy().hasHeightForWidth()))
        self.iLdapDhcpDefaultLeaseTime.setMaximumSize(QSize(90,32767))

        frame25_2_2Layout.addWidget(self.iLdapDhcpDefaultLeaseTime,1,1)

        self.cbLdapDhcpDefaultLeaseTime = QComboBox(0,self.frame25_2_2,"cbLdapDhcpDefaultLeaseTime")
        self.cbLdapDhcpDefaultLeaseTime.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapDhcpDefaultLeaseTime.sizePolicy().hasHeightForWidth()))

        frame25_2_2Layout.addWidget(self.cbLdapDhcpDefaultLeaseTime,1,2)

        self.iLdapDhcpMaxLeaseTime = QLineEdit(self.frame25_2_2,"iLdapDhcpMaxLeaseTime")
        self.iLdapDhcpMaxLeaseTime.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapDhcpMaxLeaseTime.sizePolicy().hasHeightForWidth()))
        self.iLdapDhcpMaxLeaseTime.setMaximumSize(QSize(90,32767))

        frame25_2_2Layout.addWidget(self.iLdapDhcpMaxLeaseTime,2,1)

        self.cbLdapDhcpMaxLeaseTime = QComboBox(0,self.frame25_2_2,"cbLdapDhcpMaxLeaseTime")
        self.cbLdapDhcpMaxLeaseTime.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapDhcpMaxLeaseTime.sizePolicy().hasHeightForWidth()))

        frame25_2_2Layout.addWidget(self.cbLdapDhcpMaxLeaseTime,2,2)

        self.iLdapDhcpDomainName = QLineEdit(self.frame25_2_2,"iLdapDhcpDomainName")

        frame25_2_2Layout.addMultiCellWidget(self.iLdapDhcpDomainName,3,3,1,2)

        self.iLdapDhcpNetbiosServers = QLineEdit(self.frame25_2_2,"iLdapDhcpNetbiosServers")

        frame25_2_2Layout.addMultiCellWidget(self.iLdapDhcpNetbiosServers,4,4,1,2)

        self.iLdapDhcpDNSservers = QLineEdit(self.frame25_2_2,"iLdapDhcpDNSservers")

        frame25_2_2Layout.addMultiCellWidget(self.iLdapDhcpDNSservers,5,5,1,2)

        self.cbLdapDhcpInterface = QComboBox(0,self.frame25_2_2,"cbLdapDhcpInterface")
        self.cbLdapDhcpInterface.setEditable(1)

        frame25_2_2Layout.addMultiCellWidget(self.cbLdapDhcpInterface,7,7,1,2)

        self.iLdapDhcpNetwork = QLineEdit(self.frame25_2_2,"iLdapDhcpNetwork")

        frame25_2_2Layout.addMultiCellWidget(self.iLdapDhcpNetwork,8,8,1,2)

        self.iLdapDhcpBroadcast = QLineEdit(self.frame25_2_2,"iLdapDhcpBroadcast")

        frame25_2_2Layout.addMultiCellWidget(self.iLdapDhcpBroadcast,9,9,1,2)

        self.iLdapDhcpRange = QLineEdit(self.frame25_2_2,"iLdapDhcpRange")
        self.iLdapDhcpRange.setCursorPosition(0)

        frame25_2_2Layout.addMultiCellWidget(self.iLdapDhcpRange,10,10,1,2)

        self.cbLdapDhcpNetmask = QComboBox(0,self.frame25_2_2,"cbLdapDhcpNetmask")

        frame25_2_2Layout.addMultiCellWidget(self.cbLdapDhcpNetmask,11,11,1,2)

        self.iLdapDhcpGateway = QLineEdit(self.frame25_2_2,"iLdapDhcpGateway")

        frame25_2_2Layout.addMultiCellWidget(self.iLdapDhcpGateway,12,12,1,2)

        WStackPageLayout_16.addWidget(self.frame25_2_2,1,0)
        self.wsLdap.addWidget(self.WStackPage_16,6)

        self.WStackPage_17 = QWidget(self.wsLdap,"WStackPage_17")
        WStackPageLayout_17 = QGridLayout(self.WStackPage_17,1,1,8,6,"WStackPageLayout_17")

        self.line27_2_3 = QFrame(self.WStackPage_17,"line27_2_3")
        self.line27_2_3.setFrameShape(QFrame.HLine)
        self.line27_2_3.setFrameShadow(QFrame.Sunken)
        self.line27_2_3.setFrameShape(QFrame.HLine)

        WStackPageLayout_17.addMultiCellWidget(self.line27_2_3,3,4,0,1)

        self.pLdapAddDhcp_3 = QPushButton(self.WStackPage_17,"pLdapAddDhcp_3")
        self.pLdapAddDhcp_3.setMaximumSize(QSize(110,26))

        WStackPageLayout_17.addMultiCellWidget(self.pLdapAddDhcp_3,4,5,1,1)
        spacer142 = QSpacerItem(411,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_17.addItem(spacer142,5,0)
        spacer159_2_3 = QSpacerItem(20,30,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_17.addItem(spacer159_2_3,2,0)

        layout92 = QGridLayout(None,1,1,0,0,"layout92")
        spacer148_2_3_3 = QSpacerItem(313,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout92.addItem(spacer148_2_3_3,0,1)

        self.line22_3_3_3 = QFrame(self.WStackPage_17,"line22_3_3_3")
        self.line22_3_3_3.setFrameShape(QFrame.HLine)
        self.line22_3_3_3.setFrameShadow(QFrame.Sunken)
        self.line22_3_3_3.setFrameShape(QFrame.HLine)

        layout92.addMultiCellWidget(self.line22_3_3_3,1,1,0,1)

        self.textLabel1_2_4_3_3 = QLabel(self.WStackPage_17,"textLabel1_2_4_3_3")
        self.textLabel1_2_4_3_3.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4_3_3.setMaximumSize(QSize(32767,26))

        layout92.addWidget(self.textLabel1_2_4_3_3,0,0)

        WStackPageLayout_17.addMultiCellLayout(layout92,0,0,0,1)

        self.frame24_2_3 = QFrame(self.WStackPage_17,"frame24_2_3")
        self.frame24_2_3.setFrameShape(QFrame.NoFrame)
        self.frame24_2_3.setFrameShadow(QFrame.Raised)
        frame24_2_3Layout = QGridLayout(self.frame24_2_3,1,1,8,6,"frame24_2_3Layout")

        self.textLabel2_3_2_2_3 = QLabel(self.frame24_2_3,"textLabel2_3_2_2_3")
        self.textLabel2_3_2_2_3.setMinimumSize(QSize(150,0))
        self.textLabel2_3_2_2_3.setMaximumSize(QSize(150,32767))

        frame24_2_3Layout.addWidget(self.textLabel2_3_2_2_3,0,0)

        self.tlLdapFormDhcpGroupName_3 = QLabel(self.frame24_2_3,"tlLdapFormDhcpGroupName_3")
        self.tlLdapFormDhcpGroupName_3.setMinimumSize(QSize(150,0))

        frame24_2_3Layout.addWidget(self.tlLdapFormDhcpGroupName_3,1,0)

        self.wsLdapGroup = QWidgetStack(self.frame24_2_3,"wsLdapGroup")
        self.wsLdapGroup.setMargin(-8)

        self.WStackPage_18 = QWidget(self.wsLdapGroup,"WStackPage_18")
        WStackPageLayout_18 = QGridLayout(self.WStackPage_18,1,1,8,6,"WStackPageLayout_18")

        self.textLabel1_3_2_2_2_3_2_3_3_2_2_3 = QLabel(self.WStackPage_18,"textLabel1_3_2_2_2_3_2_3_3_2_2_3")

        WStackPageLayout_18.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_2_2_3,1,0)

        self.cbLdapFormDhcpInterface_3 = QComboBox(0,self.WStackPage_18,"cbLdapFormDhcpInterface_3")

        WStackPageLayout_18.addWidget(self.cbLdapFormDhcpInterface_3,0,1)

        self.cbLdapFormDhcpNetmask_3 = QComboBox(0,self.WStackPage_18,"cbLdapFormDhcpNetmask_3")

        WStackPageLayout_18.addWidget(self.cbLdapFormDhcpNetmask_3,1,1)

        self.tlLdapFormDhcpInterface_3 = QLabel(self.WStackPage_18,"tlLdapFormDhcpInterface_3")
        self.tlLdapFormDhcpInterface_3.setMinimumSize(QSize(150,0))
        self.tlLdapFormDhcpInterface_3.setMaximumSize(QSize(150,32767))

        WStackPageLayout_18.addWidget(self.tlLdapFormDhcpInterface_3,0,0)

        self.textLabel1_3_2_2_2_3_2_3_3_3_2_3 = QLabel(self.WStackPage_18,"textLabel1_3_2_2_2_3_2_3_3_3_2_3")

        WStackPageLayout_18.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_3_2_3,2,0)

        self.iLdapFormDhcpGateway_3 = QLineEdit(self.WStackPage_18,"iLdapFormDhcpGateway_3")

        WStackPageLayout_18.addWidget(self.iLdapFormDhcpGateway_3,2,1)
        self.wsLdapGroup.addWidget(self.WStackPage_18,0)

        self.WStackPage_19 = QWidget(self.wsLdapGroup,"WStackPage_19")
        WStackPageLayout_19 = QGridLayout(self.WStackPage_19,1,1,8,6,"WStackPageLayout_19")

        self.textLabel2_3_3_3 = QLabel(self.WStackPage_19,"textLabel2_3_3_3")
        self.textLabel2_3_3_3.setMinimumSize(QSize(150,0))

        WStackPageLayout_19.addWidget(self.textLabel2_3_3_3,0,0)

        self.iLdapFormDhcpName_3 = QLineEdit(self.WStackPage_19,"iLdapFormDhcpName_3")

        WStackPageLayout_19.addWidget(self.iLdapFormDhcpName_3,0,1)
        spacer144 = QSpacerItem(21,21,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_19.addItem(spacer144,1,1)

        self.pushButton63 = QPushButton(self.WStackPage_19,"pushButton63")

        WStackPageLayout_19.addWidget(self.pushButton63,0,2)
        self.wsLdapGroup.addWidget(self.WStackPage_19,1)

        frame24_2_3Layout.addMultiCellWidget(self.wsLdapGroup,2,2,0,1)

        self.iLdapFormGroupName = QLineEdit(self.frame24_2_3,"iLdapFormGroupName")

        frame24_2_3Layout.addWidget(self.iLdapFormGroupName,1,1)
        spacer31_3_3 = QSpacerItem(80,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame24_2_3Layout.addItem(spacer31_3_3,0,2)

        self.cbLdapFormGroupType = QComboBox(0,self.frame24_2_3,"cbLdapFormGroupType")

        frame24_2_3Layout.addWidget(self.cbLdapFormGroupType,0,1)

        WStackPageLayout_17.addMultiCellWidget(self.frame24_2_3,1,1,0,1)
        self.wsLdap.addWidget(self.WStackPage_17,7)
        layout521.addWidget(self.wsLdap)

        WStackPageLayout_2.addWidget(self.splitter11,0,0)
        self.wsKorreio.addWidget(self.WStackPage_2,1)

        self.WStackPage_20 = QWidget(self.wsKorreio,"WStackPage_20")
        WStackPageLayout_20 = QGridLayout(self.WStackPage_20,1,1,6,6,"WStackPageLayout_20")

        self.spImap = QSplitter(self.WStackPage_20,"spImap")
        self.spImap.setOrientation(QSplitter.Horizontal)

        self.frame31 = QFrame(self.spImap,"frame31")
        self.frame31.setFrameShape(QFrame.NoFrame)
        self.frame31.setFrameShadow(QFrame.Raised)
        frame31Layout = QGridLayout(self.frame31,1,1,0,6,"frame31Layout")

        self.lvImap = QListView(self.frame31,"lvImap")
        self.lvImap.addColumn(self.__tr("IMAP Mailbox"))
        self.lvImap.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,2,0,self.lvImap.sizePolicy().hasHeightForWidth()))
        self.lvImap.setShowSortIndicator(1)
        self.lvImap.setRootIsDecorated(1)
        self.lvImap.setResizeMode(QListView.AllColumns)

        frame31Layout.addWidget(self.lvImap,1,0)

        layout58 = QHBoxLayout(None,0,6,"layout58")

        self.iImapMailbox = QLineEdit(self.frame31,"iImapMailbox")
        self.iImapMailbox.setEnabled(1)
        self.iImapMailbox.setMinimumSize(QSize(184,0))
        layout58.addWidget(self.iImapMailbox)

        self.pCyrAdd = QPushButton(self.frame31,"pCyrAdd")
        self.pCyrAdd.setMinimumSize(QSize(30,0))
        self.pCyrAdd.setMaximumSize(QSize(30,32767))
        layout58.addWidget(self.pCyrAdd)

        self.pCyrDelete = QPushButton(self.frame31,"pCyrDelete")
        self.pCyrDelete.setEnabled(1)
        self.pCyrDelete.setMinimumSize(QSize(30,0))
        self.pCyrDelete.setMaximumSize(QSize(30,32767))
        layout58.addWidget(self.pCyrDelete)

        self.pCyrReconstruct = QPushButton(self.frame31,"pCyrReconstruct")
        self.pCyrReconstruct.setMinimumSize(QSize(30,0))
        self.pCyrReconstruct.setMaximumSize(QSize(30,32767))
        layout58.addWidget(self.pCyrReconstruct)

        frame31Layout.addLayout(layout58,2,0)

        layout41_2_2 = QGridLayout(None,1,1,0,0,"layout41_2_2")

        self.textLabel4_2_2_2_2 = QLabel(self.frame31,"textLabel4_2_2_2_2")

        layout41_2_2.addWidget(self.textLabel4_2_2_2_2,0,0)
        spacer138_2_2 = QSpacerItem(210,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout41_2_2.addItem(spacer138_2_2,0,1)

        self.line3_2_2_2_2 = QFrame(self.frame31,"line3_2_2_2_2")
        self.line3_2_2_2_2.setFrameShape(QFrame.HLine)
        self.line3_2_2_2_2.setFrameShadow(QFrame.Sunken)
        self.line3_2_2_2_2.setFrameShape(QFrame.HLine)

        layout41_2_2.addMultiCellWidget(self.line3_2_2_2_2,1,1,0,1)

        frame31Layout.addLayout(layout41_2_2,0,0)

        self.frame62 = QFrame(self.spImap,"frame62")
        self.frame62.setMinimumSize(QSize(0,460))
        self.frame62.setFrameShape(QFrame.NoFrame)
        self.frame62.setFrameShadow(QFrame.Raised)
        frame62Layout = QGridLayout(self.frame62,1,1,0,6,"frame62Layout")

        self.frame28 = QFrame(self.frame62,"frame28")
        self.frame28.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed,0,0,self.frame28.sizePolicy().hasHeightForWidth()))
        self.frame28.setFrameShape(QFrame.NoFrame)
        self.frame28.setFrameShadow(QFrame.Raised)
        frame28Layout = QGridLayout(self.frame28,1,1,0,6,"frame28Layout")

        layout41_2 = QGridLayout(None,1,1,0,0,"layout41_2")

        self.textLabel4_2_2_2 = QLabel(self.frame28,"textLabel4_2_2_2")

        layout41_2.addWidget(self.textLabel4_2_2_2,0,0)
        spacer138_2 = QSpacerItem(210,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout41_2.addItem(spacer138_2,0,1)

        self.line3_2_2_2 = QFrame(self.frame28,"line3_2_2_2")
        self.line3_2_2_2.setFrameShape(QFrame.HLine)
        self.line3_2_2_2.setFrameShadow(QFrame.Sunken)
        self.line3_2_2_2.setFrameShape(QFrame.HLine)

        layout41_2.addMultiCellWidget(self.line3_2_2_2,1,1,0,1)

        frame28Layout.addLayout(layout41_2,0,0)

        layout63 = QHBoxLayout(None,0,6,"layout63")

        self.iImapAclUser = QLineEdit(self.frame28,"iImapAclUser")
        self.iImapAclUser.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed,1,0,self.iImapAclUser.sizePolicy().hasHeightForWidth()))
        layout63.addWidget(self.iImapAclUser)

        self.cbACL = QComboBox(0,self.frame28,"cbACL")
        self.cbACL.setMinimumSize(QSize(145,0))
        self.cbACL.setMaximumSize(QSize(145,32767))
        self.cbACL.setEditable(1)
        layout63.addWidget(self.cbACL)

        self.pImapAclAdd = QPushButton(self.frame28,"pImapAclAdd")
        self.pImapAclAdd.setMinimumSize(QSize(30,0))
        self.pImapAclAdd.setMaximumSize(QSize(30,32767))
        layout63.addWidget(self.pImapAclAdd)

        self.pImapAclDel = QPushButton(self.frame28,"pImapAclDel")
        self.pImapAclDel.setMinimumSize(QSize(30,0))
        self.pImapAclDel.setMaximumSize(QSize(30,32767))
        layout63.addWidget(self.pImapAclDel)

        frame28Layout.addLayout(layout63,2,0)

        self.lvImapAcl = QListView(self.frame28,"lvImapAcl")
        self.lvImapAcl.addColumn(self.__tr("User"))
        self.lvImapAcl.addColumn(self.__tr("Permissions"))
        self.lvImapAcl.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,0,0,self.lvImapAcl.sizePolicy().hasHeightForWidth()))
        self.lvImapAcl.setMaximumSize(QSize(32767,180))
        self.lvImapAcl.setSelectionMode(QListView.Extended)
        self.lvImapAcl.setAllColumnsShowFocus(1)
        self.lvImapAcl.setShowSortIndicator(1)
        self.lvImapAcl.setResizeMode(QListView.LastColumn)

        frame28Layout.addWidget(self.lvImapAcl,1,0)

        frame62Layout.addWidget(self.frame28,0,0)

        self.frame28_2 = QFrame(self.frame62,"frame28_2")
        self.frame28_2.setFrameShape(QFrame.NoFrame)
        self.frame28_2.setFrameShadow(QFrame.Raised)
        frame28_2Layout = QGridLayout(self.frame28_2,1,1,0,6,"frame28_2Layout")

        layout41 = QGridLayout(None,1,1,0,0,"layout41")

        self.textLabel4_2_2 = QLabel(self.frame28_2,"textLabel4_2_2")

        layout41.addWidget(self.textLabel4_2_2,0,0)
        spacer138 = QSpacerItem(210,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout41.addItem(spacer138,0,1)

        self.line3_2_2 = QFrame(self.frame28_2,"line3_2_2")
        self.line3_2_2.setFrameShape(QFrame.HLine)
        self.line3_2_2.setFrameShadow(QFrame.Sunken)
        self.line3_2_2.setFrameShape(QFrame.HLine)

        layout41.addMultiCellWidget(self.line3_2_2,1,1,0,1)

        frame28_2Layout.addMultiCellLayout(layout41,0,0,0,3)

        self.textLabel2_5_2 = QLabel(self.frame28_2,"textLabel2_5_2")
        self.textLabel2_5_2.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.textLabel2_5_2.sizePolicy().hasHeightForWidth()))
        self.textLabel2_5_2.setMinimumSize(QSize(90,0))

        frame28_2Layout.addWidget(self.textLabel2_5_2,1,0)

        self.cbImapAnnotation = QComboBox(0,self.frame28_2,"cbImapAnnotation")
        self.cbImapAnnotation.setEditable(1)

        frame28_2Layout.addMultiCellWidget(self.cbImapAnnotation,1,1,1,2)

        self.pImapAnnotation = QPushButton(self.frame28_2,"pImapAnnotation")
        self.pImapAnnotation.setMaximumSize(QSize(40,32767))

        frame28_2Layout.addWidget(self.pImapAnnotation,2,2)

        self.textLabel2_5 = QLabel(self.frame28_2,"textLabel2_5")
        self.textLabel2_5.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.textLabel2_5.sizePolicy().hasHeightForWidth()))

        frame28_2Layout.addWidget(self.textLabel2_5,2,0)

        self.iAnnotationValue = QLineEdit(self.frame28_2,"iAnnotationValue")
        self.iAnnotationValue.setMinimumSize(QSize(140,0))

        frame28_2Layout.addWidget(self.iAnnotationValue,2,1)
        spacer36 = QSpacerItem(30,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame28_2Layout.addMultiCell(spacer36,1,2,3,3)

        frame62Layout.addWidget(self.frame28_2,1,0)
        spacer199 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame62Layout.addItem(spacer199,3,0)

        self.frame27 = QFrame(self.frame62,"frame27")
        self.frame27.setFrameShape(QFrame.NoFrame)
        self.frame27.setFrameShadow(QFrame.Raised)
        frame27Layout = QGridLayout(self.frame27,1,1,0,6,"frame27Layout")

        layout42 = QGridLayout(None,1,1,0,0,"layout42")

        self.line3_2 = QFrame(self.frame27,"line3_2")
        self.line3_2.setFrameShape(QFrame.HLine)
        self.line3_2.setFrameShadow(QFrame.Sunken)
        self.line3_2.setFrameShape(QFrame.HLine)

        layout42.addMultiCellWidget(self.line3_2,1,1,0,1)
        spacer33_2_2_2 = QSpacerItem(391,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout42.addItem(spacer33_2_2_2,0,1)

        self.textLabel4_2 = QLabel(self.frame27,"textLabel4_2")

        layout42.addWidget(self.textLabel4_2,0,0)

        frame27Layout.addMultiCellLayout(layout42,0,0,0,3)

        self.textLabel1 = QLabel(self.frame27,"textLabel1")
        self.textLabel1.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.textLabel1.sizePolicy().hasHeightForWidth()))
        self.textLabel1.setMinimumSize(QSize(90,0))

        frame27Layout.addWidget(self.textLabel1,1,0)

        self.textLabel2_2 = QLabel(self.frame27,"textLabel2_2")
        self.textLabel2_2.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.textLabel2_2.sizePolicy().hasHeightForWidth()))

        frame27Layout.addWidget(self.textLabel2_2,2,0)

        self.iQuotaUsed = QLineEdit(self.frame27,"iQuotaUsed")
        self.iQuotaUsed.setMinimumSize(QSize(90,25))
        self.iQuotaUsed.setMaximumSize(QSize(90,25))
        self.iQuotaUsed.setAlignment(QLineEdit.AlignRight)
        self.iQuotaUsed.setReadOnly(1)

        frame27Layout.addWidget(self.iQuotaUsed,1,1)

        self.iQuota = QLineEdit(self.frame27,"iQuota")
        self.iQuota.setMinimumSize(QSize(90,0))
        self.iQuota.setMaximumSize(QSize(90,32767))
        self.iQuota.setAlignment(QLineEdit.AlignRight)

        frame27Layout.addWidget(self.iQuota,2,1)

        self.textLabel2 = QLabel(self.frame27,"textLabel2")
        self.textLabel2.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.textLabel2.sizePolicy().hasHeightForWidth()))

        frame27Layout.addWidget(self.textLabel2,1,2)

        self.textLabel2_4 = QLabel(self.frame27,"textLabel2_4")
        self.textLabel2_4.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.textLabel2_4.sizePolicy().hasHeightForWidth()))

        frame27Layout.addWidget(self.textLabel2_4,2,2)

        self.pImapQuota = QPushButton(self.frame27,"pImapQuota")
        self.pImapQuota.setMaximumSize(QSize(40,32767))

        frame27Layout.addWidget(self.pImapQuota,2,3)
        spacer33_2_2 = QSpacerItem(90,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame27Layout.addItem(spacer33_2_2,1,3)

        frame62Layout.addWidget(self.frame27,2,0)

        WStackPageLayout_20.addWidget(self.spImap,1,0)

        layout145 = QHBoxLayout(None,0,6,"layout145")

        self.tCyrUser = QLabel(self.WStackPage_20,"tCyrUser")
        self.tCyrUser.setMinimumSize(QSize(65,0))
        layout145.addWidget(self.tCyrUser)

        self.iImapSearch = QLineEdit(self.WStackPage_20,"iImapSearch")
        self.iImapSearch.setMinimumSize(QSize(220,0))
        self.iImapSearch.setMaximumSize(QSize(220,32767))
        layout145.addWidget(self.iImapSearch)

        self.pImapSearch = QPushButton(self.WStackPage_20,"pImapSearch")
        layout145.addWidget(self.pImapSearch)

        self.cImapExpand = QCheckBox(self.WStackPage_20,"cImapExpand")
        layout145.addWidget(self.cImapExpand)
        spacer1 = QSpacerItem(190,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout145.addItem(spacer1)

        self.buttonGroup3_2_2 = QButtonGroup(self.WStackPage_20,"buttonGroup3_2_2")
        self.buttonGroup3_2_2.setFrameShape(QButtonGroup.NoFrame)
        self.buttonGroup3_2_2.setColumnLayout(0,Qt.Vertical)
        self.buttonGroup3_2_2.layout().setSpacing(6)
        self.buttonGroup3_2_2.layout().setMargin(0)
        buttonGroup3_2_2Layout = QGridLayout(self.buttonGroup3_2_2.layout())
        buttonGroup3_2_2Layout.setAlignment(Qt.AlignTop)

        self.rbImapMailboxMode = QRadioButton(self.buttonGroup3_2_2,"rbImapMailboxMode")
        self.rbImapMailboxMode.setChecked(1)

        buttonGroup3_2_2Layout.addWidget(self.rbImapMailboxMode,0,0)

        self.rbImapMailboxMode2 = QRadioButton(self.buttonGroup3_2_2,"rbImapMailboxMode2")

        buttonGroup3_2_2Layout.addWidget(self.rbImapMailboxMode2,0,1)
        layout145.addWidget(self.buttonGroup3_2_2)

        WStackPageLayout_20.addLayout(layout145,0,0)
        self.wsKorreio.addWidget(self.WStackPage_20,2)

        self.WStackPage_21 = QWidget(self.wsKorreio,"WStackPage_21")
        WStackPageLayout_21 = QGridLayout(self.WStackPage_21,1,1,6,6,"WStackPageLayout_21")

        layout57 = QHBoxLayout(None,0,6,"layout57")

        self.tCyrUser_2 = QLabel(self.WStackPage_21,"tCyrUser_2")
        self.tCyrUser_2.setMinimumSize(QSize(65,0))
        layout57.addWidget(self.tCyrUser_2)

        self.iImapPartitionSearch = QLineEdit(self.WStackPage_21,"iImapPartitionSearch")
        self.iImapPartitionSearch.setMinimumSize(QSize(220,0))
        self.iImapPartitionSearch.setMaximumSize(QSize(220,32767))
        layout57.addWidget(self.iImapPartitionSearch)

        self.pImapPartitionSearch = QPushButton(self.WStackPage_21,"pImapPartitionSearch")
        layout57.addWidget(self.pImapPartitionSearch)

        self.cImapSize = QCheckBox(self.WStackPage_21,"cImapSize")
        self.cImapSize.setChecked(1)
        layout57.addWidget(self.cImapSize)
        spacer1_2 = QSpacerItem(90,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout57.addItem(spacer1_2)

        self.buttonGroup3_2 = QButtonGroup(self.WStackPage_21,"buttonGroup3_2")
        self.buttonGroup3_2.setFrameShape(QButtonGroup.NoFrame)
        self.buttonGroup3_2.setColumnLayout(0,Qt.Vertical)
        self.buttonGroup3_2.layout().setSpacing(6)
        self.buttonGroup3_2.layout().setMargin(0)
        buttonGroup3_2Layout = QGridLayout(self.buttonGroup3_2.layout())
        buttonGroup3_2Layout.setAlignment(Qt.AlignTop)

        self.rbImapPartMailboxMode = QRadioButton(self.buttonGroup3_2,"rbImapPartMailboxMode")
        self.rbImapPartMailboxMode.setChecked(1)

        buttonGroup3_2Layout.addWidget(self.rbImapPartMailboxMode,0,0)

        self.rbImapPartMailboxMode2 = QRadioButton(self.buttonGroup3_2,"rbImapPartMailboxMode2")

        buttonGroup3_2Layout.addWidget(self.rbImapPartMailboxMode2,0,1)
        layout57.addWidget(self.buttonGroup3_2)

        WStackPageLayout_21.addLayout(layout57,0,0)

        layout31 = QHBoxLayout(None,0,6,"layout31")

        self.textLabel1_2_2 = QLabel(self.WStackPage_21,"textLabel1_2_2")
        self.textLabel1_2_2.setMinimumSize(QSize(65,0))
        layout31.addWidget(self.textLabel1_2_2)

        self.cbImapPartition = QComboBox(0,self.WStackPage_21,"cbImapPartition")
        self.cbImapPartition.setMinimumSize(QSize(220,0))
        self.cbImapPartition.setMaximumSize(QSize(220,32767))
        self.cbImapPartition.setEditable(1)
        self.cbImapPartition.setAutoCompletion(1)
        self.cbImapPartition.setDuplicatesEnabled(0)
        layout31.addWidget(self.cbImapPartition)

        self.pImapPartitionMove = QPushButton(self.WStackPage_21,"pImapPartitionMove")
        self.pImapPartitionMove.setMinimumSize(QSize(100,0))
        self.pImapPartitionMove.setMaximumSize(QSize(100,32767))
        layout31.addWidget(self.pImapPartitionMove)
        spacer38_2 = QSpacerItem(390,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout31.addItem(spacer38_2)

        layout6 = QHBoxLayout(None,0,6,"layout6")

        self.tlImapSize = QLabel(self.WStackPage_21,"tlImapSize")
        self.tlImapSize.setMinimumSize(QSize(280,0))
        self.tlImapSize.setAlignment(QLabel.AlignVCenter | QLabel.AlignRight)
        layout6.addWidget(self.tlImapSize)

        self.cImapSizeUpdate = QCheckBox(self.WStackPage_21,"cImapSizeUpdate")
        self.cImapSizeUpdate.setMinimumSize(QSize(20,0))
        self.cImapSizeUpdate.setMaximumSize(QSize(20,32767))
        self.cImapSizeUpdate.setChecked(1)
        layout6.addWidget(self.cImapSizeUpdate)
        layout31.addLayout(layout6)

        WStackPageLayout_21.addLayout(layout31,2,0)

        self.lvImapPartition = QListView(self.WStackPage_21,"lvImapPartition")
        self.lvImapPartition.addColumn(self.__tr("IMAP Mailbox"))
        self.lvImapPartition.addColumn(self.__tr("Partition"))
        self.lvImapPartition.addColumn(self.__tr("Used"))
        self.lvImapPartition.addColumn(self.__tr("Limit"))
        self.lvImapPartition.addColumn(self.__tr("%"))
        self.lvImapPartition.setSelectionMode(QListView.Extended)
        self.lvImapPartition.setAllColumnsShowFocus(1)
        self.lvImapPartition.setShowSortIndicator(1)
        self.lvImapPartition.setRootIsDecorated(1)
        self.lvImapPartition.setResizeMode(QListView.AllColumns)

        WStackPageLayout_21.addWidget(self.lvImapPartition,1,0)
        self.wsKorreio.addWidget(self.WStackPage_21,3)

        self.WStackPage_22 = QWidget(self.wsKorreio,"WStackPage_22")
        WStackPageLayout_22 = QGridLayout(self.WStackPage_22,1,1,6,6,"WStackPageLayout_22")

        layout73 = QHBoxLayout(None,0,6,"layout73")

        self.tCyrUser_2_2 = QLabel(self.WStackPage_22,"tCyrUser_2_2")
        self.tCyrUser_2_2.setMinimumSize(QSize(65,0))
        self.tCyrUser_2_2.setMaximumSize(QSize(60,32767))
        layout73.addWidget(self.tCyrUser_2_2)

        self.iSieveSearch = QLineEdit(self.WStackPage_22,"iSieveSearch")
        self.iSieveSearch.setMinimumSize(QSize(220,0))
        self.iSieveSearch.setMaximumSize(QSize(220,32767))
        layout73.addWidget(self.iSieveSearch)

        self.pSieveSearch = QPushButton(self.WStackPage_22,"pSieveSearch")
        layout73.addWidget(self.pSieveSearch)

        self.cSieveScript = QCheckBox(self.WStackPage_22,"cSieveScript")
        self.cSieveScript.setChecked(1)
        layout73.addWidget(self.cSieveScript)
        spacer61 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout73.addItem(spacer61)

        WStackPageLayout_22.addLayout(layout73,0,0)

        self.splitter5 = QSplitter(self.WStackPage_22,"splitter5")
        self.splitter5.setOrientation(QSplitter.Vertical)

        self.lvSieve = QListView(self.splitter5,"lvSieve")
        self.lvSieve.addColumn(self.__tr("IMAP Users"))
        self.lvSieve.addColumn(self.__tr("Filed"))
        self.lvSieve.addColumn(self.__tr("Active script"))
        self.lvSieve.setSelectionMode(QListView.Extended)
        self.lvSieve.setAllColumnsShowFocus(1)
        self.lvSieve.setShowSortIndicator(1)
        self.lvSieve.setRootIsDecorated(1)
        self.lvSieve.setResizeMode(QListView.LastColumn)

        LayoutWidget_3 = QWidget(self.splitter5,"layout13")
        layout13 = QVBoxLayout(LayoutWidget_3,0,6,"layout13")

        layout12 = QHBoxLayout(None,0,6,"layout12")

        self.textLabel1_2_2_2 = QLabel(LayoutWidget_3,"textLabel1_2_2_2")
        self.textLabel1_2_2_2.setMinimumSize(QSize(65,0))
        layout12.addWidget(self.textLabel1_2_2_2)

        self.cbSieveScript = QComboBox(0,LayoutWidget_3,"cbSieveScript")
        self.cbSieveScript.setMinimumSize(QSize(220,0))
        self.cbSieveScript.setEditable(1)
        self.cbSieveScript.setAutoCompletion(1)
        self.cbSieveScript.setDuplicatesEnabled(0)
        layout12.addWidget(self.cbSieveScript)

        self.pSieveScriptActive = QPushButton(LayoutWidget_3,"pSieveScriptActive")
        self.pSieveScriptActive.setMaximumSize(QSize(30,32767))
        layout12.addWidget(self.pSieveScriptActive)

        self.pSieveScriptDisable = QPushButton(LayoutWidget_3,"pSieveScriptDisable")
        self.pSieveScriptDisable.setMaximumSize(QSize(30,32767))
        layout12.addWidget(self.pSieveScriptDisable)

        self.pSieveScriptRemove = QPushButton(LayoutWidget_3,"pSieveScriptRemove")
        self.pSieveScriptRemove.setMaximumSize(QSize(30,32767))
        layout12.addWidget(self.pSieveScriptRemove)
        spacer61_2_2 = QSpacerItem(100,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout12.addItem(spacer61_2_2)
        layout13.addLayout(layout12)

        self.spSieve = QSplitter(LayoutWidget_3,"spSieve")
        self.spSieve.setOrientation(QSplitter.Horizontal)

        self.teSieveScript = QTextEditSieveScript(self.spSieve,"teSieveScript")
        self.teSieveScript.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,1,0,self.teSieveScript.sizePolicy().hasHeightForWidth()))

        LayoutWidget_4 = QWidget(self.spSieve,"layout11")
        layout11 = QGridLayout(LayoutWidget_4,1,1,0,6,"layout11")
        spacer129 = QSpacerItem(121,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout11.addItem(spacer129,0,1)

        self.lbSieveScripts = QListBox(LayoutWidget_4,"lbSieveScripts")

        layout11.addMultiCellWidget(self.lbSieveScripts,1,1,0,1)

        self.textLabel1_8 = QLabel(LayoutWidget_4,"textLabel1_8")

        layout11.addWidget(self.textLabel1_8,0,0)
        layout13.addWidget(self.spSieve)

        WStackPageLayout_22.addWidget(self.splitter5,1,0)
        self.wsKorreio.addWidget(self.WStackPage_22,4)

        self.WStackPage_23 = QWidget(self.wsKorreio,"WStackPage_23")
        WStackPageLayout_23 = QGridLayout(self.WStackPage_23,1,1,6,6,"WStackPageLayout_23")

        layout77 = QHBoxLayout(None,0,6,"layout77")

        self.pQueueLoad = QPushButton(self.WStackPage_23,"pQueueLoad")
        self.pQueueLoad.setMinimumSize(QSize(87,0))
        self.pQueueLoad.setMaximumSize(QSize(87,32767))
        layout77.addWidget(self.pQueueLoad)
        spacer2_2 = QSpacerItem(144,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        layout77.addItem(spacer2_2)

        self.textLabel1_12 = QLabel(self.WStackPage_23,"textLabel1_12")
        layout77.addWidget(self.textLabel1_12)

        self.tlQueueMsgs = QLabel(self.WStackPage_23,"tlQueueMsgs")
        layout77.addWidget(self.tlQueueMsgs)
        spacer90_2 = QSpacerItem(341,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout77.addItem(spacer90_2)

        WStackPageLayout_23.addLayout(layout77,1,0)

        self.splitter7 = QSplitter(self.WStackPage_23,"splitter7")
        self.splitter7.setOrientation(QSplitter.Horizontal)

        self.lvQueue = QListView(self.splitter7,"lvQueue")
        self.lvQueue.addColumn(self.__tr("Sender"))
        self.lvQueue.addColumn(self.__tr("Items"))
        self.lvQueue.setMinimumSize(QSize(400,0))
        self.lvQueue.setAllColumnsShowFocus(1)
        self.lvQueue.setShowSortIndicator(1)
        self.lvQueue.setRootIsDecorated(1)
        self.lvQueue.setResizeMode(QListView.AllColumns)

        self.iQueueMessage = QTextEdit(self.splitter7,"iQueueMessage")

        WStackPageLayout_23.addWidget(self.splitter7,0,0)
        self.wsKorreio.addWidget(self.WStackPage_23,5)

        self.WStackPage_24 = QWidget(self.wsKorreio,"WStackPage_24")
        WStackPageLayout_24 = QGridLayout(self.WStackPage_24,1,1,6,6,"WStackPageLayout_24")

        self.wsServices = QWidgetStack(self.WStackPage_24,"wsServices")
        self.wsServices.setMargin(-8)

        self.WStackPage_25 = QWidget(self.wsServices,"WStackPage_25")
        WStackPageLayout_25 = QGridLayout(self.WStackPage_25,1,1,8,6,"WStackPageLayout_25")

        self.teServicesFileOpen = QTextEdit(self.WStackPage_25,"teServicesFileOpen")
        teServicesFileOpen_font = QFont(self.teServicesFileOpen.font())
        teServicesFileOpen_font.setFamily("Bitstream Vera Sans Mono")
        self.teServicesFileOpen.setFont(teServicesFileOpen_font)
        self.teServicesFileOpen.setWordWrap(QTextEdit.NoWrap)

        WStackPageLayout_25.addMultiCellWidget(self.teServicesFileOpen,2,2,0,4)

        layout24_2_4 = QVBoxLayout(None,0,0,"layout24_2_4")

        self.textLabel3_3_2_2_2_4 = QLabel(self.WStackPage_25,"textLabel3_3_2_2_2_4")
        self.textLabel3_3_2_2_2_4.setMaximumSize(QSize(32767,21))
        layout24_2_4.addWidget(self.textLabel3_3_2_2_2_4)

        self.line22_4_2_4 = QFrame(self.WStackPage_25,"line22_4_2_4")
        self.line22_4_2_4.setFrameShape(QFrame.HLine)
        self.line22_4_2_4.setFrameShadow(QFrame.Sunken)
        self.line22_4_2_4.setFrameShape(QFrame.HLine)
        layout24_2_4.addWidget(self.line22_4_2_4)

        WStackPageLayout_25.addMultiCellLayout(layout24_2_4,0,0,0,4)

        self.cbServicesFileOpen = QComboBox(0,self.WStackPage_25,"cbServicesFileOpen")
        self.cbServicesFileOpen.setMinimumSize(QSize(300,0))
        self.cbServicesFileOpen.setEditable(1)

        WStackPageLayout_25.addWidget(self.cbServicesFileOpen,1,0)

        self.pServicesFileOpen = QPushButton(self.WStackPage_25,"pServicesFileOpen")

        WStackPageLayout_25.addWidget(self.pServicesFileOpen,1,1)

        self.pServicesFileSave = QPushButton(self.WStackPage_25,"pServicesFileSave")

        WStackPageLayout_25.addWidget(self.pServicesFileSave,1,2)

        self.pServicesFilePostmap = QPushButton(self.WStackPage_25,"pServicesFilePostmap")

        WStackPageLayout_25.addWidget(self.pServicesFilePostmap,1,3)
        spacer12 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_25.addItem(spacer12,1,4)
        self.wsServices.addWidget(self.WStackPage_25,0)

        self.WStackPage_26 = QWidget(self.wsServices,"WStackPage_26")
        WStackPageLayout_26 = QGridLayout(self.WStackPage_26,1,1,8,6,"WStackPageLayout_26")

        layout24_2_2 = QVBoxLayout(None,0,0,"layout24_2_2")

        self.textLabel3_3_2_2_2_2 = QLabel(self.WStackPage_26,"textLabel3_3_2_2_2_2")
        self.textLabel3_3_2_2_2_2.setMaximumSize(QSize(32767,21))
        layout24_2_2.addWidget(self.textLabel3_3_2_2_2_2)

        self.line22_4_2_2 = QFrame(self.WStackPage_26,"line22_4_2_2")
        self.line22_4_2_2.setFrameShape(QFrame.HLine)
        self.line22_4_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_4_2_2.setFrameShape(QFrame.HLine)
        layout24_2_2.addWidget(self.line22_4_2_2)

        WStackPageLayout_26.addMultiCellLayout(layout24_2_2,0,0,0,2)
        spacer21 = QSpacerItem(180,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_26.addItem(spacer21,2,2)

        self.cbServicesPostconf = QComboBox(0,self.WStackPage_26,"cbServicesPostconf")
        self.cbServicesPostconf.setMinimumSize(QSize(340,0))

        WStackPageLayout_26.addWidget(self.cbServicesPostconf,2,0)

        self.teServicesPostconf = QTextEdit(self.WStackPage_26,"teServicesPostconf")
        teServicesPostconf_font = QFont(self.teServicesPostconf.font())
        teServicesPostconf_font.setFamily("Bitstream Vera Sans Mono")
        self.teServicesPostconf.setFont(teServicesPostconf_font)
        self.teServicesPostconf.setWordWrap(QTextEdit.NoWrap)

        WStackPageLayout_26.addMultiCellWidget(self.teServicesPostconf,3,3,0,2)

        self.pServicesPostconfSave = QPushButton(self.WStackPage_26,"pServicesPostconfSave")

        WStackPageLayout_26.addWidget(self.pServicesPostconfSave,2,1)

        self.buttonGroup3 = QButtonGroup(self.WStackPage_26,"buttonGroup3")
        self.buttonGroup3.setFrameShape(QButtonGroup.NoFrame)
        self.buttonGroup3.setColumnLayout(0,Qt.Vertical)
        self.buttonGroup3.layout().setSpacing(6)
        self.buttonGroup3.layout().setMargin(4)
        buttonGroup3Layout = QGridLayout(self.buttonGroup3.layout())
        buttonGroup3Layout.setAlignment(Qt.AlignTop)

        self.rbServicesPostconfD = QRadioButton(self.buttonGroup3,"rbServicesPostconfD")

        buttonGroup3Layout.addWidget(self.rbServicesPostconfD,0,2)
        spacer31_2 = QSpacerItem(100,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup3Layout.addItem(spacer31_2,0,3)

        self.rbServicesPostconfAll = QRadioButton(self.buttonGroup3,"rbServicesPostconfAll")

        buttonGroup3Layout.addWidget(self.rbServicesPostconfAll,0,1)

        self.rbServicesPostconfN = QRadioButton(self.buttonGroup3,"rbServicesPostconfN")
        self.rbServicesPostconfN.setAutoMask(1)

        buttonGroup3Layout.addWidget(self.rbServicesPostconfN,0,0)

        WStackPageLayout_26.addMultiCellWidget(self.buttonGroup3,1,1,0,2)
        self.wsServices.addWidget(self.WStackPage_26,1)

        self.WStackPage_27 = QWidget(self.wsServices,"WStackPage_27")
        WStackPageLayout_27 = QGridLayout(self.WStackPage_27,1,1,8,6,"WStackPageLayout_27")

        layout24_2_3 = QVBoxLayout(None,0,0,"layout24_2_3")

        self.textLabel3_3_2_2_2_3 = QLabel(self.WStackPage_27,"textLabel3_3_2_2_2_3")
        self.textLabel3_3_2_2_2_3.setMaximumSize(QSize(32767,21))
        layout24_2_3.addWidget(self.textLabel3_3_2_2_2_3)

        self.line22_4_2_3 = QFrame(self.WStackPage_27,"line22_4_2_3")
        self.line22_4_2_3.setFrameShape(QFrame.HLine)
        self.line22_4_2_3.setFrameShadow(QFrame.Sunken)
        self.line22_4_2_3.setFrameShape(QFrame.HLine)
        layout24_2_3.addWidget(self.line22_4_2_3)

        WStackPageLayout_27.addLayout(layout24_2_3,0,0)
        spacer86_3 = QSpacerItem(20,230,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_27.addItem(spacer86_3,3,0)

        layout67 = QHBoxLayout(None,0,6,"layout67")

        self.textLabel1_4 = QLabel(self.WStackPage_27,"textLabel1_4")
        layout67.addWidget(self.textLabel1_4)

        self.cbServiceService = QComboBox(0,self.WStackPage_27,"cbServiceService")
        layout67.addWidget(self.cbServiceService)

        self.cbServiceStatus = QComboBox(0,self.WStackPage_27,"cbServiceStatus")
        layout67.addWidget(self.cbServiceStatus)

        self.pServiceStatus = QPushButton(self.WStackPage_27,"pServiceStatus")
        layout67.addWidget(self.pServiceStatus)
        spacer27 = QSpacerItem(60,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout67.addItem(spacer27)

        WStackPageLayout_27.addLayout(layout67,1,0)

        self.teServiceStatus = QTextEdit(self.WStackPage_27,"teServiceStatus")
        teServiceStatus_font = QFont(self.teServiceStatus.font())
        teServiceStatus_font.setFamily("Bitstream Vera Sans Mono")
        self.teServiceStatus.setFont(teServiceStatus_font)
        self.teServiceStatus.setWordWrap(QTextEdit.NoWrap)
        self.teServiceStatus.setReadOnly(1)

        WStackPageLayout_27.addWidget(self.teServiceStatus,2,0)
        self.wsServices.addWidget(self.WStackPage_27,2)

        WStackPageLayout_24.addWidget(self.wsServices,0,1)

        self.lvServices = QListView(self.WStackPage_24,"lvServices")
        self.lvServices.addColumn(self.__tr("Menu"))
        self.lvServices.header().setClickEnabled(0,self.lvServices.header().count() - 1)
        self.lvServices.header().setResizeEnabled(0,self.lvServices.header().count() - 1)
        self.lvServices.addColumn(self.__tr("Option"))
        self.lvServices.header().setClickEnabled(0,self.lvServices.header().count() - 1)
        self.lvServices.header().setResizeEnabled(0,self.lvServices.header().count() - 1)
        self.lvServices.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Expanding,0,0,self.lvServices.sizePolicy().hasHeightForWidth()))
        self.lvServices.setMinimumSize(QSize(240,0))
        self.lvServices.setRootIsDecorated(1)
        self.lvServices.setResizeMode(QListView.AllColumns)

        WStackPageLayout_24.addWidget(self.lvServices,0,0)
        self.wsKorreio.addWidget(self.WStackPage_24,6)

        self.WStackPage_28 = QWidget(self.wsKorreio,"WStackPage_28")
        WStackPageLayout_28 = QGridLayout(self.WStackPage_28,1,1,6,6,"WStackPageLayout_28")

        layout176 = QVBoxLayout(None,0,6,"layout176")

        self.lvConfig = QListView(self.WStackPage_28,"lvConfig")
        self.lvConfig.addColumn(self.__tr("Configuration"))
        self.lvConfig.header().setClickEnabled(0,self.lvConfig.header().count() - 1)
        self.lvConfig.header().setResizeEnabled(0,self.lvConfig.header().count() - 1)
        self.lvConfig.addColumn(self.__tr("Option"))
        self.lvConfig.header().setClickEnabled(0,self.lvConfig.header().count() - 1)
        self.lvConfig.header().setResizeEnabled(0,self.lvConfig.header().count() - 1)
        self.lvConfig.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Expanding,0,0,self.lvConfig.sizePolicy().hasHeightForWidth()))
        self.lvConfig.setMinimumSize(QSize(240,0))
        self.lvConfig.setMargin(0)
        self.lvConfig.setAllColumnsShowFocus(1)
        self.lvConfig.setRootIsDecorated(1)
        self.lvConfig.setResizeMode(QListView.AllColumns)
        layout176.addWidget(self.lvConfig)
        spacer6 = QSpacerItem(33,35,QSizePolicy.Minimum,QSizePolicy.Fixed)
        layout176.addItem(spacer6)

        WStackPageLayout_28.addMultiCellLayout(layout176,0,2,0,0)

        self.wsConfig = QWidgetStack(self.WStackPage_28,"wsConfig")
        self.wsConfig.setFrameShape(QWidgetStack.NoFrame)
        self.wsConfig.setFrameShadow(QWidgetStack.Raised)
        self.wsConfig.setMargin(-8)

        self.sServLdap = QWidget(self.wsConfig,"sServLdap")
        sServLdapLayout = QGridLayout(self.sServLdap,1,1,8,6,"sServLdapLayout")

        layout26 = QVBoxLayout(None,0,0,"layout26")

        self.textLabel3_3_3 = QLabel(self.sServLdap,"textLabel3_3_3")
        self.textLabel3_3_3.setMaximumSize(QSize(32767,21))
        layout26.addWidget(self.textLabel3_3_3)

        self.line24_2 = QFrame(self.sServLdap,"line24_2")
        self.line24_2.setFrameShape(QFrame.HLine)
        self.line24_2.setFrameShadow(QFrame.Sunken)
        self.line24_2.setFrameShape(QFrame.HLine)
        layout26.addWidget(self.line24_2)

        sServLdapLayout.addMultiCellLayout(layout26,0,0,0,1)

        self.frame8 = QFrame(self.sServLdap,"frame8")
        self.frame8.setFrameShape(QFrame.NoFrame)
        self.frame8.setFrameShadow(QFrame.Raised)
        frame8Layout = QGridLayout(self.frame8,1,1,12,6,"frame8Layout")

        self.textLabel4 = QLabel(self.frame8,"textLabel4")
        self.textLabel4.setMinimumSize(QSize(100,0))
        self.textLabel4.setMaximumSize(QSize(100,32767))

        frame8Layout.addWidget(self.textLabel4,0,0)

        self.tLdapUser = QLabel(self.frame8,"tLdapUser")

        frame8Layout.addWidget(self.tLdapUser,5,0)

        self.tLdapPass = QLabel(self.frame8,"tLdapPass")

        frame8Layout.addWidget(self.tLdapPass,6,0)

        self.tLdapName = QLabel(self.frame8,"tLdapName")

        frame8Layout.addWidget(self.tLdapName,2,0)

        self.tLdapHost = QLabel(self.frame8,"tLdapHost")

        frame8Layout.addWidget(self.tLdapHost,3,0)

        self.tLdapPort = QLabel(self.frame8,"tLdapPort")

        frame8Layout.addWidget(self.tLdapPort,3,4)

        self.tLdapBaseDN = QLabel(self.frame8,"tLdapBaseDN")

        frame8Layout.addWidget(self.tLdapBaseDN,4,0)

        self.cbLdapConnection = QComboBox(0,self.frame8,"cbLdapConnection")
        self.cbLdapConnection.setMinimumSize(QSize(230,0))
        self.cbLdapConnection.setMaximumSize(QSize(230,32767))

        frame8Layout.addMultiCellWidget(self.cbLdapConnection,0,0,1,2)

        self.pConfDelLdapConnection = QPushButton(self.frame8,"pConfDelLdapConnection")
        self.pConfDelLdapConnection.setMinimumSize(QSize(40,0))
        self.pConfDelLdapConnection.setMaximumSize(QSize(40,25))

        frame8Layout.addWidget(self.pConfDelLdapConnection,0,3)

        self.iLdapConnection = QLineEdit(self.frame8,"iLdapConnection")

        frame8Layout.addMultiCellWidget(self.iLdapConnection,2,2,1,3)

        self.cbLdapMode = QComboBox(0,self.frame8,"cbLdapMode")
        self.cbLdapMode.setMaximumSize(QSize(80,32767))

        frame8Layout.addWidget(self.cbLdapMode,3,1)

        self.iLdapHost = QLineEdit(self.frame8,"iLdapHost")

        frame8Layout.addMultiCellWidget(self.iLdapHost,3,3,2,3)

        self.iLdapPort = QLineEdit(self.frame8,"iLdapPort")
        self.iLdapPort.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed,0,0,self.iLdapPort.sizePolicy().hasHeightForWidth()))
        self.iLdapPort.setMinimumSize(QSize(50,0))
        self.iLdapPort.setMaximumSize(QSize(50,32767))

        frame8Layout.addWidget(self.iLdapPort,3,5)

        self.cbLdapBaseDN = QComboBox(0,self.frame8,"cbLdapBaseDN")
        self.cbLdapBaseDN.setEditable(1)

        frame8Layout.addMultiCellWidget(self.cbLdapBaseDN,4,4,1,3)

        self.iLdapUser = QLineEdit(self.frame8,"iLdapUser")

        frame8Layout.addMultiCellWidget(self.iLdapUser,5,5,1,3)

        self.iLdapPass = QLineEdit(self.frame8,"iLdapPass")
        self.iLdapPass.setEchoMode(QLineEdit.Password)

        frame8Layout.addMultiCellWidget(self.iLdapPass,6,6,1,3)

        self.cLdapRef = QCheckBox(self.frame8,"cLdapRef")

        frame8Layout.addMultiCellWidget(self.cLdapRef,7,7,0,1)

        self.cLdapCert = QCheckBox(self.frame8,"cLdapCert")

        frame8Layout.addMultiCellWidget(self.cLdapCert,8,8,0,3)

        self.pGetBaseDN = QPushButton(self.frame8,"pGetBaseDN")
        self.pGetBaseDN.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed,0,0,self.pGetBaseDN.sizePolicy().hasHeightForWidth()))
        self.pGetBaseDN.setMaximumSize(QSize(32767,25))

        frame8Layout.addMultiCellWidget(self.pGetBaseDN,4,4,4,5)

        self.line5 = QFrame(self.frame8,"line5")
        self.line5.setFrameShape(QFrame.HLine)
        self.line5.setFrameShadow(QFrame.Sunken)
        self.line5.setFrameShape(QFrame.HLine)

        frame8Layout.addMultiCellWidget(self.line5,1,1,0,5)

        sServLdapLayout.addWidget(self.frame8,1,0)
        spacer42 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        sServLdapLayout.addItem(spacer42,1,1)
        spacer41 = QSpacerItem(20,100,QSizePolicy.Minimum,QSizePolicy.Expanding)
        sServLdapLayout.addItem(spacer41,2,0)
        self.wsConfig.addWidget(self.sServLdap,0)

        self.WStackPage_29 = QWidget(self.wsConfig,"WStackPage_29")
        WStackPageLayout_29 = QGridLayout(self.WStackPage_29,1,1,8,6,"WStackPageLayout_29")

        layout27 = QVBoxLayout(None,0,0,"layout27")

        self.textLabel3_3_2 = QLabel(self.WStackPage_29,"textLabel3_3_2")
        self.textLabel3_3_2.setMaximumSize(QSize(32767,21))
        layout27.addWidget(self.textLabel3_3_2)

        self.line25 = QFrame(self.WStackPage_29,"line25")
        self.line25.setFrameShape(QFrame.HLine)
        self.line25.setFrameShadow(QFrame.Sunken)
        self.line25.setFrameShape(QFrame.HLine)
        layout27.addWidget(self.line25)

        WStackPageLayout_29.addMultiCellLayout(layout27,0,0,0,1)
        spacer48 = QSpacerItem(21,80,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_29.addItem(spacer48,2,0)
        spacer49 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_29.addItem(spacer49,1,1)

        self.frame7 = QFrame(self.WStackPage_29,"frame7")
        self.frame7.setFrameShape(QFrame.NoFrame)
        self.frame7.setFrameShadow(QFrame.Raised)
        frame7Layout = QGridLayout(self.frame7,1,1,12,6,"frame7Layout")

        self.textLabel6_2 = QLabel(self.frame7,"textLabel6_2")
        self.textLabel6_2.setMinimumSize(QSize(100,0))
        self.textLabel6_2.setMaximumSize(QSize(100,32767))

        frame7Layout.addWidget(self.textLabel6_2,0,0)

        self.tCyrusPartition_3 = QLabel(self.frame7,"tCyrusPartition_3")

        frame7Layout.addWidget(self.tCyrusPartition_3,7,0)

        self.tCyrusPartition = QLabel(self.frame7,"tCyrusPartition")

        frame7Layout.addWidget(self.tCyrusPartition,6,0)

        self.tCyrusUser = QLabel(self.frame7,"tCyrusUser")

        frame7Layout.addWidget(self.tCyrusUser,4,0)

        self.tCyrusPass = QLabel(self.frame7,"tCyrusPass")

        frame7Layout.addWidget(self.tCyrusPass,5,0)
        spacer69 = QSpacerItem(16,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        frame7Layout.addItem(spacer69,7,2)

        self.textLabel7_2 = QLabel(self.frame7,"textLabel7_2")

        frame7Layout.addWidget(self.textLabel7_2,2,0)
        spacer71 = QSpacerItem(180,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7Layout.addMultiCell(spacer71,7,7,3,4)

        self.tCyrusHost = QLabel(self.frame7,"tCyrusHost")

        frame7Layout.addWidget(self.tCyrusHost,3,0)

        self.tCyrusPort = QLabel(self.frame7,"tCyrusPort")

        frame7Layout.addWidget(self.tCyrusPort,3,5)

        self.cbCyrusConnection = QComboBox(0,self.frame7,"cbCyrusConnection")
        self.cbCyrusConnection.setMinimumSize(QSize(230,0))
        self.cbCyrusConnection.setMaximumSize(QSize(230,32767))

        frame7Layout.addMultiCellWidget(self.cbCyrusConnection,0,0,1,3)

        self.pConfDelImapConnection = QPushButton(self.frame7,"pConfDelImapConnection")
        self.pConfDelImapConnection.setMinimumSize(QSize(40,0))
        self.pConfDelImapConnection.setMaximumSize(QSize(40,25))

        frame7Layout.addWidget(self.pConfDelImapConnection,0,4)

        self.iCyrusConnection = QLineEdit(self.frame7,"iCyrusConnection")

        frame7Layout.addMultiCellWidget(self.iCyrusConnection,2,2,1,4)

        self.cbCyrusMode = QComboBox(0,self.frame7,"cbCyrusMode")
        self.cbCyrusMode.setMinimumSize(QSize(91,0))
        self.cbCyrusMode.setMaximumSize(QSize(91,32767))

        frame7Layout.addMultiCellWidget(self.cbCyrusMode,3,3,1,2)

        self.iCyrusHost = QLineEdit(self.frame7,"iCyrusHost")

        frame7Layout.addMultiCellWidget(self.iCyrusHost,3,3,3,4)

        self.iCyrusPort = QLineEdit(self.frame7,"iCyrusPort")
        self.iCyrusPort.setMinimumSize(QSize(50,0))
        self.iCyrusPort.setMaximumSize(QSize(50,32767))

        frame7Layout.addWidget(self.iCyrusPort,3,6)

        self.iCyrusUser = QLineEdit(self.frame7,"iCyrusUser")

        frame7Layout.addMultiCellWidget(self.iCyrusUser,4,4,1,4)

        self.iCyrusPass = QLineEdit(self.frame7,"iCyrusPass")
        self.iCyrusPass.setEchoMode(QLineEdit.Password)

        frame7Layout.addMultiCellWidget(self.iCyrusPass,5,5,1,4)

        self.iCyrusPart = QLineEdit(self.frame7,"iCyrusPart")

        frame7Layout.addMultiCellWidget(self.iCyrusPart,6,6,1,4)

        self.iCyrusSievePort = QLineEdit(self.frame7,"iCyrusSievePort")
        self.iCyrusSievePort.setMinimumSize(QSize(60,0))
        self.iCyrusSievePort.setMaximumSize(QSize(60,32767))

        frame7Layout.addWidget(self.iCyrusSievePort,7,1)

        self.line6 = QFrame(self.frame7,"line6")
        self.line6.setFrameShape(QFrame.HLine)
        self.line6.setFrameShadow(QFrame.Sunken)
        self.line6.setFrameShape(QFrame.HLine)

        frame7Layout.addMultiCellWidget(self.line6,1,1,0,6)

        WStackPageLayout_29.addWidget(self.frame7,1,0)
        self.wsConfig.addWidget(self.WStackPage_29,1)

        self.WStackPage_30 = QWidget(self.wsConfig,"WStackPage_30")
        WStackPageLayout_30 = QGridLayout(self.WStackPage_30,1,1,8,6,"WStackPageLayout_30")

        layout28 = QVBoxLayout(None,0,0,"layout28")

        self.textLabel3_3 = QLabel(self.WStackPage_30,"textLabel3_3")
        self.textLabel3_3.setMaximumSize(QSize(32767,21))
        layout28.addWidget(self.textLabel3_3)

        self.line26 = QFrame(self.WStackPage_30,"line26")
        self.line26.setFrameShape(QFrame.HLine)
        self.line26.setFrameShadow(QFrame.Sunken)
        self.line26.setFrameShape(QFrame.HLine)
        layout28.addWidget(self.line26)

        WStackPageLayout_30.addMultiCellLayout(layout28,0,0,0,1)
        spacer52 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_30.addItem(spacer52,1,1)
        spacer51 = QSpacerItem(20,190,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_30.addItem(spacer51,2,0)

        self.frame4 = QFrame(self.WStackPage_30,"frame4")
        self.frame4.setFrameShape(QFrame.NoFrame)
        self.frame4.setFrameShadow(QFrame.Raised)
        frame4Layout = QGridLayout(self.frame4,1,1,12,6,"frame4Layout")

        self.line7 = QFrame(self.frame4,"line7")
        self.line7.setFrameShape(QFrame.HLine)
        self.line7.setFrameShadow(QFrame.Sunken)
        self.line7.setFrameShape(QFrame.HLine)

        frame4Layout.addMultiCellWidget(self.line7,1,1,0,4)

        self.textLabel8 = QLabel(self.frame4,"textLabel8")
        self.textLabel8.setMinimumSize(QSize(100,0))

        frame4Layout.addWidget(self.textLabel8,0,0)

        self.textLabel9 = QLabel(self.frame4,"textLabel9")

        frame4Layout.addWidget(self.textLabel9,2,0)

        self.tCyrusHost_2 = QLabel(self.frame4,"tCyrusHost_2")

        frame4Layout.addWidget(self.tCyrusHost_2,3,0)

        self.tCyrusPort_2 = QLabel(self.frame4,"tCyrusPort_2")

        frame4Layout.addWidget(self.tCyrusPort_2,3,3)

        self.tCyrusUser_2 = QLabel(self.frame4,"tCyrusUser_2")

        frame4Layout.addWidget(self.tCyrusUser_2,4,0)

        self.tCyrusPass_2 = QLabel(self.frame4,"tCyrusPass_2")

        frame4Layout.addWidget(self.tCyrusPass_2,5,0)

        self.tCyrusUser_2_3 = QLabel(self.frame4,"tCyrusUser_2_3")

        frame4Layout.addWidget(self.tCyrusUser_2_3,6,0)

        self.cbSSHConnection = QComboBox(0,self.frame4,"cbSSHConnection")
        self.cbSSHConnection.setMinimumSize(QSize(230,0))

        frame4Layout.addWidget(self.cbSSHConnection,0,1)

        self.pConfDelSshConnection = QPushButton(self.frame4,"pConfDelSshConnection")
        self.pConfDelSshConnection.setMinimumSize(QSize(40,0))
        self.pConfDelSshConnection.setMaximumSize(QSize(40,25))

        frame4Layout.addWidget(self.pConfDelSshConnection,0,2)

        self.iSSHConnection = QLineEdit(self.frame4,"iSSHConnection")

        frame4Layout.addMultiCellWidget(self.iSSHConnection,2,2,1,2)

        self.iSshHost = QLineEdit(self.frame4,"iSshHost")

        frame4Layout.addMultiCellWidget(self.iSshHost,3,3,1,2)

        self.iSshPort = QLineEdit(self.frame4,"iSshPort")
        self.iSshPort.setMinimumSize(QSize(50,0))
        self.iSshPort.setMaximumSize(QSize(50,32767))

        frame4Layout.addWidget(self.iSshPort,3,4)

        self.iSshUser = QLineEdit(self.frame4,"iSshUser")

        frame4Layout.addMultiCellWidget(self.iSshUser,4,4,1,2)

        self.iSshPass = QLineEdit(self.frame4,"iSshPass")
        self.iSshPass.setEchoMode(QLineEdit.Password)

        frame4Layout.addMultiCellWidget(self.iSshPass,5,5,1,2)

        self.cbSSHsudo = QComboBox(0,self.frame4,"cbSSHsudo")

        frame4Layout.addMultiCellWidget(self.cbSSHsudo,6,6,1,2)

        WStackPageLayout_30.addWidget(self.frame4,1,0)
        self.wsConfig.addWidget(self.WStackPage_30,2)

        self.WStackPage_31 = QWidget(self.wsConfig,"WStackPage_31")
        WStackPageLayout_31 = QGridLayout(self.WStackPage_31,1,1,8,6,"WStackPageLayout_31")
        spacer102 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_31.addItem(spacer102,2,0)

        layout21_2 = QVBoxLayout(None,0,0,"layout21_2")

        self.textLabel10_4 = QLabel(self.WStackPage_31,"textLabel10_4")
        self.textLabel10_4.setMaximumSize(QSize(32767,20))
        layout21_2.addWidget(self.textLabel10_4)

        self.line19_2 = QFrame(self.WStackPage_31,"line19_2")
        self.line19_2.setFrameShape(QFrame.HLine)
        self.line19_2.setFrameShadow(QFrame.Sunken)
        self.line19_2.setFrameShape(QFrame.HLine)
        layout21_2.addWidget(self.line19_2)

        WStackPageLayout_31.addMultiCellLayout(layout21_2,0,0,0,1)

        self.frame308 = QFrame(self.WStackPage_31,"frame308")
        self.frame308.setMinimumSize(QSize(400,0))
        self.frame308.setFrameShape(QFrame.NoFrame)
        self.frame308.setFrameShadow(QFrame.Raised)
        frame308Layout = QGridLayout(self.frame308,1,1,12,6,"frame308Layout")

        self.frame11 = QFrame(self.frame308,"frame11")
        self.frame11.setFrameShape(QFrame.NoFrame)
        self.frame11.setFrameShadow(QFrame.Raised)
        frame11Layout = QGridLayout(self.frame11,1,1,15,6,"frame11Layout")

        self.tConfShowSshServer = QLabel(self.frame11,"tConfShowSshServer")

        frame11Layout.addWidget(self.tConfShowSshServer,0,0)

        self.tConfShowSshUser = QLabel(self.frame11,"tConfShowSshUser")

        frame11Layout.addWidget(self.tConfShowSshUser,1,0)

        frame308Layout.addWidget(self.frame11,5,0)

        layout23 = QVBoxLayout(None,0,0,"layout23")

        self.textLabel10_3 = QLabel(self.frame308,"textLabel10_3")
        self.textLabel10_3.setMaximumSize(QSize(32767,20))
        layout23.addWidget(self.textLabel10_3)

        self.line21_2 = QFrame(self.frame308,"line21_2")
        self.line21_2.setFrameShape(QFrame.HLine)
        self.line21_2.setFrameShadow(QFrame.Sunken)
        self.line21_2.setFrameShape(QFrame.HLine)
        layout23.addWidget(self.line21_2)

        frame308Layout.addLayout(layout23,4,0)

        self.frame10 = QFrame(self.frame308,"frame10")
        self.frame10.setFrameShape(QFrame.NoFrame)
        self.frame10.setFrameShadow(QFrame.Raised)
        frame10Layout = QGridLayout(self.frame10,1,1,15,6,"frame10Layout")

        self.tConfShowLdapServer = QLabel(self.frame10,"tConfShowLdapServer")

        frame10Layout.addWidget(self.tConfShowLdapServer,0,0)

        self.tConfShowLdapUser = QLabel(self.frame10,"tConfShowLdapUser")

        frame10Layout.addWidget(self.tConfShowLdapUser,1,0)

        self.tConfShowLdapBaseDN = QLabel(self.frame10,"tConfShowLdapBaseDN")

        frame10Layout.addWidget(self.tConfShowLdapBaseDN,2,0)

        frame308Layout.addWidget(self.frame10,3,0)

        layout22 = QVBoxLayout(None,0,0,"layout22")

        self.textLabel10_2 = QLabel(self.frame308,"textLabel10_2")
        self.textLabel10_2.setMaximumSize(QSize(32767,20))
        layout22.addWidget(self.textLabel10_2)

        self.line20 = QFrame(self.frame308,"line20")
        self.line20.setFrameShape(QFrame.HLine)
        self.line20.setFrameShadow(QFrame.Sunken)
        self.line20.setFrameShape(QFrame.HLine)
        layout22.addWidget(self.line20)

        frame308Layout.addLayout(layout22,2,0)

        self.frame9 = QFrame(self.frame308,"frame9")
        self.frame9.setFrameShape(QFrame.NoFrame)
        self.frame9.setFrameShadow(QFrame.Raised)
        frame9Layout = QGridLayout(self.frame9,1,1,15,6,"frame9Layout")

        self.tConfShowImapServer = QLabel(self.frame9,"tConfShowImapServer")

        frame9Layout.addWidget(self.tConfShowImapServer,0,0)

        self.tConfShowImapUser = QLabel(self.frame9,"tConfShowImapUser")

        frame9Layout.addWidget(self.tConfShowImapUser,1,0)

        self.tConfShowImapSep = QLabel(self.frame9,"tConfShowImapSep")

        frame9Layout.addWidget(self.tConfShowImapSep,2,0)

        frame308Layout.addWidget(self.frame9,1,0)

        layout21 = QVBoxLayout(None,0,0,"layout21")

        self.textLabel10 = QLabel(self.frame308,"textLabel10")
        self.textLabel10.setMaximumSize(QSize(32767,20))
        layout21.addWidget(self.textLabel10)

        self.line19 = QFrame(self.frame308,"line19")
        self.line19.setFrameShape(QFrame.HLine)
        self.line19.setFrameShadow(QFrame.Sunken)
        self.line19.setFrameShape(QFrame.HLine)
        layout21.addWidget(self.line19)

        frame308Layout.addLayout(layout21,0,0)

        WStackPageLayout_31.addWidget(self.frame308,1,0)
        spacer1315 = QSpacerItem(131,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_31.addItem(spacer1315,1,1)
        self.wsConfig.addWidget(self.WStackPage_31,3)

        self.WStackPage_32 = QWidget(self.wsConfig,"WStackPage_32")
        WStackPageLayout_32 = QGridLayout(self.WStackPage_32,1,1,8,6,"WStackPageLayout_32")

        layout25_2_2_2 = QVBoxLayout(None,0,0,"layout25_2_2_2")

        self.textLabel3_3_2_3_2_2_2 = QLabel(self.WStackPage_32,"textLabel3_3_2_3_2_2_2")
        self.textLabel3_3_2_3_2_2_2.setMaximumSize(QSize(32767,21))
        layout25_2_2_2.addWidget(self.textLabel3_3_2_3_2_2_2)

        self.line23_2_2_2 = QFrame(self.WStackPage_32,"line23_2_2_2")
        self.line23_2_2_2.setFrameShape(QFrame.HLine)
        self.line23_2_2_2.setFrameShadow(QFrame.Sunken)
        self.line23_2_2_2.setFrameShape(QFrame.HLine)
        layout25_2_2_2.addWidget(self.line23_2_2_2)

        WStackPageLayout_32.addMultiCellLayout(layout25_2_2_2,0,0,0,1)
        spacer1300 = QSpacerItem(30,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_32.addItem(spacer1300,1,1)
        spacer1301 = QSpacerItem(21,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_32.addItem(spacer1301,2,0)

        self.frame307_2 = QFrame(self.WStackPage_32,"frame307_2")
        self.frame307_2.setFrameShape(QFrame.NoFrame)
        self.frame307_2.setFrameShadow(QFrame.Raised)
        frame307_2Layout = QGridLayout(self.frame307_2,1,1,12,6,"frame307_2Layout")

        self.textLabel1_3_2_3_2_3_2 = QLabel(self.frame307_2,"textLabel1_3_2_3_2_3_2")

        frame307_2Layout.addWidget(self.textLabel1_3_2_3_2_3_2,1,0)

        layout522_3 = QVBoxLayout(None,0,0,"layout522_3")

        self.textLabel1_5_3 = QLabel(self.frame307_2,"textLabel1_5_3")
        layout522_3.addWidget(self.textLabel1_5_3)

        self.line506_3 = QFrame(self.frame307_2,"line506_3")
        self.line506_3.setFrameShape(QFrame.HLine)
        self.line506_3.setFrameShadow(QFrame.Sunken)
        self.line506_3.setFrameShape(QFrame.HLine)
        layout522_3.addWidget(self.line506_3)

        frame307_2Layout.addMultiCellLayout(layout522_3,0,0,0,4)

        layout522_3_2 = QVBoxLayout(None,0,0,"layout522_3_2")

        self.textLabel1_5_3_2 = QLabel(self.frame307_2,"textLabel1_5_3_2")
        layout522_3_2.addWidget(self.textLabel1_5_3_2)

        self.line506_3_2 = QFrame(self.frame307_2,"line506_3_2")
        self.line506_3_2.setFrameShape(QFrame.HLine)
        self.line506_3_2.setFrameShadow(QFrame.Sunken)
        self.line506_3_2.setFrameShape(QFrame.HLine)
        layout522_3_2.addWidget(self.line506_3_2)

        frame307_2Layout.addMultiCellLayout(layout522_3_2,3,3,0,4)

        self.lbConfLdapFilter = QListBox(self.frame307_2,"lbConfLdapFilter")
        self.lbConfLdapFilter.setMaximumSize(QSize(32767,120))
        self.lbConfLdapFilter.setSelectionMode(QListBox.Extended)

        frame307_2Layout.addMultiCellWidget(self.lbConfLdapFilter,4,4,0,4)

        self.pConfLdapFilterAdd = QPushButton(self.frame307_2,"pConfLdapFilterAdd")
        self.pConfLdapFilterAdd.setMinimumSize(QSize(30,0))
        self.pConfLdapFilterAdd.setMaximumSize(QSize(30,32767))

        frame307_2Layout.addWidget(self.pConfLdapFilterAdd,5,3)

        self.pConfLdapFilterDel = QPushButton(self.frame307_2,"pConfLdapFilterDel")
        self.pConfLdapFilterDel.setMinimumSize(QSize(30,0))
        self.pConfLdapFilterDel.setMaximumSize(QSize(30,32767))

        frame307_2Layout.addWidget(self.pConfLdapFilterDel,5,4)

        self.iConfLdapFilter = QLineEdit(self.frame307_2,"iConfLdapFilter")

        frame307_2Layout.addMultiCellWidget(self.iConfLdapFilter,5,5,0,2)

        layout522_3_2_2 = QVBoxLayout(None,0,0,"layout522_3_2_2")

        self.textLabel1_5_3_2_2 = QLabel(self.frame307_2,"textLabel1_5_3_2_2")
        layout522_3_2_2.addWidget(self.textLabel1_5_3_2_2)

        self.line506_3_2_2 = QFrame(self.frame307_2,"line506_3_2_2")
        self.line506_3_2_2.setFrameShape(QFrame.HLine)
        self.line506_3_2_2.setFrameShadow(QFrame.Sunken)
        self.line506_3_2_2.setFrameShape(QFrame.HLine)
        layout522_3_2_2.addWidget(self.line506_3_2_2)

        frame307_2Layout.addMultiCellLayout(layout522_3_2_2,7,7,0,4)
        spacer175 = QSpacerItem(525,16,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame307_2Layout.addMultiCell(spacer175,2,2,0,4)
        spacer175_2 = QSpacerItem(525,16,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame307_2Layout.addMultiCell(spacer175_2,6,6,0,4)

        self.cbConfLdapCompleteUser = QComboBox(0,self.frame307_2,"cbConfLdapCompleteUser")
        self.cbConfLdapCompleteUser.setEditable(1)

        frame307_2Layout.addWidget(self.cbConfLdapCompleteUser,1,1)
        spacer86_2 = QSpacerItem(90,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame307_2Layout.addMultiCell(spacer86_2,1,1,2,4)

        self.cConfLdapsambaPwdMustChange = QCheckBox(self.frame307_2,"cConfLdapsambaPwdMustChange")

        frame307_2Layout.addMultiCellWidget(self.cConfLdapsambaPwdMustChange,9,9,0,4)

        layout70 = QHBoxLayout(None,0,6,"layout70")

        self.textLabel1_6 = QLabel(self.frame307_2,"textLabel1_6")
        layout70.addWidget(self.textLabel1_6)

        self.cbConfLdapUserDN = QComboBox(0,self.frame307_2,"cbConfLdapUserDN")
        self.cbConfLdapUserDN.setMinimumSize(QSize(80,0))
        layout70.addWidget(self.cbConfLdapUserDN)
        spacer86_2_2 = QSpacerItem(140,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout70.addItem(spacer86_2_2)

        frame307_2Layout.addMultiCellLayout(layout70,8,8,0,4)

        WStackPageLayout_32.addWidget(self.frame307_2,1,0)
        self.wsConfig.addWidget(self.WStackPage_32,4)

        self.WStackPage_33 = QWidget(self.wsConfig,"WStackPage_33")
        WStackPageLayout_33 = QGridLayout(self.WStackPage_33,1,1,8,6,"WStackPageLayout_33")

        layout25 = QVBoxLayout(None,0,0,"layout25")

        self.textLabel3_3_2_3 = QLabel(self.WStackPage_33,"textLabel3_3_2_3")
        self.textLabel3_3_2_3.setMaximumSize(QSize(32767,21))
        layout25.addWidget(self.textLabel3_3_2_3)

        self.line23 = QFrame(self.WStackPage_33,"line23")
        self.line23.setFrameShape(QFrame.HLine)
        self.line23.setFrameShadow(QFrame.Sunken)
        self.line23.setFrameShape(QFrame.HLine)
        layout25.addWidget(self.line23)

        WStackPageLayout_33.addMultiCellLayout(layout25,0,0,0,1)
        spacer1304 = QSpacerItem(150,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_33.addItem(spacer1304,1,1)
        spacer1309_3 = QSpacerItem(21,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_33.addItem(spacer1309_3,2,0)

        self.frame7_3 = QFrame(self.WStackPage_33,"frame7_3")
        self.frame7_3.setMaximumSize(QSize(430,32767))
        self.frame7_3.setFrameShape(QFrame.NoFrame)
        self.frame7_3.setFrameShadow(QFrame.Raised)
        frame7_3Layout = QGridLayout(self.frame7_3,1,1,12,6,"frame7_3Layout")

        layout530 = QVBoxLayout(None,0,0,"layout530")

        self.textLabel6_2_3 = QLabel(self.frame7_3,"textLabel6_2_3")
        self.textLabel6_2_3.setMinimumSize(QSize(100,0))
        layout530.addWidget(self.textLabel6_2_3)

        self.line9 = QFrame(self.frame7_3,"line9")
        self.line9.setFrameShape(QFrame.HLine)
        self.line9.setFrameShadow(QFrame.Sunken)
        self.line9.setFrameShape(QFrame.HLine)
        layout530.addWidget(self.line9)

        frame7_3Layout.addLayout(layout530,0,0)

        layout75 = QHBoxLayout(None,0,6,"layout75")

        self.iConfImapFolder = QLineEdit(self.frame7_3,"iConfImapFolder")
        self.iConfImapFolder.setMinimumSize(QSize(180,0))
        layout75.addWidget(self.iConfImapFolder)

        self.iConfImapExpire = QLineEdit(self.frame7_3,"iConfImapExpire")
        layout75.addWidget(self.iConfImapExpire)

        self.cbConfImapACLp = QComboBox(0,self.frame7_3,"cbConfImapACLp")
        layout75.addWidget(self.cbConfImapACLp)

        self.pConfImapFoldersAdd = QPushButton(self.frame7_3,"pConfImapFoldersAdd")
        self.pConfImapFoldersAdd.setMinimumSize(QSize(30,0))
        self.pConfImapFoldersAdd.setMaximumSize(QSize(30,32767))
        layout75.addWidget(self.pConfImapFoldersAdd)

        self.pConfImapFoldersDel = QPushButton(self.frame7_3,"pConfImapFoldersDel")
        self.pConfImapFoldersDel.setMinimumSize(QSize(30,0))
        self.pConfImapFoldersDel.setMaximumSize(QSize(30,32767))
        layout75.addWidget(self.pConfImapFoldersDel)

        frame7_3Layout.addLayout(layout75,2,0)

        self.lvConfImapFolders = QListView(self.frame7_3,"lvConfImapFolders")
        self.lvConfImapFolders.addColumn(self.__tr("Name"))
        self.lvConfImapFolders.addColumn(self.__tr("Expire (days)"))
        self.lvConfImapFolders.addColumn(self.__tr("ACL anyone"))
        self.lvConfImapFolders.setMaximumSize(QSize(32767,140))
        self.lvConfImapFolders.setAllColumnsShowFocus(1)
        self.lvConfImapFolders.setResizeMode(QListView.AllColumns)

        frame7_3Layout.addWidget(self.lvConfImapFolders,1,0)
        spacer82_2 = QSpacerItem(470,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addItem(spacer82_2,3,0)

        layout74_2 = QHBoxLayout(None,0,6,"layout74_2")

        self.textLabel1_10 = QLabel(self.frame7_3,"textLabel1_10")
        self.textLabel1_10.setMinimumSize(QSize(70,0))
        layout74_2.addWidget(self.textLabel1_10)

        self.iConfImapQuotaMbytes = QLineEdit(self.frame7_3,"iConfImapQuotaMbytes")
        self.iConfImapQuotaMbytes.setMinimumSize(QSize(120,0))
        self.iConfImapQuotaMbytes.setMaximumSize(QSize(120,32767))
        self.iConfImapQuotaMbytes.setAlignment(QLineEdit.AlignRight)
        layout74_2.addWidget(self.iConfImapQuotaMbytes)

        self.textLabel1_7 = QLabel(self.frame7_3,"textLabel1_7")
        layout74_2.addWidget(self.textLabel1_7)
        spacer368 = QSpacerItem(151,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout74_2.addItem(spacer368)

        frame7_3Layout.addLayout(layout74_2,5,0)

        layout531 = QVBoxLayout(None,0,0,"layout531")

        self.textLabel7_2_3 = QLabel(self.frame7_3,"textLabel7_2_3")
        layout531.addWidget(self.textLabel7_2_3)

        self.line6_3 = QFrame(self.frame7_3,"line6_3")
        self.line6_3.setFrameShape(QFrame.HLine)
        self.line6_3.setFrameShadow(QFrame.Sunken)
        self.line6_3.setFrameShape(QFrame.HLine)
        layout531.addWidget(self.line6_3)

        frame7_3Layout.addLayout(layout531,4,0)
        spacer102_2 = QSpacerItem(20,61,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame7_3Layout.addItem(spacer102_2,6,0)

        WStackPageLayout_33.addWidget(self.frame7_3,1,0)
        self.wsConfig.addWidget(self.WStackPage_33,5)

        self.WStackPage_34 = QWidget(self.wsConfig,"WStackPage_34")
        WStackPageLayout_34 = QGridLayout(self.WStackPage_34,1,1,8,6,"WStackPageLayout_34")

        layout25_2 = QVBoxLayout(None,0,0,"layout25_2")

        self.textLabel3_3_2_3_2 = QLabel(self.WStackPage_34,"textLabel3_3_2_3_2")
        self.textLabel3_3_2_3_2.setMaximumSize(QSize(32767,21))
        layout25_2.addWidget(self.textLabel3_3_2_3_2)

        self.line23_2 = QFrame(self.WStackPage_34,"line23_2")
        self.line23_2.setFrameShape(QFrame.HLine)
        self.line23_2.setFrameShadow(QFrame.Sunken)
        self.line23_2.setFrameShape(QFrame.HLine)
        layout25_2.addWidget(self.line23_2)

        WStackPageLayout_34.addMultiCellLayout(layout25_2,0,0,0,1)
        spacer51_2 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_34.addItem(spacer51_2,2,0)
        spacer88 = QSpacerItem(70,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_34.addItem(spacer88,1,1)

        self.frame4_2 = QFrame(self.WStackPage_34,"frame4_2")
        self.frame4_2.setFrameShape(QFrame.NoFrame)
        self.frame4_2.setFrameShadow(QFrame.Raised)
        frame4_2Layout = QGridLayout(self.frame4_2,1,1,12,5,"frame4_2Layout")

        self.cbConfLdapSmbDomain = QComboBox(0,self.frame4_2,"cbConfLdapSmbDomain")
        self.cbConfLdapSmbDomain.setMinimumSize(QSize(230,0))

        frame4_2Layout.addWidget(self.cbConfLdapSmbDomain,0,1)

        self.textLabel8_2 = QLabel(self.frame4_2,"textLabel8_2")
        self.textLabel8_2.setMinimumSize(QSize(100,0))

        frame4_2Layout.addWidget(self.textLabel8_2,0,0)

        self.pConfLdapSmbDomainDel = QPushButton(self.frame4_2,"pConfLdapSmbDomainDel")
        self.pConfLdapSmbDomainDel.setMinimumSize(QSize(40,0))
        self.pConfLdapSmbDomainDel.setMaximumSize(QSize(40,25))

        frame4_2Layout.addWidget(self.pConfLdapSmbDomainDel,0,2)

        self.tCyrusHost_2_2_4_2_2 = QLabel(self.frame4_2,"tCyrusHost_2_2_4_2_2")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_4_2_2,12,0)

        self.tCyrusHost_2_2_4 = QLabel(self.frame4_2,"tCyrusHost_2_2_4")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_4,10,0)

        self.iConfLdapSmbHomeDrive = QLineEdit(self.frame4_2,"iConfLdapSmbHomeDrive")

        frame4_2Layout.addMultiCellWidget(self.iConfLdapSmbHomeDrive,10,10,1,2)

        self.iConfLdapSmbDrivePath = QLineEdit(self.frame4_2,"iConfLdapSmbDrivePath")

        frame4_2Layout.addMultiCellWidget(self.iConfLdapSmbDrivePath,11,11,1,2)

        self.cbConfLdapSmbLogonScript = QComboBox(0,self.frame4_2,"cbConfLdapSmbLogonScript")
        self.cbConfLdapSmbLogonScript.setEnabled(1)
        self.cbConfLdapSmbLogonScript.setEditable(1)

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbLogonScript,12,12,1,2)

        self.cbConfLdapSmbProfilePath = QComboBox(0,self.frame4_2,"cbConfLdapSmbProfilePath")
        self.cbConfLdapSmbProfilePath.setEnabled(0)
        self.cbConfLdapSmbProfilePath.setEditable(1)

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbProfilePath,9,9,1,2)

        self.tCyrusHost_2_2_4_2 = QLabel(self.frame4_2,"tCyrusHost_2_2_4_2")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_4_2,11,0)

        layout522_2_3 = QVBoxLayout(None,0,0,"layout522_2_3")

        self.textLabel1_5_2_3 = QLabel(self.frame4_2,"textLabel1_5_2_3")
        layout522_2_3.addWidget(self.textLabel1_5_2_3)

        self.line506_2_3 = QFrame(self.frame4_2,"line506_2_3")
        self.line506_2_3.setFrameShape(QFrame.HLine)
        self.line506_2_3.setFrameShadow(QFrame.Sunken)
        self.line506_2_3.setFrameShape(QFrame.HLine)
        layout522_2_3.addWidget(self.line506_2_3)

        frame4_2Layout.addMultiCellLayout(layout522_2_3,1,1,0,4)

        self.pConfLdapSmbGetsambaUnixPoolId = QPushButton(self.frame4_2,"pConfLdapSmbGetsambaUnixPoolId")
        self.pConfLdapSmbGetsambaUnixPoolId.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pConfLdapSmbGetsambaUnixPoolId.sizePolicy().hasHeightForWidth()))
        self.pConfLdapSmbGetsambaUnixPoolId.setMaximumSize(QSize(32767,25))

        frame4_2Layout.addWidget(self.pConfLdapSmbGetsambaUnixPoolId,4,4)

        self.tCyrusUser_2_2_2 = QLabel(self.frame4_2,"tCyrusUser_2_2_2")
        self.tCyrusUser_2_2_2.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.tCyrusUser_2_2_2.sizePolicy().hasHeightForWidth()))

        frame4_2Layout.addWidget(self.tCyrusUser_2_2_2,3,0)
        spacer346 = QSpacerItem(112,16,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame4_2Layout.addMultiCell(spacer346,2,2,3,4)

        self.iConfLdapSmbDomain = QLineEdit(self.frame4_2,"iConfLdapSmbDomain")
        self.iConfLdapSmbDomain.setReadOnly(1)

        frame4_2Layout.addMultiCellWidget(self.iConfLdapSmbDomain,2,2,1,2)

        self.cbConfLdapSmbCounterEntry = QComboBox(0,self.frame4_2,"cbConfLdapSmbCounterEntry")
        self.cbConfLdapSmbCounterEntry.setMaximumSize(QSize(380,32767))

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbCounterEntry,4,4,1,3)

        self.cbConfLdapSmbSIDEntry = QComboBox(0,self.frame4_2,"cbConfLdapSmbSIDEntry")
        self.cbConfLdapSmbSIDEntry.setMaximumSize(QSize(380,32767))

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbSIDEntry,3,3,1,3)

        self.tCyrusUser_2_2 = QLabel(self.frame4_2,"tCyrusUser_2_2")
        self.tCyrusUser_2_2.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.tCyrusUser_2_2.sizePolicy().hasHeightForWidth()))

        frame4_2Layout.addWidget(self.tCyrusUser_2_2,4,0)

        self.pConfLdapSmbGetsambaDomain = QPushButton(self.frame4_2,"pConfLdapSmbGetsambaDomain")
        self.pConfLdapSmbGetsambaDomain.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pConfLdapSmbGetsambaDomain.sizePolicy().hasHeightForWidth()))
        self.pConfLdapSmbGetsambaDomain.setMaximumSize(QSize(32767,25))

        frame4_2Layout.addWidget(self.pConfLdapSmbGetsambaDomain,3,4)

        self.textLabel9_2 = QLabel(self.frame4_2,"textLabel9_2")

        frame4_2Layout.addWidget(self.textLabel9_2,2,0)

        layout522_2_3_2 = QVBoxLayout(None,0,0,"layout522_2_3_2")

        self.textLabel1_5_2_3_2 = QLabel(self.frame4_2,"textLabel1_5_2_3_2")
        layout522_2_3_2.addWidget(self.textLabel1_5_2_3_2)

        self.line506_2_3_2 = QFrame(self.frame4_2,"line506_2_3_2")
        self.line506_2_3_2.setFrameShape(QFrame.HLine)
        self.line506_2_3_2.setFrameShadow(QFrame.Sunken)
        self.line506_2_3_2.setFrameShape(QFrame.HLine)
        layout522_2_3_2.addWidget(self.line506_2_3_2)

        frame4_2Layout.addMultiCellLayout(layout522_2_3_2,5,5,0,4)

        self.tCyrusHost_2_2_2 = QLabel(self.frame4_2,"tCyrusHost_2_2_2")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_2,8,0)

        self.cbConfLdapSmbProfileType = QComboBox(0,self.frame4_2,"cbConfLdapSmbProfileType")

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbProfileType,8,8,1,2)

        self.cbConfLdapSmbPrimaryGroup = QComboBox(0,self.frame4_2,"cbConfLdapSmbPrimaryGroup")

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbPrimaryGroup,7,7,1,2)

        self.tCyrusHost_2_2_3 = QLabel(self.frame4_2,"tCyrusHost_2_2_3")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_3,7,0)

        self.cConfLdapSmbPwdMustChange = QCheckBox(self.frame4_2,"cConfLdapSmbPwdMustChange")
        self.cConfLdapSmbPwdMustChange.setChecked(1)

        frame4_2Layout.addMultiCellWidget(self.cConfLdapSmbPwdMustChange,6,6,1,4)

        WStackPageLayout_34.addWidget(self.frame4_2,1,0)
        self.wsConfig.addWidget(self.WStackPage_34,6)

        self.WStackPage_35 = QWidget(self.wsConfig,"WStackPage_35")
        WStackPageLayout_35 = QGridLayout(self.WStackPage_35,1,1,8,6,"WStackPageLayout_35")

        layout25_2_2 = QVBoxLayout(None,0,0,"layout25_2_2")

        self.textLabel3_3_2_3_2_2 = QLabel(self.WStackPage_35,"textLabel3_3_2_3_2_2")
        self.textLabel3_3_2_3_2_2.setMaximumSize(QSize(32767,21))
        layout25_2_2.addWidget(self.textLabel3_3_2_3_2_2)

        self.line23_2_2 = QFrame(self.WStackPage_35,"line23_2_2")
        self.line23_2_2.setFrameShape(QFrame.HLine)
        self.line23_2_2.setFrameShadow(QFrame.Sunken)
        self.line23_2_2.setFrameShape(QFrame.HLine)
        layout25_2_2.addWidget(self.line23_2_2)

        WStackPageLayout_35.addMultiCellLayout(layout25_2_2,0,0,0,1)
        spacer698 = QSpacerItem(20,63,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_35.addItem(spacer698,2,0)
        spacer1299 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_35.addItem(spacer1299,1,1)

        self.frame307 = QFrame(self.WStackPage_35,"frame307")
        self.frame307.setFrameShape(QFrame.NoFrame)
        self.frame307.setFrameShadow(QFrame.Raised)
        frame307Layout = QGridLayout(self.frame307,1,1,12,6,"frame307Layout")

        self.textLabel1_3_2_3_2_3 = QLabel(self.frame307,"textLabel1_3_2_3_2_3")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_3,1,0)

        self.textLabel1_3_2_3_2_2_6 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_6")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_6,2,0)

        self.textLabel1_3_2_3_2_2_3_3_3 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_3_3_3")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_3_3_3,9,0)

        self.textLabel1_3_2_3_2_2_3_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_3_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_3_2,5,0)

        self.textLabel1_3_2_3_2_2_2_3_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_2_3_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_2_3_2,8,0)

        self.textLabel1_3_2_3_2_2_3_3_2_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_3_3_2_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_3_3_2_2,10,0)

        self.textLabel1_3_2_3_2_2_4_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_4_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_4_2,6,0)

        self.textLabel1_3_2_3_2_2_2_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_2_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_2_2,4,0)

        self.textLabel1_3_2_3_2_2_5_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_5_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_5_2,7,0)

        layout522_2 = QVBoxLayout(None,0,0,"layout522_2")

        self.textLabel1_5_2 = QLabel(self.frame307,"textLabel1_5_2")
        layout522_2.addWidget(self.textLabel1_5_2)

        self.line506_2 = QFrame(self.frame307,"line506_2")
        self.line506_2.setFrameShape(QFrame.HLine)
        self.line506_2.setFrameShadow(QFrame.Sunken)
        self.line506_2.setFrameShape(QFrame.HLine)
        layout522_2.addWidget(self.line506_2)

        frame307Layout.addMultiCellLayout(layout522_2,3,3,0,2)

        layout522 = QVBoxLayout(None,0,0,"layout522")

        self.textLabel1_5 = QLabel(self.frame307,"textLabel1_5")
        layout522.addWidget(self.textLabel1_5)

        self.line506 = QFrame(self.frame307,"line506")
        self.line506.setFrameShape(QFrame.HLine)
        self.line506.setFrameShadow(QFrame.Sunken)
        self.line506.setFrameShape(QFrame.HLine)
        layout522.addWidget(self.line506)

        frame307Layout.addMultiCellLayout(layout522,0,0,0,2)

        self.iConfLdapSMBlockoutWindow = QLineEdit(self.frame307,"iConfLdapSMBlockoutWindow")
        self.iConfLdapSMBlockoutWindow.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBlockoutWindow.sizePolicy().hasHeightForWidth()))
        self.iConfLdapSMBlockoutWindow.setMaximumSize(QSize(90,32767))

        frame307Layout.addWidget(self.iConfLdapSMBlockoutWindow,10,1)

        self.iConfLdapSMBlockoutDuration = QLineEdit(self.frame307,"iConfLdapSMBlockoutDuration")
        self.iConfLdapSMBlockoutDuration.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBlockoutDuration.sizePolicy().hasHeightForWidth()))
        self.iConfLdapSMBlockoutDuration.setMaximumSize(QSize(90,32767))

        frame307Layout.addWidget(self.iConfLdapSMBlockoutDuration,9,1)

        self.iConfLdapSMBlockout = QLineEdit(self.frame307,"iConfLdapSMBlockout")
        self.iConfLdapSMBlockout.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBlockout.sizePolicy().hasHeightForWidth()))
        self.iConfLdapSMBlockout.setMaximumSize(QSize(90,32767))

        frame307Layout.addWidget(self.iConfLdapSMBlockout,8,1)

        self.iConfLdapSMBminPwdAge = QLineEdit(self.frame307,"iConfLdapSMBminPwdAge")
        self.iConfLdapSMBminPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBminPwdAge.sizePolicy().hasHeightForWidth()))
        self.iConfLdapSMBminPwdAge.setMaximumSize(QSize(90,32767))

        frame307Layout.addWidget(self.iConfLdapSMBminPwdAge,7,1)

        self.iConfLdapSMBmaxPwdAge = QLineEdit(self.frame307,"iConfLdapSMBmaxPwdAge")
        self.iConfLdapSMBmaxPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBmaxPwdAge.sizePolicy().hasHeightForWidth()))
        self.iConfLdapSMBmaxPwdAge.setMaximumSize(QSize(90,32767))

        frame307Layout.addWidget(self.iConfLdapSMBmaxPwdAge,6,1)

        self.iConfLdapSMBpwdHistLenght = QLineEdit(self.frame307,"iConfLdapSMBpwdHistLenght")
        self.iConfLdapSMBpwdHistLenght.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBpwdHistLenght.sizePolicy().hasHeightForWidth()))
        self.iConfLdapSMBpwdHistLenght.setMaximumSize(QSize(90,32767))

        frame307Layout.addWidget(self.iConfLdapSMBpwdHistLenght,5,1)

        self.iConfLdapSMBminPwdLength = QLineEdit(self.frame307,"iConfLdapSMBminPwdLength")
        self.iConfLdapSMBminPwdLength.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBminPwdLength.sizePolicy().hasHeightForWidth()))
        self.iConfLdapSMBminPwdLength.setMaximumSize(QSize(90,32767))

        frame307Layout.addWidget(self.iConfLdapSMBminPwdLength,4,1)

        self.cbConfLdapSMBminPwdAge = QComboBox(0,self.frame307,"cbConfLdapSMBminPwdAge")
        self.cbConfLdapSMBminPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapSMBminPwdAge.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.cbConfLdapSMBminPwdAge,7,2)

        self.cbConfLdapSMBlockoutDuration = QComboBox(0,self.frame307,"cbConfLdapSMBlockoutDuration")
        self.cbConfLdapSMBlockoutDuration.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapSMBlockoutDuration.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.cbConfLdapSMBlockoutDuration,9,2)

        self.cbConfLdapSMBmaxPwdAge = QComboBox(0,self.frame307,"cbConfLdapSMBmaxPwdAge")
        self.cbConfLdapSMBmaxPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapSMBmaxPwdAge.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.cbConfLdapSMBmaxPwdAge,6,2)

        self.cbConfLdapSMBlockoutWindow = QComboBox(0,self.frame307,"cbConfLdapSMBlockoutWindow")
        self.cbConfLdapSMBlockoutWindow.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapSMBlockoutWindow.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.cbConfLdapSMBlockoutWindow,10,2)

        self.iConfLdapSMBgidNumber = QLineEdit(self.frame307,"iConfLdapSMBgidNumber")
        self.iConfLdapSMBgidNumber.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBgidNumber.sizePolicy().hasHeightForWidth()))
        self.iConfLdapSMBgidNumber.setMaximumSize(QSize(90,32767))

        frame307Layout.addWidget(self.iConfLdapSMBgidNumber,2,1)

        self.iConfLdapSMBuidNumber = QLineEdit(self.frame307,"iConfLdapSMBuidNumber")
        self.iConfLdapSMBuidNumber.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBuidNumber.sizePolicy().hasHeightForWidth()))
        self.iConfLdapSMBuidNumber.setMaximumSize(QSize(90,32767))

        frame307Layout.addWidget(self.iConfLdapSMBuidNumber,1,1)

        WStackPageLayout_35.addWidget(self.frame307,1,0)
        self.wsConfig.addWidget(self.WStackPage_35,7)

        self.WStackPage_36 = QWidget(self.wsConfig,"WStackPage_36")
        WStackPageLayout_36 = QGridLayout(self.WStackPage_36,1,1,8,6,"WStackPageLayout_36")

        layout24 = QVBoxLayout(None,0,0,"layout24")

        self.textLabel3_3_2_2 = QLabel(self.WStackPage_36,"textLabel3_3_2_2")
        self.textLabel3_3_2_2.setMaximumSize(QSize(32767,21))
        layout24.addWidget(self.textLabel3_3_2_2)

        self.line22_4 = QFrame(self.WStackPage_36,"line22_4")
        self.line22_4.setFrameShape(QFrame.HLine)
        self.line22_4.setFrameShadow(QFrame.Sunken)
        self.line22_4.setFrameShape(QFrame.HLine)
        layout24.addWidget(self.line22_4)

        WStackPageLayout_36.addLayout(layout24,0,0)
        spacer48_2 = QSpacerItem(21,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_36.addItem(spacer48_2,2,0)

        self.frame7_2 = QFrame(self.WStackPage_36,"frame7_2")
        self.frame7_2.setFrameShape(QFrame.NoFrame)
        self.frame7_2.setFrameShadow(QFrame.Raised)
        frame7_2Layout = QGridLayout(self.frame7_2,1,1,12,6,"frame7_2Layout")

        self.cConfLdapSchemaAddAttr = QCheckBox(self.frame7_2,"cConfLdapSchemaAddAttr")
        self.cConfLdapSchemaAddAttr.setChecked(1)

        frame7_2Layout.addWidget(self.cConfLdapSchemaAddAttr,1,0)

        self.cConfLdapSchemaDelAttr = QCheckBox(self.frame7_2,"cConfLdapSchemaDelAttr")
        self.cConfLdapSchemaDelAttr.setChecked(1)

        frame7_2Layout.addWidget(self.cConfLdapSchemaDelAttr,1,1)

        layout47 = QVBoxLayout(None,0,0,"layout47")

        self.textLabel1_9 = QLabel(self.frame7_2,"textLabel1_9")
        layout47.addWidget(self.textLabel1_9)

        self.line43 = QFrame(self.frame7_2,"line43")
        self.line43.setFrameShape(QFrame.HLine)
        self.line43.setFrameShadow(QFrame.Sunken)
        self.line43.setFrameShape(QFrame.HLine)
        layout47.addWidget(self.line43)

        frame7_2Layout.addMultiCellLayout(layout47,0,0,0,1)

        self.fConfLdapSchema = QFrame(self.frame7_2,"fConfLdapSchema")
        self.fConfLdapSchema.setFrameShape(QFrame.NoFrame)
        self.fConfLdapSchema.setFrameShadow(QFrame.Raised)
        fConfLdapSchemaLayout = QGridLayout(self.fConfLdapSchema,1,1,0,6,"fConfLdapSchemaLayout")

        self.pConfLdapSchemaDelItem = QPushButton(self.fConfLdapSchema,"pConfLdapSchemaDelItem")
        self.pConfLdapSchemaDelItem.setEnabled(0)
        self.pConfLdapSchemaDelItem.setMinimumSize(QSize(30,0))
        self.pConfLdapSchemaDelItem.setMaximumSize(QSize(30,32767))

        fConfLdapSchemaLayout.addWidget(self.pConfLdapSchemaDelItem,1,3)

        self.pConfLdapSchemaAddItem = QPushButton(self.fConfLdapSchema,"pConfLdapSchemaAddItem")
        self.pConfLdapSchemaAddItem.setMinimumSize(QSize(30,0))
        self.pConfLdapSchemaAddItem.setMaximumSize(QSize(30,32767))

        fConfLdapSchemaLayout.addWidget(self.pConfLdapSchemaAddItem,1,2)

        self.iConfLdapSchemaAttr = QLineEdit(self.fConfLdapSchema,"iConfLdapSchemaAttr")

        fConfLdapSchemaLayout.addWidget(self.iConfLdapSchemaAttr,1,0)

        self.iConfLdapSchemaValue = QLineEdit(self.fConfLdapSchema,"iConfLdapSchemaValue")
        self.iConfLdapSchemaValue.setEnabled(0)

        fConfLdapSchemaLayout.addWidget(self.iConfLdapSchemaValue,1,1)
        spacer62 = QSpacerItem(82,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fConfLdapSchemaLayout.addItem(spacer62,1,4)

        self.lvConfLdapSchema = QListView(self.fConfLdapSchema,"lvConfLdapSchema")
        self.lvConfLdapSchema.addColumn(self.__tr("Attribute"))
        self.lvConfLdapSchema.addColumn(self.__tr("Value"))
        self.lvConfLdapSchema.setMinimumSize(QSize(0,200))
        self.lvConfLdapSchema.setAllColumnsShowFocus(1)
        self.lvConfLdapSchema.setRootIsDecorated(1)
        self.lvConfLdapSchema.setResizeMode(QListView.AllColumns)

        fConfLdapSchemaLayout.addMultiCellWidget(self.lvConfLdapSchema,0,0,0,4)

        frame7_2Layout.addMultiCellWidget(self.fConfLdapSchema,2,2,0,1)

        self.line42 = QFrame(self.frame7_2,"line42")
        self.line42.setFrameShape(QFrame.HLine)
        self.line42.setFrameShadow(QFrame.Sunken)
        self.line42.setFrameShape(QFrame.HLine)

        frame7_2Layout.addMultiCellWidget(self.line42,3,3,0,1)

        WStackPageLayout_36.addWidget(self.frame7_2,1,0)
        self.wsConfig.addWidget(self.WStackPage_36,8)

        self.WStackPage_37 = QWidget(self.wsConfig,"WStackPage_37")
        WStackPageLayout_37 = QGridLayout(self.WStackPage_37,1,1,8,6,"WStackPageLayout_37")
        self.wsConfig.addWidget(self.WStackPage_37,9)

        self.WStackPage_38 = QWidget(self.wsConfig,"WStackPage_38")
        WStackPageLayout_38 = QGridLayout(self.WStackPage_38,1,1,8,6,"WStackPageLayout_38")

        layout24_2_5 = QVBoxLayout(None,0,0,"layout24_2_5")

        self.textLabel3_3_2_2_2_5 = QLabel(self.WStackPage_38,"textLabel3_3_2_2_2_5")
        self.textLabel3_3_2_2_2_5.setMaximumSize(QSize(32767,21))
        layout24_2_5.addWidget(self.textLabel3_3_2_2_2_5)

        self.line22_4_2_5 = QFrame(self.WStackPage_38,"line22_4_2_5")
        self.line22_4_2_5.setFrameShape(QFrame.HLine)
        self.line22_4_2_5.setFrameShadow(QFrame.Sunken)
        self.line22_4_2_5.setFrameShape(QFrame.HLine)
        layout24_2_5.addWidget(self.line22_4_2_5)

        WStackPageLayout_38.addMultiCellLayout(layout24_2_5,0,0,0,1)
        spacer36_3_2 = QSpacerItem(55,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_38.addItem(spacer36_3_2,1,1)
        spacer36_2 = QSpacerItem(55,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_38.addItem(spacer36_2,2,1)
        spacer89_2 = QSpacerItem(20,270,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_38.addItem(spacer89_2,3,0)

        self.frame26 = QFrame(self.WStackPage_38,"frame26")
        self.frame26.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.frame26.sizePolicy().hasHeightForWidth()))
        self.frame26.setFrameShape(QFrame.NoFrame)
        self.frame26.setFrameShadow(QFrame.Raised)
        frame26Layout = QGridLayout(self.frame26,1,1,12,6,"frame26Layout")

        self.textLabel2_5_3 = QLabel(self.frame26,"textLabel2_5_3")

        frame26Layout.addWidget(self.textLabel2_5_3,1,0)

        self.textLabel2_5_2_3 = QLabel(self.frame26,"textLabel2_5_2_3")
        self.textLabel2_5_2_3.setMinimumSize(QSize(90,0))

        frame26Layout.addWidget(self.textLabel2_5_2_3,0,0)

        self.iAnnotationValueServer = QLineEdit(self.frame26,"iAnnotationValueServer")
        self.iAnnotationValueServer.setMinimumSize(QSize(140,0))

        frame26Layout.addWidget(self.iAnnotationValueServer,1,1)

        self.cbImapAnnotationServer = QComboBox(0,self.frame26,"cbImapAnnotationServer")
        self.cbImapAnnotationServer.setEditable(1)

        frame26Layout.addMultiCellWidget(self.cbImapAnnotationServer,0,0,1,2)

        self.pImapAnnotationServer = QPushButton(self.frame26,"pImapAnnotationServer")
        self.pImapAnnotationServer.setMaximumSize(QSize(40,32767))

        frame26Layout.addWidget(self.pImapAnnotationServer,1,2)

        WStackPageLayout_38.addMultiCellWidget(self.frame26,1,2,0,0)
        self.wsConfig.addWidget(self.WStackPage_38,10)

        self.WStackPage_39 = QWidget(self.wsConfig,"WStackPage_39")
        WStackPageLayout_39 = QGridLayout(self.WStackPage_39,1,1,8,6,"WStackPageLayout_39")

        layout25_2_2_3 = QVBoxLayout(None,0,0,"layout25_2_2_3")

        self.textLabel3_3_2_3_2_2_3 = QLabel(self.WStackPage_39,"textLabel3_3_2_3_2_2_3")
        self.textLabel3_3_2_3_2_2_3.setMaximumSize(QSize(32767,21))
        layout25_2_2_3.addWidget(self.textLabel3_3_2_3_2_2_3)

        self.line23_2_2_3 = QFrame(self.WStackPage_39,"line23_2_2_3")
        self.line23_2_2_3.setFrameShape(QFrame.HLine)
        self.line23_2_2_3.setFrameShadow(QFrame.Sunken)
        self.line23_2_2_3.setFrameShape(QFrame.HLine)
        layout25_2_2_3.addWidget(self.line23_2_2_3)

        WStackPageLayout_39.addMultiCellLayout(layout25_2_2_3,0,0,0,1)
        spacer1299_2 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_39.addItem(spacer1299_2,1,1)

        self.frame307_3 = QFrame(self.WStackPage_39,"frame307_3")
        self.frame307_3.setFrameShape(QFrame.NoFrame)
        self.frame307_3.setFrameShadow(QFrame.Raised)
        frame307_3Layout = QGridLayout(self.frame307_3,1,1,12,5,"frame307_3Layout")

        layout522_4 = QVBoxLayout(None,0,0,"layout522_4")

        self.textLabel1_5_4 = QLabel(self.frame307_3,"textLabel1_5_4")
        layout522_4.addWidget(self.textLabel1_5_4)

        self.line506_4 = QFrame(self.frame307_3,"line506_4")
        self.line506_4.setFrameShape(QFrame.HLine)
        self.line506_4.setFrameShadow(QFrame.Sunken)
        self.line506_4.setFrameShape(QFrame.HLine)
        layout522_4.addWidget(self.line506_4)

        frame307_3Layout.addMultiCellLayout(layout522_4,0,0,0,2)

        self.textLabel1_3_2_2_2_3_2_4 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_3_2_4")

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_3_2_4,3,0)

        self.textLabel1_3_2_2_2_3_2_2_3 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_3_2_2_3")

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_3_2_2_3,4,0)

        self.textLabel1_3_2_2_2_3_2_2_2_3 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_3_2_2_2_3")

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_3_2_2_2_3,5,0)

        self.textLabel1_3_2_3_2_2_5_3_2 = QLabel(self.frame307_3,"textLabel1_3_2_3_2_2_5_3_2")

        frame307_3Layout.addWidget(self.textLabel1_3_2_3_2_2_5_3_2,2,0)

        self.iConfLdapDhcpDefaultLeaseTime = QLineEdit(self.frame307_3,"iConfLdapDhcpDefaultLeaseTime")
        self.iConfLdapDhcpDefaultLeaseTime.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapDhcpDefaultLeaseTime.sizePolicy().hasHeightForWidth()))
        self.iConfLdapDhcpDefaultLeaseTime.setMaximumSize(QSize(90,32767))

        frame307_3Layout.addWidget(self.iConfLdapDhcpDefaultLeaseTime,1,1)

        self.iConfLdapDhcpMaxLeaseTime = QLineEdit(self.frame307_3,"iConfLdapDhcpMaxLeaseTime")
        self.iConfLdapDhcpMaxLeaseTime.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapDhcpMaxLeaseTime.sizePolicy().hasHeightForWidth()))
        self.iConfLdapDhcpMaxLeaseTime.setMaximumSize(QSize(90,32767))

        frame307_3Layout.addWidget(self.iConfLdapDhcpMaxLeaseTime,2,1)

        self.cbConfLdapDhcpDefaultLeaseTime = QComboBox(0,self.frame307_3,"cbConfLdapDhcpDefaultLeaseTime")
        self.cbConfLdapDhcpDefaultLeaseTime.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapDhcpDefaultLeaseTime.sizePolicy().hasHeightForWidth()))

        frame307_3Layout.addWidget(self.cbConfLdapDhcpDefaultLeaseTime,1,2)

        self.cbConfLdapDhcpMaxLeaseTime = QComboBox(0,self.frame307_3,"cbConfLdapDhcpMaxLeaseTime")
        self.cbConfLdapDhcpMaxLeaseTime.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapDhcpMaxLeaseTime.sizePolicy().hasHeightForWidth()))

        frame307_3Layout.addWidget(self.cbConfLdapDhcpMaxLeaseTime,2,2)

        self.iConfLdapDhcpDomainName = QLineEdit(self.frame307_3,"iConfLdapDhcpDomainName")

        frame307_3Layout.addMultiCellWidget(self.iConfLdapDhcpDomainName,3,3,1,2)

        self.iConfLdapDhcpNetbiosServers = QLineEdit(self.frame307_3,"iConfLdapDhcpNetbiosServers")

        frame307_3Layout.addMultiCellWidget(self.iConfLdapDhcpNetbiosServers,4,4,1,2)

        self.iConfLdapDhcpDNSservers = QLineEdit(self.frame307_3,"iConfLdapDhcpDNSservers")

        frame307_3Layout.addMultiCellWidget(self.iConfLdapDhcpDNSservers,5,5,1,2)

        layout522_2_2 = QVBoxLayout(None,0,0,"layout522_2_2")

        self.textLabel1_5_2_2 = QLabel(self.frame307_3,"textLabel1_5_2_2")
        layout522_2_2.addWidget(self.textLabel1_5_2_2)

        self.line506_2_2 = QFrame(self.frame307_3,"line506_2_2")
        self.line506_2_2.setFrameShape(QFrame.HLine)
        self.line506_2_2.setFrameShadow(QFrame.Sunken)
        self.line506_2_2.setFrameShape(QFrame.HLine)
        layout522_2_2.addWidget(self.line506_2_2)

        frame307_3Layout.addMultiCellLayout(layout522_2_2,6,6,0,2)

        self.cbConfLdapDhcpNetmask = QComboBox(0,self.frame307_3,"cbConfLdapDhcpNetmask")

        frame307_3Layout.addMultiCellWidget(self.cbConfLdapDhcpNetmask,12,12,1,2)

        self.textLabel1_3_2_2_2_3_2_3_3_2_3 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_3_2_3_3_2_3")

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_2_3,12,0)

        self.textLabel1_3_2_2_2_3_2_3_2_3 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_3_2_3_2_3")

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3_2_3,11,0)

        self.iConfLdapDhcpNetwork = QLineEdit(self.frame307_3,"iConfLdapDhcpNetwork")

        frame307_3Layout.addMultiCellWidget(self.iConfLdapDhcpNetwork,9,9,1,2)

        self.iConfLdapDhcpRange = QLineEdit(self.frame307_3,"iConfLdapDhcpRange")
        self.iConfLdapDhcpRange.setCursorPosition(0)

        frame307_3Layout.addMultiCellWidget(self.iConfLdapDhcpRange,11,11,1,2)

        self.iConfLdapDhcpGateway = QLineEdit(self.frame307_3,"iConfLdapDhcpGateway")

        frame307_3Layout.addMultiCellWidget(self.iConfLdapDhcpGateway,13,13,1,2)

        self.iConfLdapDhcpBroadcast = QLineEdit(self.frame307_3,"iConfLdapDhcpBroadcast")

        frame307_3Layout.addMultiCellWidget(self.iConfLdapDhcpBroadcast,10,10,1,2)

        self.textLabel1_3_2_2_2_3_2_3_3_3_3 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_3_2_3_3_3_3")

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_3_3,13,0)

        self.cbConfLdapDhcpInterface = QComboBox(0,self.frame307_3,"cbConfLdapDhcpInterface")
        self.cbConfLdapDhcpInterface.setEditable(1)

        frame307_3Layout.addMultiCellWidget(self.cbConfLdapDhcpInterface,7,7,1,2)

        self.textLabel1_3_2_2_2_3_2_2_2_2_2 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_3_2_2_2_2_2")

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_3_2_2_2_2_2,7,0)

        self.textLabel1_3_2_2_2_3_2_3_5 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_3_2_3_5")

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3_5,9,0)

        self.textLabel1_3_2_2_2_3_2_3_3_5 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_3_2_3_3_5")

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_3_2_3_3_5,10,0)

        self.textLabel1_3_2_2_2_2_2_2 = QLabel(self.frame307_3,"textLabel1_3_2_2_2_2_2_2")
        self.textLabel1_3_2_2_2_2_2_2.setMinimumSize(QSize(200,0))

        frame307_3Layout.addWidget(self.textLabel1_3_2_2_2_2_2_2,1,0)

        WStackPageLayout_39.addWidget(self.frame307_3,1,0)
        spacer698_2 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_39.addItem(spacer698_2,2,0)
        self.wsConfig.addWidget(self.WStackPage_39,11)

        WStackPageLayout_28.addWidget(self.wsConfig,0,1)

        layout528 = QHBoxLayout(None,0,6,"layout528")

        self.pSaveConfig = QPushButton(self.WStackPage_28,"pSaveConfig")
        self.pSaveConfig.setMinimumSize(QSize(135,0))
        self.pSaveConfig.setMaximumSize(QSize(135,26))
        layout528.addWidget(self.pSaveConfig)
        spacer7 = QSpacerItem(423,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout528.addItem(spacer7)

        WStackPageLayout_28.addLayout(layout528,2,1)

        self.line512 = QFrame(self.WStackPage_28,"line512")
        self.line512.setFrameShape(QFrame.HLine)
        self.line512.setFrameShadow(QFrame.Sunken)
        self.line512.setFrameShape(QFrame.HLine)

        WStackPageLayout_28.addWidget(self.line512,1,1)
        self.wsKorreio.addWidget(self.WStackPage_28,7)

        dKorreioLayout.addWidget(self.wsKorreio,0,0)



        self.menuBar = QMenuBar(self,"menuBar")



        self.languageChange()

        self.resize(QSize(891,632).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)

        self.connect(self.bgLog,SIGNAL("clicked(int)"),self.config_log_mode)
        self.connect(self.cbACL,SIGNAL("activated(int)"),self.imap_acl_wizard)
        self.connect(self.cbConfLdapSmbDomain,SIGNAL("activated(int)"),self.config_smb_set_domain)
        self.connect(self.cbConfLdapSmbProfileType,SIGNAL("activated(int)"),self.config_ldap_smb_perfil_changed)
        self.connect(self.cbConfLdapSmbSIDEntry,SIGNAL("activated(int)"),self.config_ldap_smb_sambaDomain_clicked)
        self.connect(self.cbCyrusConnection,SIGNAL("activated(int)"),self.config_imap_set_connection)
        self.connect(self.cbCyrusMode,SIGNAL("activated(int)"),self.config_imap_set_port)
        self.connect(self.cbImapAnnotation,SIGNAL("textChanged(const QString&)"),self.imap_annotation_user_get)
        self.connect(self.cbImapAnnotationServer,SIGNAL("textChanged(const QString&)"),self.imap_annotation_server_get)
        self.connect(self.cbLdapBaseDN,SIGNAL("activated(int)"),self.config_ldap_set_admin)
        self.connect(self.cbLdapConnection,SIGNAL("activated(int)"),self.config_ldap_set_connection)
        self.connect(self.cbLdapFormDhcpType,SIGNAL("activated(int)"),self.ldap_wizard_dhcp_type)
        self.connect(self.cbLdapFormGroupType,SIGNAL("activated(int)"),self.ldap_wizard_group_type)
        self.connect(self.cbLdapFormProfileType,SIGNAL("activated(int)"),self.ldap_wizard_sambaSamAccount_perfil_clicked)
        self.connect(self.cbLdapFormSambaDomain,SIGNAL("activated(int)"),self.ldap_wizard_sambaSamAccount_domain_clicked)
        self.connect(self.cbLdapMode,SIGNAL("activated(int)"),self.config_ldap_set_port)
        self.connect(self.cbServicesPostconf,SIGNAL("activated(int)"),self.services_postconf_changed)
        self.connect(self.cbSieveScript,SIGNAL("activated(int)"),self.sieve_get_script)
        self.connect(self.cbSSHConnection,SIGNAL("activated(int)"),self.config_ssh_set_connection)
        self.connect(self.cConfLdapSchemaAddAttr,SIGNAL("clicked()"),self.config_ldap_schema_checked)
        self.connect(self.cConfLdapSchemaDelAttr,SIGNAL("clicked()"),self.config_ldap_schema_checked)
        self.connect(self.cLdapFormAst,SIGNAL("clicked()"),self.ldap_wizard_astSipUser_enable)
        self.connect(self.cLdapFormPosix,SIGNAL("clicked()"),self.ldap_wizard_posixAccount_enable)
        self.connect(self.cLdapFormRadius,SIGNAL("clicked()"),self.ldap_wizard_radiusProfile_enable)
        self.connect(self.cLdapFormSamba,SIGNAL("clicked()"),self.ldap_wizard_sambaSamAccount_enable)
        self.connect(self.iLdapFormMail,SIGNAL("textChanged(const QString&)"),self.ldap_wizard_inetOrgPerson_mail_changed)
        self.connect(self.iLdapFormUid,SIGNAL("textChanged(const QString&)"),self.ldap_wizard_uid_changed)
        self.connect(self.lvConfig,SIGNAL("selectionChanged()"),self.config_change_widgetstack)
        self.connect(self.lvConfLdapSchema,SIGNAL("currentChanged(QListViewItem*)"),self.config_ldap_schema)
        self.connect(self.lvImap,SIGNAL("currentChanged(QListViewItem*)"),self.imap_mailbox_clicked)
        self.connect(self.lvImap,SIGNAL("itemRenamed(QListViewItem*,int)"),self.imap_rename)
        self.connect(self.lvImap,SIGNAL("contextMenuRequested(QListViewItem*,const QPoint&,int)"),self.imap_menu)
        self.connect(self.lvImapAcl,SIGNAL("currentChanged(QListViewItem*)"),self.imap_acl_clicked)
        self.connect(self.lvImapPartition,SIGNAL("contextMenuRequested(QListViewItem*,const QPoint&,int)"),self.imap_partition_menu)
        self.connect(self.lvLdap,SIGNAL("selectionChanged()"),self.ldap_dn_clicked)
        self.connect(self.lvLdap,SIGNAL("contextMenuRequested(QListViewItem*,const QPoint&,int)"),self.ldap_menu)
        self.connect(self.lvLdap,SIGNAL("itemRenamed(QListViewItem*,int)"),self.ldap_rename_rdn)
        self.connect(self.lvLdapAttr,SIGNAL("doubleClicked(QListViewItem*)"),self.ldap_rename_attr_value)
        self.connect(self.lvQueue,SIGNAL("currentChanged(QListViewItem*)"),self.queue_get_message)
        self.connect(self.lvQueue,SIGNAL("contextMenuRequested(QListViewItem*,const QPoint&,int)"),self.queue_menu)
        self.connect(self.lvServices,SIGNAL("selectionChanged()"),self.services_change_widgetstack)
        self.connect(self.lvServices,SIGNAL("contextMenuRequested(QListViewItem*,const QPoint&,int)"),self.services_menu)
        self.connect(self.lvSieve,SIGNAL("contextMenuRequested(QListViewItem*,const QPoint&,int)"),self.sieve_menu)
        self.connect(self.lvSieve,SIGNAL("currentChanged(QListViewItem*)"),self.sieve_user_clicked)
        self.connect(self.pConfDelImapConnection,SIGNAL("clicked()"),self.config_imap_del_connection)
        self.connect(self.pConfDelLdapConnection,SIGNAL("clicked()"),self.config_ldap_del_connection)
        self.connect(self.pConfDelSshConnection,SIGNAL("clicked()"),self.config_ssh_del_connection)
        self.connect(self.pConfImapFoldersAdd,SIGNAL("clicked()"),self.config_imap_add_default_folder)
        self.connect(self.pConfImapFoldersDel,SIGNAL("clicked()"),self.config_imap_del_default_folder)
        self.connect(self.pConfLdapFilterAdd,SIGNAL("clicked()"),self.config_ldap_filter_add)
        self.connect(self.pConfLdapFilterDel,SIGNAL("clicked()"),self.config_ldap_filter_del)
        self.connect(self.pConfLdapSchemaAddItem,SIGNAL("clicked()"),self.config_ldap_schema_add_attr)
        self.connect(self.pConfLdapSchemaDelItem,SIGNAL("clicked()"),self.config_ldap_schema_del_attr)
        self.connect(self.pConfLdapSmbDomainDel,SIGNAL("clicked()"),self.config_smb_del_domain)
        self.connect(self.pConfLdapSmbGetsambaDomain,SIGNAL("clicked()"),self.config_ldap_smb_get_sambaDomain)
        self.connect(self.pConfLdapSmbGetsambaUnixPoolId,SIGNAL("clicked()"),self.config_ldap_smb_get_sambaUnixIdPool)
        self.connect(self.pCyrAdd,SIGNAL("clicked()"),self.imap_add)
        self.connect(self.pCyrDelete,SIGNAL("clicked()"),self.imap_delete)
        self.connect(self.pCyrReconstruct,SIGNAL("clicked()"),self.imap_reconstruct)
        self.connect(self.pGetBaseDN,SIGNAL("clicked()"),self.config_ldap_get_basedn)
        self.connect(self.pImapAclAdd,SIGNAL("clicked()"),self.imap_acl_add)
        self.connect(self.pImapAclDel,SIGNAL("clicked()"),self.imap_acl_del)
        self.connect(self.pImapAnnotation,SIGNAL("clicked()"),self.imap_annotation_user_set)
        self.connect(self.pImapAnnotationServer,SIGNAL("clicked()"),self.imap_annotation_server_set)
        self.connect(self.pImapPartitionMove,SIGNAL("clicked()"),self.imap_partition_move)
        self.connect(self.pImapPartitionSearch,SIGNAL("clicked()"),self.imap_partition_search)
        self.connect(self.pImapQuota,SIGNAL("clicked()"),self.imap_set_quota)
        self.connect(self.pImapSearch,SIGNAL("clicked()"),self.imap_search)
        self.connect(self.pLdapAddAttr,SIGNAL("clicked()"),self.ldap_add_attr)
        self.connect(self.pLdapAddDhcp,SIGNAL("clicked()"),self.ldap_wizard_dhcp_insert)
        self.connect(self.pLdapAddOu,SIGNAL("clicked()"),self.ldap_wizard_insert_ou)
        self.connect(self.pLdapAddUser,SIGNAL("clicked()"),self.ldap_wizard_insert_user)
        self.connect(self.pLdapDelete,SIGNAL("clicked()"),self.ldap_remove_entry)
        self.connect(self.pLdapDeleteAttr,SIGNAL("clicked()"),self.ldap_remove_attr)
        self.connect(self.pLdapDhcpPopulate,SIGNAL("clicked()"),self.ldap_dhcp_populate)
        self.connect(self.pLdapFormBack,SIGNAL("clicked()"),self.ldap_wizard_user_back)
        self.connect(self.pLdapFormNext,SIGNAL("clicked()"),self.ldap_wizard_user_next)
        self.connect(self.pLdapGetUidNumber,SIGNAL("clicked()"),self.ldap_wizard_posixAccount_get_uidNumber)
        self.connect(self.pLdapModify,SIGNAL("clicked()"),self.ldap_modify_clicked)
        self.connect(self.pLdapPasswd,SIGNAL("clicked()"),self.ldap_passwd)
        self.connect(self.pLdapSambaPopulate,SIGNAL("clicked()"),self.ldap_samba_populate)
        self.connect(self.pLdapSearch,SIGNAL("clicked()"),self.ldap_search)
        self.connect(self.pQueueLoad,SIGNAL("clicked()"),self.queue_load)
        self.connect(self.pSaveConfig,SIGNAL("clicked()"),self.config_save)
        self.connect(self.pServicesFileOpen,SIGNAL("clicked()"),self.services_file_open)
        self.connect(self.pServicesFilePostmap,SIGNAL("clicked()"),self.services_postmap)
        self.connect(self.pServicesFileSave,SIGNAL("clicked()"),self.services_file_save)
        self.connect(self.pServicesPostconfSave,SIGNAL("clicked()"),self.services_postconf_save)
        self.connect(self.pServiceStatus,SIGNAL("clicked()"),self.services_status)
        self.connect(self.pSieveSearch,SIGNAL("clicked()"),self.sieve_search)
        self.connect(self.rbImapMailboxMode,SIGNAL("clicked()"),self.imap_form_clear)
        self.connect(self.rbImapMailboxMode2,SIGNAL("clicked()"),self.imap_form_clear)
        self.connect(self.rbImapPartMailboxMode,SIGNAL("clicked()"),self.imap_partition_form_clear)
        self.connect(self.rbImapPartMailboxMode2,SIGNAL("clicked()"),self.imap_partition_form_clear)
        self.connect(self.rbServicesPostconfAll,SIGNAL("clicked()"),self.services_postconf)
        self.connect(self.rbServicesPostconfD,SIGNAL("clicked()"),self.services_postconf)
        self.connect(self.rbServicesPostconfN,SIGNAL("clicked()"),self.services_postconf)
        self.connect(self.lbSieveScripts,SIGNAL("currentChanged(QListBoxItem*)"),self.sieve_template_show)
        self.connect(self.lvImapPartition,SIGNAL("selectionChanged()"),self.imap_partition_size)
        self.connect(self.pSieveScriptActive,SIGNAL("clicked()"),self.sieve_set_script)
        self.connect(self.pSieveScriptDisable,SIGNAL("clicked()"),self.sieve_unset_script)
        self.connect(self.pSieveScriptRemove,SIGNAL("clicked()"),self.sieve_del_script)
        self.connect(self.lvLdapAttr,SIGNAL("contextMenuRequested(QListViewItem*,const QPoint&,int)"),self.ldap_menu_attr)

        self.setTabOrder(self.cbLdapFilter,self.pLdapSearch)
        self.setTabOrder(self.pLdapSearch,self.lvLdap)
        self.setTabOrder(self.lvLdap,self.pLdapDelete)
        self.setTabOrder(self.pLdapDelete,self.lvLdapAttr)
        self.setTabOrder(self.lvLdapAttr,self.cbLdapAttr)
        self.setTabOrder(self.cbLdapAttr,self.cbLdapValue)
        self.setTabOrder(self.cbLdapValue,self.pLdapAddAttr)
        self.setTabOrder(self.pLdapAddAttr,self.pLdapDeleteAttr)
        self.setTabOrder(self.pLdapDeleteAttr,self.pLdapModify)
        self.setTabOrder(self.pLdapModify,self.cbLdapFormDhcpType)
        self.setTabOrder(self.cbLdapFormDhcpType,self.cbLdapFormDhcpInterface)
        self.setTabOrder(self.cbLdapFormDhcpInterface,self.iLdapFormDhcpNetwork)
        self.setTabOrder(self.iLdapFormDhcpNetwork,self.iLdapFormDhcpBroadcast)
        self.setTabOrder(self.iLdapFormDhcpBroadcast,self.iLdapFormDhcpRange)
        self.setTabOrder(self.iLdapFormDhcpRange,self.cbLdapFormDhcpNetmask)
        self.setTabOrder(self.cbLdapFormDhcpNetmask,self.iLdapFormDhcpGateway)
        self.setTabOrder(self.iLdapFormDhcpGateway,self.iLdapFormDhcpGroupName)
        self.setTabOrder(self.iLdapFormDhcpGroupName,self.iLdapFormDhcpName)
        self.setTabOrder(self.iLdapFormDhcpName,self.iLdapFormDhcpIPaddress)
        self.setTabOrder(self.iLdapFormDhcpIPaddress,self.iLdapFormDhcpMACaddress)
        self.setTabOrder(self.iLdapFormDhcpMACaddress,self.iLdapFormDhcpComments)
        self.setTabOrder(self.iLdapFormDhcpComments,self.pLdapAddDhcp)
        self.setTabOrder(self.pLdapAddDhcp,self.iLdapFormCn)
        self.setTabOrder(self.iLdapFormCn,self.iLdapFormMail)
        self.setTabOrder(self.iLdapFormMail,self.iLdapFormStreet)
        self.setTabOrder(self.iLdapFormStreet,self.iLdapFormL)
        self.setTabOrder(self.iLdapFormL,self.iLdapFormPostalCode)
        self.setTabOrder(self.iLdapFormPostalCode,self.iLdapFormHomePhone)
        self.setTabOrder(self.iLdapFormHomePhone,self.iLdapFormUserP)
        self.setTabOrder(self.iLdapFormUserP,self.iLdapFormUserP2)
        self.setTabOrder(self.iLdapFormUserP2,self.cLdapFormPosix)
        self.setTabOrder(self.cLdapFormPosix,self.iLdapFormUid)
        self.setTabOrder(self.iLdapFormUid,self.iLdapFormUidNumber)
        self.setTabOrder(self.iLdapFormUidNumber,self.pLdapGetUidNumber)
        self.setTabOrder(self.pLdapGetUidNumber,self.iLdapFormGidNumber)
        self.setTabOrder(self.iLdapFormGidNumber,self.iLdapFormLoginShell)
        self.setTabOrder(self.iLdapFormLoginShell,self.iLdapFormHomeDirectory)
        self.setTabOrder(self.iLdapFormHomeDirectory,self.cLdapFormSamba)
        self.setTabOrder(self.cLdapFormSamba,self.cbLdapFormSambaDomain)
        self.setTabOrder(self.cbLdapFormSambaDomain,self.iLdapFormSambaPwdMustChange)
        self.setTabOrder(self.iLdapFormSambaPwdMustChange,self.cbLdapFormPrimaryGroup)
        self.setTabOrder(self.cbLdapFormPrimaryGroup,self.cbLdapFormProfileType)
        self.setTabOrder(self.cbLdapFormProfileType,self.iLdapFormProfilePath)
        self.setTabOrder(self.iLdapFormProfilePath,self.iLdapFormHomeDrive)
        self.setTabOrder(self.iLdapFormHomeDrive,self.iLdapFormDrivePath)
        self.setTabOrder(self.iLdapFormDrivePath,self.iLdapFormLogonScript)
        self.setTabOrder(self.iLdapFormLogonScript,self.cLdapFormAst)
        self.setTabOrder(self.cLdapFormAst,self.iLdapFormAstUsername)
        self.setTabOrder(self.iLdapFormAstUsername,self.iLdapFormAstName)
        self.setTabOrder(self.iLdapFormAstName,self.iLdapFormAstPort)
        self.setTabOrder(self.iLdapFormAstPort,self.cLdapFormAstSecret)
        self.setTabOrder(self.cLdapFormAstSecret,self.cLdapFormRadius)
        self.setTabOrder(self.cLdapFormRadius,self.iLdapFormRadiusGroup)
        self.setTabOrder(self.iLdapFormRadiusGroup,self.pLdapFormBack)
        self.setTabOrder(self.pLdapFormBack,self.pLdapFormNext)
        self.setTabOrder(self.pLdapFormNext,self.pLdapAddUser)
        self.setTabOrder(self.pLdapAddUser,self.cbLdapFormUnit)
        self.setTabOrder(self.cbLdapFormUnit,self.iLdapFormUnit)
        self.setTabOrder(self.iLdapFormUnit,self.iLdapFormUnitStreet)
        self.setTabOrder(self.iLdapFormUnitStreet,self.iLdapFormUnitL)
        self.setTabOrder(self.iLdapFormUnitL,self.iLdapFormUnitPostalCode)
        self.setTabOrder(self.iLdapFormUnitPostalCode,self.iLdapFormUnitTelephoneNumber)
        self.setTabOrder(self.iLdapFormUnitTelephoneNumber,self.pLdapAddOu)
        self.setTabOrder(self.pLdapAddOu,self.cbLdapUserPassword)
        self.setTabOrder(self.cbLdapUserPassword,self.cbUserPassword)
        self.setTabOrder(self.cbUserPassword,self.cbLdapSambaPassword)
        self.setTabOrder(self.cbLdapSambaPassword,self.cbLdapAstPassword)
        self.setTabOrder(self.cbLdapAstPassword,self.cLdapSambaPasswordPwdMustChange)
        self.setTabOrder(self.cLdapSambaPasswordPwdMustChange,self.iLdapPasswd)
        self.setTabOrder(self.iLdapPasswd,self.iLdapPasswd2)
        self.setTabOrder(self.iLdapPasswd2,self.pLdapPasswd)
        self.setTabOrder(self.pLdapPasswd,self.iLdapSMBdomain)
        self.setTabOrder(self.iLdapSMBdomain,self.iLdapSMBSID)
        self.setTabOrder(self.iLdapSMBSID,self.iLdapSMBpassword)
        self.setTabOrder(self.iLdapSMBpassword,self.iLdapSMBuidNumber)
        self.setTabOrder(self.iLdapSMBuidNumber,self.iLdapSMBgidNumber)
        self.setTabOrder(self.iLdapSMBgidNumber,self.iLdapSMBminPwdLength)
        self.setTabOrder(self.iLdapSMBminPwdLength,self.iLdapSMBpwdHistLenght)
        self.setTabOrder(self.iLdapSMBpwdHistLenght,self.iLdapSMBmaxPwdAge)
        self.setTabOrder(self.iLdapSMBmaxPwdAge,self.cbLdapSMBmaxPwdAge)
        self.setTabOrder(self.cbLdapSMBmaxPwdAge,self.iLdapSMBminPwdAge)
        self.setTabOrder(self.iLdapSMBminPwdAge,self.cbLdapSMBminPwdAge)
        self.setTabOrder(self.cbLdapSMBminPwdAge,self.iLdapSMBlockout)
        self.setTabOrder(self.iLdapSMBlockout,self.iLdapSMBlockoutDuration)
        self.setTabOrder(self.iLdapSMBlockoutDuration,self.cbLdapSMBlockoutDuration)
        self.setTabOrder(self.cbLdapSMBlockoutDuration,self.iLdapSMBlockoutWindow)
        self.setTabOrder(self.iLdapSMBlockoutWindow,self.cbLdapSMBlockoutWindow)
        self.setTabOrder(self.cbLdapSMBlockoutWindow,self.pLdapSambaPopulate)
        self.setTabOrder(self.pLdapSambaPopulate,self.iLdapDhcpName)
        self.setTabOrder(self.iLdapDhcpName,self.iLdapDhcpDefaultLeaseTime)
        self.setTabOrder(self.iLdapDhcpDefaultLeaseTime,self.cbLdapDhcpDefaultLeaseTime)
        self.setTabOrder(self.cbLdapDhcpDefaultLeaseTime,self.iLdapDhcpMaxLeaseTime)
        self.setTabOrder(self.iLdapDhcpMaxLeaseTime,self.cbLdapDhcpMaxLeaseTime)
        self.setTabOrder(self.cbLdapDhcpMaxLeaseTime,self.iLdapDhcpDomainName)
        self.setTabOrder(self.iLdapDhcpDomainName,self.iLdapDhcpNetbiosServers)
        self.setTabOrder(self.iLdapDhcpNetbiosServers,self.iLdapDhcpDNSservers)
        self.setTabOrder(self.iLdapDhcpDNSservers,self.cbLdapDhcpInterface)
        self.setTabOrder(self.cbLdapDhcpInterface,self.iLdapDhcpNetwork)
        self.setTabOrder(self.iLdapDhcpNetwork,self.iLdapDhcpBroadcast)
        self.setTabOrder(self.iLdapDhcpBroadcast,self.iLdapDhcpRange)
        self.setTabOrder(self.iLdapDhcpRange,self.cbLdapDhcpNetmask)
        self.setTabOrder(self.cbLdapDhcpNetmask,self.iLdapDhcpGateway)
        self.setTabOrder(self.iLdapDhcpGateway,self.pLdapDhcpPopulate)
        self.setTabOrder(self.pLdapDhcpPopulate,self.iImapSearch)
        self.setTabOrder(self.iImapSearch,self.pImapSearch)
        self.setTabOrder(self.pImapSearch,self.cImapExpand)
        self.setTabOrder(self.cImapExpand,self.rbImapMailboxMode)
        self.setTabOrder(self.rbImapMailboxMode,self.lvImap)
        self.setTabOrder(self.lvImap,self.iImapMailbox)
        self.setTabOrder(self.iImapMailbox,self.pCyrAdd)
        self.setTabOrder(self.pCyrAdd,self.pCyrDelete)
        self.setTabOrder(self.pCyrDelete,self.pCyrReconstruct)
        self.setTabOrder(self.pCyrReconstruct,self.lvImapAcl)
        self.setTabOrder(self.lvImapAcl,self.iImapAclUser)
        self.setTabOrder(self.iImapAclUser,self.cbACL)
        self.setTabOrder(self.cbACL,self.pImapAclAdd)
        self.setTabOrder(self.pImapAclAdd,self.pImapAclDel)
        self.setTabOrder(self.pImapAclDel,self.cbImapAnnotation)
        self.setTabOrder(self.cbImapAnnotation,self.iAnnotationValue)
        self.setTabOrder(self.iAnnotationValue,self.pImapAnnotation)
        self.setTabOrder(self.pImapAnnotation,self.iQuotaUsed)
        self.setTabOrder(self.iQuotaUsed,self.iQuota)
        self.setTabOrder(self.iQuota,self.pImapQuota)
        self.setTabOrder(self.pImapQuota,self.iImapPartitionSearch)
        self.setTabOrder(self.iImapPartitionSearch,self.pImapPartitionSearch)
        self.setTabOrder(self.pImapPartitionSearch,self.cImapSize)
        self.setTabOrder(self.cImapSize,self.rbImapPartMailboxMode)
        self.setTabOrder(self.rbImapPartMailboxMode,self.cbImapPartition)
        self.setTabOrder(self.cbImapPartition,self.pImapPartitionMove)
        self.setTabOrder(self.pImapPartitionMove,self.cImapSizeUpdate)
        self.setTabOrder(self.cImapSizeUpdate,self.iSieveSearch)
        self.setTabOrder(self.iSieveSearch,self.pSieveSearch)
        self.setTabOrder(self.pSieveSearch,self.cSieveScript)
        self.setTabOrder(self.cSieveScript,self.lvServices)
        self.setTabOrder(self.lvServices,self.cbServiceService)
        self.setTabOrder(self.cbServiceService,self.cbServiceStatus)
        self.setTabOrder(self.cbServiceStatus,self.pServiceStatus)
        self.setTabOrder(self.pServiceStatus,self.teServiceStatus)
        self.setTabOrder(self.teServiceStatus,self.lvQueue)
        self.setTabOrder(self.lvQueue,self.pQueueLoad)
        self.setTabOrder(self.pQueueLoad,self.iQueueMessage)
        self.setTabOrder(self.iQueueMessage,self.lvConfig)
        self.setTabOrder(self.lvConfig,self.cbLdapConnection)
        self.setTabOrder(self.cbLdapConnection,self.pConfDelLdapConnection)
        self.setTabOrder(self.pConfDelLdapConnection,self.iLdapConnection)
        self.setTabOrder(self.iLdapConnection,self.cbLdapMode)
        self.setTabOrder(self.cbLdapMode,self.iLdapHost)
        self.setTabOrder(self.iLdapHost,self.iLdapPort)
        self.setTabOrder(self.iLdapPort,self.cbLdapBaseDN)
        self.setTabOrder(self.cbLdapBaseDN,self.pGetBaseDN)
        self.setTabOrder(self.pGetBaseDN,self.iLdapUser)
        self.setTabOrder(self.iLdapUser,self.iLdapPass)
        self.setTabOrder(self.iLdapPass,self.cLdapRef)
        self.setTabOrder(self.cLdapRef,self.cLdapCert)
        self.setTabOrder(self.cLdapCert,self.cbCyrusConnection)
        self.setTabOrder(self.cbCyrusConnection,self.pConfDelImapConnection)
        self.setTabOrder(self.pConfDelImapConnection,self.iCyrusConnection)
        self.setTabOrder(self.iCyrusConnection,self.cbCyrusMode)
        self.setTabOrder(self.cbCyrusMode,self.iCyrusHost)
        self.setTabOrder(self.iCyrusHost,self.iCyrusPort)
        self.setTabOrder(self.iCyrusPort,self.iCyrusUser)
        self.setTabOrder(self.iCyrusUser,self.iCyrusPass)
        self.setTabOrder(self.iCyrusPass,self.iCyrusPart)
        self.setTabOrder(self.iCyrusPart,self.iCyrusSievePort)
        self.setTabOrder(self.iCyrusSievePort,self.cbSSHConnection)
        self.setTabOrder(self.cbSSHConnection,self.pConfDelSshConnection)
        self.setTabOrder(self.pConfDelSshConnection,self.iSSHConnection)
        self.setTabOrder(self.iSSHConnection,self.iSshHost)
        self.setTabOrder(self.iSshHost,self.iSshPort)
        self.setTabOrder(self.iSshPort,self.iSshUser)
        self.setTabOrder(self.iSshUser,self.iSshPass)
        self.setTabOrder(self.iSshPass,self.cbSSHsudo)
        self.setTabOrder(self.cbSSHsudo,self.cbConfLdapCompleteUser)
        self.setTabOrder(self.cbConfLdapCompleteUser,self.lbConfLdapFilter)
        self.setTabOrder(self.lbConfLdapFilter,self.iConfLdapFilter)
        self.setTabOrder(self.iConfLdapFilter,self.pConfLdapFilterAdd)
        self.setTabOrder(self.pConfLdapFilterAdd,self.pConfLdapFilterDel)
        self.setTabOrder(self.pConfLdapFilterDel,self.cbConfLdapUserDN)
        self.setTabOrder(self.cbConfLdapUserDN,self.cConfLdapsambaPwdMustChange)
        self.setTabOrder(self.cConfLdapsambaPwdMustChange,self.lvConfImapFolders)
        self.setTabOrder(self.lvConfImapFolders,self.iConfImapFolder)
        self.setTabOrder(self.iConfImapFolder,self.iConfImapExpire)
        self.setTabOrder(self.iConfImapExpire,self.cbConfImapACLp)
        self.setTabOrder(self.cbConfImapACLp,self.pConfImapFoldersAdd)
        self.setTabOrder(self.pConfImapFoldersAdd,self.pConfImapFoldersDel)
        self.setTabOrder(self.pConfImapFoldersDel,self.iConfImapQuotaMbytes)
        self.setTabOrder(self.iConfImapQuotaMbytes,self.cbConfLdapSmbDomain)
        self.setTabOrder(self.cbConfLdapSmbDomain,self.pConfLdapSmbDomainDel)
        self.setTabOrder(self.pConfLdapSmbDomainDel,self.iConfLdapSmbDomain)
        self.setTabOrder(self.iConfLdapSmbDomain,self.cbConfLdapSmbSIDEntry)
        self.setTabOrder(self.cbConfLdapSmbSIDEntry,self.pConfLdapSmbGetsambaDomain)
        self.setTabOrder(self.pConfLdapSmbGetsambaDomain,self.cbConfLdapSmbCounterEntry)
        self.setTabOrder(self.cbConfLdapSmbCounterEntry,self.pConfLdapSmbGetsambaUnixPoolId)
        self.setTabOrder(self.pConfLdapSmbGetsambaUnixPoolId,self.cConfLdapSmbPwdMustChange)
        self.setTabOrder(self.cConfLdapSmbPwdMustChange,self.cbConfLdapSmbPrimaryGroup)
        self.setTabOrder(self.cbConfLdapSmbPrimaryGroup,self.cbConfLdapSmbProfileType)
        self.setTabOrder(self.cbConfLdapSmbProfileType,self.cbConfLdapSmbProfilePath)
        self.setTabOrder(self.cbConfLdapSmbProfilePath,self.iConfLdapSmbHomeDrive)
        self.setTabOrder(self.iConfLdapSmbHomeDrive,self.iConfLdapSmbDrivePath)
        self.setTabOrder(self.iConfLdapSmbDrivePath,self.cbConfLdapSmbLogonScript)
        self.setTabOrder(self.cbConfLdapSmbLogonScript,self.iConfLdapSMBuidNumber)
        self.setTabOrder(self.iConfLdapSMBuidNumber,self.iConfLdapSMBgidNumber)
        self.setTabOrder(self.iConfLdapSMBgidNumber,self.iConfLdapSMBminPwdLength)
        self.setTabOrder(self.iConfLdapSMBminPwdLength,self.iConfLdapSMBpwdHistLenght)
        self.setTabOrder(self.iConfLdapSMBpwdHistLenght,self.iConfLdapSMBmaxPwdAge)
        self.setTabOrder(self.iConfLdapSMBmaxPwdAge,self.cbConfLdapSMBmaxPwdAge)
        self.setTabOrder(self.cbConfLdapSMBmaxPwdAge,self.iConfLdapSMBminPwdAge)
        self.setTabOrder(self.iConfLdapSMBminPwdAge,self.cbConfLdapSMBminPwdAge)
        self.setTabOrder(self.cbConfLdapSMBminPwdAge,self.iConfLdapSMBlockout)
        self.setTabOrder(self.iConfLdapSMBlockout,self.iConfLdapSMBlockoutDuration)
        self.setTabOrder(self.iConfLdapSMBlockoutDuration,self.cbConfLdapSMBlockoutDuration)
        self.setTabOrder(self.cbConfLdapSMBlockoutDuration,self.iConfLdapSMBlockoutWindow)
        self.setTabOrder(self.iConfLdapSMBlockoutWindow,self.cbConfLdapSMBlockoutWindow)
        self.setTabOrder(self.cbConfLdapSMBlockoutWindow,self.cConfLdapSchemaAddAttr)
        self.setTabOrder(self.cConfLdapSchemaAddAttr,self.cConfLdapSchemaDelAttr)
        self.setTabOrder(self.cConfLdapSchemaDelAttr,self.lvConfLdapSchema)
        self.setTabOrder(self.lvConfLdapSchema,self.iConfLdapSchemaAttr)
        self.setTabOrder(self.iConfLdapSchemaAttr,self.iConfLdapSchemaValue)
        self.setTabOrder(self.iConfLdapSchemaValue,self.pConfLdapSchemaAddItem)
        self.setTabOrder(self.pConfLdapSchemaAddItem,self.pConfLdapSchemaDelItem)
        self.setTabOrder(self.pConfLdapSchemaDelItem,self.cbImapAnnotationServer)
        self.setTabOrder(self.cbImapAnnotationServer,self.iAnnotationValueServer)
        self.setTabOrder(self.iAnnotationValueServer,self.pImapAnnotationServer)
        self.setTabOrder(self.pImapAnnotationServer,self.iConfLdapDhcpDefaultLeaseTime)
        self.setTabOrder(self.iConfLdapDhcpDefaultLeaseTime,self.cbConfLdapDhcpDefaultLeaseTime)
        self.setTabOrder(self.cbConfLdapDhcpDefaultLeaseTime,self.iConfLdapDhcpMaxLeaseTime)
        self.setTabOrder(self.iConfLdapDhcpMaxLeaseTime,self.cbConfLdapDhcpMaxLeaseTime)
        self.setTabOrder(self.cbConfLdapDhcpMaxLeaseTime,self.iConfLdapDhcpDomainName)
        self.setTabOrder(self.iConfLdapDhcpDomainName,self.iConfLdapDhcpNetbiosServers)
        self.setTabOrder(self.iConfLdapDhcpNetbiosServers,self.iConfLdapDhcpDNSservers)
        self.setTabOrder(self.iConfLdapDhcpDNSservers,self.cbConfLdapDhcpInterface)
        self.setTabOrder(self.cbConfLdapDhcpInterface,self.iConfLdapDhcpNetwork)
        self.setTabOrder(self.iConfLdapDhcpNetwork,self.iConfLdapDhcpBroadcast)
        self.setTabOrder(self.iConfLdapDhcpBroadcast,self.iConfLdapDhcpRange)
        self.setTabOrder(self.iConfLdapDhcpRange,self.cbConfLdapDhcpNetmask)
        self.setTabOrder(self.cbConfLdapDhcpNetmask,self.iConfLdapDhcpGateway)
        self.setTabOrder(self.iConfLdapDhcpGateway,self.pSaveConfig)
        self.setTabOrder(self.pSaveConfig,self.cbServicesFileOpen)
        self.setTabOrder(self.cbServicesFileOpen,self.pServicesFileOpen)
        self.setTabOrder(self.pServicesFileOpen,self.pServicesFileSave)
        self.setTabOrder(self.pServicesFileSave,self.pServicesFilePostmap)
        self.setTabOrder(self.pServicesFilePostmap,self.teServicesFileOpen)
        self.setTabOrder(self.teServicesFileOpen,self.rbServicesPostconfN)
        self.setTabOrder(self.rbServicesPostconfN,self.rbServicesPostconfAll)
        self.setTabOrder(self.rbServicesPostconfAll,self.rbServicesPostconfD)
        self.setTabOrder(self.rbServicesPostconfD,self.cbServicesPostconf)
        self.setTabOrder(self.cbServicesPostconf,self.pServicesPostconfSave)
        self.setTabOrder(self.pServicesPostconfSave,self.teServicesPostconf)

        self.init()


    def languageChange(self):
        self.setCaption(self.__tr("Korreio - Mail Management"))
        self.tlConsole.setText(self.__tr("Korreio (c) Copyleft 2009 - Reinaldo de Carvalho <reinaldoc@gmail.com>"))
        self.bgLog.setTitle(QString.null)
        self.rbConfLogModeRecent.setText(self.__tr("Recent"))
        self.rbConfLogModeFull.setText(self.__tr("Full"))
        self.textLabel3_3_2_2_2.setText(self.__tr("<b>Log</b>"))
        self.cbLdapFilter.clear()
        self.cbLdapFilter.insertItem(self.__tr("objectClass=*"))
        self.cbLdapFilter.insertItem(self.__tr("ou=*"))
        self.cbLdapFilter.insertItem(self.__tr("cn=*"))
        self.cbLdapFilter.insertItem(self.__tr("uid=*"))
        self.cbLdapFilter.insertItem(self.__tr("mail=*"))
        QToolTip.add(self.cbLdapFilter,self.__tr("LDAP Filter: RFC-4515"))
        self.lvLdap.header().setLabel(0,self.__tr("Distinguished Name"))
        self.pLdapDelete.setText(self.__tr("&Delete"))
        self.pLdapDelete.setAccel(QKeySequence(self.__tr("Alt+D")))
        QToolTip.add(self.pLdapDelete,self.__tr("Delete entry"))
        self.pLdapSearch.setText(self.__tr("&Search"))
        self.pLdapSearch.setAccel(QKeySequence(self.__tr("Alt+S")))
        self.cbLdapAttr.clear()
        self.cbLdapAttr.insertItem(QString.null)
        self.cbLdapAttr.insertItem(self.__tr("objectClass"))
        self.cbLdapAttr.insertItem(self.__tr("structuralObjectClass"))
        self.cbLdapAttr.insertItem(self.__tr("uid"))
        self.cbLdapAttr.insertItem(self.__tr("cn"))
        self.cbLdapAttr.insertItem(self.__tr("sn"))
        self.cbLdapAttr.insertItem(self.__tr("mail"))
        self.cbLdapAttr.insertItem(self.__tr("gecos"))
        self.cbLdapAttr.insertItem(self.__tr("description"))
        self.cbLdapAttr.insertItem(self.__tr("homeDirectory"))
        self.cbLdapAttr.insertItem(self.__tr("loginShell"))
        self.cbLdapAttr.insertItem(self.__tr("uidNumber"))
        self.cbLdapAttr.insertItem(self.__tr("gidNumber"))
        self.cbLdapAttr.insertItem(self.__tr("userPassword"))
        self.cbLdapAttr.insertItem(self.__tr("shadowLastChange"))
        self.cbLdapAttr.insertItem(self.__tr("shadowMin"))
        self.cbLdapAttr.insertItem(self.__tr("shadowMax"))
        self.cbLdapAttr.insertItem(self.__tr("shadowWarning"))
        self.cbLdapAttr.insertItem(self.__tr("shadowInactive"))
        self.cbLdapAttr.insertItem(self.__tr("shadowExpire"))
        self.cbLdapAttr.insertItem(self.__tr("shadowFlag"))
        self.cbLdapAttr.insertItem(self.__tr("carLicense"))
        self.cbLdapAttr.insertItem(self.__tr("displayName"))
        self.cbLdapAttr.insertItem(self.__tr("homePhone"))
        self.cbLdapAttr.insertItem(self.__tr("l"))
        self.cbLdapAttr.insertItem(self.__tr("street"))
        self.cbLdapAttr.insertItem(self.__tr("postalCode"))
        self.cbLdapAttr.insertItem(self.__tr("o"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLMPassword"))
        self.cbLdapAttr.insertItem(self.__tr("sambaNTPassword"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdLastSet"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogoffTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaKickoffTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdCanChange"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdMustChange"))
        self.cbLdapAttr.insertItem(self.__tr("sambaAcctFlags"))
        self.cbLdapAttr.insertItem(self.__tr("sambaHomePath"))
        self.cbLdapAttr.insertItem(self.__tr("sambaHomeDrive"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonScript"))
        self.cbLdapAttr.insertItem(self.__tr("sambaProfilePath"))
        self.cbLdapAttr.insertItem(self.__tr("sambaUserWorkstations"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPrimaryGroupSID"))
        self.cbLdapAttr.insertItem(self.__tr("sambaDomainName"))
        self.cbLdapAttr.insertItem(self.__tr("sambaMungedDial"))
        self.cbLdapAttr.insertItem(self.__tr("sambaBadPasswordCount"))
        self.cbLdapAttr.insertItem(self.__tr("sambaBadPasswordTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPasswordHistory"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonHours"))
        self.cbLdapAttr.insertItem(self.__tr("mailAlternateAddress"))
        self.cbLdapAttr.insertItem(self.__tr("ipHostNumber"))
        self.cbLdapAttr.insertItem(self.__tr("owner"))
        self.cbLdapAttr.insertItem(self.__tr("manager"))
        self.cbLdapAttr.insertItem(self.__tr("serialNumber"))
        self.cbLdapAttr.insertItem(self.__tr("member"))
        QToolTip.add(self.cbLdapAttr,self.__tr("Attribute"))
        self.cbLdapValue.clear()
        self.cbLdapValue.insertItem(QString.null)
        self.cbLdapValue.insertItem(self.__tr("inetOrgPerson"))
        self.cbLdapValue.insertItem(self.__tr("posixAccount"))
        self.cbLdapValue.insertItem(self.__tr("sambaSamAccount"))
        self.cbLdapValue.insertItem(self.__tr("shadowAccount"))
        self.cbLdapValue.insertItem(self.__tr("top"))
        self.cbLdapValue.insertItem(self.__tr("simpleSecurityObject"))
        self.cbLdapValue.insertItem(self.__tr("organization"))
        self.cbLdapValue.insertItem(self.__tr("organizationalUnit"))
        self.cbLdapValue.insertItem(self.__tr("organizationalRole"))
        self.cbLdapValue.insertItem(self.__tr("groupOfNames"))
        self.cbLdapValue.insertItem(self.__tr("device"))
        self.cbLdapValue.insertItem(self.__tr("ipHost"))
        self.cbLdapValue.insertItem(self.__tr("ipNetwork"))
        self.cbLdapValue.insertItem(self.__tr("referral"))
        self.cbLdapValue.insertItem(self.__tr("extensibleObject"))
        QToolTip.add(self.cbLdapValue,self.__tr("Value"))
        self.pLdapAddAttr.setText(self.__tr("+"))
        self.pLdapAddAttr.setAccel(QKeySequence(QString.null))
        QToolTip.add(self.pLdapAddAttr,self.__tr("Add attribute"))
        self.pLdapDeleteAttr.setText(self.__tr("-"))
        QToolTip.add(self.pLdapDeleteAttr,self.__tr("Delete attribute"))
        self.pLdapModify.setText(self.__tr("&Apply"))
        self.pLdapModify.setAccel(QKeySequence(self.__tr("Alt+A")))
        QToolTip.add(self.pLdapModify,self.__tr("Commit changes"))
        self.lvLdapAttr.header().setLabel(0,self.__tr("Attribute"))
        self.lvLdapAttr.header().setLabel(1,self.__tr("Value"))
        self.pLdapAddDhcp.setText(self.__tr("&Finish"))
        self.pLdapAddDhcp.setAccel(QKeySequence(self.__tr("Alt+F")))
        self.textLabel1_2_4_3.setText(self.__tr("<b>New DHCP entry</b>"))
        self.textLabel2_3_2_2.setText(self.__tr("Type:"))
        QToolTip.add(self.textLabel2_3_2_2,self.__tr("<b>dhcp objectClass</b>"))
        self.cbLdapFormDhcpType.clear()
        self.cbLdapFormDhcpType.insertItem(self.__tr("dhcpGroup"))
        self.cbLdapFormDhcpType.insertItem(self.__tr("dhcpHost"))
        self.cbLdapFormDhcpType.insertItem(self.__tr("dhcpSharedNetwork"))
        self.cbLdapFormDhcpType.insertItem(self.__tr("dhcpSubnet"))
        QToolTip.add(self.iLdapFormDhcpIPaddress,self.__tr("<b>192.168.0.101</b>"))
        self.textLabel3_2_3_2_2.setText(self.__tr("IP address:"))
        QToolTip.add(self.textLabel3_2_3_2_2,self.__tr("<b>dhcpStatements: fixed-address</b>"))
        QToolTip.add(self.iLdapFormDhcpMACaddress,self.__tr("<b>00:11:22:33:44:55</b>"))
        self.textLabel3_2_4_2_2.setText(self.__tr("Description:"))
        QToolTip.add(self.textLabel3_2_4_2_2,self.__tr("<b>dhcpComments</b>"))
        self.textLabel5_3_2_2.setText(self.__tr("MAC address:"))
        QToolTip.add(self.textLabel5_3_2_2,self.__tr("<b>dhcpHWAddress: ethernet</b>"))
        QToolTip.add(self.iLdapFormDhcpComments,self.__tr("<b>Description</b>"))
        QToolTip.add(self.iLdapFormDhcpName,self.__tr("<b>host name</b>"))
        QToolTip.add(self.iLdapFormDhcpGroupName,self.__tr("<b>host name</b>"))
        self.textLabel2_3_3.setText(self.__tr("Host name:"))
        QToolTip.add(self.textLabel2_3_3,self.__tr("<b>cn of dhcpHost</b>"))
        self.tlLdapFormDhcpGroupName.setText(self.__tr("Group name:"))
        QToolTip.add(self.tlLdapFormDhcpGroupName,self.__tr("<b>cn of dhcpHost</b>"))
        self.tlLdapFormDhcpInterface.setText(self.__tr("Network interface:"))
        QToolTip.add(self.tlLdapFormDhcpInterface,self.__tr("<b>cn of dhcpSharedNetwork</b>"))
        self.cbLdapFormDhcpInterface.clear()
        self.cbLdapFormDhcpInterface.insertItem(self.__tr("eth0"))
        self.cbLdapFormDhcpInterface.insertItem(self.__tr("eth1"))
        self.cbLdapFormDhcpInterface.insertItem(self.__tr("eth2"))
        self.cbLdapFormDhcpInterface.insertItem(self.__tr("eth3"))
        self.textLabel1_3_2_2_2_3_2_3_4.setText(self.__tr("Network address:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_4,self.__tr("<b>cn of dhcpSubnet</b>"))
        self.iLdapFormDhcpNetwork.setText(self.__tr("192.168.0.0"))
        QToolTip.add(self.iLdapFormDhcpNetwork,self.__tr("<b> 192.168.0.0</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_4.setText(self.__tr("Broadcast address:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_4,self.__tr("<b>dhcpOption: broadcast-address</b>"))
        self.iLdapFormDhcpBroadcast.setText(self.__tr("192.168.0.255"))
        QToolTip.add(self.iLdapFormDhcpBroadcast,self.__tr("<b> 192.168.0.255</b>"))
        self.textLabel1_3_2_2_2_3_2_3_2_2.setText(self.__tr("Range IP:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_2_2,self.__tr("<b>dhcpRange</b>"))
        self.iLdapFormDhcpGateway.setText(self.__tr("192.168.0.254"))
        QToolTip.add(self.iLdapFormDhcpGateway,self.__tr("<b> 192.168.0.254</b>"))
        self.iLdapFormDhcpRange.setText(self.__tr("192.168.0.10 192.168.0.100"))
        QToolTip.add(self.iLdapFormDhcpRange,self.__tr("<b> 192.168.0.10 192.168.0.100</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_2_2.setText(self.__tr("Netmask:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_2_2,self.__tr("<b>dhcpNetMask</b>"))
        self.cbLdapFormDhcpNetmask.clear()
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("32"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("31"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("30"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("29"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("28"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("27"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("26"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("25"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("24"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("23"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("22"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("21"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("20"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("19"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("18"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("17"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("16"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("15"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("14"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("13"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("12"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("11"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("10"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("9"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("8"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("7"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("6"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("5"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("4"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("3"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("2"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("1"))
        self.cbLdapFormDhcpNetmask.insertItem(self.__tr("0"))
        self.cbLdapFormDhcpNetmask.setCurrentItem(8)
        QToolTip.add(self.cbLdapFormDhcpNetmask,self.__tr("<b>/24</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_3_2.setText(self.__tr("Gateway:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_3_2,self.__tr("<b>dhcpOption: routers</b>"))
        self.textLabel1_2.setText(self.__tr("<b>New User</b>"))
        self.pLdapFormBack.setText(self.__tr("&Back"))
        self.pLdapFormBack.setAccel(QKeySequence(self.__tr("Alt+B")))
        self.pLdapFormNext.setText(self.__tr("&Next"))
        self.pLdapFormNext.setAccel(QKeySequence(self.__tr("Alt+N")))
        self.pLdapAddUser.setText(self.__tr("&Finish"))
        self.pLdapAddUser.setAccel(QKeySequence(self.__tr("Alt+F")))
        self.textLabel1_2_3.setText(self.__tr("<b>inetOrgPerson</b>"))
        self.textLabel3_2.setText(self.__tr("Name:"))
        QToolTip.add(self.textLabel3_2,self.__tr("<b>cn</b>"))
        QToolTip.add(self.iLdapFormCn,self.__tr("<b>Full name</b>"))
        self.textLabel5.setText(self.__tr("Mail:"))
        QToolTip.add(self.textLabel5,self.__tr("<b>mail</b>"))
        QToolTip.add(self.iLdapFormMail,self.__tr("<b>user@example.com</b>"))
        self.textLabel5_3.setText(self.__tr("Locality:"))
        QToolTip.add(self.textLabel5_3,self.__tr("<b>l</b>"))
        self.textLabel3_2_3.setText(self.__tr("Address:"))
        QToolTip.add(self.textLabel3_2_3,self.__tr("<b>street</b>"))
        QToolTip.add(self.iLdapFormStreet,self.__tr("<b>Av. Example, N 123</b>"))
        QToolTip.add(self.iLdapFormL,self.__tr("<b>District, City, State</b>"))
        self.textLabel3_2_4.setText(self.__tr("Postal code:"))
        QToolTip.add(self.textLabel3_2_4,self.__tr("<b>postalCode</b>"))
        QToolTip.add(self.iLdapFormPostalCode,self.__tr("<b>000000</b>"))
        self.textLabel5_4.setText(self.__tr("Phone number:"))
        QToolTip.add(self.textLabel5_4,self.__tr("<b>homePhone</b>"))
        QToolTip.add(self.iLdapFormHomePhone,self.__tr("<b>+1 (55) 5555-5555</b>"))
        self.textLabel1_3.setText(self.__tr("Password:"))
        QToolTip.add(self.textLabel1_3,self.__tr("<b>userPassword</b>"))
        self.textLabel1_3_4.setText(self.__tr("Password (again):"))
        QToolTip.add(self.textLabel1_3_4,self.__tr("<b>userPassword</b>"))
        self.textLabel1_2_3_2.setText(self.__tr("<b>posixAccount</b>"))
        self.cLdapFormPosix.setText(QString.null)
        self.textLabel5_2_2.setText(self.__tr("Uid number:"))
        QToolTip.add(self.textLabel5_2_2,self.__tr("<b>uidNumber</b>"))
        self.textLabel1_3_3_2.setText(self.__tr("Gid number:"))
        QToolTip.add(self.textLabel1_3_3_2,self.__tr("<b>gidNumber</b>"))
        self.textLabel1_3_3.setText(self.__tr("Home:"))
        QToolTip.add(self.textLabel1_3_3,self.__tr("<b>homeDirectory</b>"))
        self.textLabel5_2.setText(self.__tr("Shell:"))
        QToolTip.add(self.textLabel5_2,self.__tr("<b>loginShell</b>"))
        self.iLdapFormGidNumber.setText(self.__tr("100"))
        self.textLabel3_2_2.setText(self.__tr("User id:"))
        QToolTip.add(self.textLabel3_2_2,self.__tr("<b>uid</b>"))
        self.iLdapFormLoginShell.setText(self.__tr("/bin/bash"))
        self.iLdapFormHomeDirectory.setText(self.__tr("/home"))
        self.iLdapFormUidNumber.setText(self.__tr("1000"))
        self.pLdapGetUidNumber.setText(self.__tr("Find"))
        self.textLabel1_2_3_2_2.setText(self.__tr("<b>sambaSamAccount</b>"))
        self.cLdapFormSamba.setText(QString.null)
        self.textLabel3_2_2_2.setText(self.__tr("Domain:"))
        QToolTip.add(self.textLabel3_2_2_2,self.__tr("<b>sambaDomain</b>"))
        self.iLdapFormLogonScript.setText(QString.null)
        self.textLabel1_3_3_3.setText(self.__tr("Drive Path:"))
        QToolTip.add(self.textLabel1_3_3_3,self.__tr("<b>sambaHomePath</b>"))
        self.textLabel5_2_2_2.setText(self.__tr("Profile type:"))
        QToolTip.add(self.textLabel5_2_2_2,self.__tr("<b>sambaProfilePath</b>"))
        self.textLabel1_3_3_3_2.setText(self.__tr("Logon script:"))
        QToolTip.add(self.textLabel1_3_3_3_2,self.__tr("<b>sambaLogonScript</b>"))
        self.iLdapFormProfilePath.setText(QString.null)
        self.textLabel5_2_3.setText(self.__tr("Drive:"))
        QToolTip.add(self.textLabel5_2_3,self.__tr("<b>sambaHomeDrive</b>"))
        self.iLdapFormDrivePath.setText(QString.null)
        self.iLdapFormHomeDrive.setText(QString.null)
        self.cbLdapFormProfileType.clear()
        self.cbLdapFormProfileType.insertItem(self.__tr("Local"))
        self.cbLdapFormProfileType.insertItem(self.__tr("Remote"))
        self.cbLdapFormPrimaryGroup.clear()
        self.cbLdapFormPrimaryGroup.insertItem(self.__tr("Domain Users (513)"))
        self.cbLdapFormPrimaryGroup.insertItem(self.__tr("Domain Guests (514)"))
        self.cbLdapFormPrimaryGroup.insertItem(self.__tr("Domain Admins (512)"))
        self.textLabel1_3_3_2_2.setText(self.__tr("Group:"))
        QToolTip.add(self.textLabel1_3_3_2_2,self.__tr("<b>sambaPrimaryGroupSID</b>"))
        self.iLdapFormSambaPwdMustChange.setText(self.__tr("Change password required in logon time"))
        QToolTip.add(self.iLdapFormSambaPwdMustChange,self.__tr("<b>sambaPwdMustChange</b>"))
        self.textLabel1_2_3_2_3.setText(self.__tr("<b>astSipPeer</b>"))
        self.cLdapFormAst.setText(QString.null)
        self.textLabel3_2_2_3.setText(self.__tr("User:"))
        QToolTip.add(self.textLabel3_2_2_3,self.__tr("<b>astUsername</b>"))
        self.cLdapFormAstSecret.setText(self.__tr("astSecret"))
        self.textLabel5_2_2_3.setText(self.__tr("Ramal:"))
        QToolTip.add(self.textLabel5_2_2_3,self.__tr("<b>astName</b>"))
        self.iLdapFormAstName.setText(self.__tr("1000"))
        self.textLabel5_2_2_3_2.setText(self.__tr("Port:"))
        QToolTip.add(self.textLabel5_2_2_3_2,self.__tr("<b>astName</b>"))
        self.iLdapFormAstPort.setText(self.__tr("5070"))
        self.textLabel1_2_3_2_4.setText(self.__tr("<b>radiusProfile</b>"))
        self.cLdapFormRadius.setText(QString.null)
        self.iLdapFormRadiusGroup.setText(self.__tr("dialup"))
        self.textLabel3_2_2_4.setText(self.__tr("Group:"))
        QToolTip.add(self.textLabel3_2_2_4,self.__tr("<b>uid</b>"))
        self.textLabel1_2_4.setText(self.__tr("<b>New Organization</b>"))
        self.textLabel3_2_3_2.setText(self.__tr("Address:"))
        QToolTip.add(self.textLabel3_2_3_2,self.__tr("<b>street</b>"))
        self.textLabel5_3_2.setText(self.__tr("Locality:"))
        QToolTip.add(self.textLabel5_3_2,self.__tr("<b>l</b>"))
        self.textLabel5_4_2.setText(self.__tr("Phone number:"))
        QToolTip.add(self.textLabel5_4_2,self.__tr("<b>homePhone</b>"))
        self.textLabel3_2_4_2.setText(self.__tr("Postal code:"))
        QToolTip.add(self.textLabel3_2_4_2,self.__tr("<b>postalCode</b>"))
        self.textLabel2_3.setText(self.__tr("Name:"))
        QToolTip.add(self.textLabel2_3,self.__tr("<b>ou</b>"))
        self.textLabel2_3_2.setText(self.__tr("Type:"))
        QToolTip.add(self.textLabel2_3_2,self.__tr("<b>ou</b>"))
        self.cbLdapFormUnit.clear()
        self.cbLdapFormUnit.insertItem(self.__tr("organizationalUnit"))
        self.cbLdapFormUnit.insertItem(self.__tr("organization"))
        QToolTip.add(self.iLdapFormUnitStreet,self.__tr("<b>Example Av. N 123</b>"))
        QToolTip.add(self.iLdapFormUnitL,self.__tr("<b>District, City, State</b>"))
        QToolTip.add(self.iLdapFormUnitPostalCode,self.__tr("<b>000000</b>"))
        QToolTip.add(self.iLdapFormUnitTelephoneNumber,self.__tr("<b>+1 (55) 5555-5555</b>"))
        self.pLdapAddOu.setText(self.__tr("&Finish"))
        self.pLdapAddOu.setAccel(QKeySequence(self.__tr("Alt+F")))
        self.textLabel1_2_4_2.setText(self.__tr("<b>Set password</b>"))
        self.pLdapPasswd.setText(self.__tr("&Change"))
        self.pLdapPasswd.setAccel(QKeySequence(self.__tr("Alt+C")))
        self.textLabel1_2_3_3.setText(self.__tr("<b>Attributes</b>"))
        self.cbLdapAstPassword.setText(self.__tr("astSecret"))
        self.textLabel1_2_3_3_2.setText(self.__tr("<b>Password</b>"))
        self.textLabel1_3_2_4.setText(self.__tr("Password (again):"))
        self.textLabel1_3_2.setText(self.__tr("Password:"))
        self.textLabel1_2_3_3_2_2.setText(self.__tr("<b>Samba</b>"))
        self.cLdapSambaPasswordPwdMustChange.setText(self.__tr("Change password required in logon time"))
        QToolTip.add(self.cLdapSambaPasswordPwdMustChange,self.__tr("<b>sambaPwdMustChange</b>"))
        self.cbLdapUserPassword.setText(self.__tr("userPassword"))
        self.cbUserPassword.clear()
        self.cbUserPassword.insertItem(self.__tr("{SSHA}"))
        self.cbUserPassword.insertItem(self.__tr("{SMD5}"))
        self.cbUserPassword.insertItem(self.__tr("{CRYPT}"))
        self.cbUserPassword.insertItem(self.__tr("{SHA}"))
        self.cbUserPassword.insertItem(self.__tr("{MD5}"))
        self.cbUserPassword.insertItem(self.__tr("{TEXT}"))
        self.cbLdapSambaPassword.setText(self.__tr("samba{LM-NT}Password"))
        self.textLabel1_2_4_2_2.setText(self.__tr("<b>Samba Populate</b>"))
        self.pLdapSambaPopulate.setText(self.__tr("P&opulate"))
        self.pLdapSambaPopulate.setAccel(QKeySequence(self.__tr("Alt+O")))
        self.textLabel1_3_2_3_2_2_3_3_2.setText(self.__tr("Extend lock after new logon errors:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_3_2,self.__tr("<b>sambaLockoutObservationWindow</b>"))
        self.textLabel1_3_2_3_2_2_3_3.setText(self.__tr("Unlock account after:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_3,self.__tr("<b>sambaLockoutDuration</b>"))
        self.textLabel1_3_2_3_2_2_2.setText(self.__tr("Minimun password lenght:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_2,self.__tr("<b>sambaMinPwdLength</b>"))
        self.textLabel1_3_2_3_2.setText(self.__tr("First uidNumber:"))
        QToolTip.add(self.textLabel1_3_2_3_2,self.__tr("<b>uidNumber</b>"))
        self.textLabel1_3_2_3_2_2_2_3.setText(self.__tr("Logon errors to lock account:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_2_3,self.__tr("<b>sambaLockoutThreshold</b>"))
        self.textLabel1_3_2_3_2_2_3.setText(self.__tr("Deny password reuse:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3,self.__tr("<b>sambaPwdHistoryLength</b>"))
        self.textLabel1_3_2_3_2_2.setText(self.__tr("First gidNumber:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2,self.__tr("<b>gidNumber</b>"))
        self.textLabel1_3_2_3_2_2_5.setText(self.__tr("Wait before change password:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_5,self.__tr("<b>sambaMinPwdAge</b>"))
        self.textLabel1_3_2_3_2_2_4.setText(self.__tr("Force change password:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_4,self.__tr("<b>sambaMaxPwdAge</b>"))
        self.textLabel1_3_2_3.setText(self.__tr("Root password:"))
        QToolTip.add(self.textLabel1_3_2_3,self.__tr("<b>userPassword<br>sambaLMPassword<br>sambaNTPassword</b>"))
        self.textLabel1_3_2_2_2.setText(self.__tr("SMB Domain:"))
        QToolTip.add(self.textLabel1_3_2_2_2,self.__tr("<b>sambaDomainName</b>"))
        self.textLabel1_3_2_2_2_2.setText(self.__tr("SID:"))
        QToolTip.add(self.textLabel1_3_2_2_2_2,self.__tr("<b>sambaDomainName</b>"))
        self.iLdapSMBSID.setText(QString.null)
        QToolTip.add(self.iLdapSMBSID,self.__tr("<b>net getlocalsid DOMAIN</b>"))
        self.iLdapSMBdomain.setText(QString.null)
        self.iLdapSMBgidNumber.setText(QString.null)
        self.iLdapSMBminPwdLength.setText(QString.null)
        self.iLdapSMBpwdHistLenght.setText(QString.null)
        QToolTip.add(self.iLdapSMBpwdHistLenght,self.__tr("<b>0: disabled</b>"))
        self.iLdapSMBminPwdAge.setText(QString.null)
        QToolTip.add(self.iLdapSMBminPwdAge,self.__tr("<b>0: disabled</b>"))
        self.iLdapSMBlockout.setText(QString.null)
        QToolTip.add(self.iLdapSMBlockout,self.__tr("<b>0: disabled</b>"))
        self.iLdapSMBlockoutWindow.setText(QString.null)
        self.iLdapSMBlockoutDuration.setText(QString.null)
        self.cbLdapSMBmaxPwdAge.clear()
        self.cbLdapSMBmaxPwdAge.insertItem(self.__tr("minutes"))
        self.cbLdapSMBmaxPwdAge.insertItem(self.__tr("hours"))
        self.cbLdapSMBmaxPwdAge.insertItem(self.__tr("days"))
        self.cbLdapSMBminPwdAge.clear()
        self.cbLdapSMBminPwdAge.insertItem(self.__tr("minutes"))
        self.cbLdapSMBminPwdAge.insertItem(self.__tr("hours"))
        self.cbLdapSMBminPwdAge.insertItem(self.__tr("days"))
        self.cbLdapSMBlockoutDuration.clear()
        self.cbLdapSMBlockoutDuration.insertItem(self.__tr("minutes"))
        self.cbLdapSMBlockoutDuration.insertItem(self.__tr("hours"))
        self.cbLdapSMBlockoutDuration.insertItem(self.__tr("days"))
        self.cbLdapSMBlockoutWindow.clear()
        self.cbLdapSMBlockoutWindow.insertItem(self.__tr("minutes"))
        self.cbLdapSMBlockoutWindow.insertItem(self.__tr("hours"))
        self.cbLdapSMBlockoutWindow.insertItem(self.__tr("days"))
        self.iLdapSMBmaxPwdAge.setText(QString.null)
        QToolTip.add(self.iLdapSMBmaxPwdAge,self.__tr("<b>-1: disabled</b>"))
        self.iLdapSMBuidNumber.setText(QString.null)
        self.textLabel1_2_4_2_2_2.setText(self.__tr("<b>DHCP Populate</b>"))
        self.pLdapDhcpPopulate.setText(self.__tr("P&opulate"))
        self.pLdapDhcpPopulate.setAccel(QKeySequence(self.__tr("Alt+O")))
        self.textLabel1_3_2_2_2_2_2.setText(self.__tr("Default lease time:"))
        QToolTip.add(self.textLabel1_3_2_2_2_2_2,self.__tr("<b>dhcpStatements: default-lease-time</b>"))
        self.textLabel1_3_2_2_2_3.setText(self.__tr("Server name:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3,self.__tr("<b>cn of dhcpServer</b>"))
        self.textLabel1_3_2_3_2_2_5_3.setText(self.__tr("Max lease time:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_5_3,self.__tr("<b>dhcpStatements: default-lease-time</b>"))
        self.textLabel1_3_2_2_2_3_2_2.setText(self.__tr("Netbios servers:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_2,self.__tr("<b>dhcpOption: netbios-name-servers</b>"))
        self.textLabel1_3_2_2_2_3_2_2_2.setText(self.__tr("DNS servers:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_2_2,self.__tr("<b>dhcpOption: domain-name-servers</b>"))
        self.textLabel1_3_2_2_2_3_2_2_2_2.setText(self.__tr("Network interface:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_2_2_2,self.__tr("<b>cn of dhcpSharedNetwork</b>"))
        self.textLabel1_3_2_2_2_3_2.setText(self.__tr("Domain name:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2,self.__tr("<b>dhcpOption: domain-name</b>"))
        self.textLabel1_3_2_2_2_3_2_3.setText(self.__tr("Network address:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3,self.__tr("<b>cn of dhcpSubnet</b>"))
        self.textLabel1_3_2_2_2_3_2_3_2.setText(self.__tr("Range IP:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_2,self.__tr("<b>dhcpRange</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_2.setText(self.__tr("Netmask:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_2,self.__tr("<b>dhcpNetMask</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3.setText(self.__tr("Broadcast address:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3,self.__tr("<b>dhcpOption: broadcast-address</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_3.setText(self.__tr("Gateway:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_3,self.__tr("<b>dhcpOption: routers</b>"))
        self.iLdapDhcpName.setText(QString.null)
        QToolTip.add(self.iLdapDhcpName,self.__tr("<b>server1.example.com</b>"))
        self.iLdapDhcpDefaultLeaseTime.setText(self.__tr("3600"))
        self.cbLdapDhcpDefaultLeaseTime.clear()
        self.cbLdapDhcpDefaultLeaseTime.insertItem(self.__tr("seconds"))
        self.cbLdapDhcpDefaultLeaseTime.insertItem(self.__tr("minutes"))
        self.cbLdapDhcpDefaultLeaseTime.insertItem(self.__tr("hours"))
        self.cbLdapDhcpDefaultLeaseTime.insertItem(self.__tr("days"))
        self.iLdapDhcpMaxLeaseTime.setText(self.__tr("28800"))
        QToolTip.add(self.iLdapDhcpMaxLeaseTime,self.__tr("<b>0: disabled</b>"))
        self.cbLdapDhcpMaxLeaseTime.clear()
        self.cbLdapDhcpMaxLeaseTime.insertItem(self.__tr("seconds"))
        self.cbLdapDhcpMaxLeaseTime.insertItem(self.__tr("minutes"))
        self.cbLdapDhcpMaxLeaseTime.insertItem(self.__tr("hours"))
        self.cbLdapDhcpMaxLeaseTime.insertItem(self.__tr("days"))
        self.iLdapDhcpDomainName.setText(self.__tr("example.com"))
        QToolTip.add(self.iLdapDhcpDomainName,self.__tr("<b>example.com</b>"))
        self.iLdapDhcpNetbiosServers.setText(self.__tr("192.168.0.1"))
        QToolTip.add(self.iLdapDhcpNetbiosServers,self.__tr("<b> 192.168.0.1</b>"))
        self.iLdapDhcpDNSservers.setText(self.__tr("192.168.0.2"))
        QToolTip.add(self.iLdapDhcpDNSservers,self.__tr("<b> 192.168.0.2</b>"))
        self.cbLdapDhcpInterface.clear()
        self.cbLdapDhcpInterface.insertItem(self.__tr("eth0"))
        self.cbLdapDhcpInterface.insertItem(self.__tr("eth1"))
        self.cbLdapDhcpInterface.insertItem(self.__tr("eth2"))
        self.cbLdapDhcpInterface.insertItem(self.__tr("eth3"))
        self.iLdapDhcpNetwork.setText(self.__tr("192.168.0.0"))
        QToolTip.add(self.iLdapDhcpNetwork,self.__tr("<b> 192.168.0.0</b>"))
        self.iLdapDhcpBroadcast.setText(self.__tr("192.168.0.255"))
        QToolTip.add(self.iLdapDhcpBroadcast,self.__tr("<b> 192.168.0.255</b>"))
        self.iLdapDhcpRange.setText(self.__tr("192.168.0.10 192.168.0.100"))
        QToolTip.add(self.iLdapDhcpRange,self.__tr("<b> 192.168.0.10 192.168.0.100</b>"))
        self.cbLdapDhcpNetmask.clear()
        self.cbLdapDhcpNetmask.insertItem(self.__tr("32"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("31"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("30"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("29"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("28"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("27"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("26"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("25"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("24"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("23"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("22"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("21"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("20"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("19"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("18"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("17"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("16"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("15"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("14"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("13"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("12"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("11"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("10"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("9"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("8"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("7"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("6"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("5"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("4"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("3"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("2"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("1"))
        self.cbLdapDhcpNetmask.insertItem(self.__tr("0"))
        self.cbLdapDhcpNetmask.setCurrentItem(8)
        QToolTip.add(self.cbLdapDhcpNetmask,self.__tr("<b>/24</b>"))
        self.iLdapDhcpGateway.setText(self.__tr("192.168.0.254"))
        QToolTip.add(self.iLdapDhcpGateway,self.__tr("<b> 192.168.0.254</b>"))
        self.pLdapAddDhcp_3.setText(self.__tr("&Finish"))
        self.pLdapAddDhcp_3.setAccel(QKeySequence(self.__tr("Alt+F")))
        self.textLabel1_2_4_3_3.setText(self.__tr("<b>New Group</b>"))
        self.textLabel2_3_2_2_3.setText(self.__tr("Type:"))
        QToolTip.add(self.textLabel2_3_2_2_3,self.__tr("<b>dhcp objectClass</b>"))
        self.tlLdapFormDhcpGroupName_3.setText(self.__tr("Group name:"))
        QToolTip.add(self.tlLdapFormDhcpGroupName_3,self.__tr("<b>cn of dhcpHost</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_2_2_3.setText(self.__tr("Domain:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_2_2_3,self.__tr("<b>dhcpNetMask</b>"))
        self.cbLdapFormDhcpInterface_3.clear()
        self.cbLdapFormDhcpInterface_3.insertItem(self.__tr("Domain"))
        self.cbLdapFormDhcpInterface_3.insertItem(self.__tr("Local"))
        self.cbLdapFormDhcpInterface_3.insertItem(self.__tr("Build-in"))
        self.cbLdapFormDhcpNetmask_3.setCurrentItem(0)
        QToolTip.add(self.cbLdapFormDhcpNetmask_3,self.__tr("<b>/24</b>"))
        self.tlLdapFormDhcpInterface_3.setText(self.__tr("Type:"))
        QToolTip.add(self.tlLdapFormDhcpInterface_3,self.__tr("<b>cn of dhcpSharedNetwork</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_3_2_3.setText(self.__tr("Description:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_3_2_3,self.__tr("<b>dhcpOption: routers</b>"))
        self.iLdapFormDhcpGateway_3.setText(QString.null)
        QToolTip.add(self.iLdapFormDhcpGateway_3,self.__tr("<b> 192.168.0.254</b>"))
        self.textLabel2_3_3_3.setText(self.__tr("Gid number:"))
        QToolTip.add(self.textLabel2_3_3_3,self.__tr("<b>cn of dhcpHost</b>"))
        QToolTip.add(self.iLdapFormDhcpName_3,self.__tr("<b>host name</b>"))
        self.pushButton63.setText(self.__tr("Find"))
        QToolTip.add(self.iLdapFormGroupName,self.__tr("<b>host name</b>"))
        self.cbLdapFormGroupType.clear()
        self.cbLdapFormGroupType.insertItem(self.__tr("sambaGroupMapping"))
        self.cbLdapFormGroupType.insertItem(self.__tr("posixGroup"))
        self.lvImap.header().setLabel(0,self.__tr("IMAP Mailbox"))
        self.pCyrAdd.setText(self.__tr("+"))
        QToolTip.add(self.pCyrAdd,self.__tr("<b>Add</b>"))
        self.pCyrDelete.setText(self.__tr("-"))
        QToolTip.add(self.pCyrDelete,self.__tr("<b>Delete</b>"))
        self.pCyrReconstruct.setText(self.__tr("R"))
        QToolTip.add(self.pCyrReconstruct,self.__tr("<b>Reconstruct</b>"))
        self.textLabel4_2_2_2_2.setText(self.__tr("<b>Mailbox</b>"))
        self.textLabel4_2_2_2.setText(self.__tr("<b>Permissions</b>"))
        QToolTip.add(self.iImapAclUser,self.__tr("<b>User</b>. Use comma as user separator."))
        self.cbACL.clear()
        self.cbACL.insertItem(QString.null)
        self.cbACL.insertItem(self.__tr("Read"))
        self.cbACL.insertItem(self.__tr("Add"))
        self.cbACL.insertItem(self.__tr("Write"))
        self.cbACL.insertItem(self.__tr("Post"))
        self.cbACL.insertItem(self.__tr("Full"))
        QToolTip.add(self.cbACL,self.__tr("<b>L</b>: List\n"
"<br><b>R</b>: Read<br><b>S</b>: Read status\n"
"<br><b>W</b>: Write status\n"
"<br><b>I</b>: Write message <br><b>C</b>: Create/Delete folders\n"
"<br><b>D</b>: Delete message\n"
"<br><b>P</b>: Post\n"
"<br><b>A</b>: Add/Delete Acls"))
        QWhatsThis.add(self.cbACL,QString.null)
        self.pImapAclAdd.setText(self.__tr("+"))
        QToolTip.add(self.pImapAclAdd,self.__tr("<b>Add</b>"))
        self.pImapAclDel.setText(self.__tr("-"))
        QToolTip.add(self.pImapAclDel,self.__tr("<b>Delete</b>"))
        self.lvImapAcl.header().setLabel(0,self.__tr("User"))
        self.lvImapAcl.header().setLabel(1,self.__tr("Permissions"))
        self.textLabel4_2_2.setText(self.__tr("<b>Annotation</b>"))
        self.textLabel2_5_2.setText(self.__tr("Annotation:"))
        self.cbImapAnnotation.clear()
        self.cbImapAnnotation.insertItem(self.__tr("/vendor/cmu/cyrus-imapd/expire"))
        self.cbImapAnnotation.insertItem(self.__tr("/vendor/cmu/cyrus-imapd/partition"))
        self.cbImapAnnotation.insertItem(self.__tr("/vendor/cmu/cyrus-imapd/size"))
        self.cbImapAnnotation.insertItem(self.__tr("/vendor/cmu/cyrus-imapd/lastupdate"))
        self.cbImapAnnotation.insertItem(self.__tr("/vendor/cmu/cyrus-imapd/lastpop"))
        self.cbImapAnnotation.insertItem(self.__tr("/vendor/cmu/cyrus-imapd/squat"))
        self.cbImapAnnotation.insertItem(self.__tr("/comment"))
        self.pImapAnnotation.setText(self.__tr("OK"))
        self.textLabel2_5.setText(self.__tr("Value:"))
        self.textLabel4_2.setText(self.__tr("<b>Quota</b>"))
        self.textLabel1.setText(self.__tr("Used:"))
        self.textLabel2_2.setText(self.__tr("Limit:"))
        self.textLabel2.setText(self.__tr("Kbytes"))
        self.textLabel2_4.setText(self.__tr("Kbytes"))
        self.pImapQuota.setText(self.__tr("OK"))
        self.tCyrUser.setText(self.__tr("Mailbox:"))
        self.pImapSearch.setText(self.__tr("&Search"))
        self.pImapSearch.setAccel(QKeySequence(self.__tr("Alt+S")))
        self.cImapExpand.setText(self.__tr("Expand"))
        self.buttonGroup3_2_2.setTitle(QString.null)
        self.rbImapMailboxMode.setText(self.__tr("User"))
        self.rbImapMailboxMode2.setText(self.__tr("Global"))
        self.tCyrUser_2.setText(self.__tr("Mailbox:"))
        self.pImapPartitionSearch.setText(self.__tr("&Search"))
        self.pImapPartitionSearch.setAccel(QKeySequence(self.__tr("Alt+S")))
        self.cImapSize.setText(self.__tr("Used/Limit"))
        self.buttonGroup3_2.setTitle(QString.null)
        self.rbImapPartMailboxMode.setText(self.__tr("User"))
        self.rbImapPartMailboxMode2.setText(self.__tr("Global"))
        self.textLabel1_2_2.setText(self.__tr("Partition:"))
        self.pImapPartitionMove.setText(self.__tr("&Move"))
        self.pImapPartitionMove.setAccel(QKeySequence(self.__tr("Alt+M")))
        self.tlImapSize.setText(self.__tr("0 ~ 0 Mbytes ~ 0%"))
        self.cImapSizeUpdate.setText(QString.null)
        self.lvImapPartition.header().setLabel(0,self.__tr("IMAP Mailbox"))
        self.lvImapPartition.header().setLabel(1,self.__tr("Partition"))
        self.lvImapPartition.header().setLabel(2,self.__tr("Used"))
        self.lvImapPartition.header().setLabel(3,self.__tr("Limit"))
        self.lvImapPartition.header().setLabel(4,self.__tr("%"))
        self.tCyrUser_2_2.setText(self.__tr("Mailbox:"))
        self.pSieveSearch.setText(self.__tr("&Search"))
        self.pSieveSearch.setAccel(QKeySequence(self.__tr("Alt+S")))
        self.cSieveScript.setText(self.__tr("Active script"))
        self.lvSieve.header().setLabel(0,self.__tr("IMAP Users"))
        self.lvSieve.header().setLabel(1,self.__tr("Filed"))
        self.lvSieve.header().setLabel(2,self.__tr("Active script"))
        self.textLabel1_2_2_2.setText(self.__tr("Script:"))
        self.pSieveScriptActive.setText(self.__tr("+"))
        QToolTip.add(self.pSieveScriptActive,self.__tr("<b>Activate</b>"))
        self.pSieveScriptDisable.setText(self.__tr("-"))
        QToolTip.add(self.pSieveScriptDisable,self.__tr("<b>Disable</b>"))
        self.pSieveScriptRemove.setText(self.__tr("x"))
        QToolTip.add(self.pSieveScriptRemove,self.__tr("<b>Delete</b>"))
        self.textLabel1_8.setText(self.__tr("<b>Templates:</b>"))
        self.pQueueLoad.setText(self.__tr("&Update"))
        self.pQueueLoad.setAccel(QKeySequence(self.__tr("Alt+U")))
        self.textLabel1_12.setText(self.__tr("<b>Total:</b>"))
        self.tlQueueMsgs.setText(self.__tr("0/0"))
        self.lvQueue.header().setLabel(0,self.__tr("Sender"))
        self.lvQueue.header().setLabel(1,self.__tr("Items"))
        self.textLabel3_3_2_2_2_4.setText(self.__tr("<b>Files</b>"))
        self.cbServicesFileOpen.clear()
        self.cbServicesFileOpen.insertItem(QString.null)
        self.cbServicesFileOpen.insertItem(self.__tr("/etc/cyrus.conf"))
        self.cbServicesFileOpen.insertItem(self.__tr("/etc/imapd.conf"))
        self.cbServicesFileOpen.insertItem(self.__tr("/etc/saslauthd.conf"))
        self.cbServicesFileOpen.insertItem(self.__tr("/etc/default/saslauthd"))
        self.cbServicesFileOpen.insertItem(self.__tr("/etc/postfix/main.cf"))
        self.cbServicesFileOpen.insertItem(self.__tr("/etc/postfix/master.cf"))
        self.pServicesFileOpen.setText(self.__tr("&Open"))
        self.pServicesFileOpen.setAccel(QKeySequence(self.__tr("Alt+O")))
        self.pServicesFileSave.setText(self.__tr("&Save"))
        self.pServicesFileSave.setAccel(QKeySequence(self.__tr("Alt+S")))
        self.pServicesFilePostmap.setText(self.__tr("P&ostmap"))
        self.pServicesFilePostmap.setAccel(QKeySequence(self.__tr("Alt+O")))
        self.textLabel3_3_2_2_2_2.setText(self.__tr("<b>Postfix</b>"))
        self.pServicesPostconfSave.setText(self.__tr("Sa&ve"))
        self.pServicesPostconfSave.setAccel(QKeySequence(self.__tr("Alt+V")))
        self.buttonGroup3.setTitle(QString.null)
        self.rbServicesPostconfD.setText(self.__tr("Defaults values"))
        self.rbServicesPostconfAll.setText(self.__tr("All options"))
        self.rbServicesPostconfN.setText(self.__tr("Configured options"))
        self.textLabel3_3_2_2_2_3.setText(self.__tr("<b>Services</b>"))
        self.textLabel1_4.setText(self.__tr("Service:"))
        self.cbServiceService.clear()
        self.cbServiceService.insertItem(self.__tr("postfix"))
        self.cbServiceService.insertItem(self.__tr("slapd"))
        self.cbServiceService.insertItem(self.__tr("cyrus2.2"))
        self.cbServiceStatus.clear()
        self.cbServiceStatus.insertItem(self.__tr("restart"))
        self.cbServiceStatus.insertItem(self.__tr("stop"))
        self.cbServiceStatus.insertItem(self.__tr("start"))
        self.pServiceStatus.setText(self.__tr("OK"))
        self.pServiceStatus.setAccel(QKeySequence(QString.null))
        self.lvServices.header().setLabel(0,self.__tr("Menu"))
        self.lvServices.header().setLabel(1,self.__tr("Option"))
        self.lvServices.clear()
        item = QListViewItem(self.lvServices,None)
        item.setText(0,self.__tr("Files"))
        item.setText(1,self.__tr("1"))

        item = QListViewItem(self.lvServices,item)
        item.setText(0,self.__tr("Services"))
        item.setText(1,self.__tr("2"))

        item_2 = QListViewItem(self.lvServices,item)
        item_2.setOpen(1)
        item = QListViewItem(item_2,item)
        item.setText(0,self.__tr("Postfix"))
        item.setText(1,self.__tr("3.1"))
        item_2.setText(0,self.__tr("Tools"))
        item_2.setText(1,self.__tr("3"))

        self.lvConfig.header().setLabel(0,self.__tr("Configuration"))
        self.lvConfig.header().setLabel(1,self.__tr("Option"))
        self.lvConfig.clear()
        item_3 = QListViewItem(self.lvConfig,None)
        item_3.setOpen(1)
        item = QListViewItem(item_3,None)
        item.setText(0,self.__tr("LDAP"))
        item.setText(1,self.__tr("2.1"))
        item_3.setOpen(1)
        item_4 = QListViewItem(item_3,item)
        item_4.setOpen(1)
        item = QListViewItem(item_4,item)
        item.setText(0,self.__tr("Annotation"))
        item.setText(1,self.__tr("2.2.1"))
        item_4.setText(0,self.__tr("IMAP"))
        item_4.setText(1,self.__tr("2.2"))
        item_3.setOpen(1)
        item = QListViewItem(item_3,item_4)
        item.setText(0,self.__tr("SSH"))
        item.setText(1,self.__tr("2.3"))
        item_3.setText(0,self.__tr("Servers"))
        item_3.setText(1,self.__tr("2"))

        item_5 = QListViewItem(self.lvConfig,item_3)
        item_5.setOpen(1)
        item_6 = QListViewItem(item_5,item_3)
        item_6.setOpen(1)
        item = QListViewItem(item_6,item_3)
        item.setText(0,self.__tr("DHCP Populate"))
        item.setText(1,self.__tr("4.1.1"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("SMB Populate"))
        item.setText(1,self.__tr("4.1.2"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("SMB"))
        item.setText(1,self.__tr("4.1.3"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("Schema"))
        item.setText(1,self.__tr("4.1.4"))
        item_6.setText(0,self.__tr("LDAP"))
        item_6.setText(1,self.__tr("4.1"))
        item_5.setOpen(1)
        item = QListViewItem(item_5,item_6)
        item.setText(0,self.__tr("IMAP"))
        item.setText(1,self.__tr("4.2"))
        item_5.setText(0,self.__tr("Preferences"))
        item_5.setText(1,self.__tr("4"))

        self.textLabel3_3_3.setText(self.__tr("<b>LDAP Server</b>"))
        self.textLabel4.setText(self.__tr("<b>Server:</b>"))
        self.tLdapUser.setText(self.__tr("Admin user:"))
        self.tLdapPass.setText(self.__tr("Password:"))
        self.tLdapName.setText(self.__tr("Name:"))
        self.tLdapHost.setText(self.__tr("Host:"))
        self.tLdapPort.setText(self.__tr("Port:"))
        self.tLdapBaseDN.setText(self.__tr("BaseDN:"))
        self.pConfDelLdapConnection.setText(self.__tr("Del"))
        self.cbLdapMode.clear()
        self.cbLdapMode.insertItem(self.__tr("ldap://"))
        self.cbLdapMode.insertItem(self.__tr("ldaps://"))
        self.iLdapPort.setText(self.__tr("389"))
        self.cLdapRef.setText(self.__tr("Expand referrals"))
        self.cLdapCert.setText(self.__tr("Don't verify SSL certificate (must restart)"))
        self.pGetBaseDN.setText(self.__tr("Get"))
        self.textLabel3_3_2.setText(self.__tr("<b>IMAP Server</b>"))
        self.textLabel6_2.setText(self.__tr("<b>Server:</b>"))
        self.tCyrusPartition_3.setText(self.__tr("Sieve port:"))
        self.tCyrusPartition.setText(self.__tr("Partition:"))
        self.tCyrusUser.setText(self.__tr("Admin user:"))
        self.tCyrusPass.setText(self.__tr("Password:"))
        self.textLabel7_2.setText(self.__tr("Name:"))
        self.tCyrusHost.setText(self.__tr("Host:"))
        self.tCyrusPort.setText(self.__tr("Port:"))
        self.pConfDelImapConnection.setText(self.__tr("Del"))
        self.cbCyrusMode.clear()
        self.cbCyrusMode.insertItem(self.__tr("imap://"))
        self.cbCyrusMode.insertItem(self.__tr("imaps://"))
        self.iCyrusPort.setText(self.__tr("143"))
        self.iCyrusPart.setText(QString.null)
        self.iCyrusSievePort.setText(self.__tr("2000"))
        self.textLabel3_3.setText(self.__tr("<b>SSH Server</b>"))
        self.textLabel8.setText(self.__tr("<b>Server:</b>"))
        self.textLabel9.setText(self.__tr("Name:"))
        self.tCyrusHost_2.setText(self.__tr("Host:"))
        self.tCyrusPort_2.setText(self.__tr("Port:"))
        self.tCyrusUser_2.setText(self.__tr("User:"))
        self.tCyrusPass_2.setText(self.__tr("Password:"))
        self.tCyrusUser_2_3.setText(self.__tr("Sudo:"))
        self.pConfDelSshConnection.setText(self.__tr("Del"))
        self.iSshPort.setText(self.__tr("22"))
        self.cbSSHsudo.clear()
        self.cbSSHsudo.insertItem(self.__tr("Disabled (root login)"))
        self.cbSSHsudo.insertItem(self.__tr("Enable without password (NOPASSWD)"))
        self.textLabel10_4.setText(self.__tr("<b>Servers</b>"))
        self.tConfShowSshServer.setText(self.__tr("Host:"))
        self.tConfShowSshUser.setText(self.__tr("User:"))
        self.textLabel10_3.setText(self.__tr("<b>SSH Server</b>"))
        self.tConfShowLdapServer.setText(self.__tr("Host:"))
        self.tConfShowLdapUser.setText(self.__tr("User:"))
        self.tConfShowLdapBaseDN.setText(self.__tr("BaseDN:"))
        self.textLabel10_2.setText(self.__tr("<b>LDAP Server</b>"))
        self.tConfShowImapServer.setText(self.__tr("Host:"))
        self.tConfShowImapUser.setText(self.__tr("User:"))
        self.tConfShowImapSep.setText(self.__tr("Imap delimiter: disconnected"))
        self.textLabel10.setText(self.__tr("<b>IMAP Server</b>"))
        self.textLabel3_3_2_3_2_2_2.setText(self.__tr("<b>LDAP Preferences</b>"))
        self.textLabel1_3_2_3_2_3_2.setText(self.__tr("Auto-complete user:"))
        QToolTip.add(self.textLabel1_3_2_3_2_3_2,self.__tr("<b>uidNumber</b>"))
        self.textLabel1_5_3.setText(self.__tr("<b>Servers</b>"))
        self.textLabel1_5_3_2.setText(self.__tr("<b>Filters</b>"))
        self.lbConfLdapFilter.clear()
        self.lbConfLdapFilter.insertItem(self.__tr("objectClass=*"))
        self.lbConfLdapFilter.insertItem(self.__tr("ou=*"))
        self.lbConfLdapFilter.insertItem(self.__tr("cn=*"))
        self.lbConfLdapFilter.insertItem(self.__tr("uid=*"))
        self.lbConfLdapFilter.insertItem(self.__tr("mail=*"))
        self.pConfLdapFilterAdd.setText(self.__tr("+"))
        self.pConfLdapFilterDel.setText(self.__tr("-"))
        self.textLabel1_5_3_2_2.setText(self.__tr("<b>New user and set Password options</b>"))
        self.cbConfLdapCompleteUser.clear()
        self.cbConfLdapCompleteUser.insertItem(self.__tr("cn=admin"))
        self.cbConfLdapCompleteUser.insertItem(self.__tr("cn=manager"))
        self.cbConfLdapCompleteUser.insertItem(self.__tr("uid=root,ou=users"))
        self.cConfLdapsambaPwdMustChange.setText(self.__tr("Change password required in logon time"))
        self.textLabel1_6.setText(self.__tr("Distinguist Name of new user entry:"))
        self.cbConfLdapUserDN.clear()
        self.cbConfLdapUserDN.insertItem(self.__tr("cn"))
        self.cbConfLdapUserDN.insertItem(self.__tr("mail"))
        self.cbConfLdapUserDN.insertItem(self.__tr("uid"))
        self.textLabel3_3_2_3.setText(self.__tr("<b>IMAP Preferences</b>"))
        self.textLabel6_2_3.setText(self.__tr("<b>Default IMAP folders</b>"))
        self.iConfImapExpire.setText(QString.null)
        self.cbConfImapACLp.clear()
        self.cbConfImapACLp.insertItem(self.__tr("No"))
        self.cbConfImapACLp.insertItem(self.__tr("Yes"))
        self.pConfImapFoldersAdd.setText(self.__tr("+"))
        self.pConfImapFoldersDel.setText(self.__tr("-"))
        self.lvConfImapFolders.header().setLabel(0,self.__tr("Name"))
        self.lvConfImapFolders.header().setLabel(1,self.__tr("Expire (days)"))
        self.lvConfImapFolders.header().setLabel(2,self.__tr("ACL anyone"))
        self.lvConfImapFolders.clear()
        item = QListViewItem(self.lvConfImapFolders,None)
        item.setText(0,self.__tr("Trash"))
        item.setText(1,self.__tr("60"))

        item = QListViewItem(self.lvConfImapFolders,item)
        item.setText(0,self.__tr("Sent"))

        item = QListViewItem(self.lvConfImapFolders,item)
        item.setText(0,self.__tr("Drafts"))

        item = QListViewItem(self.lvConfImapFolders,item)
        item.setText(0,self.__tr("Spam"))
        item.setText(1,self.__tr("30"))
        item.setText(2,self.__tr("p"))

        self.textLabel1_10.setText(self.__tr("Limit:"))
        self.textLabel1_7.setText(self.__tr("Mbytes"))
        self.textLabel7_2_3.setText(self.__tr("<b>Default Quota</b>"))
        self.textLabel3_3_2_3_2.setText(self.__tr("<b>LDAP SMB Preferences</b>"))
        self.textLabel8_2.setText(self.__tr("Domain:"))
        self.pConfLdapSmbDomainDel.setText(self.__tr("Del"))
        self.tCyrusHost_2_2_4_2_2.setText(self.__tr("Logon script:"))
        QToolTip.add(self.tCyrusHost_2_2_4_2_2,self.__tr("<b>sambaLogonScript</b>"))
        self.tCyrusHost_2_2_4.setText(self.__tr("Drive:"))
        QToolTip.add(self.tCyrusHost_2_2_4,self.__tr("<b>sambaHomeDrive</b>"))
        self.iConfLdapSmbHomeDrive.setText(self.__tr("S:"))
        self.iConfLdapSmbDrivePath.setText(self.__tr("\\\\server\\#UID#"))
        self.cbConfLdapSmbLogonScript.clear()
        self.cbConfLdapSmbLogonScript.insertItem(self.__tr("netlogon.bat"))
        self.cbConfLdapSmbLogonScript.insertItem(self.__tr("#UID#.bat"))
        self.cbConfLdapSmbLogonScript.insertItem(self.__tr("#GID#.bat"))
        self.cbConfLdapSmbProfilePath.clear()
        self.cbConfLdapSmbProfilePath.insertItem(self.__tr("\\\\server\\profiles\\#UID#"))
        self.cbConfLdapSmbProfilePath.insertItem(self.__tr("\\\\server\\#UID#\\.profile"))
        self.tCyrusHost_2_2_4_2.setText(self.__tr("Drive Path:"))
        QToolTip.add(self.tCyrusHost_2_2_4_2,self.__tr("<b>sambaHomePath</b>"))
        self.textLabel1_5_2_3.setText(self.__tr("<b>sambaDomain</b>"))
        self.pConfLdapSmbGetsambaUnixPoolId.setText(self.__tr("Get"))
        self.tCyrusUser_2_2_2.setText(self.__tr("SID Dn:"))
        QToolTip.add(self.tCyrusUser_2_2_2,self.__tr("<b>sambaSID</b>"))
        self.tCyrusUser_2_2.setText(self.__tr("Uid counter:"))
        QToolTip.add(self.tCyrusUser_2_2,self.__tr("<b>uidNumber</b>"))
        self.pConfLdapSmbGetsambaDomain.setText(self.__tr("Get"))
        self.textLabel9_2.setText(self.__tr("Domain:"))
        QToolTip.add(self.textLabel9_2,self.__tr("<b>sambaDomain</b>"))
        self.textLabel1_5_2_3_2.setText(self.__tr("<b>sambaSamAccount</b>"))
        self.tCyrusHost_2_2_2.setText(self.__tr("Profile type:"))
        QToolTip.add(self.tCyrusHost_2_2_2,self.__tr("<b>sambaProfilePath</b>"))
        self.cbConfLdapSmbProfileType.clear()
        self.cbConfLdapSmbProfileType.insertItem(self.__tr("Local"))
        self.cbConfLdapSmbProfileType.insertItem(self.__tr("Remote"))
        self.cbConfLdapSmbPrimaryGroup.clear()
        self.cbConfLdapSmbPrimaryGroup.insertItem(self.__tr("Domain Users (513)"))
        self.cbConfLdapSmbPrimaryGroup.insertItem(self.__tr("Domain Guests (514)"))
        self.cbConfLdapSmbPrimaryGroup.insertItem(self.__tr("Domain Admins (512)"))
        self.tCyrusHost_2_2_3.setText(self.__tr("Group:"))
        QToolTip.add(self.tCyrusHost_2_2_3,self.__tr("<b>sambaPrimaryGroupSID</b>"))
        self.cConfLdapSmbPwdMustChange.setText(self.__tr("Change password required in logon time"))
        QToolTip.add(self.cConfLdapSmbPwdMustChange,self.__tr("<b>sambaPwdMustChange</b>"))
        self.textLabel3_3_2_3_2_2.setText(self.__tr("<b>LDAP SMB Populate Preferences</b>"))
        self.textLabel1_3_2_3_2_3.setText(self.__tr("First uidNumber:"))
        QToolTip.add(self.textLabel1_3_2_3_2_3,self.__tr("<b>uidNumber</b>"))
        self.textLabel1_3_2_3_2_2_6.setText(self.__tr("First gidNumber:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_6,self.__tr("<b>gidNumber</b>"))
        self.textLabel1_3_2_3_2_2_3_3_3.setText(self.__tr("Unlock account after:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_3_3,self.__tr("<b>sambaLockoutDuration</b>"))
        self.textLabel1_3_2_3_2_2_3_2.setText(self.__tr("Deny password reuse:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_2,self.__tr("<b>sambaPwdHistoryLength</b>"))
        self.textLabel1_3_2_3_2_2_2_3_2.setText(self.__tr("Logon errors to lock account:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_2_3_2,self.__tr("<b>sambaLockoutThreshold</b>"))
        self.textLabel1_3_2_3_2_2_3_3_2_2.setText(self.__tr("Extend lock after new logon errors:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_3_2_2,self.__tr("<b>sambaLockoutObservationWindow</b>"))
        self.textLabel1_3_2_3_2_2_4_2.setText(self.__tr("Force change password:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_4_2,self.__tr("<b>sambaMaxPwdAge</b>"))
        self.textLabel1_3_2_3_2_2_2_2.setText(self.__tr("Minimun password lenght:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_2_2,self.__tr("<b>sambaMinPwdLength</b>"))
        self.textLabel1_3_2_3_2_2_5_2.setText(self.__tr("Wait before change password:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_5_2,self.__tr("<b>sambaMinPwdAge</b>"))
        self.textLabel1_5_2.setText(self.__tr("<b>sambaDomain</b>"))
        self.textLabel1_5.setText(self.__tr("<b>sambaUnixIdPool</b>"))
        self.iConfLdapSMBlockoutWindow.setText(self.__tr("30"))
        self.iConfLdapSMBlockoutDuration.setText(self.__tr("30"))
        self.iConfLdapSMBlockout.setText(self.__tr("3"))
        self.iConfLdapSMBminPwdAge.setText(self.__tr("60"))
        self.iConfLdapSMBmaxPwdAge.setText(self.__tr("86400"))
        self.iConfLdapSMBpwdHistLenght.setText(self.__tr("5"))
        self.iConfLdapSMBminPwdLength.setText(self.__tr("5"))
        self.cbConfLdapSMBminPwdAge.clear()
        self.cbConfLdapSMBminPwdAge.insertItem(self.__tr("minutes"))
        self.cbConfLdapSMBminPwdAge.insertItem(self.__tr("hours"))
        self.cbConfLdapSMBminPwdAge.insertItem(self.__tr("days"))
        self.cbConfLdapSMBlockoutDuration.clear()
        self.cbConfLdapSMBlockoutDuration.insertItem(self.__tr("minutes"))
        self.cbConfLdapSMBlockoutDuration.insertItem(self.__tr("hours"))
        self.cbConfLdapSMBlockoutDuration.insertItem(self.__tr("days"))
        self.cbConfLdapSMBmaxPwdAge.clear()
        self.cbConfLdapSMBmaxPwdAge.insertItem(self.__tr("minutes"))
        self.cbConfLdapSMBmaxPwdAge.insertItem(self.__tr("hours"))
        self.cbConfLdapSMBmaxPwdAge.insertItem(self.__tr("days"))
        self.cbConfLdapSMBlockoutWindow.clear()
        self.cbConfLdapSMBlockoutWindow.insertItem(self.__tr("minutes"))
        self.cbConfLdapSMBlockoutWindow.insertItem(self.__tr("hours"))
        self.cbConfLdapSMBlockoutWindow.insertItem(self.__tr("days"))
        self.iConfLdapSMBgidNumber.setText(self.__tr("1000"))
        self.iConfLdapSMBuidNumber.setText(self.__tr("1000"))
        self.textLabel3_3_2_2.setText(self.__tr("<b>LDAP Schema Preferences</b>"))
        self.cConfLdapSchemaAddAttr.setText(self.__tr("To Add objectClasses"))
        self.cConfLdapSchemaDelAttr.setText(self.__tr("To Delete objectClasses"))
        self.textLabel1_9.setText(self.__tr("<b>Auxiliary schema</b>"))
        self.pConfLdapSchemaDelItem.setText(self.__tr("-"))
        self.pConfLdapSchemaAddItem.setText(self.__tr("+"))
        self.lvConfLdapSchema.header().setLabel(0,self.__tr("Attribute"))
        self.lvConfLdapSchema.header().setLabel(1,self.__tr("Value"))
        self.lvConfLdapSchema.clear()
        item_7 = QListViewItem(self.lvConfLdapSchema,None)
        item_7.setOpen(1)
        item_8 = QListViewItem(item_7,None)
        item_8.setOpen(1)
        item = QListViewItem(item_8,None)
        item.setText(0,self.__tr("ou"))
        item.setText(1,self.__tr("domain1"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("ref"))
        item.setText(1,self.__tr("ldap://127.0.0.1/ou=example,o=Example%20Corporation??sub"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("extensibleObject"))
        item_8.setText(0,self.__tr("referral"))
        item_7.setOpen(1)
        item_9 = QListViewItem(item_7,item_8)
        item_9.setOpen(1)
        item = QListViewItem(item_9,item_8)
        item.setText(0,self.__tr("displayName"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaSID"))
        item.setText(1,self.__tr("S-0-0-00-0000000000-0000000000-0000000000-0000"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaAcctFlags"))
        item.setText(1,self.__tr("[U          ]"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaPwdMustChange"))
        item.setText(1,self.__tr("2147483647"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaPwdLastSet"))
        item.setText(1,self.__tr("1"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaPwdCanChange"))
        item.setText(1,self.__tr("0"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaProfilePath"))
        item.setText(1,self.__tr("\\\\PDC\\profiles\\#UID#"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaPrimaryGroupSID"))
        item.setText(1,self.__tr("S-0-0-00-0000000000-0000000000-0000000000-514"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaNTPassword"))
        item.setText(1,self.__tr("XXX"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaLogonTime"))
        item.setText(1,self.__tr("0"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaLogonScript"))
        item.setText(1,self.__tr("logon.bat"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaLogoffTime"))
        item.setText(1,self.__tr("2147483647"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaLMPassword"))
        item.setText(1,self.__tr("XXX"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaKickoffTime"))
        item.setText(1,self.__tr("2147483647"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaHomePath"))
        item.setText(1,self.__tr("\\\\PDC-SRV\\#UID#"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sambaHomeDrive"))
        item.setText(1,self.__tr("H:"))
        item_9.setText(0,self.__tr("sambaSamAccount"))
        item_7.setOpen(1)
        item_10 = QListViewItem(item_7,item_9)
        item_10.setOpen(1)
        item = QListViewItem(item_10,item_9)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("shadowAccount"))
        item_10.setOpen(1)
        item = QListViewItem(item_10,item)
        item.setText(0,self.__tr("sn"))
        item_10.setOpen(1)
        item = QListViewItem(item_10,item)
        item.setText(0,self.__tr("cn"))
        item_10.setOpen(1)
        item = QListViewItem(item_10,item)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("inetOrgPerson"))
        item_10.setOpen(1)
        item = QListViewItem(item_10,item)
        item.setText(0,self.__tr("loginShell"))
        item.setText(1,self.__tr("/bin/bash"))
        item_10.setOpen(1)
        item = QListViewItem(item_10,item)
        item.setText(0,self.__tr("homeDirectory"))
        item.setText(1,self.__tr("/home/"))
        item_10.setOpen(1)
        item = QListViewItem(item_10,item)
        item.setText(0,self.__tr("gidNumber"))
        item_10.setOpen(1)
        item = QListViewItem(item_10,item)
        item.setText(0,self.__tr("uidNumber"))
        item_10.setOpen(1)
        item = QListViewItem(item_10,item)
        item.setText(0,self.__tr("uid"))
        item_10.setText(0,self.__tr("posixAccount"))
        item_7.setOpen(1)
        item_11 = QListViewItem(item_7,item_10)
        item_11.setOpen(1)
        item = QListViewItem(item_11,item_10)
        item.setText(0,self.__tr("cn"))
        item_11.setOpen(1)
        item = QListViewItem(item_11,item)
        item.setText(0,self.__tr("sn"))
        item_11.setText(0,self.__tr("inetOrgPerson"))
        item_7.setText(0,self.__tr("objectClass"))

        self.textLabel3_3_2_2_2_5.setText(self.__tr("<b>IMAP Server Annotation</b>"))
        self.textLabel2_5_3.setText(self.__tr("Value:"))
        self.textLabel2_5_2_3.setText(self.__tr("Annotation:"))
        self.cbImapAnnotationServer.clear()
        self.cbImapAnnotationServer.insertItem(QString.null)
        self.cbImapAnnotationServer.insertItem(self.__tr("/admin"))
        self.cbImapAnnotationServer.insertItem(self.__tr("/comment"))
        self.cbImapAnnotationServer.insertItem(self.__tr("/motd"))
        self.cbImapAnnotationServer.insertItem(self.__tr("/vendor/cmu/cyrus-imapd/expire"))
        self.cbImapAnnotationServer.insertItem(self.__tr("/vendor/cmu/cyrus-imapd/shutdown"))
        self.cbImapAnnotationServer.insertItem(self.__tr("/vendor/cmu/cyrus-imapd/squat"))
        self.pImapAnnotationServer.setText(self.__tr("OK"))
        self.textLabel3_3_2_3_2_2_3.setText(self.__tr("<b>LDAP DHCP Populate Preferences</b>"))
        self.textLabel1_5_4.setText(self.__tr("<b>dhcpService</b>"))
        self.textLabel1_3_2_2_2_3_2_4.setText(self.__tr("Domain name:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_4,self.__tr("<b>dhcpOption: domain-name</b>"))
        self.textLabel1_3_2_2_2_3_2_2_3.setText(self.__tr("Netbios servers:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_2_3,self.__tr("<b>dhcpOption: netbios-name-servers</b>"))
        self.textLabel1_3_2_2_2_3_2_2_2_3.setText(self.__tr("DNS servers:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_2_2_3,self.__tr("<b>dhcpOption: domain-name-servers</b>"))
        self.textLabel1_3_2_3_2_2_5_3_2.setText(self.__tr("Max lease time:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_5_3_2,self.__tr("<b>dhcpStatements: default-lease-time</b>"))
        self.iConfLdapDhcpDefaultLeaseTime.setText(self.__tr("3600"))
        self.iConfLdapDhcpMaxLeaseTime.setText(self.__tr("28800"))
        QToolTip.add(self.iConfLdapDhcpMaxLeaseTime,self.__tr("<b>0: disabled</b>"))
        self.cbConfLdapDhcpDefaultLeaseTime.clear()
        self.cbConfLdapDhcpDefaultLeaseTime.insertItem(self.__tr("seconds"))
        self.cbConfLdapDhcpDefaultLeaseTime.insertItem(self.__tr("minutes"))
        self.cbConfLdapDhcpDefaultLeaseTime.insertItem(self.__tr("hours"))
        self.cbConfLdapDhcpDefaultLeaseTime.insertItem(self.__tr("days"))
        self.cbConfLdapDhcpMaxLeaseTime.clear()
        self.cbConfLdapDhcpMaxLeaseTime.insertItem(self.__tr("seconds"))
        self.cbConfLdapDhcpMaxLeaseTime.insertItem(self.__tr("minutes"))
        self.cbConfLdapDhcpMaxLeaseTime.insertItem(self.__tr("hours"))
        self.cbConfLdapDhcpMaxLeaseTime.insertItem(self.__tr("days"))
        self.iConfLdapDhcpDomainName.setText(self.__tr("example.com"))
        QToolTip.add(self.iConfLdapDhcpDomainName,self.__tr("<b>example.com</b>"))
        self.iConfLdapDhcpNetbiosServers.setText(self.__tr("192.168.0.1"))
        QToolTip.add(self.iConfLdapDhcpNetbiosServers,self.__tr("<b> 192.168.0.1</b>"))
        self.iConfLdapDhcpDNSservers.setText(self.__tr("192.168.0.2"))
        QToolTip.add(self.iConfLdapDhcpDNSservers,self.__tr("<b> 192.168.0.2</b>"))
        self.textLabel1_5_2_2.setText(self.__tr("<b>dhcpSubnet</b>"))
        self.cbConfLdapDhcpNetmask.clear()
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("32"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("31"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("30"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("29"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("28"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("27"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("26"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("25"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("24"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("23"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("22"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("21"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("20"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("19"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("18"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("17"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("16"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("15"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("14"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("13"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("12"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("11"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("10"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("9"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("8"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("7"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("6"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("5"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("4"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("3"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("2"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("1"))
        self.cbConfLdapDhcpNetmask.insertItem(self.__tr("0"))
        QToolTip.add(self.cbConfLdapDhcpNetmask,self.__tr("<b>/24</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_2_3.setText(self.__tr("Netmask:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_2_3,self.__tr("<b>dhcpNetMask</b>"))
        self.textLabel1_3_2_2_2_3_2_3_2_3.setText(self.__tr("Range IP:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_2_3,self.__tr("<b>dhcpRange</b>"))
        self.iConfLdapDhcpNetwork.setText(self.__tr("192.168.0.0"))
        QToolTip.add(self.iConfLdapDhcpNetwork,self.__tr("<b> 192.168.0.0</b>"))
        self.iConfLdapDhcpRange.setText(self.__tr("192.168.0.10 192.168.0.100"))
        QToolTip.add(self.iConfLdapDhcpRange,self.__tr("<b> 192.168.0.10 192.168.0.100</b>"))
        self.iConfLdapDhcpGateway.setText(self.__tr("192.168.0.254"))
        QToolTip.add(self.iConfLdapDhcpGateway,self.__tr("<b> 192.168.0.254</b>"))
        self.iConfLdapDhcpBroadcast.setText(self.__tr("192.168.0.255"))
        QToolTip.add(self.iConfLdapDhcpBroadcast,self.__tr("<b> 192.168.0.255</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_3_3.setText(self.__tr("Gateway:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_3_3,self.__tr("<b>dhcpOption: routers</b>"))
        self.cbConfLdapDhcpInterface.clear()
        self.cbConfLdapDhcpInterface.insertItem(self.__tr("eth0"))
        self.cbConfLdapDhcpInterface.insertItem(self.__tr("eth1"))
        self.cbConfLdapDhcpInterface.insertItem(self.__tr("eth2"))
        self.cbConfLdapDhcpInterface.insertItem(self.__tr("eth3"))
        self.textLabel1_3_2_2_2_3_2_2_2_2_2.setText(self.__tr("Network interface:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_2_2_2_2,self.__tr("<b>cn of dhcpSharedNetwork</b>"))
        self.textLabel1_3_2_2_2_3_2_3_5.setText(self.__tr("Network address:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_5,self.__tr("<b>cn of dhcpSubnet</b>"))
        self.textLabel1_3_2_2_2_3_2_3_3_5.setText(self.__tr("Broadcast address:"))
        QToolTip.add(self.textLabel1_3_2_2_2_3_2_3_3_5,self.__tr("<b>dhcpOption: broadcast-address</b>"))
        self.textLabel1_3_2_2_2_2_2_2.setText(self.__tr("Default lease time:"))
        QToolTip.add(self.textLabel1_3_2_2_2_2_2_2,self.__tr("<b>dhcpStatements: default-lease-time</b>"))
        self.pSaveConfig.setText(self.__tr("&Save"))
        self.pSaveConfig.setAccel(QKeySequence(self.__tr("Alt+S")))


    def init(self):
        
        #
        # Declare basic functions
        #
        
        global utf2uni, Q2uni, Q2utf
        
        def utf2uni(string):
            return unicode(string, 'utf-8')
        
        def Q2uni(QString2uni):
            if type(QString2uni) == type(QString()):
                str = unicode(QString2uni.latin1(), 'iso-8859-1')
            else:
                str = u""
            return str
        
        def Q2utf(QString2utf):
            if type(QString2utf) == type(QString()):
                str = unicode(QString2utf.latin1(), 'iso-8859-1')
            else:
                str = u""
            return str.encode('utf-8')
        
        #
        # Declare variables
        #
        
        self.module_failed = []
        self.ldap_cache = LdapCache()
        self.ldap_items = QLdapCache(self.lvLdap)
        self.imap_cache_items = {}
        self.inet_cache = {}
        self.confDict = {}
        self.ldap_dn_rename = None
        self.ldap_add_or_modify = True
        self.imap_mailbox_rename = None
        self.sieve_scripts = {}
        self.CONSOLE_OK = 0
        self.CONSOLE_ERR = 1
        self.CONSOLE_WARN = 2
        self.CONSOLE_INFO = 3
        
        #
        # Load Python modules
        #
        
        try:
            global sys, re, datetime, os
            import sys, re, datetime, os.path
        
            reload(sys)
            sys.setdefaultencoding("utf-8")
        
            global  sha, md5, crypt, b2a_base64, choice, letters, digits
            import sha, md5, crypt
            from binascii import b2a_base64
            from random import choice
            from string import letters, digits
        except:
            print "ERROR: python core modules can not be found."
            sys.exit()
        
        self.module_failed = []
        
        try:
            global ldap, modlist
            import ldap, ldap.modlist as modlist
        except:
            self.wsKorreio.widget(1).setEnabled(False)
            self.pGetBaseDN.setEnabled(False)
            self.module_failed.append("ldap")
        
        try:
            global smbpasswd
            import smbpasswd
        except:
            self.cbLdapSambaPassword.setEnabled(False)
            self.pLdapSambaPopulate.setEnabled(False)
            self.cLdapFormSamba.setEnabled(False)
            self.module_failed.append("smbpasswd")
        
        try:
            global cyruslib, sievelib
            import cyruslib, sievelib
        except:
            self.wsKorreio.widget(2).setEnabled(False)
            self.wsKorreio.widget(3).setEnabled(False)
            self.wsKorreio.widget(4).setEnabled(False)
            self.module_failed.append("cyrus")
        
        try:
            global pexpect, pxssh
            import pexpect, pxssh
        except:
            self.wsKorreio.widget(5).setEnabled(False)
            self.wsKorreio.widget(6).setEnabled(False)
            self.module_failed.append("pexpect")
        
        if self.module_failed:
            msg = ""
            for mod in self.module_failed:
                msg = "%s%s\n" % (msg, "    - python-%s" % mod)
            QMessageBox.warning(None, self.__tr("Can't load libraries"), self.__tr("This libraries can not be found:\n%1").arg(msg))
        
        
        #
        # Servers Menu
        #
        
        self.lvServersImapMenu = QPopupMenu(self)
        self.lvServersLdapMenu = QPopupMenu(self)
        self.lvServersSSHMenu = QPopupMenu(self)
        
        self.connect(self.lvServersImapMenu, SIGNAL('activated(int)'), self.korreio_servers_menu_set_imap)
        self.connect(self.lvServersLdapMenu, SIGNAL('activated(int)'), self.korreio_servers_menu_set_ldap)
        self.connect(self.lvServersSSHMenu, SIGNAL('activated(int)'), self.korreio_servers_menu_set_ssh)
        
        self.lvServersMenu = QPopupMenu(self)
        self.lvServersMenu.insertItem('&IMAP', self.lvServersImapMenu, 0)
        self.lvServersMenu.insertItem('&LDAP', self.lvServersLdapMenu, 1)
        self.lvServersMenu.insertItem('&SSH', self.lvServersSSHMenu, 2)
        self.lvServersMenu.insertSeparator()
        
        #
        # Korreio Menu
        #
        
        self.mainMenuKorreio = QPopupMenu(self)
        self.mainMenuKorreio.insertItem(self.__tr('&Configuration'), 0)
        self.mainMenuKorreio.insertItem(self.__tr('&Log'), 1)
        self.mainMenuKorreio.insertSeparator()
        self.mainMenuKorreio.insertItem(self.__tr('Select &Server'), self.lvServersMenu, 2)
        self.mainMenuKorreio.insertSeparator()
        self.mainMenuKorreio.insertItem(self.__tr('&Exit'), 3)
        
        self.mainMenuModules = QPopupMenu(self)
        self.mainMenuModules.insertItem(self.__tr('Open&LDAP Manager'), 10)
        self.mainMenuModules.insertItem(self.__tr('&Cyrus-Imap Manager'), 11)
        self.mainMenuModules.insertItem(self.__tr('Cyrus-Imap &Partitions'), 12)
        self.mainMenuModules.insertItem(self.__tr('Cyrus-&Sieve Manager'), 13)
        self.mainMenuModules.insertItem(self.__tr('&Postfix Queue Manager'), 14)
        self.mainMenuModules.insertSeparator()
        self.mainMenuModules.insertItem(self.__tr('&Tools'), 15)
        
        self.mainMenuHelp = QPopupMenu(self)
        self.mainMenuHelp.insertItem(self.__tr('&About...'), 20)
        
        self.menuBar.insertItem(self.__tr('&Korreio'), self.mainMenuKorreio, 0)
        self.menuBar.insertItem(self.__tr('&Modules'), self.mainMenuModules, 1)
        self.menuBar.insertItem(self.__tr('&Help'), self.mainMenuHelp, 2)
        self.menuBar.setFrameShape(QMenuBar.Panel)
        self.menuBar.setFrameShadow(QMenuBar.Raised)
        
        self.connect(self.mainMenuKorreio, SIGNAL('activated(int)'), self.korreio_menu_clicked)
        self.connect(self.mainMenuModules, SIGNAL('activated(int)'), self.korreio_menu_clicked)
        self.connect(self.mainMenuHelp, SIGNAL('activated(int)'), self.korreio_menu_clicked)
        
        #
        # LDAP Menu
        #
        
        self.lvLdapMenu         = QPopupMenu(self)
        self.lvLdapSubMenu1 = QPopupMenu(self)
        self.lvLdapSubMenu2 = QPopupMenu(self)
        
        self.lvLdapMenu.insertItem(self.__tr('&New'), self.lvLdapSubMenu1, 10)
        self.lvLdapSubMenu1.insertItem(self.__tr('&Entry...'), 11)
        self.lvLdapSubMenu1.insertItem(self.__tr('&User...'), 12)
        self.lvLdapSubMenu1.insertItem(self.__tr('&Group...'), 13)
        self.lvLdapSubMenu1.insertItem(self.__tr('&Organization...'), 14)
        self.lvLdapSubMenu1.insertItem(self.__tr('&DHCP entry...'), 15)
        
        self.lvLdapMenu.insertSeparator()
        self.lvLdapMenu.clipBoard = "None"
        self.lvLdapMenu.insertItem(self.__tr('&Edit'), 20)
        self.lvLdapMenu.insertItem(self.__tr('&Copy'), 21)
        self.lvLdapMenu.insertItem(self.__tr('C&ut'), 22)
        self.lvLdapMenu.insertItem(self.__tr('&Paste'), 23)
        self.lvLdapMenu.insertItem(self.__tr('&Delete'), 24)
        
        self.lvLdapMenu.insertSeparator()
        self.lvLdapMenu.insertItem(self.__tr('&Tools'), self.lvLdapSubMenu2, 30)
        self.lvLdapSubMenu2.insertItem(self.__tr('Set &Password'), 31)
        self.lvLdapSubMenu2.insertItem(self.__tr('&Samba Populate'), 32)
        self.lvLdapSubMenu2.insertItem(self.__tr('&DHCP Populate'), 33)
        self.lvLdapSubMenu2.insertItem(self.__tr('View: &set as LDAP Base'), 34)
        self.lvLdapSubMenu2.insertItem(self.__tr('View: &back to LDAP Base'), 35)
        
        self.lvLdapMenu.insertSeparator()
        self.lvLdapMenu.insertItem(self.__tr('&Server'), self.lvServersLdapMenu, 42)
        
        self.connect(self.lvLdapMenu,         SIGNAL('activated(int)'), self.ldap_menu_clicked)
        self.connect(self.lvLdapSubMenu1, SIGNAL('activated(int)'), self.ldap_menu_clicked)
        self.connect(self.lvLdapSubMenu2, SIGNAL('activated(int)'), self.ldap_menu_clicked)
        
        #
        # IMAP Menu
        #
        
        self.lvImapMenu = QPopupMenu(self)
        self.lvImapMenu.insertItem(self.__tr('&Rename'), 0)
        self.lvImapMenu.insertItem(self.__tr('&Delete'), 1)
        self.lvImapMenu.insertItem(self.__tr('Re&construct'), 2)
        self.lvImapMenu.insertSeparator()
        self.lvImapMenu.insertItem(self.__tr('&Server'), self.lvServersImapMenu, 3)
        
        self.connect(self.lvImapMenu, SIGNAL('activated(int)'), self.imap_menu_clicked)
        
        #
        # IMAP Partition Menu
        #
        
        self.lvImapPartMenu = QPopupMenu(self)
        self.lvImapPartMenu.insertItem(self.__tr('Select &all'), 0)
        self.lvImapPartMenu.insertItem(self.__tr('Set &Quota...'), 1)
        self.lvImapPartMenu.insertSeparator()
        self.lvImapPartMenu.insertItem(self.__tr('&Server'), self.lvServersImapMenu, 2)
        
        self.connect(self.lvImapPartMenu, SIGNAL('activated(int)'), self.imap_partition_menu_clicked)
        
        #
        # Sieve Menu
        #
        
        self.lvSieveMenu = QPopupMenu(self)
        self.lvSieveMenu.insertItem(self.__tr('Select &all'), 0)
        self.lvSieveMenu.insertSeparator()
        self.lvSieveMenu.insertItem(self.__tr('&Server'), self.lvServersImapMenu, 1)
        
        self.lvSieveTemplateMenu = QPopupMenu(self)
        self.lvSieveTemplateMenu.insertItem(self.__tr('&New...'), 10)
        self.lvSieveTemplateMenu.insertItem(self.__tr('&Save'), 11)
        self.lvSieveTemplateMenu.insertItem(self.__tr('Save &as...'), 12)
        self.lvSieveTemplateMenu.insertItem(self.__tr('&Rename'), 13)
        self.lvSieveTemplateMenu.insertItem(self.__tr('&Delete'), 14)
        
        self.connect(self.lvSieveMenu, SIGNAL('activated(int)'), self.sieve_menu_clicked)
        self.connect(self.lvSieveTemplateMenu, SIGNAL('activated(int)'), self.sieve_menu_clicked)
        
        #
        # Services Menu
        #
        
        self.lvServicesMenu = QPopupMenu(self)
        self.lvServicesMenu.insertItem(self.__tr('&Server'), self.lvServersSSHMenu, 0)
        
        #
        # Queue Menu
        #
        
        self.lvQueueSubMenu1 = QPopupMenu(self)
        self.lvQueueSubMenu1.insertItem(self.__tr('&Flush'), 10)
        self.lvQueueSubMenu1.insertItem(self.__tr('&Hold'), 11)
        self.lvQueueSubMenu1.insertItem(self.__tr('&Unhold'), 12)
        self.lvQueueSubMenu1.insertItem(self.__tr('&Requeue'), 13)
        self.lvQueueSubMenu1.insertItem(self.__tr('&Delete'), 14)
        
        self.lvQueueMenu = QPopupMenu(self)
        self.lvQueueMenu.insertItem(self.__tr('&Update'), 0)
        self.lvQueueMenu.insertSeparator()
        self.lvQueueMenu.insertItem(self.__tr('&Show message'), 1)
        self.lvQueueMenu.insertItem(self.__tr('&Show already sent'), 2)
        self.lvQueueMenu.insertItem(self.__tr('&Hold'), 3)
        self.lvQueueMenu.insertItem(self.__tr('&Unhold'), 4)
        self.lvQueueMenu.insertItem(self.__tr('&Requeue'), 5)
        self.lvQueueMenu.insertItem(self.__tr('&Delete'), 6)
        self.lvQueueMenu.insertSeparator()
        self.lvQueueMenu.insertItem(self.__tr('For &all'), self.lvQueueSubMenu1, 7)
        self.lvQueueMenu.insertSeparator()
        self.lvQueueMenu.insertItem(self.__tr('&Server'), self.lvServersSSHMenu, 8)
        
        self.connect(self.lvQueueMenu, SIGNAL('activated(int)'), self.queue_menu_clicked)
        self.connect(self.lvQueueSubMenu1, SIGNAL('activated(int)'), self.queue_menu_clicked)
        
        #
        # End Menu
        #
        
        self.cbConfLdapSmbSIDEntry.listBox().setMinimumWidth(600)
        self.cbConfLdapSmbCounterEntry.listBox().setMinimumWidth(600)
        self.teSieveScript.setConfig(self.korreioConfigDict.get("path.sieveConf"))
        
        #
        # Load configuration
        #
        
        self.config_load()
        self.sieve_template_load()
        
        #
        # Update Interface
        #
        
        self.wsKorreio.raiseWidget(1)
        self.korreio_module_changed()
        
        

    def statusBar(self):
        
        #
        # Remove default status bar
        #
        
        pass
        
        

    def console(self,a0,a1=None,a2=True):
        # a0=str:text, a1=int:textMode
        # textMode: 0 (OK), 1 (ERROR), 2 (WARN), 3 (INFO)
        
        text = a0
        status = a2
        
        if a1 is None or a1 == self.CONSOLE_OK:
            textMode = "<b>%s:</b> " % self.__tr("Ok")
        elif a1 == self.CONSOLE_ERR:
            textMode = "<b>%s:</b> " % self.__tr("Error")
        elif a1 == self.CONSOLE_WARN:
            textMode = "<b>%s:</b> " % self.__tr("Warn")
        elif a1 == self.CONSOLE_INFO:
            textMode = "<b>%s:</b> " % self.__tr("Info")
        else:
            print "ERROR: unexpected console() mode."
            raise "KORREIOError", "ERROR: unexpected console() mode."
        
        textDate = datetime.datetime.now().strftime("%d %b %Y %H:%M:%S :/# ")
        
        #
        # Update Console
        #
        
        if status:
            self.tlConsole.setText("&nbsp;%s%s%s" % (textDate, utf2uni(textMode), utf2uni(text)))
            self.tlConsole.setIndent(0)
        
        #
        # Update Log Interface
        #
        
        textMode = re.sub("(</?b>)", "", str(textMode))
        self.lbLog.insertItem("%s%s%s" % (textDate, utf2uni(textMode), utf2uni(text)))
        self.lbLog.setCurrentItem(self.lbLog.count() - 1)
        self.lbLog.ensureCurrentVisible()
        
        #
        # Update Log File
        #
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.log"), 'a')
            f.write("%s%s%s\n" % (textDate, textMode, text))
            f.close()
        except OSError, e:
            print "ERROR: can't save log file. "+e
        
        

    def console_debug(self,a0):
        # a0=str:text
        
        print "#\n# Korreio Debug Started\n#\n\n", a0, "\n\n#\n# Korreio Debug Stopped\n#\n"
        
        

    def parse_exception(self,a0,a1):
        # a0=str:type, a1=list:reason
        # type: "LDAPError", "IMAPError", "pexpect.EOF", "pexpect.TIMEOUT"
        
        #
        # Parse LDAPError
        #
        
        if a0 == "LDAPError":
            if a1[0]["desc"] == "Size limit exceeded":
                self.console(self.__tr("search results many entries, server limit anwser. Set a filter properly."), self.CONSOLE_INFO)
            elif a1[0]["desc"] == "Bad search filter":
                self.console(self.__tr("invalid syntax for search filter. Set a filter properly."), self.CONSOLE_ERR)
            elif a1[0]["desc"] == "No such object":
                self.console(self.__tr("search don't have results."), self.CONSOLE_WARN)
            elif a1[0]["desc"] == "Already exists":
                self.console(self.__tr("entry already exists."), self.CONSOLE_ERR)
            elif a1[0]["desc"] == "Invalid syntax":
                self.console(self.__tr("invalid syntax for attribute '%1'.").arg(a1[0]['info'].split(":")[0]), self.CONSOLE_ERR)
            elif a1[0]['desc'] == "Object class violation":
                errList = a1[0]['info'].split("'")
                if len(errList) == 4:
                    self.console(self.__tr("objectClass '%1' require attribute '%2'.").arg(errList[1]).arg(errList[3]), self.CONSOLE_ERR)
                elif len(errList) == 3:
                    self.console(self.__tr("attribute '%1' is not supported by these objectClass's.").arg(errList[1]), self.CONSOLE_ERR)
                else:
                    errList = a1[0]['info'].split("/")
                    if len(errList) == 2:
                        self.console(self.__tr("incompatible objectClasses '%1' e '%2'.").arg(errList[0].split("(")[1]).arg(errList[1].split(")")[0]), self.CONSOLE_ERR)
                    else:
                        self.console(self.__tr("object class violation (%1).").arg(a1[0]['info']), self.CONSOLE_ERR)
            elif a1[0]['desc'] == "Naming violation":
                self.console(a1[0]['info'], self.CONSOLE_ERR)
            elif a1[0]['desc'] == "Can't contact LDAP server":
                server = "%s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii())
                self.console(self.__tr("connection refused to %1.").arg(server), self.CONSOLE_ERR)
                try:
                    del self.l
                except:
                    pass
            elif a1[0]['desc'] == "Undefined attribute type":
                self.console(self.__tr("attribute '%1' undefined at schema.").arg(a1[0]['info'].split(":")[0]), self.CONSOLE_ERR)
            elif a1[0]['desc'] == "Type or value exists":
                self.console(self.__tr("duplicate attribute '%1'.").arg(a1[0]['info'].split(":")[0]), self.CONSOLE_ERR)
            elif a1[0]['info'] == "no write access to parent":
                self.console(self.__tr("no write permission to parent entry '%1'.").arg(self.ldap_current_dn()), self.CONSOLE_ERR)
            elif a1[0]['info'] == "modifications require authentication":
                user = self.iLdapUser.text().ascii()
                if not user: user = "anonymous"
                self.console(self.__tr("no write permission by user '%1' or wrong ldap authentication.").arg(user), self.CONSOLE_ERR)
            elif a1[0]['desc'] == "No such attribute":
                self.console(a1[0]['info'], self.CONSOLE_ERR)
            else:
                self.console(str(a1), self.CONSOLE_ERR)
        
        #
        # Parse IMAPError
        #
        
        elif a0 == "IMAPError":
            self.korreio_module_clear("imap")
            server = "%s%s:%s/%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii(), self.iCyrusUser.text().ascii())
            if a1[2] == "Connection error":
                self.console(self.__tr("connection refused to %1.").arg(server), self.CONSOLE_ERR)
            elif a1[2] == "authentication failure":
                self.console(self.__tr("wrong user or password to %1.").arg(server), self.CONSOLE_ERR)
            elif a1[2] == "User is not cyrus administrator":
                self.console(self.__tr("user is not cyrus administrator to %1.").arg(server), self.CONSOLE_ERR)
            else:
                #self.console(self.__tr("%1 (%2).").arg(server).arg("%s" % a1[2]), self.CONSOLE_ERR)
                print a1, "xww"
        #
        # Parse pexpect.EOF
        #
        
        elif a0 == "pexpect.EOF":
            server = "ssh://%s:%s" % (self.iSshHost.text().ascii(), self.iSshPort.text().ascii())
            if re.search("match: pexpect.TIMEOUT", "%s" % a1):
                self.console(self.__tr("connection timeout to %1.").arg(server), self.CONSOLE_ERR)
            elif re.search("after: Permission denied", "%s" % a1):
                self.console(self.__tr("wrong user or password to %1.").arg(server), self.CONSOLE_ERR)
            elif re.search("Connection refused", "%s" % a1):
                self.console(self.__tr("connection refused to %1.").arg(server), self.CONSOLE_ERR)
            elif re.search("Host key verification failed", "%s" % a1):
                self.console(self.__tr("invalid fingerprint to %1.").arg(server), self.CONSOLE_ERR)
            else:
                self.console(self.__tr("connection dropped to %1.").arg(server), self.CONSOLE_ERR)
                self.console_debug(a1)
        
        #
        # Parse pexpect.TIMEOUT
        #
        
        elif a0 == "pexpect.TIMEOUT":
            server = "ssh://%s:%s" % (self.iSshHost.text().ascii(), self.iSshPort.text().ascii())
            self.console(self.__tr("connection timeout to %1.").arg(server), self.CONSOLE_ERR)
            self.console_debug(a1)
        
        #
        # Parse Anything
        #
        
        else:
            self.console(str(a1), self.CONSOLE_ERR)
        
        

    def korreio_update_servers_menu(self):
        
        #
        # Update Imap Servers Menu
        #
        
        self.lvServersImapMenu.clear()
        for server in range(0, self.cbCyrusConnection.count()):
            self.lvServersImapMenu.insertItem(self.cbCyrusConnection.text(server).ascii(), int(server))
        
        #
        # Update Ldap Servers Menu
        #
        
        self.lvServersLdapMenu.clear()
        for server in range(0, self.cbLdapConnection.count()):
            self.lvServersLdapMenu.insertItem(self.cbLdapConnection.text(server).ascii(), int(server))
        
        #
        # Update SSH Servers Menu
        #
        
        self.lvServersSSHMenu.clear()
        for server in range(0, self.cbSSHConnection.count()):
            self.lvServersSSHMenu.insertItem(self.cbSSHConnection.text(server).ascii(), int(server))
        
        

    def korreio_servers_menu_set_ldap(self,a0):
        
        #
        # Change current Ldap server
        #
        
        self.cbLdapConnection.setCurrentItem(a0)
        self.config_ldap_set_connection()
        
        

    def korreio_servers_menu_set_imap(self,a0):
        
        #
        # Change current Imap server
        #
        
        self.cbCyrusConnection.setCurrentItem(a0)
        self.config_imap_set_connection()
        
        

    def korreio_servers_menu_set_ssh(self,a0):
        
        #
        # Change current SSH server
        #
        
        self.cbSSHConnection.setCurrentItem(a0)
        self.config_ssh_set_connection()
        
        

    def korreio_module_clear(self,a0):
        # a0=str:module
        # module: "ldap", "imap", "imap-partition", "sieve", "ssh"
        #               "ldap.form", "ldap.form.unit", "ldap.form.password"
        #               "ldap.smb.populate", "ldap.dhcp.populate"
        
        module = a0
        
        if module == "ldap":
            self.lvLdap.clear()
            self.lvLdapAttr.clear()
        elif module == "imap":
            self.lvImap.clear()
            self.iImapMailbox.clear()
            self.lvImapAcl.clear()
            self.iImapAclUser.clear()
            self.cbACL.setCurrentItem(0)
            self.iQuota.clear()
            self.iQuotaUsed.clear()
            self.iAnnotationValue.clear()
            self.cbImapAnnotation.setCurrentItem(0)
            self.iAnnotationValue.clear()
        elif module == "imap-partition":
            self.lvImapPartition.clear()
            self.cbImapPartition.clear()
            self.pImapPartitionMove.setEnabled(False)
            self.tlImapSize.setText("0 ~ 0 Mbytes ~ 0%")
        elif module == "sieve":
            self.lvSieve.clear()
        #    self.lvSieve.setColumnAlignment(1, Qt.AlignHCenter)
            self.cbSieveScript.clear()
            self.teSieveScript.clear()
        elif module == "ssh":
            self.cbServicesPostconf.clear()
            self.teServicesPostconf.clear()
            self.teServicesFileOpen.clear()
            self.korreio_module_clear("ssh.queue")
        elif module == "ssh.queue":
            self.lvQueue.clear()
            self.iQueueMessage.clear()
            self.tlQueueMsgs.setText("0/0")
        elif module == "ldap.form":
            self.iLdapFormCn.setFocus()
            self.iLdapFormCn.clear()
            self.iLdapFormMail.clear()
            self.iLdapFormStreet.clear()
            self.iLdapFormL.clear()
            self.iLdapFormPostalCode.clear()
            self.iLdapFormHomePhone.clear()
            self.iLdapFormUserP.clear()
            self.iLdapFormUserP2.clear()
            self.cLdapFormPosix.setChecked(False)
            self.fLdapFormPosix.setEnabled(False)
            self.iLdapFormUid.clear()
            self.iLdapFormUidNumber.setText("1000")
            self.iLdapFormGidNumber.setText("100")
            self.iLdapFormUidNumber.setEnabled(True)
            self.pLdapGetUidNumber.setEnabled(True)
            self.iLdapFormGidNumber.setEnabled(True)
            self.iLdapFormLoginShell.setText("/bin/bash")
            self.iLdapFormHomeDirectory.setText("/home")
            self.cLdapFormSamba.setChecked(False)
            self.fLdapFormSamba.setEnabled(False)
            self.cbLdapFormSambaDomain.clear()
            self.cbLdapFormPrimaryGroup.setCurrentItem(0)
            self.iLdapFormSambaPwdMustChange.setChecked(True)
            self.cbLdapFormProfileType.setCurrentItem(0)
            self.iLdapFormProfilePath.clear()
            self.iLdapFormProfilePath.setEnabled(False)
            self.iLdapFormHomeDrive.clear()
            self.iLdapFormDrivePath.clear()
            self.iLdapFormLogonScript.clear()
            self.cLdapFormAst.setChecked(False)
            self.fLdapFormAst.setEnabled(False)
            self.iLdapFormAstUsername.clear()
            self.iLdapFormAstName.setText("1000")
            self.cLdapFormRadius.setChecked(False)
            self.fLdapFormRadius.setEnabled(False)
            self.iLdapFormRadiusGroup.clear()
            self.wsLdapForm.raiseWidget(0)
        elif module == "ldap.form.unit":
            self.iLdapFormUnit.setFocus()
            self.cbLdapFormUnit.setCurrentItem(0)
            self.iLdapFormUnit.clear()
            self.iLdapFormUnitStreet.clear()
            self.iLdapFormUnitL.clear()
            self.iLdapFormUnitPostalCode.clear()
            self.iLdapFormUnitTelephoneNumber.clear()
        elif module == "ldap.form.dhcp":
            self.ldap_wizard_dhcp_type()
            self.iLdapFormDhcpGroupName.clear()
            self.iLdapFormDhcpName.clear()
            self.iLdapFormDhcpIPaddress.clear()
            self.iLdapFormDhcpMACaddress.clear()
            self.iLdapFormDhcpComments.clear()
            self.cbLdapFormDhcpInterface.setCurrentItem(0)
            self.iLdapFormDhcpNetwork.clear()
            self.iLdapFormDhcpBroadcast.clear()
            self.iLdapFormDhcpRange.clear()
            self.cbLdapFormDhcpNetmask.setCurrentItem(8)
            self.iLdapFormDhcpGateway.clear()
        elif module == "ldap.form.password":
            self.iLdapPasswd.clear()
            self.iLdapPasswd2.clear()
            self.iLdapPasswd.setFocus()
        elif module == "ldap.smb.populate":
            self.iLdapSMBdomain.setFocus()
            self.iLdapSMBdomain.clear()
            self.iLdapSMBSID.clear()
            self.iLdapSMBpassword.clear()
            self.iLdapSMBuidNumber.setText(self.iConfLdapSMBuidNumber.text().ascii())
            self.iLdapSMBgidNumber.setText(self.iConfLdapSMBgidNumber.text().ascii())
            self.iLdapSMBminPwdLength.setText(self.iConfLdapSMBminPwdLength.text().ascii())
            self.iLdapSMBpwdHistLenght.setText(self.iConfLdapSMBpwdHistLenght.text().ascii())
            self.iLdapSMBmaxPwdAge.setText(self.iConfLdapSMBmaxPwdAge.text().ascii())
            self.cbLdapSMBmaxPwdAge.setCurrentItem(self.cbConfLdapSMBmaxPwdAge.currentItem())
            self.iLdapSMBminPwdAge.setText(self.iConfLdapSMBminPwdAge.text().ascii())
            self.cbLdapSMBminPwdAge.setCurrentItem(self.cbConfLdapSMBminPwdAge.currentItem())
            self.iLdapSMBlockout.setText(self.iConfLdapSMBlockout.text().ascii())
            self.iLdapSMBlockoutDuration.setText(self.iConfLdapSMBlockoutDuration.text().ascii())
            self.cbLdapSMBlockoutDuration.setCurrentItem(self.cbConfLdapSMBlockoutDuration.currentItem())
            self.iLdapSMBlockoutWindow.setText(self.iConfLdapSMBlockoutWindow.text().ascii())
            self.cbLdapSMBlockoutWindow.setCurrentItem(self.cbConfLdapSMBlockoutWindow.currentItem())
        elif module == "ldap.dhcp.populate":
            self.iLdapDhcpName.setFocus()
            self.iLdapDhcpName.clear()
            self.iLdapDhcpDefaultLeaseTime.setText(self.iConfLdapDhcpDefaultLeaseTime.text().ascii())
            self.cbLdapDhcpDefaultLeaseTime.setCurrentItem(self.cbConfLdapDhcpDefaultLeaseTime.currentItem())
            self.iLdapDhcpMaxLeaseTime.setText(self.iConfLdapDhcpMaxLeaseTime.text().ascii())
            self.cbLdapDhcpMaxLeaseTime.setCurrentItem(self.cbConfLdapDhcpMaxLeaseTime.currentItem())
            self.iLdapDhcpDomainName.setText(self.iConfLdapDhcpDomainName.text().ascii())
            self.iLdapDhcpNetbiosServers.setText(self.iConfLdapDhcpNetbiosServers.text().ascii())
            self.iLdapDhcpDNSservers.setText(self.iConfLdapDhcpDNSservers.text().ascii())
            self.cbLdapDhcpInterface.setCurrentText(self.cbConfLdapDhcpInterface.currentText().ascii())
            self.iLdapDhcpNetwork.setText(self.iConfLdapDhcpNetwork.text().ascii())
            self.iLdapDhcpBroadcast.setText(self.iConfLdapDhcpBroadcast.text().ascii())
            self.iLdapDhcpRange.setText(self.iConfLdapDhcpRange.text().ascii())
            self.cbLdapDhcpNetmask.setCurrentItem(self.cbConfLdapDhcpNetmask.currentItem())
            self.iLdapDhcpGateway.setText(self.iConfLdapDhcpGateway.text().ascii())
        
        

    def korreio_module_changed(self):
        
        try:
            self.startup
        except:
            self.startup = 1
            # Update servers menu
            self.korreio_update_servers_menu()
            # Retrive log
            self.config_log_mode()
            # Default Config Widget
            self.wsConfig.raiseWidget(3)
            # Default Imap Width
            self.spImap.setSizes([400, 457])
            # Default Sieve Width
            self.spSieve.setSizes([600, 257])
        
        #
        # Korreio Module was changed
        #
        
        page = self.wsKorreio.id(self.wsKorreio.visibleWidget())
        
        if page == 5:
                # Queue
                self.lvQueue.setColumnWidth(1, 126)
                self.lvQueue.setColumnWidth(0, self.lvQueue.width() - 130)
        
        elif page == 6:
            # Services
            if self.cbSSHsudo.currentItem() == 0:
                self.pServicesFileSave.setEnabled(True)
            else:
                self.console("File saving is not available with sudo mode.", self.CONSOLE_INFO)
                self.pServicesFileSave.setEnabled(False)
            self.lvServices.setColumnWidth(1, 0)
            self.lvServices.setColumnWidth(0, self.lvServices.width() - 4)
        elif page == 7:
            # Configuration
            self.lvConfig.setColumnWidth(1, 0)
            self.lvConfig.setColumnWidth(0, self.lvServices.width() - 4)
            self.lvConfig.currentItem().setSelected(True)
            self.config_change_widgetstack()
        
        

    def korreio_menu_clicked(self,a0):
        
        if a0 == 0:
            self.wsKorreio.raiseWidget(7)
        elif a0 == 1:
            self.wsKorreio.raiseWidget(0)
        elif a0 == 3:
            sys.exit(0)
        elif a0 == 10:
            self.wsKorreio.raiseWidget(1)
        elif a0 == 11:
            self.wsKorreio.raiseWidget(2)
        elif a0 == 12:
            self.wsKorreio.raiseWidget(3)
        elif a0 == 13:
            self.wsKorreio.raiseWidget(4)
        elif a0 == 14:
            self.wsKorreio.raiseWidget(5)
        elif a0 == 15:
            self.wsKorreio.raiseWidget(6)
        elif a0 == 20:
            QMessageBox.information( None, self.__tr("About..."), self.__tr("\n     Korreio - Copyright 2007-2009, Reinaldo de Carvalho     \n\n     Website: http://korreio.sf.net\n     Mailing list: http://groups.google.com/group/korreio\n\n"))
        
        
        self.korreio_module_changed()
        
        

    def config_load(self):
        
        #
        # Make Korreio work directory
        #
        
        try:
            os.makedirs(os.path.expanduser("~/.korreio/sieve"), 0700)
        except OSError, e:
            # e:17 directory already exists
            if e[0] != 17:
                self.console(self.__tr("can't make directory ~/.korreio (%1).").arg(e), self.CONSOLE_ERR)
                print "ERROR: make directory ~/.korreio failed (%s)." % e
                return False
        
        #
        # Create default configuration file
        #
        
        try:
            if not os.path.isfile(os.path.expanduser("~/.korreio/korreio.conf")):
                self.config_save()
        except OSError, e:
            pass
        
        #
        # Read configuration file
        #
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
            conf = f.read()
            f.close()
        except IOError, e:
            self.console(self.__tr("can't read configuration file ~/.korreio/korreio.conf (%1).").arg(e), self.CONSOLE_ERR)
            print "ERROR: can't read configuration file ~/.korreio/korreio.conf (%s)." % e
            return False
        
        confList = conf.split("\n")
        confList.pop()
        confDict = {}
        
        for line in confList:
           key=line.split("=")
           confDict[key[0]] = "=".join(key[1:])
        
        self.confDict = confDict
        
        #
        # LDAP Connection
        #
        
        i=0
        self.cbLdapConnection.clear()
        while confDict.get("ldap%s.name" % i):
            self.cbLdapConnection.insertItem(confDict.get("ldap%s.name" % i))
            i+=1
        
        lastConn=confDict.get("ldap.last")
        if lastConn:
            self.cbLdapConnection.setCurrentText(confDict.get("%s.name" % lastConn))
            self.iLdapConnection.setText(confDict.get("%s.name" % lastConn))
            self.cbLdapMode.setCurrentText(confDict.get("%s.mode" % lastConn))
            self.iLdapHost.setText(confDict.get("%s.host" % lastConn))
            self.iLdapPort.setText(confDict.get("%s.port" % lastConn))
            self.cbLdapBaseDN.clear()
            self.cbLdapBaseDN.insertItem(confDict.get("%s.basedn" % lastConn))
            self.iLdapUser.setText(confDict.get("%s.user" % lastConn))
            self.iLdapPass.setText(confDict.get("%s.pass" % lastConn))
            if confDict.get("%s.ref" % lastConn) == "True":
                self.cLdapRef.setChecked(True)
            if confDict.get("%s.cert" % lastConn) == "True":
                self.cLdapCert.setChecked(True)
        
        #
        # IMAP Connection
        #
        
        i=0
        self.cbCyrusConnection.clear()
        while confDict.get("imap%s.name" % i):
            self.cbCyrusConnection.insertItem(confDict.get("imap%s.name" % i))
            i+=1
        
        lastConn=confDict.get("imap.last")
        if lastConn:
            self.cbCyrusConnection.setCurrentText(confDict.get("%s.name" % lastConn))
            self.iCyrusConnection.setText(confDict.get("%s.name" % lastConn))
            self.cbCyrusMode.setCurrentText(confDict.get("%s.mode" % lastConn))
            self.iCyrusHost.setText(confDict.get("%s.host" % lastConn))
            self.iCyrusPort.setText(confDict.get("%s.port" % lastConn))
            self.iCyrusSievePort.setText(confDict.get("%s.sieport" % lastConn))
            self.iCyrusUser.setText(confDict.get("%s.user" % lastConn))
            self.iCyrusPass.setText(confDict.get("%s.pass" % lastConn))
            self.iCyrusPart.setText(confDict.get("%s.part" % lastConn))
        
        #
        # SSH Connection
        #
        
        i=0
        self.cbSSHConnection.clear()
        while confDict.get("ssh%s.name" % i):
            self.cbSSHConnection.insertItem(confDict.get("ssh%s.name" % i))
            i+=1
        
        lastConn=confDict.get("ssh.last")
        if lastConn:
            self.cbSSHConnection.setCurrentText(confDict.get("%s.name" % lastConn))
            self.iSSHConnection.setText(confDict.get("%s.name" % lastConn))
            self.iSshHost.setText(confDict.get("%s.host" % lastConn))
            self.iSshPort.setText(confDict.get("%s.port" % lastConn))
            self.iSshUser.setText(confDict.get("%s.user" % lastConn))
            self.iSshPass.setText(confDict.get("%s.pass" % lastConn))
        try:
            self.cbSSHsudo.setCurrentItem(int(confDict.get("%s.sudo" % lastConn)))
        except:
            pass
        
        #
        # IMAP Prefs
        #
        
        self.lvConfImapFolders.clear()
        i=0
        while confDict.get("imap.defaultfolder%s" % i):
            folderList = confDict.get("imap.defaultfolder%s" % i).split(":")
            item = QListViewItem(self.lvConfImapFolders)
            item.setText(0, folderList[0])
            if folderList[1] != "None" and folderList[1] != "0":
                item.setText(1, folderList[1])
            if folderList[2] != "None":
                item.setText(2, folderList[2])
            i+=1
        
        if confDict.get("imap.defaultquota"):
            self.iConfImapQuotaMbytes.setText(confDict.get("imap.defaultquota"))
        
        #
        # LDAP Prefs
        #
        
        if confDict.get("ldap.admin.autocomplete"):
            self.cbConfLdapCompleteUser.setCurrentText(confDict.get("ldap.admin.autocomplete"))
        
        if confDict.get("ldap.passwd.sambaPwdMustChange") == "True":
            self.cConfLdapsambaPwdMustChange.setChecked(True)
        else:
            self.cConfLdapsambaPwdMustChange.setChecked(False)
        
        if confDict.get("ldap.entry.attributeDN"):
            self.cbConfLdapUserDN.setCurrentItem(int(confDict.get("ldap.entry.attributeDN")))
        
        self.lvConfLdapSchema.clear()
        item = QListViewItem(self.lvConfLdapSchema)
        item.setText(0,'objectClass')
        item.setOpen(True)
        objnodes = {}
        i=0
        while confDict.get("ldap.objectclass%s" % i):
            objclass = confDict.get("ldap.objectclass%s" % i).split(".")
            if not objnodes.get(objclass[0]):
                objnodes[objclass[0]] = QListViewItem(item)
                objnodes[objclass[0]].setText(0,objclass[0])
            subitem=QListViewItem(objnodes[objclass[0]])
            subitem.setText(0,objclass[1])
            subitem.setText(1,".".join(objclass[2:]))
            i+=1
        
        if confDict.get("ldap.schema.addattrs") == "True" or not confDict.get("ldap.schema.addattrs"):
            self.cConfLdapSchemaAddAttr.setChecked(True)
        else:
            self.cConfLdapSchemaAddAttr.setChecked(False)
        
        if confDict.get("ldap.schema.delattrs") == "True" or not confDict.get("ldap.schema.delattrs"):
            self.cConfLdapSchemaDelAttr.setChecked(True)
        else:
            self.cConfLdapSchemaDelAttr.setChecked(False)
        
        self.lbConfLdapFilter.clear()
        self.cbLdapFilter.clear()
        i=0
        while confDict.get("ldap.filter%s" % i):
            self.lbConfLdapFilter.insertItem(confDict.get("ldap.filter%s" % i))
            self.cbLdapFilter.insertItem(confDict.get("ldap.filter%s" % i))
            i+=1
        
        #
        # LDAP SMB Prefs
        #
        
        i=0
        self.cbConfLdapSmbDomain.clear()
        while confDict.get("ldap.smb%s.domain" % i):
            self.cbConfLdapSmbDomain.insertItem(confDict.get("ldap.smb%s.domain" % i))
            i+=1
        
        lastConn=confDict.get("ldap.smb.last")
        if lastConn:
            self.cbConfLdapSmbDomain.setCurrentText(confDict.get("%s.domain" % lastConn))
            self.iConfLdapSmbDomain.setText(confDict.get("%s.domain" % lastConn))
            if confDict.get("%s.SIDEntry" % lastConn):
                self.cbConfLdapSmbSIDEntry.clear()
                self.cbConfLdapSmbSIDEntry.insertItem(confDict.get("%s.SIDEntry" % lastConn))
            self.cbConfLdapSmbSIDEntry.insertItem("")
            self.cbConfLdapSmbCounterEntry.clear()
            if confDict.get("%s.counterEntry" % lastConn):
                self.cbConfLdapSmbCounterEntry.clear()
                self.cbConfLdapSmbCounterEntry.insertItem(confDict.get("%s.counterEntry" % lastConn))
            self.cbConfLdapSmbCounterEntry.insertItem("")
            self.cbConfLdapSmbProfileType.setCurrentItem(int(confDict.get("%s.profileType" % lastConn)))
            if int(confDict.get("%s.profileType" % lastConn)) == 0:
                self.cbConfLdapSmbProfilePath.setEnabled(False)
            else:
                self.cbConfLdapSmbProfilePath.setEnabled(True)
            self.cbConfLdapSmbProfilePath.setCurrentText(confDict.get("%s.profilePath" % lastConn))
            self.iConfLdapSmbHomeDrive.setText(confDict.get("%s.homeDrive" % lastConn))
            self.iConfLdapSmbDrivePath.setText(confDict.get("%s.drivePath" % lastConn))
            self.cbConfLdapSmbLogonScript.setCurrentText(confDict.get("%s.logonScript" % lastConn))
            if confDict.get("%s.pwdMustChange" % lastConn) == "True":
                self.cConfLdapSmbPwdMustChange.setChecked(True)
            else:
                self.cConfLdapSmbPwdMustChange.setChecked(False)
            self.cbConfLdapSmbPrimaryGroup.setCurrentItem(int(confDict.get("%s.primaryGroup" % lastConn)))
        
        #
        # LDAP SMB Populate Prefs
        #
        
        if confDict.get("ldap.smb.populate.1stUidNumber"):
            self.iConfLdapSMBuidNumber.setText(confDict.get("ldap.smb.populate.1stUidNumber"))
        
        if confDict.get("ldap.smb.populate.1stGidNumber"):
            self.iConfLdapSMBgidNumber.setText(confDict.get("ldap.smb.populate.1stGidNumber"))
        
        if confDict.get("ldap.smb.populate.sambaMinPwdLenght"):
            self.iConfLdapSMBminPwdLength.setText(confDict.get("ldap.smb.populate.sambaMinPwdLenght"))
        
        if confDict.get("ldap.smb.populate.sambaPwdHistoryLenght"):
            self.iConfLdapSMBpwdHistLenght.setText(confDict.get("ldap.smb.populate.sambaPwdHistoryLenght"))
        
        if confDict.get("ldap.smb.populate.sambaMaxPwdAge"):
            self.iConfLdapSMBmaxPwdAge.setText(confDict.get("ldap.smb.populate.sambaMaxPwdAge"))
        
        if confDict.get("ldap.smb.populate.sambaMaxPwdAgeTime"):
            self.cbConfLdapSMBmaxPwdAge.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaMaxPwdAgeTime")))
        
        if confDict.get("ldap.smb.populate.sambaMinPwdAge"):
            self.iConfLdapSMBminPwdAge.setText(confDict.get("ldap.smb.populate.sambaMinPwdAge"))
        
        if confDict.get("ldap.smb.populate.sambaMinPwdAgeTime"):
            self.cbConfLdapSMBminPwdAge.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaMinPwdAgeTime")))
        
        if confDict.get("ldap.smb.populate.sambaLockoutThreshold"):
            self.iConfLdapSMBlockout.setText(confDict.get("ldap.smb.populate.sambaLockoutThreshold"))
        
        if confDict.get("ldap.smb.populate.sambaLockoutDuration"):
            self.iConfLdapSMBlockoutDuration.setText(confDict.get("ldap.smb.populate.sambaLockoutDuration"))
        
        if confDict.get("ldap.smb.populate.sambaLockoutDurationTime"):
            self.cbConfLdapSMBlockoutDuration.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaLockoutDurationTime")))
        
        if confDict.get("ldap.smb.populate.sambaLockoutObservationWindow"):
            self.iConfLdapSMBlockoutWindow.setText(confDict.get("ldap.smb.populate.sambaLockoutObservationWindow"))
        
        if confDict.get("ldap.smb.populate.sambaLockoutObservationWindowTime"):
            self.cbConfLdapSMBlockoutWindow.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaLockoutObservationWindowTime")))
        
        #
        # LDAP DHCP Populate Prefs
        #
        
        if confDict.get("ldap.dhcp.populate.defaultLeaseTime"):
            self.iConfLdapDhcpDefaultLeaseTime.setText(confDict.get("ldap.dhcp.populate.defaultLeaseTime"))
        
        if confDict.get("ldap.dhcp.populate.defaultLeaseTimeTime"):
            self.cbConfLdapDhcpDefaultLeaseTime.setCurrentItem(int(confDict.get("ldap.dhcp.populate.defaultLeaseTimeTime")))
        
        if confDict.get("ldap.dhcp.populate.maxLeaseTime"):
            self.iConfLdapDhcpMaxLeaseTime.setText(confDict.get("ldap.dhcp.populate.maxLeaseTime"))
        
        if confDict.get("ldap.dhcp.populate.maxLeaseTimeTime"):
            self.cbConfLdapDhcpMaxLeaseTime.setCurrentItem(int(confDict.get("ldap.dhcp.populate.maxLeaseTimeTime")))
        
        if confDict.get("ldap.dhcp.populate.domainName"):
            self.iConfLdapDhcpDomainName.setText(confDict.get("ldap.dhcp.populate.domainName"))
        
        if confDict.get("ldap.dhcp.populate.netbiosNameServers"):
            self.iConfLdapDhcpNetbiosServers.setText(confDict.get("ldap.dhcp.populate.netbiosNameServers"))
        
        if confDict.get("ldap.dhcp.populate.domainNameServers"):
            self.iConfLdapDhcpDNSservers.setText(confDict.get("ldap.dhcp.populate.domainNameServers"))
        
        if confDict.get("ldap.dhcp.populate.dhcpSharedNetwork"):
            self.cbConfLdapDhcpInterface.setCurrentText(confDict.get("ldap.dhcp.populate.dhcpSharedNetwork"))
        
        if confDict.get("ldap.dhcp.populate.dhcpNetworkAddress"):
            self.iConfLdapDhcpNetwork.setText(confDict.get("ldap.dhcp.populate.dhcpNetworkAddress"))
        
        if confDict.get("ldap.dhcp.populate.dhcpBroadcastAddress"):
            self.iConfLdapDhcpBroadcast.setText(confDict.get("ldap.dhcp.populate.dhcpBroadcastAddress"))
        
        if confDict.get("ldap.dhcp.populate.dhcpRange"):
            self.iConfLdapDhcpRange.setText(confDict.get("ldap.dhcp.populate.dhcpRange"))
        
        if confDict.get("ldap.dhcp.populate.dhcpNetmask"):
            self.cbConfLdapDhcpNetmask.setCurrentItem(int(confDict.get("ldap.dhcp.populate.dhcpNetmask")))
        else:
            self.cbConfLdapDhcpNetmask.setCurrentItem(8)
        
        if confDict.get("ldap.dhcp.populate.dhcpGateway"):
            self.iConfLdapDhcpGateway.setText(confDict.get("ldap.dhcp.populate.dhcpGateway"))
        
        

    def config_save(self):
        
        confList = []
        
        #
        # LDAP Connection
        #
        
        i=0
        while self.confDict.get("ldap%s.name" % i):
            if self.confDict.get("ldap%s.name" % i) == self.iLdapConnection.text().ascii():
                break
            i+=1
        
        #
        # Update selected Ldap connection before save
        #
        
        if self.iLdapConnection.text().ascii():
            confList.append("ldap.last=ldap%s" % i)
            self.confDict["ldap%s.name" % i] = self.iLdapConnection.text().ascii()
            self.confDict["ldap%s.mode" % i] = self.cbLdapMode.currentText().ascii()
            self.confDict["ldap%s.host" % i] = self.iLdapHost.text().ascii()
            self.confDict["ldap%s.port" % i] = self.iLdapPort.text().ascii()
            self.confDict["ldap%s.basedn" % i] = self.cbLdapBaseDN.currentText().ascii()
            self.confDict["ldap%s.user" % i] = self.iLdapUser.text().ascii()
            self.confDict["ldap%s.pass" % i] = self.iLdapPass.text().ascii()
            self.confDict["ldap%s.ref" % i] = str(self.cLdapRef.isChecked())
            self.confDict["ldap%s.cert" % i] = str(self.cLdapCert.isChecked())
        
        k=0
        self.cbLdapConnection.clear()
        while self.confDict.get("ldap%s.name" % k):
            self.cbLdapConnection.insertItem(self.confDict.get("ldap%s.name" % k))
            for j in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                opt = "ldap%s.%s" % (k, j)
                confList.append("%s=%s" % (opt, self.confDict.get(opt)))
            k+=1
        
        self.cbLdapConnection.setCurrentItem(i)
        
        #
        # IMAP Connection
        #
        
        i=0
        while self.confDict.get("imap%s.name" % i):
            if self.confDict.get("imap%s.name" % i) == self.iCyrusConnection.text().ascii():
                break
            i+=1
        
        #
        # Update selected Imap connection before save
        #
        
        if self.iCyrusConnection.text().ascii():
            confList.append("imap.last=imap%s" % i)
            self.confDict["imap%s.name" % i] = self.iCyrusConnection.text().ascii()
            self.confDict["imap%s.mode" % i] = self.cbCyrusMode.currentText().ascii()
            self.confDict["imap%s.host" % i] = self.iCyrusHost.text().ascii()
            self.confDict["imap%s.port" % i] = self.iCyrusPort.text().ascii()
            self.confDict["imap%s.sieport" % i] = self.iCyrusSievePort.text().ascii()
            self.confDict["imap%s.user" % i] = self.iCyrusUser.text().ascii()
            self.confDict["imap%s.pass" % i] = self.iCyrusPass.text().ascii()
            self.confDict["imap%s.part" % i] = self.iCyrusPart.text().ascii()
        
        k=0
        self.cbCyrusConnection.clear()
        while self.confDict.get("imap%s.name" % k):
            self.cbCyrusConnection.insertItem(self.confDict.get("imap%s.name" % k))
            for j in ['name','mode','host','port','sieport','user','pass','part']:
                opt = "imap%s.%s" % (k, j)
                confList.append("%s=%s" % (opt, self.confDict.get(opt)))
            k+=1
        
        self.cbCyrusConnection.setCurrentItem(i)
        
        #
        # SSH Connection
        #
        
        i=0
        while self.confDict.get("ssh%s.name" % i):
            if self.confDict.get("ssh%s.name" % i) == self.iSSHConnection.text().ascii():
                break
            i+=1
        
        #
        # Update selected SSH connection before save
        #
        
        if self.iSSHConnection.text().ascii():
            confList.append("ssh.last=ssh%s" % i)
            self.confDict["ssh%s.name" % i] = self.iSSHConnection.text().ascii()
            self.confDict["ssh%s.host" % i] = self.iSshHost.text().ascii()
            self.confDict["ssh%s.port" % i] = self.iSshPort.text().ascii()
            self.confDict["ssh%s.user" % i] = self.iSshUser.text().ascii()
            self.confDict["ssh%s.pass" % i] = self.iSshPass.text().ascii()
            self.confDict["ssh%s.sudo" % i] = self.cbSSHsudo.currentItem()
        
        k=0
        self.cbSSHConnection.clear()
        while self.confDict.get("ssh%s.name" % k):
            self.cbSSHConnection.insertItem(self.confDict.get("ssh%s.name" % k))
            for j in ['name','host','port','user','pass','sudo']:
                opt="ssh%s.%s" % (k, j)
                confList.append("%s=%s" % (opt, self.confDict.get(opt)))
            k+=1
        
        self.cbSSHConnection.setCurrentItem(i)
        
        #
        # IMAP Prefs
        #
        
        i=0
        item = self.lvConfImapFolders.firstChild()
        while item is not None:
            confList.append("imap.defaultfolder%s=%s:%s:%s" % (i, item.text(0).ascii(), item.text(1).ascii(), item.text(2).ascii()))
            item = item.nextSibling()
            i+=1
        confList.append("imap.defaultquota=%s" % self.iConfImapQuotaMbytes.text().ascii())
        
        #
        # LDAP Prefs
        #
        
        confList.append("ldap.admin.autocomplete=%s" % self.cbConfLdapCompleteUser.currentText().ascii())
        confList.append("ldap.passwd.sambaPwdMustChange=%s" % self.cConfLdapsambaPwdMustChange.isChecked())
        confList.append("ldap.entry.attributeDN=%i" % self.cbConfLdapUserDN.currentItem())
        confList.append("ldap.schema.addattrs=%s" % self.cConfLdapSchemaAddAttr.isChecked())
        confList.append("ldap.schema.delattrs=%s" % self.cConfLdapSchemaDelAttr.isChecked())
        
        item=self.lvConfLdapSchema.firstChild()
        item=item.firstChild()
        i=0
        while item is not None:
            subitem=item.firstChild()
            while subitem is not None:
                if subitem.text(1).ascii() is None: value=""
                else: value=subitem.text(1).ascii()
                confList.append("ldap.objectclass%s=%s.%s.%s" % (i, item.text(0).ascii(), subitem.text(0).ascii(), value))
                subitem=subitem.nextSibling()
                i+=1
            item=item.nextSibling()
        
        i=0
        item = self.lbConfLdapFilter.firstItem()
        while item is not None:
            confList.append("ldap.filter%s=%s" % (i, item.text().ascii()))
            i+=1
            item = item.next()
        
        #
        # LDAP SMB Prefs
        #
        
        i=0
        while self.confDict.get("ldap.smb%s.domain" % i):
            if self.confDict.get("ldap.smb%s.domain" % i) == self.iConfLdapSmbDomain.text().ascii():
                break
            i+=1
        
        #
        # Update selected SMB domain before save
        #
        
        if self.iConfLdapSmbDomain.text().ascii():
            confList.append("ldap.smb.last=ldap.smb%s" % i)
            self.confDict["ldap.smb%s.domain" % i] = self.iConfLdapSmbDomain.text().ascii()
            self.confDict["ldap.smb%s.SIDEntry" % i] = self.cbConfLdapSmbSIDEntry.currentText().ascii()
            self.confDict["ldap.smb%s.counterEntry" % i] = self.cbConfLdapSmbCounterEntry.currentText().ascii()
            self.confDict["ldap.smb%s.profileType" % i] = "%s" % self.cbConfLdapSmbProfileType.currentItem()
            self.confDict["ldap.smb%s.profilePath" % i] = self.cbConfLdapSmbProfilePath.currentText().ascii()
            self.confDict["ldap.smb%s.homeDrive" % i] = self.iConfLdapSmbHomeDrive.text().ascii()
            self.confDict["ldap.smb%s.drivePath" % i] = self.iConfLdapSmbDrivePath.text().ascii()
            self.confDict["ldap.smb%s.logonScript" % i] = self.cbConfLdapSmbLogonScript.currentText().ascii()
            self.confDict["ldap.smb%s.pwdMustChange" % i] = "%s" % self.cConfLdapSmbPwdMustChange.isChecked()
            self.confDict["ldap.smb%s.primaryGroup" % i] = self.cbConfLdapSmbPrimaryGroup.currentItem()
        
        k=0
        self.cbConfLdapSmbDomain.clear()
        while self.confDict.get("ldap.smb%s.domain" % k):
            self.cbConfLdapSmbDomain.insertItem(self.confDict.get("ldap.smb%s.domain" % k))
            for j in ['domain', 'SIDEntry', 'counterEntry', 'profileType', 'profilePath', 'homeDrive', 'drivePath', 'logonScript', 'pwdMustChange', 'primaryGroup']:
                opt = "ldap.smb%s.%s" % (k, j)
                confList.append("%s=%s" % (opt, self.confDict.get(opt)))
            k+=1
        
        self.cbConfLdapSmbDomain.setCurrentItem(i)
        
        #
        # LDAP SMB Populate Prefs
        #
        
        confList.append("ldap.smb.populate.1stUidNumber=%s" % self.iConfLdapSMBuidNumber.text().ascii())
        confList.append("ldap.smb.populate.1stGidNumber=%s" % self.iConfLdapSMBgidNumber.text().ascii())
        confList.append("ldap.smb.populate.sambaMinPwdLenght=%s" % self.iConfLdapSMBminPwdLength.text().ascii())
        confList.append("ldap.smb.populate.sambaPwdHistoryLenght=%s" % self.iConfLdapSMBpwdHistLenght.text().ascii())
        confList.append("ldap.smb.populate.sambaMaxPwdAge=%s" % self.iConfLdapSMBmaxPwdAge.text().ascii())
        confList.append("ldap.smb.populate.sambaMaxPwdAgeTime=%s" % self.cbConfLdapSMBmaxPwdAge.currentItem())
        confList.append("ldap.smb.populate.sambaMinPwdAge=%s" % self.iConfLdapSMBminPwdAge.text().ascii())
        confList.append("ldap.smb.populate.sambaMinPwdAgeTime=%s" % self.cbConfLdapSMBminPwdAge.currentItem())
        confList.append("ldap.smb.populate.sambaLockoutThreshold=%s" % self.iConfLdapSMBlockout.text().ascii())
        confList.append("ldap.smb.populate.sambaLockoutDuration=%s" % self.iConfLdapSMBlockoutDuration.text().ascii())
        confList.append("ldap.smb.populate.sambaLockoutDurationTime=%s" % self.cbConfLdapSMBlockoutDuration.currentItem())
        confList.append("ldap.smb.populate.sambaLockoutObservationWindow=%s" % self.iConfLdapSMBlockoutWindow.text().ascii())
        confList.append("ldap.smb.populate.sambaLockoutObservationWindowTime=%s" % self.cbConfLdapSMBlockoutWindow.currentItem())
        
        #
        # LDAP DHCP Populate Prefs
        #
        
        confList.append("ldap.dhcp.populate.defaultLeaseTime=%s" % self.iConfLdapDhcpDefaultLeaseTime.text().ascii())
        confList.append("ldap.dhcp.populate.defaultLeaseTimeTime=%s" % self.cbConfLdapDhcpDefaultLeaseTime.currentItem())
        confList.append("ldap.dhcp.populate.maxLeaseTime=%s" % self.iConfLdapDhcpMaxLeaseTime.text().ascii())
        confList.append("ldap.dhcp.populate.maxLeaseTimeTime=%s" % self.cbConfLdapDhcpMaxLeaseTime.currentItem())
        confList.append("ldap.dhcp.populate.domainName=%s" % self.iConfLdapDhcpDomainName.text().ascii())
        confList.append("ldap.dhcp.populate.netbiosNameServers=%s" % self.iConfLdapDhcpNetbiosServers.text().ascii())
        confList.append("ldap.dhcp.populate.domainNameServers=%s" % self.iConfLdapDhcpDNSservers.text().ascii())
        confList.append("ldap.dhcp.populate.dhcpSharedNetwork=%s" % self.cbConfLdapDhcpInterface.currentText().ascii())
        confList.append("ldap.dhcp.populate.dhcpNetworkAddress=%s" % self.iConfLdapDhcpNetwork.text().ascii())
        confList.append("ldap.dhcp.populate.dhcpBroadcastAddress=%s" % self.iConfLdapDhcpBroadcast.text().ascii())
        confList.append("ldap.dhcp.populate.dhcpRange=%s" % self.iConfLdapDhcpRange.text().ascii())
        confList.append("ldap.dhcp.populate.dhcpNetmask=%s" % self.cbConfLdapDhcpNetmask.currentItem())
        confList.append("ldap.dhcp.populate.dhcpGateway=%s" % self.iConfLdapDhcpGateway.text().ascii())
        
        #
        # Save configuration
        #
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')
            f.write("\n".join(confList))
            f.write("\n")
            f.close()
            os.chmod(os.path.expanduser("~/.korreio/korreio.conf"), 0600)
            self.console(self.__tr("Configuration saved."))
        except OSError, e:
            self.parse_exception("OSError", e)
        
        self.korreio_update_servers_menu()
        
        

    def config_log_mode(self):
        
        self.lbLog.clear()
        try:
            if os.path.isfile(os.path.expanduser("~/.korreio/korreio.log")):
                f = open(os.path.expanduser("~/.korreio/korreio.log"), 'r')
                if self.rbConfLogModeRecent.isChecked():
                    f.seek(-1000, 2)
                for line in f.xreadlines():
                    line=line.strip('\n')
                    try:
                        self.lbLog.insertItem(utf2uni(line))
                    except:
                        pass
                f.close()
                if self.rbConfLogModeRecent.isChecked():
                    self.lbLog.removeItem(0)
                self.lbLog.setCurrentItem(self.lbLog.count() - 1)
                self.lbLog.ensureCurrentVisible()
        except:
            pass
        
        

    def config_change_widgetstack(self):
        
        self.pSaveConfig.setEnabled(True)
        
        #
        # Set servers page as first page view
        #
        
        try:
            self.config1st
        except:
            item = self.lvConfig.firstChild()
            while item is not None:
                if item.text(1).ascii() == "2":
                    self.lvConfig.setCurrentItem(item)
                    break
                item = item.nextSibling()
            self.config1st = 1
        
        #
        # Show selected configuration
        #
        
        item=self.lvConfig.currentItem()
        
        if  item.text(1).ascii() == "2":
            #
            # Servers
            #
            self.wsConfig.raiseWidget(3)
            self.tConfShowLdapServer.setText(self.__tr("Host: %1").arg("%s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii())))
            self.tConfShowLdapUser.setText(self.__tr("User: %1").arg(self.iLdapUser.text().ascii()))
            self.tConfShowLdapBaseDN.setText(self.__tr("Base: %1").arg(self.cbLdapBaseDN.currentText().ascii()))
            self.tConfShowImapServer.setText(self.__tr("Host: %1").arg("%s%s:%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii())))
            self.tConfShowImapUser.setText(self.__tr("User: %1").arg(self.iCyrusUser.text().ascii()))
            self.tConfShowSshServer.setText(self.__tr("Host: %1").arg("ssh://%s:%s" % (self.iSshHost.text().ascii(), self.iSshPort.text().ascii())))
            self.tConfShowSshUser.setText(self.__tr("User: %1").arg(self.iSshUser.text().ascii()))
        
        elif  item.text(1).ascii() == "2.1":
            #
            # Servers LDAP
            #
            self.wsConfig.raiseWidget(0)
        
        elif  item.text(1).ascii() == "2.2":
            #
            # Servers IMAP
            #
            self.wsConfig.raiseWidget(1)
        
        elif  item.text(1).ascii() == "2.2.1":
            #
            # IMAP Annotation
            #
            self.wsConfig.raiseWidget(10)
            self.pSaveConfig.setEnabled(False)
            self.cbImapAnnotationServer.setCurrentItem(0)
            self.iAnnotationValueServer.clear()
        
        elif  item.text(1).ascii() == "2.3":
            #
            # Servers SSH
            #
            self.wsConfig.raiseWidget(2)
        
        elif  item.text(1).ascii() == "4.1":
            #
            # Preferences LDAP
            #
            self.wsConfig.raiseWidget(4)
        
        elif  item.text(1).ascii() == "4.2":
            #
            # Preferences IMAP
            #
            self.wsConfig.raiseWidget(5)
        
        elif  item.text(1).ascii() == "4.1.1":
            #
            # Preferences LDAP DHCP Populate
            #
            self.wsConfig.raiseWidget(11)
        
        elif  item.text(1).ascii() == "4.1.2":
            #
            # Preferences LDAP SMB Populate
            #
            self.wsConfig.raiseWidget(7)
        
        elif  item.text(1).ascii() == "4.1.3":
            #
            # Preferences LDAP SMB
            #
            self.wsConfig.raiseWidget(6)
        
        elif  item.text(1).ascii() == "4.1.4":
            #
            # Preferences LDAP Schema
            #
            self.wsConfig.raiseWidget(8)
        
        
        

    def config_imap_set_port(self):
        
        #
        # Imap mode was changed
        #
        
        if self.cbCyrusMode.currentItem() == 0:
            self.iCyrusPort.setText("143")
        else:
            self.iCyrusPort.setText("993")
        
        

    def config_ldap_set_port(self):
        
        #
        # Ldap mode was changed
        #
        
        if self.cbLdapMode.currentItem() == 0:
            self.iLdapPort.setText("389")
        else:
            self.iLdapPort.setText("636")
        
        

    def config_ldap_get_basedn(self):
        
        #
        # Detect BaseDN
        #
        
        try:
            self.cbLdapBaseDN.clear()
            dnDict = self.ldap_query("objectclass=*", ["namingContexts"], "", ldap.SCOPE_BASE).get('')
            if dnDict.get('namingContexts'):
                for base in dnDict.get('namingContexts'):
                    self.cbLdapBaseDN.insertItem(base)
                if self.cbLdapBaseDN.count() > 1:
                    self.cbLdapBaseDN.popup()
                elif self.cbLdapBaseDN.count() == 1:
                    self.config_ldap_set_admin()
        
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
        
        

    def config_ldap_set_admin(self):
        
        #
        # Set Ldap user if BaseDN was changed
        #
        
        self.iLdapUser.setText("%s,%s" % (self.cbConfLdapCompleteUser.currentText().ascii(), self.cbLdapBaseDN.currentText().ascii()))
        
        

    def config_ldap_schema(self):
        
        item = self.lvConfLdapSchema.currentItem()
        if item.parent() is None:
            self.iConfLdapSchemaValue.setEnabled(False)
            self.pConfLdapSchemaDelItem.setEnabled(False)
            self.iConfLdapSchemaAttr.clear()
            self.iConfLdapSchemaValue.clear()
        else:
            self.iConfLdapSchemaValue.setEnabled(True)
            self.pConfLdapSchemaDelItem.setEnabled(True)
            if item.parent().parent() is None:
                self.iConfLdapSchemaAttr.clear()
                self.iConfLdapSchemaValue.clear()
            else:
                if item.text(0).ascii() is not None:
                    self.iConfLdapSchemaAttr.setText(item.text(0).ascii())
                if item.text(1).ascii() is not None:
                    self.iConfLdapSchemaValue.setText(item.text(1).ascii())
        
        

    def config_ldap_schema_checked(self):
        
        #
        # Disable auxiliary schema if not in use
        #
        
        if not self.cConfLdapSchemaAddAttr.isChecked() and not self.cConfLdapSchemaDelAttr.isChecked():
            self.fConfLdapSchema.setEnabled(False)
        else:
            self.fConfLdapSchema.setEnabled(True)
        
        

    def config_ldap_schema_add_attr(self):
        
        if not self.iConfLdapSchemaAttr.text().ascii():
            self.console(self.__tr("set objectClass/attribute."), self.CONSOLE_WARN)
            self.iConfLdapSchemaAttr.setFocus()
            return True
        
        item = self.lvConfLdapSchema.currentItem()
        
        if item.parent() is None or item.parent().parent() is None:
            item.setOpen(True)
            newitem=QListViewItem(item)
        else:
            if self.iConfLdapSchemaAttr.text().ascii() == item.text(0).ascii():
                item.setText(1, self.iConfLdapSchemaValue.text().ascii())
                return True
            newitem=QListViewItem(item.parent())
        
        newitem.setText(0, self.iConfLdapSchemaAttr.text().ascii())
        newitem.setText(1, self.iConfLdapSchemaValue.text().ascii())
        
        

    def config_ldap_schema_del_attr(self):
        
        item = self.lvConfLdapSchema.currentItem()
        
        if item.parent() is not None:
            item.parent().takeItem(item)
            self.lvConfLdapSchema.currentItem().setSelected(True)
        
        

    def config_ldap_smb_perfil_changed(self):
        
        #
        # Disable Profile Path if is profile is local
        #
        
        if self.cbConfLdapSmbProfileType.currentItem() == 0:
            self.cbConfLdapSmbProfilePath.setEnabled(False)
        else:
            self.cbConfLdapSmbProfilePath.setEnabled(True)
        
        

    def config_ldap_smb_get_sambaUnixIdPool(self):
        
        #
        # Search uid counters entries
        #
        
        self.cbConfLdapSmbCounterEntry.clear()
        self.cbConfLdapSmbCounterEntry.insertItem("")
        ldap_result = self.ldap_query("objectClass=sambaUnixIdPool")
        if ldap_result is not None:
            for dn in ldap_result:
                self.cbConfLdapSmbCounterEntry.insertItem(dn)
        
        if self.cbConfLdapSmbCounterEntry.count() > 1:
            self.cbConfLdapSmbCounterEntry.popup()
        
        

    def config_ldap_smb_get_sambaDomain(self):
        
        #
        # Search Samba domain/SID entries
        #
        
        self.cbConfLdapSmbSIDEntry.clear()
        self.cbConfLdapSmbSIDEntry.insertItem("")
        ldap_result = self.ldap_query("objectClass=sambaDomain")
        if ldap_result is not None:
            for dn in ldap_result:
                self.cbConfLdapSmbSIDEntry.insertItem(dn)
        
        if self.cbConfLdapSmbSIDEntry.count() > 1:
            self.cbConfLdapSmbSIDEntry.popup()
        
        

    def config_ldap_smb_sambaDomain_clicked(self):
        
        #
        # Set domain name based on sambaDomain entry
        #
        
        SIDdn = self.cbConfLdapSmbSIDEntry.currentText().ascii()
        if SIDdn:
            self.iConfLdapSmbDomain.setText(SIDdn.split(",")[0].split("=")[1].lower())
        else:
            self.iConfLdapSmbDomain.clear()
        
        

    def config_imap_add_default_folder(self):
        
        #
        # Add folder to creation with user imap mailbox
        #
        
        if not self.iConfImapFolder.text().ascii():
            return False
        
        item = self.lvConfImapFolders.firstChild()
        while item is not None:
            if item.text(0).ascii() == self.iConfImapFolder.text().ascii():
                tmp = item.nextSibling()
                self.lvConfImapFolders.takeItem(item)
                item = tmp
            else:
                item = item.nextSibling()
        
        item = QListViewItem(self.lvConfImapFolders)
        item.setText(0, self.iConfImapFolder.text().ascii())
        item.setText(1, self.iConfImapExpire.text().ascii())
        if self.cbConfImapACLp.currentItem() == 1:
            item.setText(2, "p")
        
        

    def config_imap_del_default_folder(self):
        
        #
        # Del folder to creation with user imap mailbox
        #
        
        self.lvConfImapFolders.takeItem(self.lvConfImapFolders.currentItem())
        
        

    def config_ldap_set_connection(self):
        
        #
        # Get selected LDAP server
        #
        
        i=0
        while self.confDict.get("ldap%s.name" % i):
            if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
                lastConn="ldap%s" % i
            i+=1
        
        self.iLdapConnection.setText(self.confDict.get("%s.name" % lastConn))
        self.cbLdapMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
        self.iLdapHost.setText(self.confDict.get("%s.host" % lastConn))
        self.iLdapPort.setText(self.confDict.get("%s.port" % lastConn))
        self.cbLdapBaseDN.clear()
        self.cbLdapBaseDN.insertItem(self.confDict.get("%s.basedn" % lastConn))
        self.iLdapUser.setText(self.confDict.get("%s.user" % lastConn))
        self.iLdapPass.setText(self.confDict.get("%s.pass" % lastConn))
        if self.confDict.get("%s.ref" % lastConn) == "True":
            self.cLdapRef.setChecked(True)
        else:
            self.cLdapRef.setChecked(False)
        if self.confDict.get("%s.cert" % lastConn) == "True":
            self.cLdapCert.setChecked(True)
        else:
            self.cLdapCert.setChecked(False)
        
        self.korreio_module_clear("ldap")
        
        

    def config_imap_set_connection(self):
        
        #
        # Get selected IMAP server
        #
        
        i=0
        while self.confDict.get("imap%s.name" % i):
            if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
                lastConn="imap%s" % i
            i+=1
        
        self.iCyrusConnection.setText(self.confDict.get("%s.name" % lastConn))
        self.cbCyrusMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
        self.iCyrusHost.setText(self.confDict.get("%s.host" % lastConn))
        self.iCyrusPort.setText(self.confDict.get("%s.port" % lastConn))
        self.iCyrusSievePort.setText(self.confDict.get("%s.sieport" % lastConn))
        self.iCyrusUser.setText(self.confDict.get("%s.user" % lastConn))
        self.iCyrusPass.setText(self.confDict.get("%s.pass" % lastConn))
        self.iCyrusPart.setText(self.confDict.get("%s.part" % lastConn))
        
        self.korreio_module_clear("imap")
        self.korreio_module_clear("imap-partition")
        self.korreio_module_clear("sieve")
        
        

    def config_ssh_set_connection(self):
        
        #
        # Get selected SSH server
        #
        
        i=0
        while self.confDict.get("ssh%s.name" % i):
            if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
                lastConn="ssh%s" % i
            i+=1
        self.iSSHConnection.setText(self.confDict.get("%s.name" % lastConn))
        self.iSshHost.setText(self.confDict.get("%s.host" % lastConn))
        self.iSshPort.setText(self.confDict.get("%s.port" % lastConn))
        self.iSshUser.setText(self.confDict.get("%s.user" % lastConn))
        self.iSshPass.setText(self.confDict.get("%s.pass" % lastConn))
        try:
            self.cbSSHsudo.setCurrentItem(int(self.confDict.get("%s.sudo" % lastConn)))
        except:
            self.cbSSHsudo.setCurrentItem(0)
        
        self.korreio_module_clear("ssh")
        
        

    def config_smb_set_domain(self):
        
        #
        # Get selected Samba Domain
        #
        
        i=0
        while self.confDict.get("ldap.smb%s.domain" % i):
            if self.confDict.get("ldap.smb%s.domain" % i) == self.cbConfLdapSmbDomain.currentText().ascii():
                lastConn = "ldap.smb%s" % i
                break
            i+=1
        
        self.iConfLdapSmbDomain.setText(self.confDict.get("%s.domain" % lastConn))
        
        self.cbConfLdapSmbSIDEntry.clear()
        self.cbConfLdapSmbSIDEntry.insertItem(self.confDict.get("%s.SIDEntry" % lastConn))
        self.cbConfLdapSmbSIDEntry.insertItem("")
        
        self.cbConfLdapSmbCounterEntry.clear()
        if self.confDict.get("%s.counterEntry" % lastConn) != "None":
            self.cbConfLdapSmbCounterEntry.insertItem(self.confDict.get("%s.counterEntry" % lastConn))
        self.cbConfLdapSmbProfileType.setCurrentItem(int(self.confDict.get("%s.profileType" % lastConn)))
        if int(self.confDict.get("%s.profileType" % lastConn)) == 0:
            self.cbConfLdapSmbProfilePath.setEnabled(False)
        else:
            self.cbConfLdapSmbProfilePath.setEnabled(True)
        self.cbConfLdapSmbProfilePath.setCurrentText(self.confDict.get("%s.profilePath" % lastConn))
        self.iConfLdapSmbHomeDrive.setText(self.confDict.get("%s.homeDrive" % lastConn))
        self.iConfLdapSmbDrivePath.setText(self.confDict.get("%s.drivePath" % lastConn))
        self.cbConfLdapSmbLogonScript.setCurrentText(self.confDict.get("%s.logonScript" % lastConn))
        if self.confDict.get("%s.pwdMustChange" % lastConn) == "True":
            self.cConfLdapSmbPwdMustChange.setChecked(True)
        else:
            self.cConfLdapSmbPwdMustChange.setChecked(False)
        self.cbConfLdapSmbPrimaryGroup.setCurrentItem(int(self.confDict.get("%s.primaryGroup" % lastConn)))
        
        

    def config_ldap_del_connection(self):
        
        #
        # Delete selected Ldap server
        #
        
        if not self.cbLdapConnection.currentText().ascii():
            return True
        
        i=0
        while self.confDict.get("ldap%s.name" % i):
            if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
                j=i+1
                while self.confDict.get("ldap%s.name" % j):
                    for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                        self.confDict["ldap%s.%s" % ((j-1), opt)]=self.confDict.get("ldap%s.%s" % (j, opt))
                    j+=1
            i+=1
        
        for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
            del self.confDict["ldap%s.%s" % ((i-1), opt)]
        
        i=self.cbLdapConnection.currentItem()
        self.cbLdapConnection.removeItem(i)
        if i > 0:
            self.cbLdapConnection.setCurrentItem(i-1)
            self.config_ldap_set_connection()
        elif self.cbLdapConnection.count() > 0:
            self.cbLdapConnection.setCurrentItem(0)
            self.config_ldap_set_connection()
        else:
            self.iLdapConnection.clear()
            self.cbLdapMode.setCurrentText("ldap://")
            self.iLdapHost.clear()
            self.iLdapPort.setText("389")
            self.cbLdapBaseDN.clear()
            self.iLdapUser.clear()
            self.iLdapPass.clear()
            self.cLdapRef.setChecked(False)
            self.cLdapCert.setChecked(False)
        
        

    def config_imap_del_connection(self):
        
        #
        # Delete selected Imap server
        #
        
        if not self.cbCyrusConnection.currentText().ascii():
            return True
        
        i=0
        while self.confDict.get("imap%s.name" % i):
            if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
                j=i+1
                while self.confDict.get("imap%s.name" % j):
                    for opt in ['name','mode','host','port','sieport','user','pass','part']:
                        self.confDict["imap%s.%s" % ((j-1), opt)]=self.confDict.get("imap%s.%s" % (j, opt))
                    j+=1
            i+=1
        
        for opt in ['name','mode','host','port','sieport','user','pass','part']:
            del self.confDict["imap%s.%s" % ((i-1), opt)]
        
        i=self.cbCyrusConnection.currentItem()
        self.cbCyrusConnection.removeItem(i)
        if i > 0:
            self.cbCyrusConnection.setCurrentItem(i-1)
            self.config_imap_set_connection()
        elif self.cbCyrusConnection.count() > 0:
            self.cbCyrusConnection.setCurrentItem(0)
            self.config_imap_set_connection()
        else:
            self.iCyrusConnection.clear()
            self.cbCyrusMode.setCurrentText("imap://")
            self.iCyrusHost.clear()
            self.iCyrusPort.setText("143")
            self.iCyrusSievePort.setText("2000")
            self.iCyrusUser.clear()
            self.iCyrusPass.clear()
            self.iCyrusPart.clear()
        
        

    def config_ssh_del_connection(self):
        
        #
        # Delete selected SSH server
        #
        
        if not self.cbSSHConnection.currentText().ascii():
            return True
        i=0
        while self.confDict.get("ssh%s.name" % i):
            if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
                j=i+1
                while self.confDict.get("ssh%s.name" % j):
                    for opt in ['name','host','port','user','pass']:
                        self.confDict["ssh%s.%s" % ((j-1), opt)]=self.confDict.get("ssh%s.%s" % (j, opt))
                    j+=1
            i+=1
        
        for opt in ['name','host','port','user','pass']:
            del self.confDict["ssh%s.%s" % ((i-1), opt)]
        
        i=self.cbSSHConnection.currentItem()
        self.cbSSHConnection.removeItem(i)
        if i > 0:
            self.cbSSHConnection.setCurrentItem(i-1)
            self.config_ssh_set_connection()
        elif self.cbSSHConnection.count() > 0:
            self.cbSSHConnection.setCurrentItem(0)
            self.config_ssh_set_connection()
        else:
            self.iSSHConnection.clear()
            self.iSshHost.clear()
            self.iSshPort.setText("22")
            self.iSshUser.clear()
            self.iSshPass.clear()
        
        

    def config_smb_del_domain(self):
        
        #
        # Delete selected Samba Domain
        #
        
        if not self.cbConfLdapSmbDomain.currentText().ascii():
            return True
        i=0
        while self.confDict.get("ldap.smb%s.domain" % i):
            if self.confDict.get("ldap.smb%s.domain" % i) == self.cbConfLdapSmbDomain.currentText().ascii():
                j=i+1
                while self.confDict.get("ldap.smb%s.domain" % j):
                    for opt in['domain', 'SIDEntry', 'counterEntry', 'profileType', 'profilePath', 'homeDrive', 'drivePath', 'logonScript', 'pwdMustChange', 'primaryGroup']:
                        self.confDict["ldap.smb%s.%s" % ((j-1), opt)]=self.confDict.get("ldap.smb%s.%s" % (j, opt))
                    j+=1
            i+=1
        
        for opt in ['domain', 'SIDEntry', 'counterEntry', 'profileType', 'profilePath', 'homeDrive', 'drivePath', 'logonScript', 'pwdMustChange', 'primaryGroup']:
            del self.confDict["ldap.smb%s.%s" % ((i-1), opt)]
        
        i=self.cbConfLdapSmbDomain.currentItem()
        self.cbConfLdapSmbDomain.removeItem(i)
        if i > 0:
            self.cbConfLdapSmbDomain.setCurrentItem(i-1)
            self.config_smb_set_domain()
        elif self.cbConfLdapSmbDomain.count() > 0:
            self.cbConfLdapSmbDomain.setCurrentItem(0)
            self.config_smb_set_domain()
        else:
            self.cbConfLdapSmbDomain.clear()
            self.iConfLdapSmbDomain.clear()
            self.cbConfLdapSmbSIDEntry.clear()
            self.cbConfLdapSmbCounterEntry.clear()
            self.cbConfLdapSmbProfileType.setCurrentItem(0)
            self.cbConfLdapSmbProfilePath.setEnabled(False)
            self.cbConfLdapSmbProfilePath.setCurrentText("\\server\profiles\#UID#")
            self.iConfLdapSmbHomeDrive.setText("Z:")
            self.iConfLdapSmbDrivePath.setText("\\server\#UID#")
            self.cbConfLdapSmbLogonScript.setCurrentText("netlogon.bat")
            self.cConfLdapSmbPwdMustChange.setChecked(True)
            self.cbConfLdapSmbPrimaryGroup.setCurrentItem(0)
        
        

    def config_ldap_filter_add(self):
        
        #
        # Add ldap filter and update Ldap module
        #
        
        self.lbConfLdapFilter.insertItem(self.iConfLdapFilter.text().ascii())
        
        self.config_ldap_filter_sync()
        
        

    def config_ldap_filter_del(self):
        
        #
        # Delete selected ldap filter and update Ldap module
        #
        
        for filter in range(self.lbConfLdapFilter.count()-1, -1, -1):
            if self.lbConfLdapFilter.item(filter).isSelected():
                self.lbConfLdapFilter.removeItem(filter)
        
        self.config_ldap_filter_sync()
          
        

    def config_ldap_filter_sync(self):
        
        #
        # Update Ldap module after change ldap filters
        #
        
        self.cbLdapFilter.clear()
        for filter in range(0, self.lbConfLdapFilter.count()):
            self.cbLdapFilter.insertItem(self.lbConfLdapFilter.item(filter).text().ascii())
        
        

    def imap_connect(self):
        
        #
        # Verify IMAP connection cache
        #
        
        try:
            if self.m:
                if self.inet_cache.get("imap.mode") == self.cbCyrusMode.currentText().ascii() and self.inet_cache.get("imap.host") == self.iCyrusHost.text().ascii() and self.inet_cache.get("imap.port") == self.iCyrusPort.text().ascii() and self.inet_cache.get("imap.user") == self.iCyrusUser.text().ascii() and self.inet_cache.get("imap.pass") == self.iCyrusPass.text().ascii():
                    if self.m.m.isadmin():
                        return self.m
        except:
            pass
        
        
        #
        # Connect to IMAP
        #
        
        try:
            if self.cbCyrusMode.currentItem() == 0:
                mode = "imap"
            else:
                mode = "imaps"
            server = "%s://%s:%s" % (mode, self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii())
            self.m = cyruslib.CYRUS(server)
            self.m.login(self.iCyrusUser.text().ascii(), self.iCyrusPass.text().ascii())
            self.m.setEncoding('iso-8859-1')
            self.console(self.__tr("%1 connected.").arg("%s/%s" % (server, self.iCyrusUser.text().ascii())))
        except cyruslib.CYRUSError, e:
            try:        del self.m
            except:  pass
            self.parse_exception("IMAPError", e)
            return None
        
        #
        # Save current connection information
        #
        
        self.inet_cache["imap.mode"] = self.cbCyrusMode.currentText().ascii()
        self.inet_cache["imap.host"] = self.iCyrusHost.text().ascii()
        self.inet_cache["imap.port"] = self.iCyrusPort.text().ascii()
        self.inet_cache["imap.user"] = self.iCyrusUser.text().ascii()
        self.inet_cache["imap.pass"] = self.iCyrusPass.text().ascii()
        
        self.tConfShowImapSep.setText(self.__tr("Imap delimiter: %1").arg(self.m.SEP))
        
        return self.m
        
        

    def imap_current_mailbox(self,a0):
        # a0: str:SEP (Imap Delimiter)
        
        #
        # Get selected mailbox
        #
        
        SEP = a0
        
        item = self.lvImap.currentItem()
        if item is None or not item.text(0).ascii():
            return None
        
        mailbox = item.text(0).ascii()
        while item.parent() is not None:
            mailbox = "%s%s%s" % (item.parent().text(0).ascii(), SEP, mailbox)
            item = item.parent()
        
        if self.rbImapMailboxMode.isChecked():
            mailbox = "user%s%s" % (SEP, mailbox)
        
        return mailbox
        
        

    def imap_search(self):
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        #
        # Save current selection
        #
        
        try:
            oldMailbox = re.sub("^user%s" % imap.SEP, "", self.imap_current_mailbox(imap.SEP))
        except:
            oldMailbox = None
        self.korreio_module_clear("imap")
        
        #
        # Imap query
        #
        if self.iImapSearch.text().ascii():
            query = "user%s%s*" % (imap.SEP, self.iImapSearch.text().ascii())
        elif self.rbImapMailboxMode.isChecked():
            query = "user%s*" % imap.SEP
        else:
            query = "*"
        
        mailbox = imap.lm(query)
        
        #
        # Select global folders (query not supported)
        #
        if self.rbImapMailboxMode2.isChecked():
            globalList = []
            for mbx in mailbox:
                if not re.search("^user%s" % imap.SEP, mbx):
                    globalList.append(mbx)
            mailbox = globalList
        
        #
        # Create Tree Item
        #
        def __create_item(mbx):
            if self.imap_cache_items.get(mbx):
                return True
            mbxList = mbx.split(imap.SEP)
            if len(mbxList) == 1:
                self.imap_cache_items[mbx] = QListViewItem(self.lvImap)
                self.imap_cache_items[mbx].setText(0, mbx)
                if self.cImapExpand.isChecked():
                    self.imap_cache_items[mbx].setOpen(True)
                return True
            mbxParent = imap.SEP.join(mbxList[:-1])
            if not self.imap_cache_items.get(mbxParent):
                self.console(self.__tr("sub-folder '%1' listed before folder '%2'.").arg(mbx).arg(mbxParent), self.CONSOLE_WARN)
                __create_item(mbxParent)
            self.imap_cache_items[mbx] = QListViewItem(self.imap_cache_items.get(mbxParent))
            self.imap_cache_items[mbx].setText(0, mbxList[-1])
        
        self.imap_cache_items = {}
        for mbx in mailbox:
            mbx = re.sub("^user%s" % imap.SEP, "", mbx)
            __create_item(mbx)
        
        #
        # Set last selection
        #
        
        if self.imap_cache_items.get(oldMailbox):
                self.lvImap.setCurrentItem(self.imap_cache_items.get(oldMailbox))
                self.lvImap.ensureItemVisible(self.imap_cache_items.get(oldMailbox))
                self.imap_cache_items[oldMailbox].setSelected(True)
                while self.imap_cache_items.get(oldMailbox).parent() is not None:
                    self.imap_cache_items[oldMailbox].parent().setOpen(True)
                    oldMailbox = imap.SEP.join(oldMailbox.split(imap.SEP)[:-1])
        elif self.lvImap.childCount() > 0:
                item = self.lvImap.firstChild()
                self.lvImap.setCurrentItem(item)
                self.lvImap.ensureItemVisible(item)
                item.setSelected(True)
        
        #
        # Get selected mailbox information
        #
        
        self.imap_mailbox_clicked(None, imap)
        self.lvImap.setFocus()
        
        

    def imap_mailbox_clicked(self,a0=None,a1=None):
        # a0=obj:QListViewItem or None, a1=obj:imap or None
        
        imap = a1
        
        if imap is None:
            imap = self.imap_connect()
            if imap is None:
                return False
        
        #
        # Mailbox Path
        #
        
        mailbox = self.imap_current_mailbox(imap.SEP)
        if mailbox is None:
            return True
        
        mbxtop = re.sub("^user%s" % imap.SEP, "", mailbox)
        self.iImapMailbox.setText(mbxtop)
        
        #
        # Quota
        #
        
        if len(mbxtop.split(imap.SEP)) == 1:
            self.pImapQuota.setEnabled(True)
        else:
            self.pImapQuota.setEnabled(False)
        
        if re.search("^user%s" % imap.SEP, mailbox):
            mbxtop = "user%s%s" % (imap.SEP, mailbox.split(imap.SEP)[1])
        else:
            mbxtop = mailbox.split(imap.SEP)[0]
        
        try:
            quota = imap.lq(mbxtop)
        except:
            quota = (0, 0)
        self.iQuotaUsed.setText("%s" % quota[0])
        self.iQuota.setText("%s" % quota[1])
        
        #
        # ACL
        #
        
        self.lvImapAcl.clear()
        
        acls = imap.lam(mailbox)
        for user, acl in acls.items():
            item = QListViewItem(self.lvImapAcl)
            item.setText(0, user)
            item.setText(1, acl)
        
        item = self.lvImapAcl.firstChild()
        if item is not None:
            self.lvImapAcl.setCurrentItem(item)
            item.setSelected(False)
            self.imap_acl_clicked(item)
        
        #
        # Annotation
        #
        
        self.imap_annotation_user_get(None, imap)
        
        

    def imap_add(self):
        
        def __imap_add(mailbox, partition=None):
            mbxList = mailbox.split(imap.SEP)
            if mbxList[0] == "user":
                mbxItem = imap.SEP.join(mbxList[1:])
                mbxParent = None
                if len(mbxList) != 2:
                    mbxParent = imap.SEP.join(mbxList[1:-1])
                    if not self.imap_cache_items.get(mbxParent):
                        self.console(self.__tr("parent mailbox '%1' don't exist.").arg(mbxParent), self.CONSOLE_ERR)
                        return False
            else:
                mbxItem = mailbox
                if len(mbxList) == 1:
                    mbxParent = None
                else:
                    mbxParent = imap.SEP.join(mbxList[:-1])
        
            imap.cm(mailbox, partition)
            if mbxParent is None:
                self.imap_cache_items[mbxItem] = QListViewItem(self.lvImap)
            else:
                self.imap_cache_items[mbxItem] = QListViewItem(self.imap_cache_items.get(mbxParent))
                self.imap_cache_items[mbxParent].setOpen(True)
            self.imap_cache_items[mbxItem].setText(0, mbxList[-1])
            self.console(self.__tr("mailbox '%1' created.").arg(mailbox))
        
        mailbox = re.sub("^ *", "", "%s" % self.iImapMailbox.text().ascii())
        
        if not mailbox:
            self.console(self.__tr("set mailbox."), self.CONSOLE_WARN)
            self.iImapMailbox.setFocus()
            return True
        
        if self.imap_cache_items.get(mailbox):
            self.console(self.__tr("mailbox '%1' already exists.").arg(mailbox), self.CONSOLE_WARN)
            return True
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        if self.rbImapMailboxMode.isChecked():
            mbPath = "user%s%s" % (imap.SEP, mailbox)
        else:
            mbPath = mailbox
        
        partition = None
        if self.iCyrusPart.text().ascii():
            partition = self.iCyrusPart.text().ascii()
        
        try:
            __imap_add(mbPath, partition)
        except cyruslib.CYRUSError, e:
            self.console(self.__tr("mailbox '%1' creation failed (%2).").arg(mailbox).arg(e[2]), self.CONSOLE_ERR)
            return False
        
        if len(mailbox.split(imap.SEP)) == 1:
            if self.iConfImapQuotaMbytes.text().ascii():
                imap.sq(mbPath, (int(self.iConfImapQuotaMbytes.text().ascii()) * 1024))
            if self.rbImapMailboxMode.isChecked():
                item = self.lvConfImapFolders.firstChild()
                while item is not None:
                    __imap_add("%s%s%s" % (mbPath, imap.SEP, item.text(0).ascii()))
                    if item.text(1).ascii() and item.text(1).ascii() != "0":
                        imap.setannotation("%s%s%s" % (mbPath, imap.SEP, item.text(0).ascii()), "/vendor/cmu/cyrus-imapd/expire", item.text(1).ascii())
                    if item.text(2).ascii():
                        imap.sam("%s%s%s" % (mbPath, imap.SEP, item.text(0).ascii()), "anyone", "p")
                    item = item.nextSibling()
        
        self.lvImap.setCurrentItem(self.imap_cache_items.get(mailbox))
        self.lvImap.ensureItemVisible(self.imap_cache_items.get(mailbox))
        self.imap_mailbox_clicked()
        
        

    def imap_delete(self):
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        mailbox = self.imap_current_mailbox(imap.SEP)
        if mailbox is None:
            self.console(self.__tr("select mailbox for deletion."), self.CONSOLE_WARN)
            return True
        
        #
        # Ask about deletion
        #
        
        if QMessageBox.information( None, self.__tr("Confirm!"),
                                                       self.__tr("Check mailbox for deletion:\n\n    - %1\n\n").arg(mailbox),
                                                       self.__tr("&Yes"), self.__tr("&No") ) != 0:
            self.console(self.__tr("mailbox '%1' deletion aborted.").arg(mailbox), self.CONSOLE_WARN)
            return True
        
        #
        # Delete Imap Mailbox
        #
        
        try:
            imap.dm(mailbox)
            del self.imap_cache_items[re.sub("^user%s" % imap.SEP, "", mailbox)]
            self.console(self.__tr("mailbox '%1' deleted.").arg(mailbox))
        except cyruslib.CYRUSError, e:
            self.console(self.__tr("mailbox '%1' deletion failed. (%2)").arg(mailbox).arg(e[2]), self.CONSOLE_ERR)
            return False
        
        #
        # Delete Interface item
        #
        
        item = self.lvImap.currentItem()
        if item is not None:
            if item.parent() is None:
                self.lvImap.takeItem(item)
            else:
                item.parent().takeItem(item)
        
        item = self.lvImap.currentItem()
        if item is not None:
            item.setSelected(True)
        
        

    def imap_set_quota(self):
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        mailbox = self.imap_current_mailbox(imap.SEP)
        if mailbox is None:
            self.console(self.__tr("select mailbox to set quota."), self.CONSOLE_WARN)
            return True
        
        #
        # IMAP Set Quota
        #
        
        try:
            imap.sq(mailbox, self.iQuota.text().ascii())
            self.console(self.__tr("mailbox '%1' seted quota to '%2 Kbytes'.").arg(mailbox).arg(self.iQuota.text().ascii()))
        except:
            self.console(self.__tr("can't set quota to mailbox '%1'.").arg(mailbox), self.CONSOLE_ERR)
        
        

    def imap_reconstruct(self):
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        mailbox = self.imap_current_mailbox(imap.SEP)
        if mailbox is None:
            self.console(self.__tr("select mailbox for reconstruct."), self.CONSOLE_WARN)
            return True
        
        try:
            imap.reconstruct(mailbox)
            self.console(self.__tr("mailbox '%1' has been reconstructed.").arg(mailbox))
        except:
            self.console(self.__tr("can't reconstruct mailbox '%1'.").arg(mailbox), self.CONSOLE_ERR)
        
        

    def imap_edit(self):
        
        #
        # Turn field editable
        #
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        self.imap_mailbox_rename = self.imap_current_mailbox(imap.SEP)
        self.lvImap.currentItem().setRenameEnabled(0, True)
        self.lvImap.currentItem().startRename(0)
        
        

    def imap_rename(self):
        
        #
        # Undo rename
        #
        
        def rename_undo():
            self.lvImap.currentItem().setText(0, self.imap_mailbox_rename.split(imap.SEP)[-1])
        
        #
        # Current mailbox is a root mailbox
        #
        
        def is_root_folder():
            if len(re.sub("^user%s" % imap.SEP, "", self.imap_mailbox_rename).split(imap.SEP)) == 1:
                return True
            return False
        
        #
        # Imap Connect
        #
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        #
        # Mailbox has a name?
        #
        
        mailbox = self.imap_current_mailbox(imap.SEP)
        if mailbox is None:
            self.console(self.__tr("type a valid mailbox name."), self.CONSOLE_WARN)
            rename_undo()
            return False
        
        #
        # Mailbox was renamed?
        #
        
        if self.imap_mailbox_rename == mailbox:
            return False
        
        #
        # Mailbox already exist?
        #
        
        if len(imap.lm(mailbox)) > 0:
            self.console(self.__tr("mailbox '%1' already exist.").arg(mailbox), self.CONSOLE_WARN)
            rename_undo()
            return False
        
        #
        # Confirm
        #
        
        msg = self.__tr("Please verify if user is not logged by POP/IMAP before you proceed.\n         # grep -r johndoe /var/lib/cyrus/proc/")
        if QMessageBox.information( None, self.__tr("Warning!"), msg, self.__tr("&Ok")) != 0:
            self.console(self.__tr("rename aborted."), self.CONSOLE_WARN)
            rename_undo()
            return False
        
        #
        # Detect mailbox partition
        #
        
        partition = None
        if is_root_folder():
            try:
                partitionDict = imap.getannotation(self.imap_mailbox_rename, "/vendor/cmu/cyrus-imapd/partition")
                partition = partitionDict[self.imap_mailbox_rename]["/vendor/cmu/cyrus-imapd/partition"]
            except:
                self.console(self.__tr("can't detect IMAP-partition to '%1'.").arg(mailbox), self.CONSOLE_ERR)
                rename_undo()
                return None
        
        #
        # Do rename
        #
        
        try:
            imap.rename(self.imap_mailbox_rename, mailbox, partition)
            self.console(self.__tr("mailbox '%1' renamed to '%2'.").arg(self.imap_mailbox_rename).arg(mailbox))
        except:
            self.console(self.__tr("can't rename '%1'. Set option: \"allowusermoves: yes\".").arg(self.imap_mailbox_rename), self.CONSOLE_ERR)
            rename_undo()
        
        self.imap_mailbox_clicked()
        
        

    def imap_annotation_set(self,a0,a1,a2,a3):
        # a0=obj:imap, a1=str:mailbox, a2=str:annot, a3=str:annotvalue
        
        imap = a0
        mailbox = a1
        annot = a2
        annotvalue = a3
        
        if not annot:
            self.console(self.__tr("select annotation."), self.CONSOLE_WARN)
            return False
        
        try:
            imap.setannotation(mailbox, annot, annotvalue)
            self.console(self.__tr("mailbox '%1' has annotation '%2' set to '%3'.").arg(mailbox).arg(annot).arg(annotvalue))
        except cyruslib.CYRUSError, e:
            self.console(self.__tr("can't set annotation '%1' for mailbox '%2' (%3).").arg(annot).arg(mailbox).arg(e[2]), self.CONSOLE_ERR)
        
        

    def imap_annotation_user_set(self):
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        mailbox = self.imap_current_mailbox(imap.SEP)
        if mailbox is None:
            self.console(self.__tr("select mailbox to set annotation."), self.CONSOLE_WARN)
            return True
        
        self.imap_annotation_set(imap, mailbox, self.cbImapAnnotation.currentText().ascii(), self.iAnnotationValue.text().ascii())
        
        

    def imap_annotation_server_set(self):
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        self.imap_annotation_set(imap, "", self.cbImapAnnotationServer.currentText().ascii(), self.iAnnotationValueServer.text().ascii())
        
        

    def imap_annotation_get(self,a0,a1,a2):
        # a0=obj:imap, a1=str:mailbox, a2=str:annot
        
        imap = a0
        mailbox = a1
        annot = a2
        
        if imap is None:
            return False
        
        if not annot:
            self.console(self.__tr("select annotation."), self.CONSOLE_WARN)
            return False
        
        try:
            annotation = imap.getannotation(mailbox, annot)
            return annotation.get(mailbox).get(annot)
        except cyruslib.CYRUSError, e:
            self.console(self.__tr("can't get annotation '%1' for mailbox '%2' (%3)." % (annot, mailbox, e[2])), self.CONSOLE_ERR)
            return ""
        except:
            return ""
        
        

    def imap_annotation_user_get(self,a0=None,a1=None):
        # a0=obj:QString or None, a1=obj:imap or None
        
        imap = a1
        
        if imap is None:
            imap = self.imap_connect()
            if imap is None:
                return False
        
        mailbox = self.imap_current_mailbox(imap.SEP)
        if mailbox is None:
            self.console(self.__tr("select a mailbox."), self.CONSOLE_WARN)
            return True
        
        annot = self.imap_annotation_get(imap, mailbox, self.cbImapAnnotation.currentText().ascii())
        if annot:
            self.iAnnotationValue.setText(annot)
        else:
            self.iAnnotationValue.setText("")
        
        

    def imap_annotation_server_get(self):
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        annot = self.imap_annotation_get(imap, "", self.cbImapAnnotationServer.currentText().ascii())
        if annot:
            self.iAnnotationValueServer.setText(annot)
        else:
            self.iAnnotationValueServer.setText("")
        
        

    def imap_acl_wizard(self):
        
        if self.cbACL.currentItem() == 1:
            self.cbACL.setCurrentText("lrsw")
        elif self.cbACL.currentItem() == 2:
            self.cbACL.setCurrentText("lrswi")
        elif self.cbACL.currentItem() == 3:
            self.cbACL.setCurrentText("lrswicd")
        elif self.cbACL.currentItem() == 4:
            self.cbACL.setCurrentText("p")
        elif self.cbACL.currentItem() == 5:
            self.cbACL.setCurrentText("lrswipcda")
        
        

    def imap_acl_del(self):
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        mailbox = self.imap_current_mailbox(imap.SEP)
        if mailbox is None:
            self.console(self.__tr("select mailbox for ACL deletion."), self.CONSOLE_WARN)
            return True
        
        def __acl_del(user):
            try:
                imap.sam(mailbox, user, "")
                self.console(self.__tr("mailbox '%1' has ACL to '%2' deleted.").arg(mailbox).arg(user))
                return True
            except:
                self.console(self.__tr("can't delete ACL to '%1' for mailbox '%2'.").arg(user).arg(mailbox), self.CONSOLE_ERR)
                return False
        
        itemDel = []
        item = self.lvImapAcl.firstChild()
        while item is not None:
            if item.isSelected():
                if __acl_del(item.text(0).ascii()):
                    itemDel.append(item)
            item = item.nextSibling()
        
        for item in itemDel:
            self.lvImapAcl.takeItem(item)
        
        

    def imap_acl_add(self):
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        mailbox = self.imap_current_mailbox(imap.SEP)
        if mailbox is None:
            self.console(self.__tr("select mailbox to set ACL."), self.CONSOLE_WARN)
            return True
        
        AclUser = self.iImapAclUser.text().latin1().replace(" ", "").replace(";", ",")
        Acl = self.cbACL.currentText().ascii()
        
        for user in AclUser.split(","):
            if not user:
                continue
            try:
                imap.sam(mailbox, user, Acl)
                self.console(self.__tr("mailbox '%1' has added ACL '%2' to '%3'.").arg(mailbox).arg(Acl).arg(user))
                item = self.lvImapAcl.firstChild()
                while item is not None:
                    if item.text(0).ascii() == user:
                        self.lvImapAcl.takeItem(item)
                        break
                    item = item.nextSibling()
                item = QListViewItem(self.lvImapAcl)
                item.setText(0, user)
                item.setText(1, Acl)
                self.lvImapAcl.setCurrentItem(item)
            except:
                self.console(self.__tr("can't set ACL '%1' to user '%2' for mailbox '%3'.").arg(Acl).arg(user).arg(self.iImapMailbox.text().ascii()), self.CONSOLE_ERR)
        
        

    def imap_acl_clicked(self,a0):
        # a0=item:current ACL item
        
        item = a0
        if item is not None:
            self.iImapAclUser.setText(item.text(0).ascii())
            self.cbACL.setCurrentText(item.text(1).ascii())
        else:
            self.iImapAclUser.clear()
            self.cbACL.setCurrentItem(0)
        
        

    def imap_menu(self,a0,a1):
        # a0: item, a1: pos-xy
        
        item = a0
        pos = a1
        
        if item is None:
            self.lvImapMenu.setItemEnabled(0, False)
            self.lvImapMenu.setItemEnabled(1, False)
            self.lvImapMenu.setItemEnabled(2, False)
        else:
            self.lvImapMenu.setItemEnabled(0, True)
            self.lvImapMenu.setItemEnabled(1, True)
            self.lvImapMenu.setItemEnabled(2, True)
        
        self.korreio_update_servers_menu()
        self.lvImapMenu.popup(pos)
        
        

    def imap_menu_clicked(self,a0):
        
        if a0 == 0:
            self.imap_edit()
        elif a0 == 1:
            self.imap_delete()
        elif a0 == 2:
            self.imap_reconstruct()
        
        

    def imap_form_clear(self):
        
        self.korreio_module_clear("imap")
        
        

    def imap_partition_search(self):
        
        self.korreio_module_clear("imap-partition")
        partitions = {}
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        #
        # Imap query
        #
        
        if self.rbImapPartMailboxMode.isChecked():
            query = "user%s%s%%" % (imap.SEP, self.iImapPartitionSearch.text().ascii())
        else:
            query = "%s%%" % (self.iImapPartitionSearch.text().ascii())
        
        try:
            annot = imap.getannotation(query, "/vendor/cmu/cyrus-imapd/partition")
        except:
            return False
        
        for mailbox in annot:
            partitions[annot[mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = None
            item = QListViewItem(self.lvImapPartition)
            item.setText(0, re.sub("^user%s" % imap.SEP, "", mailbox))
            item.setText(1, annot[mailbox]["/vendor/cmu/cyrus-imapd/partition"])
            if self.cImapSize.isChecked():
                try:
                    limit = imap.lq(mailbox)
                    item.setText(2, "%s" % limit[0])
                    item.setText(3, "%s" % limit[1])
                    item.setText(4, "%s%%" % (limit[0] * 100 / limit[1]) )
                    continue
                except:
                    item.setText(2, "-")
                    item.setText(3, "-")
                    item.setText(4, "0%")
            else:
                item.setText(2, "-")
                item.setText(3, "-")
                item.setText(4, "0%")
        
        if self.lvImapPartition.childCount() > 0:
            self.pImapPartitionMove.setEnabled(True)
        else:
            self.pImapPartitionMove.setEnabled(False)
        
        for part in partitions:
            self.cbImapPartition.insertItem(part)
        
        

    def imap_partition_move(self):
        
        partition = self.cbImapPartition.currentText().ascii()
        if partition == "" or re.search(" ", partition):
            self.cbImapPartition.setFocus()
            self.console(self.__tr("select IMAP-Partition."), self.CONSOLE_WARN)
            return False
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        item = self.lvImapPartition.firstChild()
        while item is not None:
            if item.isSelected():
                if self.rbImapPartMailboxMode.isChecked():
                    mailbox = "user%s%s" % (imap.SEP, item.text(0).ascii())
                else:
                    mailbox = item.text(0).ascii()
                
                try:
                    imap.rename(mailbox, mailbox, partition)
                    item.setText(1, partition)
                    self.console(self.__tr("mailbox '%1' moved to IMAP-Partition '%2'.").arg(item.text(0).ascii()).arg(partition))
                except cyruslib.CYRUSError, e:
                    self.console(self.__tr("can't move mailbox '%1' to IMAP-Partition '%2'. (%3)").arg(item.text(0).ascii()).arg(partition).arg(e[2]), self.CONSOLE_ERR)
            item = item.nextSibling()
        
        

    def imap_partition_size(self):
        
        if not self.cImapSizeUpdate.isChecked():
            self.tlImapSize.setText("0 ~ 0 Mbytes ~ 0%")
            return True
        
        size = 0
        percent = 0
        count = 0
        item = self.lvImapPartition.firstChild()
        while item is not None:
            if item.isSelected() and item.text(2).ascii() != "-":
                size += int(item.text(2).ascii())
                percent += int(item.text(4).ascii().replace("%", ""))
                count += 1
            item=item.nextSibling()
        
        if count == 0:
            media = 0
        else:
            media = percent / count
        
        self.tlImapSize.setText("%s ~ %s Mbytes ~ %s%%" % ((count), (size / 1024), media))
        
        

    def imap_partition_menu(self,a0,a1):
        # a0: item, a1: pos-xy
        
        self.korreio_update_servers_menu()
        self.lvImapPartMenu.popup(a1)
        
        

    def imap_partition_menu_clicked(self,a0):
        
        if a0 == 0:
            # Select All
            self.lvImapPartition.selectAll(True)
        elif a0 == 1:
            # Set quota
            try:
                dflquota = int(self.iConfImapQuotaMbytes.text().ascii()) * 1024
            except:
                dflquota = 0
            quota, msg = QInputDialog.getInteger(self.__tr("Quota"), self.__tr("Set quota limit (Kbytes):"), dflquota, 0, 2147483647, 512)
            if msg:
                imap = self.imap_connect()
                if imap is None:
                    return False
                item = self.lvImapPartition.firstChild()
                while item is not None:
                    if item.isSelected():
                        if self.rbImapPartMailboxMode.isChecked():
                            mbx = "user%s%s" % (imap.SEP, item.text(0).ascii())
                        else:
                            mbx = item.text(0).ascii()
                        try:
                            imap.sq(mbx, quota)
                            item.setText(3, str(quota))
                            self.console(self.__tr("mailbox '%1' has set quota to '%2 Kbytes'.").arg(item.text(0).ascii()).arg(str(quota)))
                        except:
                            self.console(self.__tr("can't set quota to mailbox '%1'.").arg(item.text(0).ascii()), self.CONSOLE_ERR)
                    item=item.nextSibling()
            else:
                self.console(self.__tr("set quota aborted."), self.CONSOLE_INFO)
        

    def imap_partition_form_clear(self):
        
        self.korreio_module_clear("imap-partition")
        
        

    def ldap_connect(self):
        
        #
        # Verify LDAP connection cache
        #
        
        try:
            if self.l:
                if self.inet_cache.get("ldap.mode") == self.cbLdapMode.currentText().ascii() and self.inet_cache.get("ldap.host") == self.iLdapHost.text().ascii() and self.inet_cache.get("ldap.port") == self.iLdapPort.text().ascii() and self.inet_cache.get("ldap.user") == self.iLdapUser.text().ascii() and self.inet_cache.get("ldap.pass") == self.iLdapPass.text().ascii() and self.inet_cache.get("ldap.ref") == "%s" % self.cLdapRef.isChecked():
                    return self.l
        except:
            pass
        
        #
        # Connect to LDAP
        #
        
        try:
            if self.cLdapCert.isChecked():
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, 0)
            else:
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, 2)
            if self.cLdapRef.isChecked():
                ldap.set_option(ldap.OPT_REFERRALS, 1)
            else:
                ldap.set_option(ldap.OPT_REFERRALS, 0)
            server = "%s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii())
            self.l = ldap.initialize(server)
            self.l.protocol_version = ldap.VERSION3
            if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
                self.l.simple_bind(Q2utf(self.iLdapUser.text()), Q2utf(self.iLdapPass.text()))
            else:
                self.l.simple_bind()
        except ldap.LDAPError, e:
            try:
                del self.l
            except:
                pass
            raise ldap.LDAPError, e
        
        #
        # Save current LDAP connection information
        #
        
        self.inet_cache["ldap.mode"] = self.cbLdapMode.currentText().ascii()
        self.inet_cache["ldap.host"] = self.iLdapHost.text().ascii()
        self.inet_cache["ldap.port"] = self.iLdapPort.text().ascii()
        self.inet_cache["ldap.user"] = self.iLdapUser.text().ascii()
        self.inet_cache["ldap.pass"] = self.iLdapPass.text().ascii()
        self.inet_cache["ldap.ref"] = "%s" % self.cLdapRef.isChecked()
        
        self.console(self.__tr("%1 connected.").arg("%s/%s" % (server, self.iLdapUser.text().ascii())))
        return self.l
        
        

    def ldap_search(self):
        
        #
        # Save current ldap filter and remove oldest
        #
        
        self.cbLdapFilter.insertItem(self.cbLdapFilter.currentText().latin1())
        if self.cbLdapFilter.count() > self.lbConfLdapFilter.count() + 7:
            self.cbLdapFilter.removeItem(self.lbConfLdapFilter.count())
        self.cbLdapFilter.setCurrentItem(self.cbLdapFilter.count() - 1)
        
        #
        # Save selected entry
        #
        
        basedn = Q2uni(self.cbLdapBaseDN.currentText())
        dnOld = self.ldap_current_dn()
        if dnOld is None:
            dnOld = basedn
        
        self.korreio_module_clear("ldap")
        
        #
        # Ldap query
        #
        
        if not self.cbLdapFilter.currentText().latin1():
            filter = "(objectClass=*)"
        else:
            filter = "(%s)" % Q2utf(self.cbLdapFilter.currentText())
        self.ldap_cache.load(self.ldap_query(filter))
        if self.ldap_cache.isEmpty():
            return True
        
        #
        # Update interface
        #
        
        self.ldap_items.init([basedn])
        
        for dn in self.ldap_cache.keys():
            self.ldap_items.load(dn)
            self.ldap_cache.rename(dn, dn.lower())
        
        #
        # Set last selection
        #
        
        item = self.ldap_items.get(dnOld.lower())
        if item is None:
            item = self.lvLdap.firstChild()
        if item is not None:
            self.lvLdap.setCurrentItem(item)
            self.lvLdap.currentItem().setSelected(True)
            while item is not None:
                item.setOpen(True)
                item = item.parent()
        
        #
        # ensureItemVisible improvent
        #
        
        item = self.lvLdap.currentItem()
        if item is not None:
            self.lvLdap.scrollBy(0, item.itemPos() - 30)
        
        #
        # Show attibutes for selected item
        #
        
        self.ldap_dn_clicked()
        self.lvLdap.setFocus()
        
        

    def ldap_query(self,a0,a1=None,a2=None,a3=None):
        # a0=str:ldap_filter, a1=list:attrs or None (retrive attributes)
        # a2=str:baseDN or None (default base), a3:ldap.SCOPE:scope or None (subtree)
        
        ldap_filter = a0
        attrs = a1
        baseDN = a2
        scope = a3
        
        if baseDN is None:
            baseDN = Q2utf(self.cbLdapBaseDN.currentText())
        if scope is None:
            scope = ldap.SCOPE_SUBTREE
        
        try:
            l = self.ldap_connect()
            if l is None:
                return False
            ldap_result_id = l.search(baseDN, scope, ldap_filter, attrs)
            ldap_result = {}
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                if result_type == ldap.RES_SEARCH_RESULT:
                    break
                elif result_type == ldap.RES_SEARCH_ENTRY:
                    ldap_result[utf2uni(result_data[0][0])] = result_data[0][1]
                elif result_type == ldap.RES_SEARCH_REFERENCE:
                    dn = result_data[0][1][0].split('/', 3)[3].split("?")[0]
                    attr, value = dn.split(',')[0].split('=')
                    ldap_result[dn] = {'ref': [result_data[0][1][0]], 'objectClass': ['referral', 'extensibleObject'], attr: [value]}
                else:
                    print "ERROR: result type not implemented. %s" % result_type
            return ldap_result
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            if e[0]["desc"] == "Size limit exceeded":
                return ldap_result
        
        

    def ldap_current_dn(self):
        
        item = self.lvLdap.currentItem()
        if item is None:
            return None
        
        dn = Q2uni(item.text(0))
        while item.parent() is not None:
            dn = dn + u"," + Q2uni(item.parent().text(0))
            item = item.parent()
        
        return dn
        
        

    def ldap_dn_clicked(self):
        
        #
        # Default is modify action
        #
        self.ldap_add_or_modify = True
        
        self.lvLdapAttr.clear()
        self.wsLdap.raiseWidget(0)
        
        dn = self.ldap_current_dn()
        if dn is None:
            return True
        
        if self.ldap_cache.get(dn.lower()):
            self.pLdapDelete.setEnabled(True)
            if 'ref' in self.ldap_cache.get(dn.lower()).keys():
                self.pLdapModify.setEnabled(False)
            else:
                self.pLdapModify.setEnabled(True)
            for attribute, values in self.ldap_cache.get(dn.lower()).items():
                for value in values:
                    item = QListViewItem(self.lvLdapAttr)
                    item.setText(0, attribute)
                    try:
                        item.setText(1, utf2uni(value))
                    except:
                        item.setText(1, value)
        else:
            self.pLdapModify.setEnabled(False)
            self.pLdapDelete.setEnabled(False)
        
        #
        # Select first attribute
        #
        
        if self.lvLdapAttr.childCount() > 0:
            self.lvLdapAttr.setCurrentItem(self.lvLdapAttr.firstChild())
            self.lvLdapAttr.currentItem().setSelected(True)
        
        

    def ldap_wizard_user_next(self):
        
            self.wsLdapForm.raiseWidget(self.wsLdapForm.id(self.wsLdapForm.visibleWidget()) + 1)
        
        

    def ldap_wizard_user_back(self):
        
            self.wsLdapForm.raiseWidget(self.wsLdapForm.id(self.wsLdapForm.visibleWidget()) - 1)
        
        

    def ldap_wizard_posixAccount_enable(self):
        
            if self.cLdapFormPosix.isChecked():
                self.fLdapFormPosix.setEnabled(True)
            else:
                self.fLdapFormPosix.setEnabled(False)
                self.fLdapFormSamba.setEnabled(False)
                self.cLdapFormSamba.setChecked(False)
        
        

    def ldap_wizard_posixAccount_get_uidNumber(self):
        
        try:
            uidNumbers = self.ldap_query("(&(uidNumber=*)(!(objectClass=sambaUnixIdPool)))", ["uidNumber"])
            if uidNumbers:
                nextUidNumber = 999
                for item in uidNumbers:
                    uidNumber = uidNumbers.get(item).get("uidNumber")[0]
                    if int(uidNumber) > nextUidNumber:
                        nextUidNumber = int(uidNumber)
        
                if nextUidNumber > 998:
                    self.iLdapFormUidNumber.setText("%s" % (nextUidNumber + 1))
            
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
        
        

    def ldap_wizard_sambaSamAccount_enable(self):
        
        if self.cLdapFormSamba.isChecked():
            if not self.iLdapFormUid.text().latin1():
                self.console(self.__tr("set email or uid."), self.CONSOLE_WARN)
                self.cLdapFormSamba.setChecked(False)
                return False
        
            i=0
            domains = []
            while self.confDict.get("ldap.smb%s.domain" % i):
                domains.append(self.confDict.get("ldap.smb%s.domain" % i))
                i+=1
        
            self.cbLdapFormSambaDomain.clear()
            domains.sort()
            for domain in domains:
                self.cbLdapFormSambaDomain.insertItem(domain)
        
            if self.cbLdapFormSambaDomain.count() == 0:
                self.console(self.__tr("set netbios domains."), self.CONSOLE_WARN)
                self.cLdapFormSamba.setChecked(False)
            else:
                self.cLdapFormPosix.setChecked(True)
                self.fLdapFormPosix.setEnabled(True)
                self.iLdapFormUidNumber.setEnabled(False)
                self.pLdapGetUidNumber.setEnabled(False)
                self.iLdapFormGidNumber.setEnabled(False)
                self.fLdapFormSamba.setEnabled(True)
                self.ldap_wizard_sambaSamAccount_domain_clicked()
        else:
            self.fLdapFormSamba.setEnabled(False)
            self.iLdapFormUidNumber.setEnabled(True)
            self.pLdapGetUidNumber.setEnabled(True)
            self.iLdapFormGidNumber.setEnabled(True)
            self.iLdapFormGidNumber.setText("100")
        
        

    def ldap_wizard_sambaSamAccount_domain_clicked(self):
        
        domain = self.cbLdapFormSambaDomain.currentText().ascii()
        i=0
        while self.confDict.get("ldap.smb%s.domain" % i):
            if self.confDict.get("ldap.smb%s.domain" % i) == domain:
                break
            i+=1
        
        #
        # sambaPwdMustChange
        #
        if self.confDict["ldap.smb%s.pwdMustChange" % i] == "True":
            self.iLdapFormSambaPwdMustChange.setChecked(True)
        else:
            self.iLdapFormSambaPwdMustChange.setChecked(False)
        
        #
        # sambaPrimaryGroupSID / gidNumber
        #
        self.cbLdapFormPrimaryGroup.setCurrentItem(int(self.confDict["ldap.smb%s.primaryGroup" % i]))
        gidNumber = self.cbLdapFormPrimaryGroup.currentText().ascii().split("(")[1].split(")")[0]
        self.iLdapFormGidNumber.setText(gidNumber)
        
        #
        # sambaProfilePath
        #
        if self.confDict["ldap.smb%s.profileType" % i] == "0":
            self.cbLdapFormProfileType.setCurrentItem(0)
            self.iLdapFormProfilePath.setEnabled(False)
        else:
            self.cbLdapFormProfileType.setCurrentItem(1)
            self.iLdapFormProfilePath.setEnabled(True)
        profilePath = re.sub("#UID#", self.iLdapFormUid.text().ascii(), self.confDict["ldap.smb%s.profilePath" % i])
        profilePath = re.sub("#GID#", gidNumber, profilePath)
        self.iLdapFormProfilePath.setText(profilePath)
        
        #
        # sambaHomeDrive
        #
        self.iLdapFormHomeDrive.setText(self.confDict["ldap.smb%s.homeDrive" % i])
        
        #
        # sambaHomePath
        #
        drivePath = re.sub("#UID#", self.iLdapFormUid.text().ascii(), self.confDict["ldap.smb%s.drivePath" % i])
        drivePath = re.sub("#GID#", gidNumber, drivePath)
        self.iLdapFormDrivePath.setText(drivePath)
        
        #
        # sambaLogonScript
        #
        logonScript = re.sub("#UID#", self.iLdapFormUid.text().ascii(), self.confDict["ldap.smb%s.logonScript" % i])
        logonScript = re.sub("#GID#", gidNumber, logonScript)
        self.iLdapFormLogonScript.setText(logonScript)
        
        

    def ldap_wizard_sambaSamAccount_perfil_clicked(self):
        
            if self.cbLdapFormProfileType.currentItem() == 0:
                self.iLdapFormProfilePath.setEnabled(False)
            else:
                self.iLdapFormProfilePath.setEnabled(True)
        
        

    def ldap_wizard_astSipUser_enable(self):
        
            if self.cLdapFormAst.isChecked():
                self.fLdapFormAst.setEnabled(True)
            else:
                self.fLdapFormAst.setEnabled(False)
        
        

    def ldap_wizard_radiusProfile_enable(self):
        
            if self.cLdapFormRadius.isChecked():
                self.fLdapFormRadius.setEnabled(True)
            else:
                self.fLdapFormRadius.setEnabled(False)
        
        

    def ldap_wizard_uid_changed(self):
        
            self.iLdapFormHomeDirectory.setText("/home/%s" % self.iLdapFormUid.text().ascii())
            self.iLdapFormAstUsername.setText(self.iLdapFormUid.text().ascii())
        
        

    def ldap_wizard_inetOrgPerson_mail_changed(self):
        
            self.iLdapFormUid.setText(self.iLdapFormMail.text().ascii().split("@")[0])
        
        

    def ldap_wizard_insert_user(self):
        
        if not self.iLdapFormCn.text().ascii():
            self.console(self.__tr("set user name."), self.CONSOLE_WARN)
            self.wsLdapForm.raiseWidget(0)
            self.iLdapFormCn.setFocus()
            return False
        
        cn = Q2utf(self.iLdapFormCn.text())
        
        attrs = {}
        
        #
        # inetOrgPerson
        #
        
        attrs['objectClass'] = ['inetOrgPerson']
        attrs['cn'] = [cn]
        attrs['sn'] = [cn.split(" ")[-1]]
        if self.iLdapFormMail.text().ascii():
            attrs['mail'] = [self.iLdapFormMail.text().ascii()]
        
        if self.iLdapFormStreet.text().ascii():
            attrs['street'] = [Q2utf(self.iLdapFormStreet.text())]
        
        if self.iLdapFormL.text().ascii():
            attrs['l'] = [Q2utf(self.iLdapFormL.text())]
        
        if self.iLdapFormPostalCode.text().ascii():
            attrs['postalCode'] = [self.iLdapFormPostalCode.text().ascii()]
        
        if self.iLdapFormHomePhone.text().ascii():
            attrs['homePhone'] = [self.iLdapFormHomePhone.text().ascii()]
        
        if self.iLdapFormUserP.text().ascii() != self.iLdapFormUserP2.text().ascii():
            self.console(self.__tr("password don't match, type again."), self.CONSOLE_WARN)
            self.wsLdapForm.raiseWidget(0)
            self.iLdapFormUserP.clear()
            self.iLdapFormUserP2.clear()
            self.iLdapFormUserP.setFocus()
            return False
        
        if self.iLdapFormUserP.text().ascii():
            salt = ''
            for i in range(16):
                salt += choice(letters+digits)
            attrs['userPassword'] = ["{SSHA}%s"  % b2a_base64(sha.new(self.iLdapFormUserP.text().ascii() + salt).digest() + salt)[:-1]]
        
        #
        # posixAccount
        #
        
        if self.cLdapFormPosix.isChecked():
            attrs['objectClass'].extend(['posixAccount', 'shadowAccount'])
        
            if not self.iLdapFormUid.text().ascii():
                self.console(self.__tr("set uid."), self.CONSOLE_INFO)
                self.iLdapFormUid.setFocus()
                return False
            attrs['uid'] = [Q2utf(self.iLdapFormUid.text())]
        
            if not self.iLdapFormUidNumber.text().ascii():
                self.console(self.__tr("set uidNumber."), self.CONSOLE_INFO)
                self.iLdapFormUidNumber.setFocus()
                return False
            attrs['uidNumber'] = [self.iLdapFormUidNumber.text().ascii()]
        
            if not self.iLdapFormGidNumber.text().ascii():
                self.console(self.__tr("set gidNumber."), self.CONSOLE_INFO)
                self.iLdapFormGidNumber.setFocus()
                return False
            attrs['gidNumber'] = [self.iLdapFormGidNumber.text().ascii()]
        
            if self.iLdapFormLoginShell.text().ascii():
                attrs['loginShell'] = [Q2utf(self.iLdapFormLoginShell.text())]
        
            if not self.iLdapFormHomeDirectory.text().ascii():
                self.console(self.__tr("set home directory."), self.CONSOLE_INFO)
                self.iLdapFormHomeDirectory.setFocus()
                return False
            attrs['homeDirectory'] = [Q2utf(self.iLdapFormHomeDirectory.text())]
        
        #
        # sambaSamAccount
        #
        
        if self.cLdapFormSamba.isChecked():
            attrs['objectClass'].extend(['sambaSamAccount'])
            attrs['uid'] = [Q2utf(self.iLdapFormUid.text())]
        
            domain = self.cbLdapFormSambaDomain.currentText().ascii()
            i=0
            while self.confDict.get("ldap.smb%s.domain" % i):
                if self.confDict.get("ldap.smb%s.domain" % i) == domain:
                    break
                i+=1
        
            if not self.confDict.get("ldap.smb%s.domain" % i):
                self.console(self.__tr("domain '%1' is not configured.").arg(domain), self.CONSOLE_WARN)
                self.wsLdapForm.raiseWidget(2)
                return False
        
            #
            # required for sambaSID / sambaPrimaryGroup
            #
            SIDEntry = self.confDict["ldap.smb%s.SIDEntry" % i]
            if not SIDEntry:
                self.console(self.__tr("SIDdn for domain '%1' is not configured.").arg(domain), self.CONSOLE_WARN)
                self.wsLdapForm.raiseWidget(2)
                return False
            SID = self.ldap_query(SIDEntry.split(",")[0]).get(SIDEntry).get("sambaSID")[0]
        
            #
            # required for sambaSID / uidNumber
            #
            uidCounter = self.confDict["ldap.smb%s.counterEntry" % i]
            if not uidCounter:
                self.console(self.__tr("uidNumber counter for domain '%1' is not configured.").arg(domain), self.CONSOLE_WARN)
                self.wsLdapForm.raiseWidget(2)
                return False
            uidNumber = self.ldap_query(uidCounter.split(",")[0]).get(uidCounter).get("uidNumber")[0]
        
            #
            # default attributes
            #
            attrs['sambaLogonTime'] = ["0"]
            attrs['sambaLogoffTime'] = ["2147483647"]
            attrs['sambaKickoffTime'] = ["2147483647"]
            attrs['sambaPwdCanChange'] = ["0"]
            attrs['sambaAcctFlags'] = ["[U          ]"]
            attrs['sambaPwdLastSet'] = ["1"]
        
            #
            # sambaPwdMustChange
            #
            if self.iLdapFormSambaPwdMustChange.isChecked():
                attrs['sambaPwdMustChange'] = ["1"]
            else:
                attrs['sambaPwdMustChange'] = ["2147483647"]
        
            #
            # sambaSID / uidNumber
            #
            attrs['uidNumber'] = [uidNumber]
            attrs['sambaSID'] = ["%s-%s" % (SID, int(uidNumber) * 2 + 1000)]
        
            #
            # sambaPrimaryGroupSID / gidNumber
            #
            gidNumber = self.cbLdapFormPrimaryGroup.currentText().ascii().split("(")[1].split(")")[0]
            attrs['gidNumber'] = [gidNumber]
            attrs['sambaPrimaryGroupSID'] = ["%s-%s" % (SID, gidNumber)]
        
            #
            # sambaProfilePath
            #
            if self.cbLdapFormProfileType.currentItem() == 1:
                attrs['sambaProfilePath'] = [self.iLdapFormProfilePath.text().ascii()]
        
            #
            # sambaHomeDrive
            #
            if self.iLdapFormHomeDrive.text().ascii():
                attrs['sambaHomeDrive'] = [self.iLdapFormHomeDrive.text().ascii()]
        
            #
            # sambaHomePath
            #
            if self.iLdapFormDrivePath.text().ascii():
                attrs['sambaHomePath'] = [self.iLdapFormDrivePath.text().ascii()]
        
            #
            # sambaLogonScript
            #
            if self.iLdapFormLogonScript.text().ascii():
                attrs['sambaLogonScript'] = [self.iLdapFormLogonScript.text().ascii()]
        
            #
            # samba{NT-LM}Password
            #
            if self.iLdapFormUserP.text().ascii():
                attrs['sambaNTPassword'] = [smbpasswd.nthash(self.iLdapFormUserP.text().ascii())]
                attrs['sambaLMPassword'] = [smbpasswd.lmhash(self.iLdapFormUserP.text().ascii())]
        
        #
        # astSipGeneric
        #
        
        if self.cLdapFormAst.isChecked():
            attrs['objectClass'].extend(['astSipGeneric', 'astSipPeer'])
            attrs['astContext'] = ["from-sip"]
            attrs['astRegseconds'] = ["10"]
            attrs['astLanguage'] = ["en"]
            attrs['astHost'] = ["dynamic"]
        
            if not self.iLdapFormAstUsername.text().ascii():
                self.console(self.__tr("set user for asterisk."), self.CONSOLE_INFO)
                self.wsLdapForm.raiseWidget(3)
                self.iLdapFormAstUsername.setFocus()
                return False
            attrs['astUsername'] = [Q2utf(self.iLdapFormAstUsername.text())]
        
            if not self.iLdapFormAstName.text().ascii():
                self.console(self.__tr("set ramal for asterisk user."), self.CONSOLE_INFO)
                self.wsLdapForm.raiseWidget(3)
                self.iLdapFormAstName.setFocus()
                return False
            attrs['astName'] = [Q2utf(self.iLdapFormAstName.text())]
        
            if not self.iLdapFormAstPort.text().ascii():
                self.console(self.__tr("set port for asterisk."), self.CONSOLE_INFO)
                self.wsLdapForm.raiseWidget(3)
                self.iLdapFormAstPort.setFocus()
                return False
            attrs['astPort'] = [Q2utf(self.iLdapFormAstPort.text())]
        
            if self.iLdapFormUserP.text().ascii() and self.cLdapFormAstSecret.isChecked():
                attrs['astSecret'] = [Q2utf(self.iLdapFormUserP.text())]
        
        #
        # radiusProfile
        #
        
        if self.cLdapFormRadius.isChecked():
            attrs['objectClass'].extend(['radiusProfile'])
            if not self.iLdapFormRadiusGroup.text().ascii():
                self.console(self.__tr("set user radius group."), self.CONSOLE_INFO)
                self.wsLdapForm.raiseWidget(4)
                self.iLdapFormRadiusGroup.setFocus()
                return False
            attrs['radiusGroupName'] = [Q2utf(self.iLdapFormRadiusGroup.text())]
        
        #
        # Distinguist Name
        #
        
        dn = u"cn=%s,%s" % (Q2uni(self.iLdapFormCn.text()), self.ldap_current_dn())
        
        if self.cbConfLdapUserDN.currentItem() == 1 and self.iLdapFormMail.text().ascii():
            dn = u"mail=%s,%s" % (Q2uni(self.iLdapFormMail.text()), self.ldap_current_dn())
        elif self.cbConfLdapUserDN.currentItem() == 2 and self.cLdapFormPosix.isChecked():
            dn = u"uid=%s,%s" % (Q2uni(self.iLdapFormUid.text()), self.ldap_current_dn())
        
        if self.ldap_add(dn, attrs):
            if self.cLdapFormSamba.isChecked():
                attrsOld = {}
                attrsOld['uidNumber'] = [attrs.get("uidNumber")[0]]
                attrsNew = {}
                attrsNew['uidNumber'] = ["%s" % (int(attrs.get("uidNumber")[0]) + 1)]
                self.ldap_modify(uidCounter, attrsOld, attrsNew)
            self.korreio_module_clear("ldap.form")
        
        

    def ldap_wizard_insert_ou(self):
        
        attrs = {}
        if self.cbLdapFormUnit.currentItem() == 0:
            attrs['objectClass'] = ['organizationalUnit']
            attrs['ou'] = [Q2utf(self.iLdapFormUnit.text())]
            dn = u"ou=%s,%s" % (Q2uni(self.iLdapFormUnit.text()), self.ldap_current_dn())
        else:
            attrs['objectClass'] = ['organization']
            attrs['o'] = [Q2utf(self.iLdapFormUnit.text())]
            dn = u"o=%s,%s" % (Q2uni(self.iLdapFormUnit.text()), self.ldap_current_dn())
        if self.iLdapFormUnitStreet.text().ascii():
            attrs['street'] = [Q2utf(self.iLdapFormUnitStreet.text())]
        if self.iLdapFormUnitL.text().ascii():
            attrs['l'] = [Q2utf(self.iLdapFormUnitL.text())]
        if self.iLdapFormUnitPostalCode.text().ascii():
            attrs['postalCode'] = [Q2utf(self.iLdapFormUnitPostalCode.text())]
        if self.iLdapFormUnitTelephoneNumber.text().ascii():
            attrs['telephoneNumber'] = [Q2utf(self.iLdapFormUnitTelephoneNumber.text())]
        
        if self.ldap_add(dn, attrs):
            self.korreio_module_clear("ldap.form.unit")
        
        

    def ldap_wizard_dhcp_type(self):
        
        item = self.cbLdapFormDhcpType.currentItem()
        
        if item == 0:
            self.iLdapFormDhcpGroupName.setFocus()
            self.iLdapFormDhcpGroupName.setEnabled(True)
            self.tlLdapFormDhcpGroupName.setEnabled(True)
        elif item == 1:
            item = 0
            self.iLdapFormDhcpName.setFocus()
            self.iLdapFormDhcpGroupName.setEnabled(False)
            self.tlLdapFormDhcpGroupName.setEnabled(False)
        elif item == 2:
            item = 1
            self.cbLdapFormDhcpInterface.setFocus()
            self.cbLdapFormDhcpInterface.setEnabled(True)
            self.tlLdapFormDhcpInterface.setEnabled(True)
        elif item == 3:
            item = 1
            self.iLdapFormDhcpNetwork.setFocus()
            self.cbLdapFormDhcpInterface.setEnabled(False)
            self.tlLdapFormDhcpInterface.setEnabled(False)
        
        self.wsLdapDhcp.raiseWidget(item)
        
        

    def ldap_wizard_dhcp_insert(self):
        
        attrs = {}
        
        if self.cbLdapFormDhcpType.currentItem() < 2:
            #
            # dhcpGroup
            #
        
            if self.cbLdapFormDhcpType.currentItem() == 0:
                dn = u"cn=%s,%s" % (Q2uni(self.iLdapFormDhcpGroupName.text()), self.ldap_current_dn())
                attrs['objectClass'] = ['dhcpGroup']
                attrs['cn'] = [self.iLdapFormDhcpGroupName.text().ascii()]
                if not self.ldap_add(dn, attrs):
                    return False
                dn = u"cn=%s,cn=%s,%s" % (Q2uni(self.iLdapFormDhcpName.text()), Q2uni(self.iLdapFormDhcpGroupName.text()), self.ldap_current_dn())
            else:
                dn = u"cn=%s,%s" % (Q2uni(self.iLdapFormDhcpName.text()), self.ldap_current_dn())
        
            #
            # dhcpHost
            #
        
            attrs['objectClass'] = ['dhcpHost']
            attrs['cn'] = [Q2utf(self.iLdapFormDhcpName.text())]
            attrs['dhcpStatements'] = ["fixed-address %s" % self.iLdapFormDhcpIPaddress.text().ascii()]
            attrs['dhcpHWAddress'] = ["ethernet %s" % self.iLdapFormDhcpMACaddress.text().ascii()]
            if self.iLdapFormDhcpComments.text().ascii():
                attrs['dhcpComments'] = [Q2utf(self.iLdapFormDhcpComments.text())]
        
        else:
            #
            # dhcpSharedNetwork
            #
        
            if self.cbLdapFormDhcpType.currentItem() == 2:
                dn = u"cn=%s,%s" % (Q2uni(self.cbLdapFormDhcpInterface.currentText()), self.ldap_current_dn())
                attrs['objectClass'] = ['dhcpSharedNetwork']
                attrs['cn'] = [self.cbLdapFormDhcpInterface.currentText().ascii()]
                if not self.ldap_add(dn, attrs):
                    return False
                dn = u"cn=%s,cn=%s,%s" % (Q2uni(self.iLdapFormDhcpNetwork.text()), Q2uni(self.cbLdapFormDhcpInterface.currentText()), self.ldap_current_dn())
            else:
                dn = u"cn=%s,%s" % (Q2uni(self.iLdapFormDhcpNetwork.text()), self.ldap_current_dn())
        
            #
            # dhcpSubnet
            #
        
            attrs = {}
            attrs['objectClass'] = ['dhcpSubnet', 'dhcpOptions']
            attrs['cn'] = [self.iLdapFormDhcpNetwork.text().ascii()]
            attrs['dhcpOption'] = ['routers %s' % self.iLdapFormDhcpGateway.text().ascii()]
            if self.iLdapFormDhcpRange.text().ascii():
                attrs['dhcpRange'] = [self.iLdapFormDhcpRange.text().ascii()]
            attrs['dhcpNetMask'] = [self.cbLdapFormDhcpNetmask.currentText().ascii()]
        
        if self.ldap_add(dn, attrs):
            self.korreio_module_clear("ldap.form.dhcp")
        
        

    def ldap_wizard_group_type(self):
        
        item = self.cbLdapFormGroupType.currentItem()
        self.wsLdapGroup.raiseWidget(item)
        self.iLdapFormGroupName.setFocus()
        
        

    def ldap_wizard_group_insert(self):
        pass
        

    def ldap_add(self,a0,a1):
        # a0=unicode:DN, a1=list:attrs
        
        dn = a0
        attrs = a1
        
        try:
        
            #
            # Ldap Add
            #
        
            ldif = modlist.addModlist(attrs)
            l = self.ldap_connect()
            l.add_s(dn.encode('utf-8'), ldif)
        
            #
            # Update Ldap Cache and Interface
            #
        
            self.ldap_cache.add(dn.lower(), ldif)
            self.ldap_items.add(dn)
        
            #
            # Message
            #
        
            self.console(self.__tr("entry '%1' added.").arg(dn))
            return True
        
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_modify(self,a0,a1,a2):
        # a0=unicode:DN, a1=list:attrold, a2=list:attrnew
        
        dn = a0
        
        try:
        
            #
            # Ldap Modify
            #
        
            ldif = modlist.modifyModlist(a1, a2)
            l = self.ldap_connect()
            l.modify_s(dn.encode('utf-8'), ldif)
        
            #
            # Update Ldap Cache
            #
        
            self.ldap_cache.modify(dn.lower(), ldif)
        
            self.console(self.__tr("entry '%1' modified.").arg(a0))
            return True
        
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_modify_clicked(self):
        
        if self.lvLdap.currentItem() is None:
            self.console(self.__tr("select a entry."), self.CONSOLE_WARN)
            return True
        
        #
        # Modify current entry
        #
        
        if self.ldap_add_or_modify:
            attrsOld = {}
        
            for attribute, values in self.ldap_cache.get(self.ldap_current_dn().lower()).items():
                if attrsOld.get(attribute):
                   attrsOld[attribute].extend(values)
                else:
                   attrsOld[attribute] = values
        
            attrsNew = {}
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if attrsNew.get(Q2utf(item.text(0))):
                    attrsNew[Q2utf(item.text(0))].extend([Q2utf(item.text(1))])
                else:
                    attrsNew[Q2utf(item.text(0))] = [Q2utf(item.text(1))]
                item = item.nextSibling()
        
            if self.ldap_modify(self.ldap_current_dn(), attrsOld, attrsNew):
                self.ldap_dn_clicked()
        
        #
        # Add current entry
        #
        
        else:
            attrs = {}
            dnParent = self.ldap_current_dn()
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if item.isSelected():
                    if dnParent is None:
                        dn = u"%s=%s" % (Q2uni(item.text(0)), Q2uni(item.text(1)))
                    else:
                        dn = u"%s=%s,%s" % (Q2uni(item.text(0)), Q2uni(item.text(1)), dnParent)
                if attrs.get(Q2utf(item.text(0))):
                    attrs[Q2utf(item.text(0))].extend([Q2utf(item.text(1))])
                else:
                    attrs[Q2utf(item.text(0))] = [Q2utf(item.text(1))]
                item = item.nextSibling()
            try:
                if attrs.get('ref'):
                    refCheckList = attrs.get('ref')[0].split('/', 3)[3].split('?')[0].split(',')[0].split('=')
                    item = self.lvLdapAttr.firstChild()
                    refCheckBool = False
                    while item is not None:
                        if item.text(0).ascii() == refCheckList[0] and item.text(1).ascii() == re.sub("%20", " ", refCheckList[1]):
                            refCheckBool = True
                            dn = u"%s=%s,%s" % (Q2uni(item.text(0)), Q2uni(item.text(1)), dnParent)
                        item = item.nextSibling()
                    if not refCheckBool:
                        self.console(self.__tr("referral dn '%1' don't present in this entry.").arg("%s=%s" % (refCheckList[0], refCheckList[1])), self.CONSOLE_INFO)
                        return False
            except:
                self.console("invalid referral sintaxe", self.CONSOLE_WARN)
                return False
        
            try:
                self.ldap_add(dn, attrs)
                self.ldap_add_or_modify = True
                self.ldap_dn_clicked()
            except UnboundLocalError, e:
                self.console(self.__tr("select a attribute to be DN."), self.CONSOLE_WARN)
        
        

    def ldap_del_entry(self,a0):
        # a0=str:dn
        
        dn = a0
        
        try:
            l = self.ldap_connect()
            if 'ref' in self.ldap_cache.get(dn.lower()).keys():
                l.manage_dsa_it(True)
            l.delete_s(dn.encode('utf-8'))
            l.manage_dsa_it(False)
            self.ldap_cache.unset(dn.lower())
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        except KeyError, e:
            return True
        
        

    def ldap_remove(self,a0):
        
        dn = a0
        
        def __ldap_remove(dn):
            item = self.ldap_items.get(dn.lower())
            subitem = item.firstChild()
            while subitem is not None:
                __ldap_remove(u"%s,%s" % (Q2uni(subitem.text(0)), dn))
                subitem = subitem.nextSibling()
        
            if self.ldap_del_entry(dn):
                self.console(self.__tr("entry '%1' deleted.").arg(dn))
                return True
            else:
                self.console(self.__tr("can't delete entry '%1'.").arg(dn), self.CONSOLE_ERR)
                return False
        
        if __ldap_remove(dn):
            item = self.ldap_items.get(dn.lower())
            if item.parent() is None:
                self.korreio_module_clear("ldap")
            else:
                item.parent().takeItem(item)
                self.lvLdap.currentItem().setSelected(True)
        
        

    def ldap_remove_entry(self):
        
        dn =  self.ldap_current_dn()
        
        if dn is not None:
            ok = QMessageBox.information( None, self.__tr("Confirm!"), self.__tr("Confirm entry deletion:\n\n    - %1\n\n").arg(dn), self.__tr("&Yes"), self.__tr("&No"))
            if ok == 0:
                self.ldap_remove(dn)
                self.ldap_dn_clicked()
            else:
                self.console(self.__tr("entry '%1' deletion been aborted.").arg(dn), self.CONSOLE_INFO)
        
        

    def ldap_copy(self,a0,a1,a2):
        
        dnFrom = a0
        dnTo = a1
        rdnTo = a2
        
        attrs = self.ldap_cache.get(dnFrom.lower())
        if rdnTo is None:
            rdnTo = u"%s,%s" % (dnFrom.split(u",")[0], dnTo)
        else:
            rdnToList = rdnTo.split(u"=")
            rdnTo = u"%s,%s" % (rdnTo, dnTo)
            attrs[rdnToList[0].encode('utf-8')] = [rdnToList[1].encode('utf-8')]
        
        if self.ldap_add(rdnTo, attrs):
            item = self.ldap_items.get(dnFrom.lower()).firstChild()
            while item is not None:
                self.ldap_copy(u"%s,%s" % (Q2uni(item.text(0)), dnFrom), rdnTo, None)
                self.ldap_items.get(rdnTo.lower()).setOpen(False)
                item = item.nextSibling()
            return True
        else:
            return False
        
        

    def ldap_remove_attr(self):
        
        itemAttr = self.lvLdapAttr.currentItem()
        if itemAttr is None:
            return
        
        if self.cConfLdapSchemaDelAttr.isChecked() and itemAttr.text(0).ascii().lower() == 'objectclass':
            depends = []
        
            item=self.lvConfLdapSchema.firstChild().firstChild()
            while item is not None:
                if item.text(0).ascii().lower() == itemAttr.text(1).ascii().lower():
                    subitem=item.firstChild()
                    while subitem is not None:
                        if subitem.text(0).ascii().lower() != 'objectclass':
                            depends.append(subitem.text(0).ascii())
                        subitem=subitem.nextSibling()
                    break
                item=item.nextSibling()
        
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if item.text(0).ascii() in depends:
                    tmp=item
                    item=item.nextSibling()
                    self.lvLdapAttr.takeItem(tmp)
                else:
                    item=item.nextSibling()
        
        self.lvLdapAttr.takeItem(itemAttr)
        
        try:
            self.lvLdapAttr.currentItem().setSelected(True)
        except AttributeError, e:
            pass
        
        

    def ldap_rename_attr_value(self):
        
        if not self.lvLdap.currentItem().text(0).ascii() == "=".join([self.lvLdapAttr.currentItem().text(0).ascii(),self.lvLdapAttr.currentItem().text(1).ascii()]):
            self.lvLdapAttr.currentItem().setRenameEnabled(1,True)
            self.lvLdapAttr.currentItem().startRename(1)
        
        

    def ldap_add_attr(self):
        
        attr = self.cbLdapAttr.currentText().ascii()
        value = self.cbLdapValue.currentText().ascii()
        if not attr:
            return True
        
        attrs = [(attr,value)]
        
        if self.cConfLdapSchemaAddAttr.isChecked() and attr.lower() == 'objectclass':
            if not value:
                self.console(self.__tr("set objectClass name."), self.CONSOLE_INFO)
                self.cbLdapValue.setFocus()
                return True
            item = self.lvConfLdapSchema.firstChild().firstChild()
            while item is not None:
                subitem = item.firstChild()
                if item.text(0).ascii().lower() == value.lower():
                    while subitem is not None:
                        if subitem.text(1).ascii() is None:
                            newvalue = ""
                        else:
                            newvalue = subitem.text(1).ascii()
                        attrs.extend([(subitem.text(0).ascii(), newvalue)])
                        subitem = subitem.nextSibling()
                    break
                item = item.nextSibling()
        
        for attr, value in attrs:
            item = self.lvLdapAttr.firstChild()
            jump = False
            while item is not None:
                if item.text(0).ascii() == attr and (item.text(1).ascii() == value or value == ''):
                    jump = True
                    break
                item = item.nextSibling()
            if jump:
                continue
            item = QListViewItemColored(self.lvLdapAttr)
            item.setText(0, attr)
            item.setText(1, value)
        
        if not self.ldap_add_or_modify:
            self.console(self.__tr("selected attribute will be Distinguish Name."), self.CONSOLE_INFO)
        
        

    def ldap_edit_rdn(self):
        
        #
        # Save current dn name and start edition
        #
        
        if self.lvLdap.currentItem().parent() is not None:
            self.ldap_dn_rename = self.ldap_current_dn()
            self.lvLdap.currentItem().setRenameEnabled(0,True)
            self.lvLdap.currentItem().startRename(0)
        
        

    def ldap_rename_rdn(self):
        
        item = self.lvLdap.currentItem()
        ldap_dn_new = Q2uni(item.text(0))
        
        #
        # Verify change
        #
        
        if self.ldap_dn_rename.split(u",")[0].lower() == ldap_dn_new.lower():
            item.setText(0, self.ldap_dn_rename.split(u",")[0])
            return True
        
        #
        # If have children we need add entries and delete this
        #
        
        if item.childCount() > 0:
            item.setText(0, self.ldap_dn_rename.split(u",")[0])
            if self.ldap_copy(self.ldap_dn_rename, u",".join(self.ldap_dn_rename.split(u",")[1:]), ldap_dn_new):
                self.ldap_remove(self.ldap_dn_rename)
        else:
        
        #
        # If new dn attribute does not already existed, then delete old dn attribute
        #
        
            delete_dn_attribute = 1
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                searchDn = u"%s=%s" % (Q2uni(item.text(0)), Q2uni(item.text(1)))
                if searchDn.lower() == ldap_dn_new.lower():
                    delete_dn_attribute = 0
                    break
                item = item.nextSibling()
            if self.ldap_modify_rdn(self.ldap_dn_rename, ldap_dn_new, None, delete_dn_attribute):
                self.console(self.__tr("entry Distinguish Name '%1' changed.").arg(self.ldap_dn_rename))
            else:
                self.lvLdap.currentItem().setText(0, self.ldap_dn_rename.split(u",")[0])
                return False
        
        self.ldap_dn_clicked()
        return True
        
        

    def ldap_modify_rdn(self,a0,a1,a2,a3):
        # a0=str:ldap_dn_rename, a1=str:ldap_dn_new, a2=str:newParent or None, a3=delete_dn_attribute
        
        ldap_dn_rename = a0
        ldap_dn_new = a1
        newParent = a2
        delete_dn_attribute = a3
        
        try:
            l = self.ldap_connect()
        
        #
        # Change DN
        #
        
            l.rename_s(ldap_dn_rename.encode('utf-8'), ldap_dn_new.encode('utf-8'), newParent, delete_dn_attribute)
        
        #
        # Update Ldap Attrs Cache and Interface
        #
        
            dn = u"%s,%s" % (ldap_dn_new, u",".join(ldap_dn_rename.split(u",")[1:]))
            self.ldap_items.rename(ldap_dn_rename.lower(), dn.lower())
            self.ldap_cache.rename(ldap_dn_rename.lower(), dn.lower())
            if delete_dn_attribute == 1:
                self.ldap_cache.removeAttr(dn.lower(), ldap_dn_rename.split(u",")[0].encode('utf-8'))
                self.ldap_cache.addAttr(dn.lower(), ldap_dn_new.encode('utf-8'))
            return True
        
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_passwd(self):
        
        if not self.cbLdapUserPassword.isChecked() and not self.cbLdapSambaPassword.isChecked() and not self.cbLdapAstPassword.isChecked() and not self.cLdapSambaPasswordPwdMustChange.isChecked():
            self.console(self.__tr("select at least one option."), self.CONSOLE_WARN)
            return False
        
        if self.iLdapPasswd.text().ascii() != self.iLdapPasswd2.text().ascii():
            self.console(self.__tr("passwords don't match, type again."), self.CONSOLE_WARN)
            self.korreio_module_clear("ldap.form.password")
            return False
        
        #
        # Salt method
        #
        
        def __salt(mode):
            salt = ''
            if mode == 2:
                for i in [0,1]:
                    salt += choice(letters+digits)
                return salt
            elif mode == 16:
                for i in range(16):
                    salt += choice(letters+digits)
                return salt
            else:
                self.console(self.__tr("unsupported salt."), self.CONSOLE_ERR)
                raise "KORREIOError", "unsupported salt"
        
        #
        # Init variables
        #
        
        dn = self.ldap_current_dn()
        attrOld={}
        attrNew={}
        
        #
        # userPassword
        #
        
        if self.cbLdapUserPassword.isChecked():
            if self.ldap_cache.get(dn.lower()).get("userPassword"):
                attrOld["userPassword"] = 'None'
            hash = self.cbUserPassword.currentItem()
            password = Q2utf(self.iLdapPasswd.text())
            salt = __salt(16)
            if hash == 0:
                attrNew["userPassword"] = ["{SSHA}%s" % b2a_base64(sha.new(password + salt).digest() + salt).strip()]
            elif hash == 1:
                attrNew["userPassword"] = ["{SMD5}%s" % b2a_base64(md5.new(password + salt).digest() + salt).strip()]
            elif hash == 2:
                salt = __salt(2)
                attrNew["userPassword"] = ["{CRYPT}%s" % crypt.crypt(password, salt)]
            elif hash == 3:
                attrNew["userPassword"] = ["{SHA}%s" % b2a_base64(sha.new(password).digest()).strip()]
            elif hash == 4:
                attrNew["userPassword"] = ["{MD5}%s" % b2a_base64(md5.new(password).digest()).strip()]
            elif hash == 5:
                attrNew["userPassword"] = [password]
            else:
                self.console(self.__tr("unsupported hash."), self.CONSOLE_ERR)
                raise "KORREIOError", "unsupported hash"
        
        if self.cbLdapSambaPassword.isChecked():
        
            #
            # sambaNTPassword
            #
        
            if self.ldap_cache.get(dn.lower()).get("sambaNTPassword"):
                attrOld["sambaNTPassword"] = 'None'
            attrNew["sambaNTPassword"] = [smbpasswd.nthash(self.iLdapPasswd.text().ascii())]
        
            #
            # sambaLMPassword
            #
        
            if self.ldap_cache.get(dn.lower()).get("sambaLMPassword"):
                attrOld["sambaLMPassword"] = 'None'
            attrNew["sambaLMPassword"] = [smbpasswd.lmhash(self.iLdapPasswd.text().ascii())]
        
        #
        # sambaPwdMustChange
        #
        
        if self.cLdapSambaPasswordPwdMustChange.isChecked():
            if self.ldap_cache.get(dn.lower()).get("sambaPwdMustChange"):
                attrOld["sambaPwdMustChange"] = 'None'
            attrNew["sambaPwdMustChange"] = ["1"]
        
        #
        # astSecret
        #
        
        if self.cbLdapAstPassword.isChecked():
            if self.ldap_cache.get(dn.lower()).get("astSecret"):
                attrOld["astSecret"] = 'None'
            attrNew["astSecret"] = [self.iLdapPasswd.text().ascii()]
        
        #
        # Set Passwords
        #
        
        if self.ldap_modify(dn, attrOld, attrNew):
            self.iLdapPasswd.clear()
            self.iLdapPasswd2.clear()
            self.iLdapPasswd.setFocus()
        
        #
        # Show entry
        #
        
        self.ldap_dn_clicked()
        
        

    def ldap_samba_populate(self):
        
        dnPopulate = self.ldap_current_dn()
        
        domain = Q2uni(self.iLdapSMBdomain.text())
        if not domain:
            self.console(self.__tr("set netbios domain name."), self.CONSOLE_WARN)
            self.iLdapSMBdomain.setFocus()
            return False
        
        SID = self.iLdapSMBSID.text().ascii()
        if not SID:
            self.console(self.__tr("set netbios domain SID."), self.CONSOLE_WARN)
            self.iLdapSMBSID.setFocus()
            return False
        
        passwd = self.iLdapSMBpassword.text().ascii()
        if not passwd:
            self.console(self.__tr("set uid=root password."), self.CONSOLE_WARN)
            self.iLdapSMBpassword.setFocus()
            return False
        
        
        #
        # Units
        #
        
        units = []
        units.append("Users")
        units.append("Groups")
        units.append("Computers")
        units.append("Idmap")
        
        for unit in units:
            dn = u"ou=%s,%s" % (unicode(unit), dnPopulate)
            attrs = {}
            attrs['objectClass'] = ['organizationalUnit']
            attrs['ou'] = [unit]
            if not self.ldap_add(dn, attrs):
                self.console(self.__tr("can't add entry '%1'.").arg(dn), self.CONSOLE_ERR)
        
        #
        # Groups
        #
        
        groups = []
        groups.append(["2", "512", "Domain Admins", "Netbios Domain Administrators"])
        groups.append(["2", "513", "Domain Users", "Netbios Domain Users"])
        groups.append(["2", "514", "Domain Guests", "Netbios Domain Guests Users"])
        groups.append(["2", "515", "Domain Computers", "Netbios Domain Computers accounts"])
        groups.append(["5", "544", "Administrators", "Netbios Domain Members can fully administer the computer/sambaDomainName"])
        groups.append(["5", "548", "Account Operators", "Netbios Domain Users to manipulate users accounts"])
        groups.append(["5", "550", "Print Operators", "Netbios Domain Print Operators"])
        groups.append(["5", "551", "Backup Operators", "Netbios Domain Members can bypass file security to back up files"])
        groups.append(["5", "552", "Replicators", "Netbios Domain Supports file replication in a sambaDomainName"])
        
        for group in groups:
            dn = u"cn=%s,ou=Groups,%s" % (group[2], dnPopulate)
            attrs = {}
            attrs['objectClass'] = ['posixGroup', 'sambaGroupMapping']
            attrs['gidNumber'] = [group[1]]
            attrs['cn'] = [group[2]]
            attrs['displayName'] = [group[2]]
            if group[1] == '512':
                attrs['memberUid'] = ['root']
            attrs['description'] = [group[3]]
            attrs['sambaGroupType'] = [group[0]]
            if group[0] == "2":
                attrs['sambaSID'] = ["%s-%s" % (SID, group[1])]
            elif group[0] == "5":
                attrs['sambaSID'] = ["S-1-5-32-%s" % group[1]]
            if not self.ldap_add(dn, attrs):
                self.console(self.__tr("can't add entry '%1'.").arg(dn), self.CONSOLE_ERR)
        
        #
        # Users: Root
        #
        
        dn = u"uid=root,ou=Users,%s" % dnPopulate
        attrs = {}
        attrs['objectClass'] = ['inetOrgPerson', 'sambaSamAccount','posixAccount','shadowAccount']
        attrs['cn'] = ["Administrador"]
        attrs['sn'] = ["root"]
        attrs['uidNumber'] = ["0"]
        attrs['gidNumber'] = ["0"]
        attrs['uid'] = ["root"]
        attrs['homeDirectory'] = ["/root"]
        attrs['loginShell'] = ["/bin/false"]
        attrs['gecos'] = ["Netbios Domain Administrator"]
        attrs['sambaLogonTime'] = ["0"]
        attrs['sambaLogoffTime'] = ["2147483647"]
        attrs['sambaKickoffTime'] = ["2147483647"]
        attrs['sambaPwdMustChange'] = ["2147483647"]
        attrs['sambaPwdCanChange'] = ["0"]
        attrs['sambaHomeDrive'] = ["H:"]
        attrs['sambaHomePath'] = ["\\\\server\\root"]
        attrs['sambaProfilePath'] = ["\\\\server\\profiles\\root"]
        attrs['sambaSID'] = ["%s-500" % SID]
        attrs['sambaPrimaryGroupSID'] = ["%s-512" % SID]
        attrs['sambaNTPassword'] = [smbpasswd.nthash(passwd)]
        attrs['sambaLMPassword'] = [smbpasswd.lmhash(passwd)]
        attrs['sambaAcctFlags'] = ["[U          ]"]
        attrs['sambaPwdLastSet'] = ["1"]
        salt = ''
        for i in range(16):
            salt += choice(letters+digits)
        attrs["userPassword"] = ["{SSHA}%s" % b2a_base64(sha.new("%s%s" % (passwd, salt)).digest() + salt).strip()]
        
        if not self.ldap_add(dn, attrs):
            self.console(self.__tr("can't add entry '%1'.").arg(dn), self.CONSOLE_ERR)
        
        #
        # Users: Nobody
        #
        
        dn = u"uid=nobody,ou=Users,%s" % dnPopulate
        attrs = {}
        attrs['objectClass'] = ['inetOrgPerson', 'sambaSamAccount','posixAccount','shadowAccount']
        attrs['cn'] = ["nobody"]
        attrs['sn'] = ["nobody"]
        attrs['uidNumber'] = ["999"]
        attrs['gidNumber'] = ["514"]
        attrs['uid'] = ["nobody"]
        attrs['homeDirectory'] = ["/dev/null"]
        attrs['loginShell'] = ["/bin/false"]
        attrs['sambaLogonTime'] = ["0"]
        attrs['sambaLogoffTime'] = ["2147483647"]
        attrs['sambaKickoffTime'] = ["2147483647"]
        attrs['sambaPwdMustChange'] = ["2147483647"]
        attrs['sambaPwdCanChange'] = ["0"]
        attrs['sambaHomeDrive'] = ["H:"]
        attrs['sambaHomePath'] = ["\\\\server\\nonexistent"]
        attrs['sambaProfilePath'] = ["\\\\server\\profiles\\nonexistent"]
        attrs['sambaSID'] = ["%s-2998" % SID]
        attrs['sambaPrimaryGroupSID'] = ["%s-514" % SID]
        attrs['sambaNTPassword'] = ["NO PASSWORDXXXXXXXXXXXXXXXXXXXXX"]
        attrs['sambaLMPassword'] = ["NO PASSWORDXXXXXXXXXXXXXXXXXXXXX"]
        attrs['sambaAcctFlags'] = ["[NUD        ]"]
        attrs['sambaPwdLastSet'] = ["0"]
        if not self.ldap_add(dn, attrs):
            self.console(self.__tr("can't add entry '%1'.").arg(dn), self.CONSOLE_ERR)
        
        #
        # sambaDomain
        #
        
        # from: 0=m, 1=h, 2=d
        def time2seconds(value, type):
            valueInt=int(value)
            if type == 0:
                return "%i" % (valueInt * 60)
            elif type == 1:
                return "%i" % (valueInt * 60 * 60)
            elif type == 2:
                return "%i" % (valueInt * 24 * 60 * 60)
            else:
                raise "KORREIOError", "ERROR: unexpected time mode."
        
        def time2minutes(value, type):
            valueInt=int(value)
            if type == 0:
                return "%i" % (valueInt)
            elif type == 1:
                return "%i" % (valueInt * 60)
            elif type == 2:
                return "%i" % (valueInt * 24 * 60)
            else:
                raise "KORREIOError", "ERROR: unexpected time mode."
        
        dn = u"sambaDomainName=%s,%s" % (domain.upper(), dnPopulate)
        attrs = {}
        attrs['objectClass'] = ['sambaDomain', 'sambaUnixIdPool']
        attrs['sambaDomainName'] = [domain.upper().encode('utf-8')]
        attrs['sambaSID'] = [SID]
        attrs['uidNumber'] = [self.iLdapSMBuidNumber.text().ascii()]
        attrs['gidNumber'] = [self.iLdapSMBgidNumber.text().ascii()]
        attrs['sambaAlgorithmicRidBase'] = ["1000"]
        attrs['sambaNextUserRid'] = ["1000"]
        attrs['sambaNextRid'] = ["1000"]
        attrs['sambaMinPwdLength'] = [self.iLdapSMBminPwdLength.text().ascii()]
        attrs['sambaPwdHistoryLength'] = [self.iLdapSMBpwdHistLenght.text().ascii()]
        attrs['sambaMaxPwdAge'] = [time2seconds(self.iLdapSMBmaxPwdAge.text().ascii(), self.cbLdapSMBmaxPwdAge.currentItem())]
        attrs['sambaMinPwdAge'] = [time2seconds(self.iLdapSMBminPwdAge.text().ascii(), self.cbLdapSMBminPwdAge.currentItem())]
        attrs['sambaLockoutThreshold'] = [self.iLdapSMBlockout.text().ascii()]
        attrs['sambaLockoutDuration'] = [time2minutes(self.iLdapSMBlockoutDuration.text().ascii(), self.cbLdapSMBlockoutDuration.currentItem())]
        attrs['sambaLockoutObservationWindow'] = [time2minutes(self.iLdapSMBlockoutWindow.text().ascii(), self.cbLdapSMBlockoutWindow.currentItem())]
        attrs['sambaLogonToChgPwd'] = ["0"]
        attrs['sambaForceLogoff'] = ["-1"]
        attrs['sambaRefuseMachinePwdChange'] = ["0"]
        if not self.ldap_add(dn, attrs):
            self.console(self.__tr("can't add entry '%1'.").arg(dn), self.CONSOLE_ERR)
        
        self.lvLdap.currentItem().setOpen(True)
        
        

    def ldap_dhcp_populate(self):
        
        # from: 0=s, 1=m, 2=h, 3=d
        def __time2sec(value, mode):
            try:
                valueInt = int(value)
            except:
                return "0"
            if mode == 0:
                return value
            elif mode == 1:
                return "%i" % (valueInt * 60)
            elif mode == 2:
                return "%i" % (valueInt * 60 * 60)
            elif mode == 3:
                return "%i" % (valueInt * 24 * 60 * 60)
            else:
                raise "KORREIOError", "ERROR: unexpected time mode."
        
        serverName = Q2uni(self.iLdapDhcpName.text())
        if not serverName:
            self.console(self.__tr("set server name."), self.CONSOLE_WARN)
            self.iLdapDhcpName.setFocus()
            return False
        
        sharedName = Q2uni(self.cbLdapDhcpInterface.currentText())
        if not sharedName:
            self.console(self.__tr("set shared network name."), self.CONSOLE_WARN)
            self.cbLdapDhcpInterface.setFocus()
            return False
        
        networkAddress = Q2uni(self.iLdapDhcpNetwork.text())
        if not networkAddress:
            self.console(self.__tr("set network address."), self.CONSOLE_WARN)
            self.iLdapDhcpNetwork.setFocus()
            return False
        
        #
        # dhcpServer
        #
        
        dnPopulate = self.ldap_current_dn()
        dn = u"cn=%s,%s" % (serverName, dnPopulate)
        attrs = {}
        attrs['objectClass'] = ['dhcpServer']
        attrs['cn'] = [serverName.encode('utf-8')]
        attrs['dhcpServiceDN'] = ['cn=dhcpConfig,%s' % dn]
        
        if not self.ldap_add(dn, attrs):
            self.console(self.__tr("can't add entry '%1'.").arg(dn), self.CONSOLE_ERR)
        
        #
        # dhcpService
        #
        
        dnPopulate = self.ldap_current_dn()
        dn = u"cn=dhcpConfig,cn=%s,%s" % (serverName, dnPopulate)
        attrs = {}
        attrs['objectClass'] = ['dhcpService']
        attrs['cn'] = ['dhcpConfig']
        attrs['dhcpPrimaryDN'] = ["cn=%s,%s" % (serverName.encode('utf-8'), dnPopulate.encode('utf-8'))]
        attrs['dhcpStatements'] = ['ddns-update-style none', 'authoritative']
        if self.iLdapDhcpDefaultLeaseTime.text().ascii():
            attrs['dhcpStatements'].append('default-lease-time %s' % __time2sec(self.iLdapDhcpDefaultLeaseTime.text().ascii(), self.cbLdapDhcpDefaultLeaseTime.currentItem()))
        if self.iLdapDhcpMaxLeaseTime.text().ascii():
            attrs['dhcpStatements'].append('max-lease-time %s' % __time2sec(self.iLdapDhcpMaxLeaseTime.text().ascii(), self.cbLdapDhcpMaxLeaseTime.currentItem()))
        attrs['dhcpOption'] = []
        if self.iLdapDhcpDomainName.text().ascii():
            attrs['dhcpOption'].append('domain-name "%s"' % self.iLdapDhcpDomainName.text().ascii())
        if self.iLdapDhcpDNSservers.text().ascii():
            attrs['dhcpOption'].append('domain-name-servers %s' % self.iLdapDhcpDNSservers.text().ascii())
        if self.iLdapDhcpNetbiosServers.text().ascii():
            attrs['dhcpOption'].append('netbios-name-servers %s' % self.iLdapDhcpNetbiosServers.text().ascii())
        if attrs['dhcpOption']:
            attrs['objectClass'].append('dhcpOptions')
        else:
            del attrs['dhcpOption']
        
        if not self.ldap_add(dn, attrs):
            self.console(self.__tr("can't add entry '%1'.").arg(dn), self.CONSOLE_ERR)
        
        #
        # dhcpSharedNetwork
        #
        
        dn = "cn=%s,cn=dhcpConfig,cn=%s,%s" % (sharedName, serverName, dnPopulate)
        attrs = {}
        attrs['objectClass'] = ['dhcpSharedNetwork']
        attrs['cn'] = [sharedName.encode('utf-8')]
        
        if not self.ldap_add(dn, attrs):
            self.console(self.__tr("can't add entry '%1'.").arg(dn), self.CONSOLE_ERR)
        
        #
        # dhcpSubnet
        #
        
        dn = u"cn=%s,cn=%s,cn=dhcpConfig,cn=%s,%s" % (networkAddress, sharedName, serverName, dnPopulate)
        attrs = {}
        attrs['objectClass'] = ['dhcpSubnet']
        attrs['cn'] = [networkAddress.encode('utf-8')]
        if self.iLdapDhcpGateway.text().ascii():
            attrs['objectClass'].append('dhcpOptions')
            attrs['dhcpOption'] = ['routers %s' % self.iLdapDhcpGateway.text().ascii()]
        if self.iLdapDhcpRange.text().ascii():
            attrs['dhcpRange'] = [self.iLdapDhcpRange.text().ascii()]
        attrs['dhcpNetMask'] = [self.cbLdapDhcpNetmask.currentText().ascii()]
        
        if not self.ldap_add(dn, attrs):
            self.console(self.__tr("can't add entry '%1'.").arg(dn), self.CONSOLE_ERR)
        
        

    def ldap_menu(self,a0,a1):
        
        self.korreio_update_servers_menu()
        
        if a0 is None:
            self.lvLdapMenu.setItemEnabled(10, False)
            self.lvLdapMenu.setItemEnabled(20, False)
            self.lvLdapMenu.setItemEnabled(21, False)
            self.lvLdapMenu.setItemEnabled(22, False)
            self.lvLdapMenu.setItemEnabled(23, False)
            self.lvLdapMenu.setItemEnabled(24, False)
            self.lvLdapMenu.setItemEnabled(30, False)
            self.lvLdapMenu.setItemEnabled(40, False)
            self.lvLdapMenu.setItemEnabled(41, False)
        else:
            self.lvLdapMenu.setItemEnabled(10, True)
            if self.ldap_cache.get(self.ldap_current_dn().lower()):
                self.lvLdapMenu.setItemEnabled(20, True)
                self.lvLdapMenu.setItemEnabled(21, True)
                self.lvLdapMenu.setItemEnabled(22, True)
                self.lvLdapMenu.setItemEnabled(24, True)
            else:
                self.lvLdapMenu.setItemEnabled(20, False)
                self.lvLdapMenu.setItemEnabled(21, False)
                self.lvLdapMenu.setItemEnabled(22, False)
                self.lvLdapMenu.setItemEnabled(24, False)
            if self.lvLdapMenu.clipBoard == "None" or not self.ldap_cache.get(self.lvLdapMenu.clipBoard.lower()):
                self.lvLdapMenu.setItemEnabled(23, False)
            else:
                self.lvLdapMenu.setItemEnabled(23, True)
            self.lvLdapMenu.setItemEnabled(30, True)
            self.lvLdapMenu.setItemEnabled(40, True)
            self.lvLdapMenu.setItemEnabled(41, True)
        
        self.lvLdapMenu.popup(a1)
        
        

    def ldap_menu_attr(self,a0,a1):
        
        self.lvLdapMenuAttr = QPopupMenu(self)
        self.lvLdapMenuAttr.insertItem(self.__tr('Delete attribute'), 54)
        if self.cConfLdapSchemaAddAttr.isChecked():
            self.lvLdapMenuAttr.insertItem(self.__tr('Disable LDAP Auxiliary on Add'), 50)
        else:
            self.lvLdapMenuAttr.insertItem(self.__tr('Enable LDAP Auxiliary on Add'), 51)
        if self.cConfLdapSchemaDelAttr.isChecked():
            self.lvLdapMenuAttr.insertItem(self.__tr('Disable LDAP Auxiliary on Delete'), 52)
        else:
            self.lvLdapMenuAttr.insertItem(self.__tr('Enable LDAP Auxiliary on Delete'), 53)
        
        self.connect(self.lvLdapMenuAttr, SIGNAL('activated(int)'), self.ldap_menu_clicked)
        
        self.lvLdapMenuAttr.popup(a1)
        
        

    def ldap_menu_clicked(self,a0):
        # a0=int:menuItem
        
        menuItem = a0
        dn = self.ldap_current_dn()
        
        if menuItem == 11:
            #
            # Add new entry
            #
            self.ldap_add_or_modify = False
            self.wsLdap.raiseWidget(0)
            self.lvLdapAttr.clear()
            self.cbLdapAttr.setFocus()
            self.console(self.__tr("the entry will be added to '%1'.").arg(dn), self.CONSOLE_INFO)
        
        elif menuItem == 12:
            #
            # Add new User Wizard
            #
            self.wsLdap.raiseWidget(2)
            self.korreio_module_clear("ldap.form")
            self.console(self.__tr("the entry will be added to '%1'.").arg(dn), self.CONSOLE_INFO)
        
        elif menuItem == 13:
            #
            # Add new Group Wizard
            #
            self.wsLdap.raiseWidget(7)
            self.korreio_module_clear("ldap.form.group")
            self.console(self.__tr("the entry will be added to '%1'.").arg(dn), self.CONSOLE_INFO)
        
        elif menuItem == 14:
            #
            # Add new Organization[alUnit] Wizard
            #
            self.wsLdap.raiseWidget(3)
            self.korreio_module_clear("ldap.form.unit")
            self.console(self.__tr("the entry will be added to '%1'.").arg(dn), self.CONSOLE_INFO)
        
        elif menuItem == 15:
            #
            # Add new DHCP Wizard
            #
            self.wsLdap.raiseWidget(1)
            self.korreio_module_clear("ldap.form.dhcp")
            self.console(self.__tr("the entry will be added to '%1'.").arg(dn), self.CONSOLE_INFO)
        
        elif menuItem == 20:
            #
            # Turn QListViewItem editable
            #
            self.ldap_edit_rdn()
        
        elif menuItem == 21 or menuItem == 22:
            #
            # Copy or Cut and store operation
            #
            self.lvLdapMenu.clipBoardMode = menuItem
            self.lvLdapMenu.clipBoard = dn
        
        elif menuItem == 23:
            #
            # Paste and verify operation
            #
            if re.search(self.lvLdapMenu.clipBoard, dn):
                self.console(self.__tr("invalid request. Operation can't be done."), self.CONSOLE_WARN)
            else:
                if self.ldap_copy(self.lvLdapMenu.clipBoard, dn, None):
                    if self.lvLdapMenu.clipBoardMode == 22:
                        self.ldap_remove(self.lvLdapMenu.clipBoard)
                        self.lvLdapMenu.clipBoard = "None"
        
        elif menuItem == 24:
            #
            # Proceed entry deletion
            #
            self.ldap_remove_entry()    
        
        elif menuItem == 31:
            #
            # Set password
            #
            self.wsLdap.raiseWidget(4)
            self.korreio_module_clear("ldap.form.password")
        
            if "smbpasswd" not in self.module_failed:
                if "sambaSamAccount" in self.ldap_cache.get(dn.lower()).get("objectClass"):
                    self.cbLdapSambaPassword.setEnabled(True)
                    self.cbLdapSambaPassword.setChecked(True)
                    self.cLdapSambaPasswordPwdMustChange.setEnabled(True)
                    self.cLdapSambaPasswordPwdMustChange.setChecked(self.cConfLdapsambaPwdMustChange.isChecked())
                else:
                    self.cbLdapSambaPassword.setEnabled(False)
                    self.cbLdapSambaPassword.setChecked(False)
                    self.cLdapSambaPasswordPwdMustChange.setEnabled(False)
                    self.cLdapSambaPasswordPwdMustChange.setChecked(False)
        
            if "astSipGeneric" in self.ldap_cache.get(dn.lower()).get("objectClass"):
                self.cbLdapAstPassword.setEnabled(True)
                self.cbLdapAstPassword.setChecked(True)
            else:
                self.cbLdapAstPassword.setEnabled(False)
                self.cbLdapAstPassword.setChecked(False)
        
        
            self.console(self.__tr("selected entry to password change is '%1'.").arg(dn), self.CONSOLE_INFO)
        
        elif menuItem == 32:
            #
            # Samba populate
            #
            self.wsLdap.raiseWidget(5)
            self.korreio_module_clear("ldap.smb.populate")
            self.console(self.__tr("selected entry to populate is '%1'.").arg(dn), self.CONSOLE_INFO)
        
        elif menuItem == 33:
            #
            # DHCP populate
            #
            self.wsLdap.raiseWidget(6)
            self.korreio_module_clear("ldap.dhcp.populate")
            self.console(self.__tr("selected entry to populate is '%1'.").arg(dn), self.CONSOLE_INFO)
        
        elif menuItem == 34:
            #
            # Change BaseDN
            #
            self.cbLdapBaseDN.setCurrentText(dn)
            self.ldap_search()
        
        elif menuItem == 35:
            #
            # Set origin BaseDN
            #
            conn = self.iLdapConnection.text().ascii()
            i=0
            while self.confDict.get("ldap%s.name" % i):
                if self.confDict.get("ldap%s.name" % i) == conn:
                    self.cbLdapBaseDN.setCurrentText(self.confDict.get("ldap%s.basedn" % i))
                    self.ldap_search()
                    break
                i+=1
        
        elif menuItem == 50:
            self.cConfLdapSchemaAddAttr.setChecked(False)
        
        elif menuItem == 51:
            self.cConfLdapSchemaAddAttr.setChecked(True)
        
        elif menuItem == 52:
            self.cConfLdapSchemaDelAttr.setChecked(False)
        
        elif menuItem == 53:
            self.cConfLdapSchemaDelAttr.setChecked(True)
        
        elif menuItem == 54:
            self.ldap_remove_attr()
        
        

    def ssh_connect(self):
        
        #
        # Verify SSH connection cache
        #
        
        try:
            if self.ssh.isalive():
                if self.inet_cache.get("ssh.host") == self.iSshHost.text().ascii() and self.inet_cache.get("ssh.port") == self.iSshPort.text().ascii() and self.inet_cache.get("ssh.user") == self.iSshUser.text().ascii() and self.inet_cache.get("ssh.pass") == self.iSshPass.text().ascii():
                    return self.ssh
        except:
            pass
        
        #
        # Connect to SSH
        #
        
        try:
            self.ssh = pxssh.pxssh()
            if not self.ssh.login("-p%s %s" % (self.iSshPort.text().ascii(), self.iSshHost.text().ascii()), self.iSshUser.text().ascii(), self.iSshPass.text().ascii(), login_timeout=20):
                raise pexpect.EOF, self.ssh
        except pexpect.EOF, t:
            self.parse_exception("pexpect.EOF", t)
            del self.ssh
            return None
        
        #
        # Save current LDAP connection information
        #
        
        self.inet_cache["ssh.host"] = self.iSshHost.text().ascii()
        self.inet_cache["ssh.port"] = self.iSshPort.text().ascii()
        self.inet_cache["ssh.user"] = self.iSshUser.text().ascii()
        self.inet_cache["ssh.pass"] = self.iSshPass.text().ascii()
        
        server = "ssh://%s@%s:%s" % (self.iSshUser.text().ascii(), self.iSshHost.text().ascii(), self.iSshPort.text().ascii())
        self.console(self.__tr("%1 connected.").arg(server))
        return self.ssh
        
        

    def ssh_open(self,a0):
        
        if self.cbSSHsudo.currentItem() == 0:
            cmd = a0
        else:
            cmd = "sudo %s" % a0
        
        result = []
        
        s = self.ssh_connect()
        if s is None:
            return None
        
        self.console(self.__tr("running remote request: %1.").arg(cmd), self.CONSOLE_INFO, False)
        try:
            s.sendline(cmd)
            s.prompt()
            for line in s.before.split("\n")[1:-1]:
                line = re.sub("\r","",line)
                result.append(line)
            return result
        except pexpect.EOF, t:
            self.parse_exception("pexpect.EOF", t)
        except pexpect.TIMEOUT, t:
            self.parse_exception("pexpect.TIMEOUT", t)
        
        

    def ssh_exec(self,a0):
        
        if self.cbSSHsudo.currentItem() == 0:
            cmd = a0
        else:
            cmd = "sudo %s" % a0
        
        s = self.ssh_connect()
        if s is None:
            return False
        
        s.sendline ("%s > /dev/null 2>&1 && echo OK" % cmd)
        s.prompt()
        if re.search("\nOK", s.before):
            self.console(self.__tr("running remote request: %1.").arg(cmd), self.CONSOLE_OK, False)
            return True
        else:
            self.console(self.__tr("running remote request: %1.").arg(cmd), self.CONSOLE_ERR)
            return False
        
        

    def scp_exec(self,a0):
        
        try:
            self.console(self.__tr("saving file: %1").arg(a0), self.CONSOLE_ERR)
            child = pexpect.spawn('scp -P%s /tmp/korreio.tmp %s@%s:"%s"' % (self.iSshPort.text().ascii(), self.iSshUser.text().ascii(), self.iSshHost.text().ascii(), a0))
            i = child.expect(['assword','want to continue connecting'], timeout=5)
            if i==0:
                child.sendline(self.iSshPass.text().ascii())
            elif i==1:
                child.sendline('yes')
                child.expect('assword', timeout=2)
                child.sendline(self.iSshPass.text().ascii())
            print_cmd=[]
            for line in child:
                print_cmd.append(line)
            child.kill(0)
        except pexpect.EOF, t:
            self.parse_exception("pexpect.EOF", t)
        except pexpect.TIMEOUT, t:
            self.parse_exception("pexpect.TIMEOUT", t)
        
        

    def services_file_open(self):
        
        if not self.cbServicesFileOpen.currentText().ascii():
            self.console(self.__tr("set file name."), self.CONSOLE_INFO)
            self.cbServicesFileOpen.setFocus()
            return True
        
        contentList = self.ssh_open("cat %s" % self.cbServicesFileOpen.currentText().ascii())
        
        if contentList is None:
            return False
        
        content = "\n".join(contentList)
        
        if re.search("^cat: ", content):
            self.console(self.__tr("file '%1' not found.").arg(self.cbServicesFileOpen.currentText().ascii()), self.CONSOLE_ERR)
            return True
        
        self.teServicesFileOpen.setText(content)
        
        

    def services_file_save(self):
        
        if self.teServicesFileOpen.length () == 0:
            self.ssh_exec("rm -f %s" % self.cbServicesFileOpen.currentText().ascii())
            return True
        
        # pexpect dont handle tab correctly.
        self.ssh_open("cat <<< \"%s\" | sed -e \'s/#TAB#/\\t/g\' > %s" % (re.sub("\t", "#TAB#", self.teServicesFileOpen.text().ascii()), self.cbServicesFileOpen.currentText().ascii()))
        
        

    def services_postconf(self):
        
        if self.rbServicesPostconfN.isChecked():
            cmd = "postconf -n"
        elif self.rbServicesPostconfAll.isChecked():
            cmd = "postconf"
        if self.rbServicesPostconfD.isChecked():
            cmd = "postconf -d"
        
        cmd = self.ssh_open(cmd)
        
        if cmd is None:
            return False
        
        self.postconf = {}
        lastOpt = self.cbServicesPostconf.currentText().ascii()
        self.cbServicesPostconf.clear()
        i = 0
        for config in cmd:
            if re.search("=",config):
                configlist = config.strip().split("=")
                configlist[0]=configlist[0].strip(" ")
                self.postconf[configlist[0]] = configlist[1]
                self.cbServicesPostconf.insertItem(configlist[0])
                if configlist[0] == lastOpt:
                    lastItem = i
                i += 1
        try:
            self.cbServicesPostconf.setCurrentItem(lastItem)
        except UnboundLocalError, e:
            pass
        self.services_postconf_changed()
        
        

    def services_postconf_changed(self):
        
        value = self.postconf.get(self.cbServicesPostconf.currentText().ascii())
        value = re.sub("( )+"," ",value)
        value = re.sub(", ",",",value)
        value = re.sub(",",",\n",value)
        value = re.sub("^ ","",value)
        self.teServicesPostconf.setText(value)
        
        

    def services_postconf_save(self):
        
        value = re.sub(",", ", ", self.teServicesPostconf.text().ascii())
        value = re.sub(" +", " ",value)
        value = re.sub("\n","",value)
        value = re.sub("\r","",value)
        option = self.cbServicesPostconf.currentText().ascii()
        
        if self.ssh_exec("postconf -e %s=%s" % (option, re.sub(" ", "\ ", value))):
            self.console(self.__tr("option '%1' is set.").arg(option))
            self.postconf[option] = value
        else:
            self.console(self.__tr("can't set option '%1'.").arg(option), self.CONSOLE_ERR)
        
        

    def services_postmap(self):
        
        file = self.cbServicesFileOpen.currentText().ascii()
        if self.ssh_exec("postmap %s" % file):
            self.console(self.__tr("hash '%1.db' created.").arg(file))
        else:
            self.console(self.__tr("can't create hash '%1.db'.").arg(file), self.CONSOLE_ERR)
        
        

    def services_status(self):
        
        service = self.cbServiceService.currentText().ascii()
        status = self.cbServiceStatus.currentText().ascii()
        log = self.ssh_open("/etc/init.d/%s %s" % (service, status))
        
        if log is None:
            return False
        
        self.teServiceStatus.setText("\n".join(log))
        
        

    def services_change_widgetstack(self):
        
        item = self.lvServices.currentItem()
        
        if  item.text(1).ascii() == "1":
            self.wsServices.raiseWidget(0)
        elif item.text(1).ascii() == "2":
           self.wsServices.raiseWidget(2)
        elif item.text(1).ascii() == "3.1":
            self.wsServices.raiseWidget(1)
        
        

    def services_menu(self,a0,a1):
        # a0: item, a1: pos-xy
        
        self.korreio_update_servers_menu()
        self.lvServicesMenu.popup(a1)
        
        

    def sieve_search(self):
        
        self.korreio_module_clear("sieve")
        
        imap = self.imap_connect()
        if imap is None:
            return False
        
        for user in imap.lm("user%s%s%%" % (imap.SEP, self.iSieveSearch.text().ascii())):
            user = user.split(imap.SEP)[1]
            item = QListViewItem(self.lvSieve)
            item.setText(0, user)
            if self.cSieveScript.isChecked():
                try:
                    s = self.sieve_connect(user)
                    ok, scripts = s.listscripts()
                    s.logout()
                    if ok == 'OK':
                        item.setText(1, "   (%s)" % len(scripts))
                        for script, active in scripts:
                            if active:
                                item.setText(2, script)
                                break
                except:
                    pass
        

    def sieve_connect(self,a0):
        
        admin = self.iCyrusUser.text().ascii().split("@")
        if admin[0] != self.iCyrusUser.text().ascii():
            user = "%s@%s" % (a0, admin[1])
        else:
            user = a0
        
        server = "sieve://%s:%s/%s" % (self.iCyrusHost.text().ascii(), self.iCyrusSievePort.text().ascii(), user)
        
        s = sievelib.MANAGESIEVE(self.iCyrusHost.text().ascii(),int(self.iCyrusSievePort.text().ascii()))
        if s.alive:
            if s.login('PLAIN',user,self.iCyrusPass.text().ascii(),self.iCyrusUser.text().ascii()):
                self.console(self.__tr("%1 connected.").arg(server))
                return s
            else:
                self.console(self.__tr("%1 disconnected. (wrong user or password)").arg(server), self.CONSOLE_ERR)
        else:
            self.console(self.__tr("%1 disconnected. (connection refused)").arg(server), self.CONSOLE_ERR)
        
        return False
        
        

    def sieve_user_clicked(self):
        
        self.teSieveScript.clear()
        self.cbSieveScript.clear()
        
        item = self.lvSieve.currentItem()
        if item is None:
            return True
        
        try:
            s = self.sieve_connect(item.text(0).ascii())
            ok, scripts = s.listscripts()
            s.logout()
        except:
            return True
        
        if ok == 'OK':
            i = 0
            for script, active in scripts:
                self.cbSieveScript.insertItem(script)
                if active:
                    self.cbSieveScript.setCurrentItem(i)
                i += 1
        
        if self.cbSieveScript.count() > 0:
            self.sieve_get_script()
        
        

    def sieve_get_script(self):
        
        item = self.lvSieve.currentItem()
        
        if item is None:
            return True
        
        s = self.sieve_connect(item.text(0).ascii())
        ok, script = s.getscript(self.cbSieveScript.currentText().ascii())
        s.logout()
        
        self.teSieveScript.clear()
        if ok == 'OK':
            self.teSieveScript.setText(script)
        
        

    def sieve_set_script(self):
        
        if not self.cbSieveScript.currentText().ascii():
            self.console(self.__tr("set sieve script name."), self.CONSOLE_WARN)
            return True
        
        item = self.lvSieve.firstChild()
        if item is None:
            self.console(self.__tr("select user for set sieve script."), self.CONSOLE_WARN)
            return True
        
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                status = s.putscript(self.cbSieveScript.currentText().ascii(), self.teSieveScript.text().ascii().replace("#USER#", item.text(0).ascii()))
                if status == 'OK':
                    item.setText(2, self.cbSieveScript.currentText().ascii())
                    s.setactive(self.cbSieveScript.currentText().ascii())
                s.logout()
            item = item.nextSibling()
        
        self.sieve_get_script()
        
        

    def sieve_unset_script(self):
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                s.setactive()
                s.logout()
                item.setText(2, "")
            item = item.nextSibling()
        
        

    def sieve_del_script(self):
        
        if not self.cbSieveScript.currentText().ascii():
            self.console(self.__tr("set sieve script name."), self.CONSOLE_WARN)
            return True
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                if s.deletescript(self.cbSieveScript.currentText().ascii()) == 'OK':
                    if self.cbSieveScript.currentText().ascii() == item.text(2).ascii():
                        item.setText(2, "")
                s.logout()
            item = item.nextSibling()
        
        self.sieve_get_script()
        
        

    def sieve_template_show(self,a0):
        # a0=QListBoxItem:templateName
        
        templateName = a0
        if templateName is None:
            return True
        
        ssList = self.sieve_scripts.get(Q2uni(templateName.text()))
        if not ssList:
            self.console(self.__tr("Sieve script not available: %1 (Probably a bug).").arg("%s" % templateName.text().ascii()), self.CONSOLE_WARN)
            return False
        
        self.cbSieveScript.setCurrentText(ssList[1])
        
        #
        # %(sep)
        #
        
        try:
            sep = self.m.SEP
        except AttributeError, e:
            sep = "/"
        
        #
        # %(Domain)
        #
        
        if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
            domain = "example.com"
        else:
            domain = self.iCyrusUser.text().ascii().split("@")[1]
        
        #
        # Replace
        #
        
        script = ssList[2].replace('%(sep)', sep).replace('%(domain)', domain)
        
        if re.search("#USER#", script):
            self.console(self.__tr("'#USER#' macro will be replaced properly."), self.CONSOLE_INFO)
        
        self.teSieveScript.setText(script)
        
        

    def sieve_template_load(self):
        
        #
        # Load Sieve Scripts
        #
        
        self.lbSieveScripts.clear()
        
        #
        # Load Dist Sieve Scripts
        #
        
        try:
            sievePath = self.korreioConfigDict.get("path.sieveDir")
            tmpSieveTemplates = os.listdir(sievePath)
            sieveTemplates = []
            for template in tmpSieveTemplates:
                sieveTemplates.append("%s/%s" % (sievePath, template))
            del tmpSieveTemplates
        except Exception, e:
            self.console(self.__tr("can't read sieve templates directory (%1).").arg(utf2uni(str(e))), self.CONSOLE_ERR)
            print "ERROR: can't read sieve templates (%s)." % e
            return False
        
        #
        # Load User Sieve Scripts
        #
        
        try:
            sieveUserTemplates = os.listdir(os.path.expanduser("~/.korreio/sieve"))
            for template in sieveUserTemplates:
                sieveTemplates.append("%s/%s" % (os.path.expanduser("~/.korreio/sieve"), template))
        except Exception, e:
            self.console(self.__tr("can't read user sieve templates directory (%1).").arg(utf2uni(str(e))), self.CONSOLE_WARN)
        
        re_kstFile = re.compile(r'^\[General\]\nfile name ?= ?(.*?)\ndisplay name ?= ?(.*?)\n(.*\n)*\n\[SieveScript\]\n((.*\n)*)$')
        
        sieveTemplates.sort()
        for templateFile in sieveTemplates:
            try:
                f = open(templateFile, "r")
                kstFile = f.read()
                f.close()
            except Exception, e:
                self.console(self.__tr("can't read sieve template: %1 (%2).").arg(utf2uni(templateFile)).arg(utf2uni(str(e))), self.CONSOLE_ERR)
                continue
        
            match = re_kstFile.match(kstFile)
            if match:
                displayName = utf2uni(self.__tr(match.group(2)))
                self.sieve_scripts[displayName] = []
                self.sieve_scripts[displayName].extend([templateFile, match.group(1), match.group(4)])
                self.lbSieveScripts.insertItem(displayName)
            else:
                self.console(self.__tr("invalid sintax for kstFile: %1.").arg(utf2uni(templateFile)), self.CONSOLE_ERR)
        
        #
        # pylupdate forget for default sieve scripts
        #
        
        nullList = []
        nullList.append(self.__tr("Forward"))
        nullList.append(self.__tr("Forward and save message"))
        nullList.append(self.__tr("Select folder by sender"))
        nullList.append(self.__tr("Select folder by senders"))
        nullList.append(self.__tr("Select folder if Spam"))
        nullList.append(self.__tr("Discard Spam"))
        nullList.append(self.__tr("Vacation"))
        nullList.append(self.__tr("Vacation if not Spam"))
        del nullList
        
        

    def sieve_menu(self,a0,a1):
        # a0: item, a1: pos-xy
        
        self.korreio_update_servers_menu()
        self.lvSieveMenu.popup(a1)
        
        

    def sieve_menu_template(self,a0,a1):
        # a0: item, a1: pos-xy
        
        item = a0
        
        if item is None:
            self.lvSieveTemplateMenu.setItemEnabled(11, False)
            self.lvSieveTemplateMenu.setItemEnabled(12, False)
            self.lvSieveTemplateMenu.setItemEnabled(13, False)
            self.lvSieveTemplateMenu.setItemEnabled(14, False)
        else:
            ssList = self.sieve_scripts.get(item.text().ascii())
            try:
                f = open(ssList[0], "a")
                f.close()
                self.lvSieveTemplateMenu.setItemEnabled(11, True)
                self.lvSieveTemplateMenu.setItemEnabled(12, True)
                self.lvSieveTemplateMenu.setItemEnabled(13, True)
                self.lvSieveTemplateMenu.setItemEnabled(14, True)
            except:
                self.lvSieveTemplateMenu.setItemEnabled(11, False)
                self.lvSieveTemplateMenu.setItemEnabled(12, True)
                self.lvSieveTemplateMenu.setItemEnabled(13, False)
                self.lvSieveTemplateMenu.setItemEnabled(14, False)
        
        self.lvSieveTemplateMenu.popup(a1)
        
        

    def sieve_menu_clicked(self,a0):
        # a0=QListViewMenu:menuItem
        
        menuItem = a0
        
        if menuItem == 0:
            #
            # Select all listed users
            #
        
            self.lvSieve.selectAll(True)
        
        elif menuItem == 10:
            #
            # New template
            #
        
            quota, msg = QInputDialog.getInteger(self.__tr("Quota"), self.__tr("Set quota limit (Kbytes):"), dflquota, 0, 2147483647, 512)
        
            ssList = self.sieve_scripts.get(self.lbSieveScripts.currentText().ascii())
            print ssList
        
        elif menuItem == 11:
            #
            # Save current template
            #
        
            pass
        
        elif menuItem == 12:
            #
            # Save as new current template
            #
        
            pass
        elif menuItem == 13:
            #
            # Rename current template
            #
        
            ssList = self.sieve_scripts.get(self.lbSieveScripts.currentText().ascii())
            print ssList
        elif menuItem == 14:
            #
            # Delete current template
            #
        
            ssList = self.sieve_scripts.get(self.lbSieveScripts.currentText().ascii())
            print ssList
        
        

    def queue_load(self):
        
        re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)\s+(\d+)\s([A-Z][a-z][a-z])\s([A-Z][a-z][a-z])\s+(\d+)\s(\d\d:\d\d:\d\d)\s+(.*)')
        re_rcpt  = re.compile(r'\s+(.*@.*)\b')
        re_log  = re.compile(r'(\s+)?\(.*\)')
        
        oldItem = self.lvQueue.currentItem()
        if oldItem is not None:
            while oldItem.parent() is not None:
                oldItem = oldItem.parent()
            oldFrom = oldItem.text(0).ascii()
        else:
            oldFrom = None
        
        self.korreio_module_clear("ssh.queue")
        
        itemFrom = {}
        itemQueueID = {}
        self.itemLog = {}
        
        queueList = self.ssh_open("postqueue -p")
        if queueList is None:
            return False
        
        if re.search("command not found", queueList[0]):
            self.console(self.__tr("command not found: %1.").arg("postqueue"), self.CONSOLE_ERR)
            return False
        
        for line in queueList:
            match = re_queueid.match(line)
            if match is not None:
                tmp = ""
                self.itemLog[match.group(1)] = "%s %s %s %s" % (match.group(3), match.group(4), match.group(5), match.group(6))
                #print "regexp: %s %s %s %s %s %s %s" % (match.group(1), match.group(2), match.group(3), match.group(4), match.group(5), match.group(6), match.group(7))
                mailFrom = match.group(7)
                if not itemFrom.get(mailFrom):
                    itemFrom[mailFrom] = QListViewItem(self.lvQueue)
                    itemFrom[mailFrom].setText(0,match.group(7))
                    if match.group(7) == oldFrom:
                        self.lvQueue.setCurrentItem(itemFrom[mailFrom])
                        itemFrom[mailFrom].setSelected(True)
                        itemFrom[mailFrom].setOpen(True)
                queueid = match.group(1)
                itemQueueID[queueid] = QListViewItem(itemFrom[mailFrom])
                itemQueueID[queueid].setText(0,"%s - %s Kb" % (queueid, int(match.group(2)) / 1024) )
                itemQueueID[queueid].setOpen(True)
                continue
            match = re_log.match(line)
            if match is not None:
                tmp = line
                continue
            match = re_rcpt.match(line)
            if match is not None:
                try:
                    self.itemLog["%s:%s" % ( queueid, match.group(1) )] = tmp
                except:
                    pass
                tmp = ""
                itemRcpt = QListViewItem(itemQueueID[queueid])
                itemRcpt.setText(0,match.group(1))
        
        if oldFrom is None:
            item = self.lvQueue.firstChild()
            if item is not None:
                self.lvQueue.setCurrentItem(item)
                item.setSelected(True)
        
        item = self.lvQueue.firstChild()
        total = [0, 0]
        while item is not None:
            count = item.childCount()
            subcount = 0
            if count > 0:
                subitem = item.firstChild()
                while subitem is not None:
                    subcount = subcount + subitem.childCount()
                    subitem.setText(1, "%s" % subitem.childCount())
                    subitem = subitem.nextSibling()
            item.setText(1, "%s/%s" % (count, subcount))
            item = item.nextSibling()
            total[0] += count
            total[1] += subcount
        
        self.tlQueueMsgs.setText("%s/%s" % (total[0], total[1]))
        self.lvQueue.ensureItemVisible(self.lvQueue.currentItem())
        self.queue_get_message()
        
        

    def queue_get_message(self):
        
        item = self.lvQueue.currentItem()
        
        if item is None:
            return True
        
        if item.parent() is None:
            size = 0
            subitem = item.firstChild()
            while subitem is not None:
                queueid = subitem.text(0).ascii()
                re_queueid  = re.compile(r'\b[A-Z0-9]+\*?\!? - (\d+) Kb')
                match = re_queueid.match(queueid)
                if match is not None:
                    size += int(match.group(1))
                subitem.text(0).ascii()
                subitem = subitem.nextSibling()
            self.iQueueMessage.setText(self.__tr("*** TOTAL SIZE ***\n%1 Kbytes").arg(size))
            return True
        
        if item.childCount() == 0:
            re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)')
            match = re_queueid.match(item.parent().text(0).ascii())
            if match is not None:
                self.iQueueMessage.setText(self.__tr("*** DELAY REASON ***\n%1").arg(re.sub(" *\(", "(", self.itemLog.get("%s:%s" % (match.group(1), item.text(0).ascii()) ) )))
                return True
        
        queueid = item.text(0).ascii()
        re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)')
        match = re_queueid.match(queueid)
        if match is not None:
            self.iQueueMessage.setText(self.__tr("*** ARRIVAL TIME ***\n%1").arg(self.itemLog.get(match.group(1))))
        
        

    def queue_set_message(self,a0,a1):
        # a0=cmd, a1=remove item
        
        self.iQueueMessage.clear()
        
        item = self.lvQueue.currentItem()
        re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
        
        if item.parent() is None:
            subitem = item.firstChild()
            success = False
            queuelist = []
            while subitem is not None:
                queuelist.append(re_queueid.match(subitem.text(0).ascii()).group(1))
                if len(queuelist) == 50 or subitem.nextSibling() is None:
                    if self.ssh_exec("%s - <<< \"%s\"" % (a0, "\n".join(queuelist))):
                        success = True
                    queuelist = []
                subitem = subitem.nextSibling()
            if success:
                self.console(self.__tr("'%1' processed message(s).").arg(item.childCount()))
            if a1 == True:
                self.lvQueue.takeItem(item)
        else:
            match = re_queueid.match(item.text(0).ascii())
            if match is not None:
                self.ssh_exec("%s %s" % (a0, match.group(1)))
                if a1 == True:
                    count = item.parent().text(1).ascii().split("/")
                    if int(count[0]) == 1:
                        self.lvQueue.takeItem(item.parent())
                    else:
                        item.parent().setText(1 ,"%s/%s" % (str(int(count[0]) - 1), str(int(count[1]) - int(item.childCount()))))
                        item.parent().takeItem(item)
        
        

    def queue_menu(self,a0,a1):
        
        self.korreio_update_servers_menu()
        
        item = a0
        
        if item is None or item.childCount() == 0:
            self.lvQueueMenu.setItemEnabled(1, False)
            self.lvQueueMenu.setItemEnabled(2, False)
            self.lvQueueMenu.setItemEnabled(3, False)
            self.lvQueueMenu.setItemEnabled(4, False)
            self.lvQueueMenu.setItemEnabled(5, False)
            self.lvQueueMenu.setItemEnabled(6, False)
        elif item.parent() is None:
            self.lvQueueMenu.setItemEnabled(1, False)
            self.lvQueueMenu.setItemEnabled(2, False)
            self.lvQueueMenu.setItemEnabled(3, True)
            self.lvQueueMenu.setItemEnabled(4, True)
            self.lvQueueMenu.setItemEnabled(5, True)
            self.lvQueueMenu.setItemEnabled(6, True)
        else:
            self.lvQueueMenu.setItemEnabled(1, True)
            self.lvQueueMenu.setItemEnabled(2, True)
            self.lvQueueMenu.setItemEnabled(3, True)
            self.lvQueueMenu.setItemEnabled(4, True)
            self.lvQueueMenu.setItemEnabled(5, True)
            self.lvQueueMenu.setItemEnabled(6, True)
        
        self.lvQueueMenu.popup(a1)
        
        

    def queue_menu_clicked(self,a0):
        # a0=int:menuItem
        
        menuItem = a0
        
        if menuItem == 0:
            #
            # Update message list
            #
        
            self.queue_load()
        
        elif menuItem == 1:
            #
            # Get message content
            #
        
            queueid = self.lvQueue.currentItem().text(0).ascii()
            re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
            match = re_queueid.match(queueid)
            if match is not None:
                cmd = self.ssh_open("postcat -q %s" % match.group(1))
                if cmd is not None:
                    self.iQueueMessage.setText("\n".join(cmd))
        
        elif menuItem == 2:
            #
            # Get recipient already sent
            #
        
            queueid = self.lvQueue.currentItem().text(0).ascii()
            re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
            match = re_queueid.match(queueid)
            if match is not None:
                cmd = self.ssh_open("postcat -q %s | grep done_recipient:" % match.group(1))
                if cmd is not None:
                    cmd.sort()
                    tmpCmd = []
                    for line in cmd:
                        tmpCmd.append(line.replace("done_recipient: ", ""))
                    self.iQueueMessage.setText(self.__tr("*** DELIVERED RECIPIENT ***\nTotal: %1\n\n*** RECIPIENTS ***\n%2").arg(len(tmpCmd)).arg("\n".join(tmpCmd)))
        
        elif menuItem == 3:
            #
            # Hold selected messages
            #
        
            self.queue_set_message("postsuper -h", False)
        
        elif menuItem == 4:
            #
            # Unhold selected messages
            #
        
            self.queue_set_message("postsuper -H", False)
        
        elif menuItem == 5:
            #
            # Requeue selected messages
            #
        
            self.queue_set_message("postsuper -r", False)
        
        elif menuItem == 6:
            #
            # Delete selected messages
            #
        
            item = self.lvQueue.currentItem()
            if item.parent() is None:
                msg = self.__tr("Confirm all messages deletion request from user '%1'?").arg(item.text(0).ascii())
            else:
                re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
                match = re_queueid.match(item.text(0).ascii())
                msg = self.__tr("Confirm message '%1' deletion request from user '%2'?").arg(match.group(1)).arg(item.parent().text(0).ascii())
            if QMessageBox.information( None, self.__tr("Confirm!"), msg, self.__tr("&Yes"), self.__tr("&No") ) != 0:
                self.console(self.__tr("deletion request was aborted."), self.CONSOLE_INFO)
                return True
            self.queue_set_message("postsuper -d", True)
        
        elif menuItem == 10:
            #
            # Flush messages
            #
        
            if QMessageBox.information( None, self.__tr("Warning!"),
                   self.__tr("    Warning: the FLUSH operation cause negative interference in QMGR \n"+
                               "sent messages scheduler algorithm, especially in large queues.\n"+
                               "Use only when necessary."), self.__tr("&Ok")) != 0:
                self.console(self.__tr("flush request was aborted."), self.CONSOLE_INFO)
                return True
            cmd = "postqueue -f"
        
        elif menuItem == 11:
            #
            # Hold all messages
            #
        
            if QMessageBox.information( None, self.__tr("Confirm!"),
                   self.__tr("Confim set all messages on hold?"), self.__tr("&Yes"), self.__tr("&No")) != 0:
                self.console(self.__tr("hold on request was aborted."), self.CONSOLE_INFO)
                return True
            cmd = "postsuper -h ALL"
        
        elif menuItem == 12:
            #
            # Unhold all messages
            #
        
            if QMessageBox.information( None, self.__tr("Confirm!"),
                   self.__tr("Confirm set all messages to delivery (unhold)?"), self.__tr("&Yes"), self.__tr("&No")) != 0:
                self.console(self.__tr("unhold request was aborted."), self.CONSOLE_INFO)
                return True
            cmd = "postsuper -H ALL"
        
        elif menuItem == 13:
            #
            # Requeue all messages
            #
        
            if QMessageBox.information( None, self.__tr("Confirm!"),
                   self.__tr("Confirm transport requeue for all messages?"), self.__tr("&Yes"), self.__tr("&No")) != 0:
                self.console(self.__tr("transport requeue request was aborted."), self.CONSOLE_INFO)
                return True
            cmd = "postsuper -r ALL"
        
        elif menuItem == 14:
            #
            # Delete all messages
            #
        
            if QMessageBox.information( None, self.__tr("Confirm!"),
                   self.__tr("Confirme all messages deletion request?"), self.__tr("&Yes"), self.__tr("&No")) != 0:
                self.console(self.__tr("deletion request was aborted."), self.CONSOLE_INFO)
                return True
            cmd = "postsuper -d ALL"
        
        if menuItem > 10 and menuItem < 15:
            if self.ssh_exec(cmd) and menuItem == 14:
                self.lvQueue.clear()
        
        

    def __tr(self,s,c = None):
        return qApp.translate("dKorreio",s,c)

class QTextEditSieveScript(QTextEdit):
    def __init__(self, parent, name):
        self.config = ""
        self.sievePopup = {}
        apply(QTextEdit.__init__, (self, parent, name))

    def _load_config(self):
        if not self.config:
            return

        try:
            f = open(self.config, 'r')
            sieveConfig = f.read()
            f.close()
        except IOError, e:
            print "ERROR: can't read sieve helper '%s' (%s)." % (self.config, e)

        re_sieveMenu = re.compile(r'(\[Menu\]\nid ?= ?(.*)\nparent ?= ?(.*)\ndisplay name ?= ?(.*)\n)')
        re_sieveItem = re.compile(r'(\[Item\]\nid ?= ?(.*)\nparent ?= ?(.*)\ndisplay name ?= ?(.*)\nstrip script ?= ?(.*)\nsieve script ?= ?<< ?EOF\n((.*\n)*?)EOF\n)')

        self.sieveMenu = {}
        match = re_sieveMenu.findall(sieveConfig)
        for menu in match:
            self.sieveMenu[int(menu[1])] = { "parent": int(menu[2]), "display name": menu[3] }

        self.sieveItem = {}
        match = re_sieveItem.findall(sieveConfig)
        for item in match:
            self.sieveItem[int(item[1])] = { "parent": int(item[2]), "display name": item[3], "strip script": item[4], "sieve script": item[5]}

    def _load_popup(self):

        self.sievePopup = {}
        self.sievePopup[-1] = QPopupMenu(self)

        ids = self.sieveMenu.keys()
        ids.sort()

        for id in ids:
            info = self.sieveMenu.get(id)
            self.sievePopup[id] = QPopupMenu(self)
            self.sievePopup[info.get("parent")].insertItem(info.get("display name"), self.sievePopup.get(id), 0)
            self.connect(self.sievePopup.get(id), SIGNAL('activated(int)'), self.sieve_menu_clicked)

        ids = self.sieveItem.keys()
        ids.sort()
        for id in ids:
            info = self.sieveItem.get(id)
            self.sievePopup[info.get("parent")].insertItem(info.get("display name"), id)

    def createPopupMenu(self, *args):
        if not self.sievePopup:
            self._load_config()
        self._load_popup()
        return self.sievePopup[-1]

    def sieve_menu_clicked(self, menuItem):
        script = self.sieveItem.get(menuItem).get("sieve script")
        if self.sieveItem.get(menuItem).get("strip script") == "yes":
            script = script.strip()
        self.insert(script, True, True)
        return True

    def setConfig(self, config):
        self.config = config

class LdapCacheError(Exception): pass

class LdapCache:
    """
    Dict = {
             unicode_dn1: { utf8_attr1: [utf8_values], utf8_attr2: [utf8_values] },
             unicode_dn2: { utf8_attr1: [utf8_values], utf8_attr2: [utf8_values] }
           }
    """

    def __init__(self):
        self.ldap_cache = {}

    def _sanitize(self, value):
        if type(value) != type(u'') or len(value) == 0:
            raise LdapCacheError, "Invalid codification"

    def load(self, dnDict):
        if dnDict is None:
            self.ldap_cache = {}
        else:
            self.ldap_cache = dnDict

    def get(self, dn):
        self._sanitize(dn)
        return self.ldap_cache.get(dn)

    def set(self, dn, attrs):
        self._sanitize(dn)
        self.ldap_cache[dn] = attrs

    def unset(self, dn):
        self._sanitize(dn)
        del self.ldap_cache[dn]
    
    def add(self, dn, modlistAdd):
        self._sanitize(dn)
        self.ldap_cache[dn] = {}
        for tuple in modlistAdd:
            self.ldap_cache[dn][tuple[0]] = tuple[1]

    def modify(self, dn, modlistModify):
        self._sanitize(dn)
        for tuple in modlistModify:
            if tuple[2] is None:
                del self.ldap_cache[dn][tuple[1]]
            else:
                self.ldap_cache[dn][tuple[1]] = tuple[2]

    def show(self):
        print self.ldap_cache

    def isEmpty(self):
        if self.ldap_cache == {}:
            return True
        else:
            return False
    
    def keys(self):
        return self.ldap_cache.keys()
    
    def rename(self, dn, newDn):
        self._sanitize(dn)
        self._sanitize(newDn)
        if dn != newDn:
            self.ldap_cache[newDn] = self.ldap_cache.get(dn)
            del self.ldap_cache[dn]

    def removeAttr(self, dn, rdn):
        self._sanitize(dn)
        rdnList = rdn.split("=")
        i = 0
        for attr in self.ldap_cache[dn][rdnList[0]]:
            if rdnList[1].lower() == attr.lower():
                del self.ldap_cache[dn][rdnList[0]][i]
                break
            i += 1
        if self.ldap_cache[dn][rdnList[0]] == []:
            del self.ldap_cache[dn][rdnList[0]]

    def addAttr(self, dn, rdn):
        self._sanitize(dn)
        rdnList = rdn.split("=")
        if self.ldap_cache[dn].get(rdnList[0]):
             self.ldap_cache[dn][rdnList[0]].append(rdnList[1])
        else:
             self.ldap_cache[dn][rdnList[0]] = [rdnList[1]]

class QLdapCacheError(Exception): pass

class QLdapCache:
    """
    Dict = {
             unicode_dn1: { QListViewItem_1 },
             unicode_dn2: { QListViewItem_2 }
           }
    """

    def __init__(self, listView):
        self.ListView = listView
        self.LdapCache = {}

    def _sanitize(self, value):
        if type(value) != type(u'') or len(value) == 0:
            raise QLdapCacheError, "Invalid codification"

    def init(self, baseList=[]):
        """
            Initialize QLdapCache dictionary
        """
        self.LdapCache = {}
        for base in baseList:
            self._sanitize(base)
        self.baseList = baseList
    
    def _isBase(self, dn):
        for base in self.baseList:
            if base.lower() == dn.lower():
                return True
        return False

    def _loadRoot(self, dn):
        self.LdapCache[dn.lower()] = QListViewItem(self.ListView)
        self.LdapCache[dn.lower()].setOpen(True)
        self.LdapCache[dn.lower()].setText(0, dn)

    def _load(self, dn):
        dnList = dn.split(u",")
        dnParent = u",".join(dnList[1:])
        if not self.LdapCache.get(dnParent.lower()):
            if self._isBase(dn):
                self._loadRoot(dn)
                return
            if len(dnList) > 2:
                self._load(dnParent)
            else:
                self._loadRoot(dnParent)
        self.LdapCache[dn.lower()] = QListViewItem(self.LdapCache.get(dnParent.lower()))
        self.LdapCache[dn.lower()].setText(0, dnList[0])

    def _fix(self, dn):
        """
            Fix caracter case for auto-generate nodes
        """
        if self._isBase(dn):
            self.LdapCache.get(dn.lower()).setText(0, dn)
        else:
            self.LdapCache.get(dn.lower()).setText(0, dn.split(u",")[0])

    def load(self, dn):
        """
            Create QListViewItem and parents nodes
        """
        self._sanitize(dn)
        if not self.LdapCache.get(dn.lower()):
            if self._isBase(dn):
                self._loadRoot(dn)
            else:
                self._load(dn)
        self._fix(dn)

    def add(self, dn):
        """
            Create QListViewItem
        """
        dnList = dn.split(u",")
        if self._isBase(dn) or len(dnList) == 1:
            self.LdapCache[dn.lower()] = QListViewItem(self.ListView)
            self.LdapCache[dn.lower()].setText(0, dn)
        else:
            itemParent = self.LdapCache.get(",".join(dnList[1:]).lower())
            itemParent.setOpen(True)
            self.LdapCache[dn.lower()] = QListViewItem(itemParent)
            self.LdapCache[dn.lower()].setText(0, dnList[0])
        self.ListView.ensureItemVisible(self.LdapCache.get(dn.lower()))

    def get(self, dn):
        """
            Get QListViewItem by DN
        """
        self._sanitize(dn)
        return self.LdapCache.get(dn)

    def rename(self, dn, newDn):
        """
            Rename DN key
        """
        self._sanitize(dn)
        self._sanitize(newDn)
        if dn != newDn:
            self.LdapCache[newDn] = self.LdapCache.get(dn)
            del self.LdapCache[dn]


class QListViewItemColored(QListViewItem):
  def __init__(self, *args):
    QListViewItem.__init__(self, *args)

  def paintCell(self, p, cg, column, width, align):
    g = QColorGroup(cg)
    g.setColor( QColorGroup.Base, QColor("grey95"))
#    g.setColor( QColorGroup.Text, QColor("darkgreen"))
    QListViewItem.paintCell(self, p, g, column, width, align)
