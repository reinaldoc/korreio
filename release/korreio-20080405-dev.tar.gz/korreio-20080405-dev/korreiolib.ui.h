# Copyright (c) 2007-2008 -  Reinaldo de Carvalho <reinaldoc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.

void dKorreio::init() {

global iso2utf, utf2iso

def iso2utf(string):
    return str(self.__tr(string))

def utf2iso(string):
    return string.encode('iso8859-1')

try:
    global sys, re, datetime, os
    import sys, re, datetime, os.path

    reload(sys)
    sys.setdefaultencoding("utf-8")

    global  sha, md5, b2a_base64, choice, letters, digits
    import sha, md5
    from binascii import b2a_base64
    from random import choice
    from string import letters, digits
except:
    print "Error importing core modules."
    sys.exit()

modfailed = []

try:
    global ldap, modlist
    import ldap, ldap.modlist as modlist
except:
    self.wKorreio.page(0).setEnabled(False)
    self.pGetBaseDN.setEnabled(False)
    modfailed.append("ldap")

try:
    global  smbpasswd
    import smbpasswd
except:
    self.cbLdapSambaPassword.setEnabled(False)
    modfailed.append("smbpasswd")

try:
    global cyruslib
    import cyruslib
except:
    self.wKorreio.page(1).setEnabled(False)
    self.wKorreio.page(2).setEnabled(False)
    modfailed.append("cyrus")

try:
    global sievelib
    import sievelib
except:
    self.wKorreio.page(3).setEnabled(False)
    modfailed.append("sieve")

try:
    global pexpect, pxssh
    import pexpect, pxssh
except:
    self.wKorreio.page(4).setEnabled(False)
    self.wKorreio.page(5).setEnabled(False)
    modfailed.append("pexpect")

if modfailed:
    msg = ""
    for mod in modfailed:
        msg = "%s%s\n" % (msg, "    - python-%s" % mod)
    QMessageBox.warning(None, "Modulos falharam", utf2iso("Os seguintes módulos não foram carregados:\n%s" % msg))

global active_conn
active_conn = {}

}

void dKorreio::customEvent( a0 ) {
event = a0
if event.type() == "set_console_text":
    self.console(event.data())
}

void dKorreio::statusBar() {
pass
}

void dKorreio::console( a0 ) {

text = datetime.datetime.now().strftime("%d %b %Y %H:%M:%S :/# ")+a0
self.tlConsole.setText(utf2iso(text))

try:
    f = open(os.path.expanduser("~/.korreio/korreio.log"), 'a')
    f.write(text+'\n')
    f.close()
except OSError, e:
    print e

}

void dKorreio::parse_exception( a0, a1 ) {

if a0 == "LDAPError":
    if a1[0]["desc"] == "Size limit exceeded":
        self.console("Atenção: quantidade de registros excedido, utilize um filtro mais restritivo.")
    elif a1[0]["desc"] == "Already exists":
        self.console("Erro: o registro já existe.")
    elif a1[0]['desc'] == "Object class violation":
        self.console(a1[0]['info'])
    elif a1[0]['desc'] == "Naming violation":
        self.console(a1[0]['info'])
    elif a1[0]['desc'] == "Can't contact LDAP server":
        self.console("Erro: conexão ao host %s recusada." % self.iLdapHost.text().ascii())
    elif a1[0]['info'] == "no write access to parent":
        self.console("Erro: sem permissão de escrita no referral, autentique-se na raiz %s." % self.ldap_get_dn())
    elif a1[0]['info'] == "modifications require authentication":
        user = self.iLdapUser.text().ascii()
        if not user: user = "anonymous"
        self.console("Erro: usuário %s sem permissão de escrita ou senha incorreta." % user)
    elif a1[0]['desc'] == "No such attribute":
        self.console(a1[0]['info'])
    else:
        self.console(str(a1))
else:
    self.console(str(a1))

}

void dKorreio::korreio_module_clear( a0 ) {

if a0 == "ldap":
    self.lvLdap.clear()
    self.lvLdapAttr.clear()
elif a0 == "imap":
    self.lvCyrus.clear()
    self.lvCyrusGlobal.clear()
    self.iImapMailbox.clear()
    self.lvImapAcl.clear()
    self.iImapAclUser.clear()
    self.cbACL.setCurrentText("")
    self.iQuota.clear()
    self.iQuotaUsed.clear()
    self.iAnnotationExpire.clear()
elif a0 == "imap-partition":
    self.lvImapPartition.clear()
    self.lvImapPartitionGlobal.clear()
    self.cbImapPartition.clear()
elif a0 == "sieve":
    self.lvSieve.clear()
    self.cbSieveScript.clear()
    self.teSieveScript.clear()
elif a0 == "ssh":
    self.cbPostconf.clear()
    self.tePostconf.clear()
    self.tePostFileOpen.clear()
    self.lvQueue.clear()
    self.iQueueMessage.clear()

}

void dKorreio::korreio_module_changed() {

menu=str(self.wKorreio.tabLabel(self.wKorreio.currentPage()))
if menu == "LDAP Manager":
    try:
        self.loadconfig
    except:
        self.loadconfig = 1
        self.config_load()
elif menu == "Configurações":
    self.config_change_widgetstack()

}

void dKorreio::config_load() {

try:
    os.mkdir(os.path.expanduser("~/.korreio"),0700)
except OSError, e:
    if e[0] != 17:
        self.console("Erro: não foi possível criar ~/.korreio. %s" % e)
        print "Error creating ~/.korreio "+e
        return False

try:
    if not os.path.isfile(os.path.expanduser("~/.korreio/korreio.conf")):
        self.config_save()
except OSError, e:
    pass

try:
    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
    conf=f.read()
    f.close()
except IOError, e:
    return True

confList = conf.split("\n")
confList.pop()
self.confDict = {}

for line in confList:
   key=line.split("=")
   self.confDict[key[0]] = "=".join(key[1:])

#
# LDAP Connection
#

i=0
self.cbLdapConnection.clear()
while self.confDict.get("ldap%s.name" % i):
    self.cbLdapConnection.insertItem(self.confDict.get("ldap%s.name" % i))
    i=i+1

lastConn=self.confDict.get("ldap.last")
if lastConn:
    self.cbLdapConnection.setCurrentText(self.confDict.get("%s.name" % lastConn))
    self.iLdapConnection.setText(self.confDict.get("%s.name" % lastConn))
    self.cbLdapMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
    self.iLdapHost.setText(self.confDict.get("%s.host" % lastConn))
    self.iLdapPort.setText(self.confDict.get("%s.port" % lastConn))
    self.cbLdapBaseDN.clear()
    self.cbLdapBaseDN.insertItem(self.confDict.get("%s.basedn" % lastConn))
    self.iLdapUser.setText(self.confDict.get("%s.user" % lastConn))
    self.iLdapPass.setText(self.confDict.get("%s.pass" % lastConn))
    if self.confDict.get("%s.ref" % lastConn) == "True":
        self.cLdapRef.setChecked(True)
    if self.confDict.get("%s.cert" % lastConn) == "True":
        self.cLdapCert.setChecked(True)

#
# IMAP Connection
#

i=0
self.cbCyrusConnection.clear()
while self.confDict.get("imap%s.name" % i):
    self.cbCyrusConnection.insertItem(self.confDict.get("imap%s.name" % i))
    i=i+1

lastConn=self.confDict.get("imap.last")
if lastConn:
    self.cbCyrusConnection.setCurrentText(self.confDict.get("%s.name" % lastConn))
    self.iCyrusConnection.setText(self.confDict.get("%s.name" % lastConn))
    self.cbCyrusMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
    self.iCyrusHost.setText(self.confDict.get("%s.host" % lastConn))
    self.iCyrusPort.setText(self.confDict.get("%s.port" % lastConn))
    self.iCyrusSievePort.setText(self.confDict.get("%s.sieport" % lastConn))
    self.iCyrusUser.setText(self.confDict.get("%s.user" % lastConn))
    self.iCyrusPass.setText(self.confDict.get("%s.pass" % lastConn))
    self.iCyrusPart.setText(self.confDict.get("%s.part" % lastConn))

#
# SSH Connection
#

i=0
self.cbSSHConnection.clear()
while self.confDict.get("ssh%s.name" % i):
    self.cbSSHConnection.insertItem(self.confDict.get("ssh%s.name" % i))
    i=i+1

lastConn=self.confDict.get("ssh.last")
if lastConn:
    self.cbSSHConnection.setCurrentText(self.confDict.get("%s.name" % lastConn))
    self.iSSHConnection.setText(self.confDict.get("%s.name" % lastConn))
    self.iSshHost.setText(self.confDict.get("%s.host" % lastConn))
    self.iSshPort.setText(self.confDict.get("%s.port" % lastConn))
    self.iSshUser.setText(self.confDict.get("%s.user" % lastConn))
    self.iSshPass.setText(self.confDict.get("%s.pass" % lastConn))

#
# IMAP Prefs
#

self.lbConfImapFolders.clear()
for folder in self.confDict.get("imap.dflfolders").split(","):
    self.lbConfImapFolders.insertItem(folder)
self.iConfImapQuota.setText(self.confDict.get("imap.dflquota"))
self.iConfImapExpire.setText(self.confDict.get("imap.dflexpirefolder"))
self.iConfImapExpireDays.setText(self.confDict.get("imap.dflexpiredays"))
self.iConfImapACLp.setText(self.confDict.get("imap.addaclp"))

#
# LDAP Prefs
#

self.lvConfLdap.clear()
item = QListViewItem(self.lvConfLdap)
item.setText(0,'objectClass')
item.setOpen(True)
objnodes = {}
i=0
while self.confDict.get("ldap.objectclass%s" % i):
    objclass = self.confDict.get("ldap.objectclass%s" % i).split(".")
    if not objnodes.get(objclass[0]):
        objnodes[objclass[0]] = QListViewItem(item)
        objnodes[objclass[0]].setText(0,objclass[0])
    subitem=QListViewItem(objnodes[objclass[0]])
    subitem.setText(0,objclass[1])
    subitem.setText(1,".".join(objclass[2:]))
    i=i+1

}

void dKorreio::config_save() {

try:
    try:
        self.confDict
    except AttributeError, e:
        self.confDict = {}

    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')

#
# LDAP Connection
#

    if not self.iLdapConnection.text().ascii():
        self.console("Preencha o nome da conexão LDAP.")
    else:
        i=0
        while self.confDict.get("ldap%s.name" % i):
            if self.confDict.get("ldap%s.name" % i) == self.iLdapConnection.text().ascii():
                break
            i=i+1
        tmpLast=i
        f.write('ldap.last=ldap%s\n' % i)

        self.confDict["ldap%s.name" % i]=self.iLdapConnection.text().ascii()
        self.confDict["ldap%s.mode" % i]=self.cbLdapMode.currentText().ascii()
        self.confDict["ldap%s.host" % i]=self.iLdapHost.text().ascii()
        self.confDict["ldap%s.port" % i]=self.iLdapPort.text().ascii()
        self.confDict["ldap%s.basedn" % i]=self.cbLdapBaseDN.currentText().ascii()
        self.confDict["ldap%s.user" % i]=self.iLdapUser.text().ascii()
        self.confDict["ldap%s.pass" % i]=self.iLdapPass.text().ascii()
        self.confDict["ldap%s.ref" % i]=str(self.cLdapRef.isChecked())
        self.confDict["ldap%s.cert" % i]=str(self.cLdapCert.isChecked())

        i=0
        self.cbLdapConnection.clear()
        while self.confDict.get("ldap%s.name" % i):
            self.cbLdapConnection.insertItem(self.confDict.get("ldap%s.name" % i))
            for j in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                opt = "ldap%s.%s" % (i, j)
                f.write("%s=%s\n" % (opt, self.confDict.get(opt)))
            i=i+1
        self.cbLdapConnection.setCurrentItem(tmpLast)

#
# IMAP Connection
#

    if not self.iCyrusConnection.text().ascii():
        self.console("Preencha o nome da conexão IMAP.")
    else:
        i=0
        while self.confDict.get("imap%s.name" % i):
            if self.confDict.get("imap%s.name" % i) == self.iCyrusConnection.text().ascii():
                break
            i=i+1
        tmpLast=i
        f.write("imap.last=imap%s\n" % i)

        self.confDict["imap%s.name" % i]=self.iCyrusConnection.text().ascii()
        self.confDict["imap%s.mode" % i]=self.cbCyrusMode.currentText().ascii()
        self.confDict["imap%s.host" % i]=self.iCyrusHost.text().ascii()
        self.confDict["imap%s.port" % i]=self.iCyrusPort.text().ascii()
        self.confDict["imap%s.sieport" % i]=self.iCyrusSievePort.text().ascii()
        self.confDict["imap%s.user" % i]=self.iCyrusUser.text().ascii()
        self.confDict["imap%s.pass" % i]=self.iCyrusPass.text().ascii()
        self.confDict["imap%s.part" % i]=self.iCyrusPart.text().ascii()

        i=0
        self.cbCyrusConnection.clear()
        while self.confDict.get("imap%s.name" % i):
            self.cbCyrusConnection.insertItem(self.confDict.get("imap%s.name" % i))
            for j in ['name','mode','host','port','sieport','user','pass','part']:
                opt = "imap%s.%s" % (i, j)
                f.write("%s=%s\n" % (opt, self.confDict.get(opt)))
            i=i+1
        self.cbCyrusConnection.setCurrentItem(tmpLast)

#
# SSH Connection
#

    if not self.iSSHConnection.text().ascii():
        self.console("Preencha o nome da conexão SSH.")
    else:
        i=0
        while self.confDict.get("ssh%s.name" % i):
            if self.confDict.get("ssh%s.name" % i) == self.iSSHConnection.text().ascii():
                break
            i=i+1
        tmpLast=i
        f.write("ssh.last=ssh%s\n" % i)

        self.confDict["ssh%s.name" % i]=self.iSSHConnection.text().ascii()
        self.confDict["ssh%s.host" % i]=self.iSshHost.text().ascii()
        self.confDict["ssh%s.port" % i]=self.iSshPort.text().ascii()
        self.confDict["ssh%s.user" % i]=self.iSshUser.text().ascii()
        self.confDict["ssh%s.pass" % i]=self.iSshPass.text().ascii()

        i=0
        self.cbSSHConnection.clear()
        while self.confDict.get("ssh%s.name" % i):
            self.cbSSHConnection.insertItem(self.confDict.get("ssh%s.name" % i))
            for j in ['name','host','port','user','pass']:
                opt="ssh%s.%s" % (i, j)
                f.write("%s=%s\n" % (opt, self.confDict.get(opt)))
            i=i+1
        self.cbSSHConnection.setCurrentItem(tmpLast)

#
# IMAP Prefs
#

    folders=[]
    for folder in range(0,self.lbConfImapFolders.count()):
        folders.extend([self.lbConfImapFolders.item(folder).text().ascii()])
    f.write("imap.dflfolders=%s\n" % ",".join(folders))
    f.write("imap.dflquota=%s\n" % self.iConfImapQuota.text().ascii())
    f.write("imap.dflexpirefolder=%s\n" % self.iConfImapExpire.text().ascii())
    f.write("imap.dflexpiredays=%s\n" % self.iConfImapExpireDays.text().ascii())
    f.write("imap.addaclp=%s\n" % self.iConfImapACLp.text().ascii())


#
# LDAP Prefs
#
    item=self.lvConfLdap.firstChild()
    item=item.firstChild()
    i=0
    while item is not None:
        subitem=item.firstChild()
        while subitem is not None:
            if subitem.text(1).ascii() is None: value=""
            else: value=subitem.text(1).ascii()
            f.write("ldap.objectclass%s=%s.%s.%s\n" % (i, item.text(0).ascii(), subitem.text(0).ascii(), value))
            subitem=subitem.nextSibling()
            i=i+1
        item=item.nextSibling()
#
# End
#
    f.close()
    os.chmod(os.path.expanduser("~/.korreio/korreio.conf"), 0600)
    self.console("Configuração salva.")
except OSError, e:
    self.parse_exception("OSError", e)

}

void dKorreio::config_change_widgetstack() {
item=self.lvConfig.currentItem()
if item.parent() is None:
   if  item.text(0).ascii() == "Servidores":
        self.wsConfig.raiseWidget(3)
        self.tConfShowLdapServer.setText("Host: %s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii()))
        self.tConfShowLdapUser.setText("User: %s" % self.iLdapUser.text().ascii())
        self.tConfShowLdapBaseDN.setText("Base: %s" % self.cbLdapBaseDN.currentText().ascii())
        self.tConfShowImapServer.setText("Host: %s%s:%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii()))
        self.tConfShowImapUser.setText("User: %s" % self.iCyrusUser.text().ascii())
        self.tConfShowSshServer.setText("Host: ssh://%s:%s" % (self.iSshHost.text().ascii(), self.iSshPort.text().ascii()))
        self.tConfShowSshUser.setText("User: %s" % self.iSshUser.text().ascii())
elif "%s.%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) == "Servidores.LDAP":
    self.wsConfig.raiseWidget(0)
elif "%s.%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) == "Servidores.IMAP":
    self.wsConfig.raiseWidget(1)
elif "%s.%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) == "Servidores.SSH":
    self.wsConfig.raiseWidget(2)
elif "%s.%s" % (iso2utf(item.parent().text(0).ascii()), item.text(0).ascii()) == "Preferências.LDAP":
    self.wsConfig.raiseWidget(4)
elif "%s.%s" % (iso2utf(item.parent().text(0).ascii()), item.text(0).ascii()) == "Preferências.IMAP":
    self.wsConfig.raiseWidget(5)
}

void dKorreio::config_imap_set_port() {

if self.cbCyrusMode.currentText().ascii() == "imap://":
    self.iCyrusPort.setText("143")
else:
    self.iCyrusPort.setText("993")

}

void dKorreio::config_ldap_set_port() {
if self.cbLdapMode.currentText().ascii() == "ldap://":
    self.iLdapPort.setText("389")
else:
    self.iLdapPort.setText("636")
}

void dKorreio::config_ldap_get_basedn() {

try:
    l = self.ldap_connect()
    ldap_result_id = l.search("", ldap.SCOPE_BASE, "objectclass=*", ["namingContexts"])
    self.cbLdapBaseDN.clear()
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if (result_data == []):
            break
        else:
            if result_type == ldap.RES_SEARCH_ENTRY:
                for j in result_data:
                     for root in j[1]["namingContexts"]:
                         self.cbLdapBaseDN.insertItem(root)
                         if not self.iLdapUser.text().ascii():
                             self.iLdapUser.setText("cn=admin,%s" % root)
    if self.cbLdapBaseDN.count() > 1:
            self.cbLdapBaseDN.popup()
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)

}

void dKorreio::config_imap_add_default_folder() {

self.lbConfImapFolders.insertItem(self.iConfImapFolder.text().ascii())
self.iConfImapFolder.clear()

}

void dKorreio::config_imap_del_default_folder() {

self.lbConfImapFolders.removeItem(self.lbConfImapFolders.currentItem())

}

void dKorreio::config_ldap_add_attr() {

itemroot=self.lvConfLdap.firstChild()
if itemroot.isSelected():
    newitem=QListViewItem(itemroot)
    newitem.setText(0,self.iConfLdapAttr.text().ascii())
    newitem.setText(1,self.iConfLdapValue.text().ascii())
    return True
item=itemroot.firstChild()
while item is not None:
    if item.isSelected():
        item.setOpen(True)
        newitem=QListViewItem(item)
        newitem.setText(0,self.iConfLdapAttr.text().ascii())
        newitem.setText(1,self.iConfLdapValue.text().ascii())
        return True
    subitem=item.firstChild()
    while subitem is not None:
        if subitem.isSelected():
            subitem.setOpen(True)
            newitem=QListViewItem(item)
            newitem.setText(0,self.iConfLdapAttr.text().ascii())
            newitem.setText(1,self.iConfLdapValue.text().ascii())
            return True
        subitem=subitem.nextSibling()
    item=item.nextSibling()

}

void dKorreio::config_ldap_del_attr() {

itemroot=self.lvConfLdap.firstChild()
item=itemroot.firstChild()
while item is not None:
    if item.isSelected():
        itemroot.takeItem(item)
        self.lvConfLdap.currentItem().setSelected(True)
        return True
    subitem=item.firstChild()
    while subitem is not None:
        if subitem.isSelected():
            item.takeItem(subitem)
            self.lvConfLdap.currentItem().setSelected(True)
            return True
        subitem=subitem.nextSibling()
    item=item.nextSibling()

}

void dKorreio::config_ldap_set_connection() {

i=0
while self.confDict.get("ldap%s.name" % i):
    if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
        lastConn="ldap%s" % i
    i=i+1

self.iLdapConnection.setText(self.confDict.get("%s.name" % lastConn))
self.cbLdapMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
self.iLdapHost.setText(self.confDict.get("%s.host" % lastConn))
self.iLdapPort.setText(self.confDict.get("%s.port" % lastConn))
self.cbLdapBaseDN.clear()
self.cbLdapBaseDN.insertItem(self.confDict.get("%s.basedn" % lastConn))
self.iLdapUser.setText(self.confDict.get("%s.user" % lastConn))
self.iLdapPass.setText(self.confDict.get("%s.pass" % lastConn))
if self.confDict.get("%s.ref" % lastConn) == "True":
    self.cLdapRef.setChecked(True)
else:
    self.cLdapRef.setChecked(False)
if self.confDict.get("%s.cert" % lastConn) == "True":
    self.cLdapCert.setChecked(True)
else:
    self.cLdapCert.setChecked(False)

self.korreio_module_clear("ldap")

}

void dKorreio::config_imap_set_connection() {

i=0
while self.confDict.get("imap%s.name" % i):
    if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
        lastConn="imap%s" % i
    i=i+1

self.iCyrusConnection.setText(self.confDict.get("%s.name" % lastConn))
self.cbCyrusMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
self.iCyrusHost.setText(self.confDict.get("%s.host" % lastConn))
self.iCyrusPort.setText(self.confDict.get("%s.port" % lastConn))
self.iCyrusSievePort.setText(self.confDict.get("%s.sieport" % lastConn))
self.iCyrusUser.setText(self.confDict.get("%s.user" % lastConn))
self.iCyrusPass.setText(self.confDict.get("%s.pass" % lastConn))
self.iCyrusPart.setText(self.confDict.get("%s.part" % lastConn))

self.korreio_module_clear("imap")
self.korreio_module_clear("imap-partition")
self.korreio_module_clear("sieve")

}

void dKorreio::config_ssh_set_connection() {

i=0
while self.confDict.get("ssh%s.name" % i):
    if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
        lastConn="ssh%s" % i
    i=i+1
self.iSSHConnection.setText(self.confDict.get("%s.name" % lastConn))
self.iSshHost.setText(self.confDict.get("%s.host" % lastConn))
self.iSshPort.setText(self.confDict.get("%s.port" % lastConn))
self.iSshUser.setText(self.confDict.get("%s.user" % lastConn))
self.iSshPass.setText(self.confDict.get("%s.pass" % lastConn))

self.korreio_module_clear("ssh")

}

void dKorreio::config_ldap_del_connection() {

if not self.cbLdapConnection.currentText().ascii():
    return True

i=0
while self.confDict.get("ldap%s.name" % i):
    if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
        j=i+1
        while self.confDict.get("ldap%s.name" % j):
            for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                self.confDict["ldap%s.%s" % ((j-1), opt)]=self.confDict.get("ldap%s.%s" % (j, opt))
            j=j+1
    i=i+1

for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
    del self.confDict["ldap%s.%s" % ((i-1), opt)]

i=self.cbLdapConnection.currentItem()
self.cbLdapConnection.removeItem(i)
if i > 0:
    self.cbLdapConnection.setCurrentItem(i-1)
    self.config_ldap_set_connection()
elif self.cbLdapConnection.count() > 0:
    self.cbLdapConnection.setCurrentItem(0)
    self.config_ldap_set_connection()
else:
    self.iLdapConnection.clear()
    self.cbLdapMode.setCurrentText("ldap://")
    self.iLdapHost.clear()
    self.iLdapPort.setText("389")
    self.cbLdapBaseDN.clear()
    self.iLdapUser.clear()
    self.iLdapPass.clear()
    self.cLdapRef.setChecked(False)
    self.cLdapCert.setChecked(False)

}

void dKorreio::config_imap_del_connection() {

if not self.cbCyrusConnection.currentText().ascii():
    return True

i=0
while self.confDict.get("imap%s.name" % i):
    if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
        j=i+1
        while self.confDict.get("imap%s.name" % j):
            for opt in ['name','mode','host','port','sieport','user','pass','part']:
                self.confDict["imap%s.%s" % ((j-1), opt)]=self.confDict.get("imap%s.%s" % (j, opt))
            j=j+1
    i=i+1

for opt in ['name','mode','host','port','sieport','user','pass','part']:
    del self.confDict["imap%s.%s" % ((i-1), opt)]

i=self.cbCyrusConnection.currentItem()
self.cbCyrusConnection.removeItem(i)
if i > 0:
    self.cbCyrusConnection.setCurrentItem(i-1)
    self.config_imap_set_connection()
elif self.cbCyrusConnection.count() > 0:
    self.cbCyrusConnection.setCurrentItem(0)
    self.config_imap_set_connection()
else:
    self.iCyrusConnection.clear()
    self.cbCyrusMode.setCurrentText("imap://")
    self.iCyrusHost.clear()
    self.iCyrusPort.setText("143")
    self.iCyrusSievePort.setText("2000")
    self.iCyrusUser.clear()
    self.iCyrusPass.clear()
    self.iCyrusPart.clear()

}

void dKorreio::config_ssh_del_connection() {

if not self.cbSSHConnection.currentText().ascii():
    return True
i=0
while self.confDict.get("ssh%s.name" % i):
    if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
        j=i+1
        while self.confDict.get("ssh%s.name" % j):
            for opt in ['name','host','port','user','pass']:
                self.confDict["ssh%s.%s" % ((j-1), opt)]=self.confDict.get("ssh%s.%s" % (j, opt))
            j=j+1
    i=i+1

for opt in ['name','host','port','user','pass']:
    del self.confDict["ssh%s.%s" % ((i-1), opt)]

i=self.cbSSHConnection.currentItem()
self.cbSSHConnection.removeItem(i)
if i > 0:
    self.cbSSHConnection.setCurrentItem(i-1)
    self.config_ssh_set_connection()
elif self.cbSSHConnection.count() > 0:
    self.cbSSHConnection.setCurrentItem(0)
    self.config_ssh_set_connection()
else:
    self.iSSHConnection.clear()
    self.iSshHost.clear()
    self.iSshPort.setText("22")
    self.iSshUser.clear()
    self.iSshPass.clear()

}

void dKorreio::imap_connect() {

def imap_connect_now():
    ssl = False
    if self.cbCyrusMode.currentText().ascii() == "imaps://":
        ssl = True
    self.m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),ssl)
    msg = "%s%s:%s/%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii(), self.iCyrusUser.text().ascii())
    if self.m.ALIVE:
        if self.m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii()):
            if self.m.ADMIN is not None:
                self.console("Servidor %s conectado com sucesso." % msg)
            else:
                self.m.logout()
                self.console("Erro de conexão: %s (Usuário não é administrador)." % msg)
        else:
            self.console("Erro de conexão: %s (Usuário ou senha inválidos)." % msg)
    else:
        self.console("Erro de conexão: %s (Conexão recusada)." % msg)

def server_changed():
    if active_conn["imap.mode"] != self.cbCyrusMode.currentText().ascii() or active_conn["imap.host"] != self.iCyrusHost.text().ascii() or active_conn["imap.port"] != self.iCyrusPort.text().ascii() or active_conn["imap.user"] != self.iCyrusUser.text().ascii() or active_conn["imap.pass"] != self.iCyrusPass.text().ascii():
        return True
    return False

try:
    # Is connected?
    if self.m.m.isadmin():
        if server_changed():
            imap_connect_now()
    else:
        imap_connect_now()
except AttributeError, e:
    # First connection
    imap_connect_now()

active_conn["imap.mode"] = self.cbCyrusMode.currentText().ascii()
active_conn["imap.host"] = self.iCyrusHost.text().ascii()
active_conn["imap.port"] = self.iCyrusPort.text().ascii()
active_conn["imap.user"] = self.iCyrusUser.text().ascii()
active_conn["imap.pass"] = self.iCyrusPass.text().ascii()

self.tConfShowImapSep.setText("Imap delimiter: "+self.m.SEP)

return self.m
}

void dKorreio::imap_search() {

# Save current selection
oldmailbox=['','']
if self.lvCyrus.childCount() > 1:
    item=self.lvCyrus.currentItem()
    oldmailbox[0]=item.text(0).ascii()
    while item.parent() is not None:
        oldmailbox[0]=item.parent().text(0).ascii()
        item=item.parent()

if self.lvCyrusGlobal.childCount() > 1:
    item=self.lvCyrusGlobal.currentItem()
    oldmailbox[1]=item.text(0).ascii()
    while item.parent() is not None:
        oldmailbox[1]=item.parent().text(0).ascii()
        item=item.parent()

self.korreio_module_clear("imap")

# Imap query
imap = self.imap_connect()
if self.iImapSearch.text().ascii():
    pattern = "user%s%s*" % (imap.SEP, self.iImapSearch.text().ascii())
else:
    pattern = "*"
mailboxes = imap.lm(pattern)

def create_nodes(dn):
    dnlist = dn.split(imap.SEP)
    dnnode = imap.SEP.join(dnlist[:-1])
    if not self.tree.get(dnnode):
        create_nodes(dnnode)
    self.tree[dn] = QListViewItem(self.tree.get(dnnode))
    self.tree[dn].setText(0,dnlist[-1])

try:
    self.tree = {}
    for id in mailboxes:
        idlist = id.split(imap.SEP)
        if re.search("^user",id):
            id = imap.SEP.join(idlist[1:])
            if len(idlist) == 2:
                self.tree[id] = QListViewItem(self.lvCyrus)
                self.tree[id].setText(0, id)
                continue
        elif len(idlist) == 1:
            self.tree[id] = QListViewItem(self.lvCyrusGlobal)
            self.tree[id].setText(0, idlist[0])
            continue
        idlist = id.split(imap.SEP)
        if not self.tree.get(id):
            create_nodes(id)
        else:
            print "Erro obtendo "+ idlist[-1]
except KeyError, e:
    pass

try:
    def selectItem(item):
        self.lvCyrus.setCurrentItem(item)
        item.setOpen(True)
        item.setSelected(True)

    item=self.lvCyrus.firstChild()
    if not oldmailbox[0]:
        selectItem(item)
    else:
        while item is not None:
            if item.text(0).ascii() == oldmailbox[0]:
                selectItem(item)
                self.lvCyrus.scrollBy(0,item.itemPos())
                break
            item=item.nextSibling()
        if item is None:
            selectItem(self.lvCyrus.firstChild())
except AttributeError, e:
    pass

try:
    def selectItem(item):
        self.lvCyrusGlobal.setCurrentItem(item)
        item.setOpen(True)
        item.setSelected(True)

    item=self.lvCyrusGlobal.firstChild()
    if not oldmailbox[1]:
        selectItem(item)
    else:
        item=self.lvCyrusGlobal.firstChild()
        while item is not None:
            if item.text(0).ascii() == oldmailbox[1]:
                selectItem(item)
                self.lvCyrusGlobal.scrollBy(0,item.itemPos())
                break
            item=item.nextSibling()
        if item is None:
            selectItem(self.lvCyrusGlobal.firstChild())

except AttributeError, e:
    pass

if self.lvCyrus.childCount() > 0:
    self.imap_mailbox_clicked()

}

void dKorreio::imap_create_mailbox() {

def create_mailbox(mailbox, partition=None):
    if imap.cm(mailbox, partition):
        self.console("Mailbox %s criada com sucesso." % mailbox)
    else:
        self.console("Erro ao criar mailbox %s." % mailbox)
        raise "Error creating mailbox %s" % mailbox
    
mailbox = self.iImapMailbox.text().ascii()

if not mailbox:
    self.console("Informe a mailbox para ser criada.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""

if self.iCyrusPart.text().ascii():
    create_mailbox("%s%s" % (mbtype, mailbox), self.iCyrusPart.text().ascii())
else:
    create_mailbox("%s%s" % (mbtype, mailbox))

if self.iConfImapQuota.text().ascii():
    imap.sq("%s%s" % (mbtype, mailbox), self.iConfImapQuota.text().ascii())

if self.cbImapMailbox.currentItem() == 0:
    if len(mailbox.split(imap.SEP)) == 1:
        folders=self.confDict.get("imap.dflfolders").split(",")
        for folder in folders:
            if len(folder) == 0: continue
            create_mailbox("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, folder))
            if folder == self.iConfImapACLp.text().ascii():
                imap.sam("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, folder), "anyone", "p")
            if folder == self.iConfImapExpire.text().ascii():
                imap.setannotation("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, folder), "/vendor/cmu/cyrus-imapd/expire", self.iConfImapExpireDays.text().ascii())

self.imap_search()

if self.cbImapMailbox.currentItem() == 1:
    self.imap_gmailbox_clicked()
    self.lvCyrusGlobal.currentItem().setSelected(True)

}

void dKorreio::imap_delete_mailbox() {

def delete_mailbox(mailbox):
    imap.sam(mailbox, self.iCyrusUser.text().ascii(), "c")
    if imap.dm(mailbox):
        self.console("Mailbox %s removida com sucesso." % mailbox)
    else:
        self.console("Erro ao remover Mailbox %s." % mailbox)
        raise "Error deleting mailbox %s" % mailbox

mailbox = self.iImapMailbox.text().ascii()

if not mailbox:
    self.console("Selecione a mailbox para exclusão.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""

if QMessageBox.information( None, "Confirme!",
                                               utf2iso("Confirme a remoção da caixa postal:\n\n    - %s%s\n\n" % (mbtype, mailbox)),
                                               "Sim",
                                               utf2iso("Não") ) != 0:
    self.console("Remoção da mailbox %s%s cancelada." % (mbtype, mailbox) )
    return True

# Cyrus is not recursive for subfolders
if len(mailbox.split(imap.SEP)) > 1:
    for mbox in imap.lm(mbtype+mailbox+imap.SEP+"*"):
        delete_mailbox(mbox)
delete_mailbox(mbtype+mailbox)

if self.cbImapMailbox.currentItem() == 0:
    if self.lvCyrus.currentItem().parent() is None:
        self.lvCyrus.takeItem(self.lvCyrus.currentItem())
    else:
        self.lvCyrus.currentItem().parent().takeItem(self.lvCyrus.currentItem())
    self.lvCyrus.currentItem().setSelected(True)
    self.imap_mailbox_clicked()
else:
    if self.lvCyrusGlobal.currentItem().parent() is None:
        self.lvCyrusGlobal.takeItem(self.lvCyrusGlobal.currentItem())
    else:
        self.lvCyrusGlobal.currentItem().parent().takeItem(self.lvCyrusGlobal.currentItem())
    self.lvCyrusGlobal.currentItem().setSelected(True)
    self.imap_gmailbox_clicked()

}

void dKorreio::imap_set_quota() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplicar a quota.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""
if imap.sq(mbtype+self.iImapMailbox.text().ascii(),self.iQuota.text().ascii()):
    self.console("Quota de %s Kbytes configurada para o usuário %s." % (self.iQuota.text().ascii(), self.iImapMailbox.text().ascii()))
else:
    self.console("Erro: não foi possível configurar quota para o usuário %s" % self.iImapMailbox.text().ascii())

}

void dKorreio::imap_reconstruct() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para reconstruir.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""
if imap.reconstruct(mbtype+self.iImapMailbox.text().ascii()):
    self.console("Mailbox %s esta sendo reconstruida." % self.iImapMailbox.text().ascii())
else:
    self.console("Erro: não foi possível reconstruir mailbox %s." % self.iImapMailbox.text().ascii())

}

void dKorreio::imap_set_annotation_expire() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplica o auto-expire.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""

if imap.setannotation(mbtype+self.iImapMailbox.text().ascii(),"/vendor/cmu/cyrus-imapd/expire",self.iAnnotationExpire.text().ascii()):
    self.console("Auto-expire de %s dias configurado para mailbox %s." % (self.iAnnotationExpire.text().ascii(), self.iImapMailbox.text().ascii()))
else:
    self.console("Erro: não foi possível configurar auto-expire para mailbox %s." % self.iImapMailbox.text().ascii())

}

void dKorreio::imap_partition_search() {

self.lvImapPartition.clear()
self.lvImapPartitionGlobal.clear()
self.cbImapPartition.clear()

partitions = {}

imap = self.imap_connect()

mailboxes = imap.getannotation("user%s%s%%" % (imap.SEP, self.iImapPartitionSearch.text().ascii()), "/vendor/cmu/cyrus-imapd/partition")
if mailboxes[0] == True:
    for mailbox in mailboxes[1]:
        idlist = mailbox.split(imap.SEP)
        item = QListViewItem(self.lvImapPartition)
        item.setText(0, imap.SEP.join(idlist[1:]))
        item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
        if self.cImapSize.isChecked():
            item.setText(2, "%s" % imap.lq(mailbox)[0])
        else:
            item.setText(2, "0")
        partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""

mailboxes = imap.getannotation("%s%%" % self.iImapPartitionSearch.text().ascii(), "/vendor/cmu/cyrus-imapd/partition")
if mailboxes[0] == True:
    for mailbox in mailboxes[1]:
        item = QListViewItem(self.lvImapPartitionGlobal)
        item.setText(0, mailbox)
        item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
        if self.cImapSize.isChecked():
            item.setText(2, "%s" % imap.lq(mailbox)[0])
        else:
            item.setText(2, "0")
        partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""

for i in partitions:
    self.cbImapPartition.insertItem(i)

}

void dKorreio::imap_partition_move() {

imap = self.imap_connect()
item = self.lvImapPartition.firstChild()
while item is not None:
    if item.isSelected():
        self.console("Mailbox %s movida para partição IMAP %s." % (item.text(0).ascii(), self.cbImapPartition.currentText().ascii()))
        mailbox="user%s%s" % (imap.SEP, item.text(0).ascii())
        imap.rename(mailbox, mailbox, self.cbImapPartition.currentText().ascii())
    item=item.nextSibling()

item = self.lvImapPartitionGlobal.firstChild()
while item is not None:
    if item.isSelected():
        self.console("Mailbox %s movida para partição IMAP %s." % (item.text(0).ascii(), self.cbImapPartition.currentText().ascii()))
        imap.rename(item.text(0).ascii(), item.text(0).ascii(), self.cbImapPartition.currentText().ascii())
    item=item.nextSibling()

self.imap_partition_search()

}

void dKorreio::imap_partition_size() {

if not self.cImapSizeUpdate.isChecked():
    self.tlImapSize.setText("0 Mbytes")
    return True

size = 0
item = self.lvImapPartition.firstChild()
while item is not None:
    if item.isSelected():
        size += int(item.text(2).ascii())
    item=item.nextSibling()

item = self.lvImapPartitionGlobal.firstChild()
while item is not None:
    if item.isSelected():
        size += int(item.text(2).ascii())
    item=item.nextSibling()

self.tlImapSize.setText("%s Mbytes" % (size / 1024))

}

void dKorreio::imap_rename( a0, a1 ) {

currentItem = a0

imap = self.imap_connect()
item = a0
new = item.text(0).ascii()
while item.parent() is not None:
    item=item.parent()        
    new = item.text(0).ascii()+imap.SEP+new

if self.mailboxold != new:
    if len(imap.lm(a1+new)) > 0:
        self.console("Mailbox %s já existe." % new)
        currentItem.setText(0,self.mailboxold.split(m.SEP)[-1])
        return True
    if imap.rename(a1+self.mailboxold,a1+new):
        self.console("Mailbox %s renomeada para %s." % (self.mailboxold, new))
    else:
        self.console("Erro: não foi possível renomear %s para %s." % (self.mailboxold, new))
        currentItem.setText(0,self.mailboxold.split(imap.SEP)[-1])

}

void dKorreio::imap_rename_mailbox() {

    self.imap_rename(self.lvCyrus.currentItem(), "user%s" % self.m.SEP)

}

void dKorreio::imap_gmailbox_rename() {

    self.imap_rename(self.lvCyrusGlobal.currentItem(),"")

}


void dKorreio::imap_acl_wizard() {

if self.cbACL.currentItem() == 1:
    self.cbACL.setCurrentText("lrsw")
elif self.cbACL.currentItem() == 2:
    self.cbACL.setCurrentText("lrswi")
elif self.cbACL.currentItem() == 3:
    self.cbACL.setCurrentText("lrswicd")
elif self.cbACL.currentItem() == 4:
    self.cbACL.setCurrentText("p")
elif self.cbACL.currentItem() == 5:
    self.cbACL.setCurrentText("lrswipcda")

}

void dKorreio::imap_acl_del() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplicar a ACL.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""

def acl_del(user):
    if imap.sam(mbtype+self.iImapMailbox.text().ascii(), user, ""):
        self.console("Mailbox %s: ACL de %s removida." % (self.iImapMailbox.text().ascii(), user))
        return True
    else:
        self.console("Erro: não foi possível remover ACL de %s em %s." % (user, self.iImapMailbox.text().ascii()))
        return False

itemDel = []
item = self.lvImapAcl.firstChild()
while item is not None:
    if item.isSelected():
        if acl_del(item.text(0).ascii()):
            itemDel.append(item)
    item = item.nextSibling()

for item in itemDel:
    self.lvImapAcl.takeItem(item)

}

void dKorreio::imap_acl_add() {

if len(self.iImapMailbox.text().ascii()) == 0:
    self.console("Selecione a mailbox para aplicar a ACL.")
    return True

imap = self.imap_connect()
if self.cbImapMailbox.currentItem() == 0:
    mbtype = "user%s" % imap.SEP
else:
    mbtype = ""

AclUser = self.iImapAclUser.text().ascii()
Acl = self.cbACL.currentText().ascii()

for user in AclUser.split(","):
    if imap.sam(mbtype+self.iImapMailbox.text().ascii(), user, Acl):
        item = self.lvImapAcl.firstChild()
        while item is not None:
            if item.text(0).ascii() == user:
                self.lvImapAcl.takeItem(item)
                break
            item = item.nextSibling()
        item = QListViewItem(self.lvImapAcl)
        item.setText(0,user)
        item.setText(1,Acl)
        self.lvImapAcl.setCurrentItem(item)
        self.console("Mailbox %s: ACL %s -> %s " % (self.iImapMailbox.text().ascii(), Acl, AclUser))
    else:
        self.console("Erro ao aplicar ACL %s -> %s em %s." % (Acl, AclUser, self.iImapMailbox.text().ascii()))

}


void dKorreio::imap_acl_clicked() {

item = self.lvImapAcl.currentItem()
self.iImapAclUser.setText(item.text(0).ascii())
self.cbACL.setCurrentText(item.text(1).ascii())

}

void dKorreio::imap_selectall() {

if self.lvImapPartition.hasFocus():
    self.lvImapPartition.selectAll(True)
    self.lvImapPartitionGlobal.selectAll(False)
else:
    self.lvImapPartitionGlobal.selectAll(True)
    self.lvImapPartition.selectAll(False)

}

void dKorreio::imap_mailbox_clicked() {

self.cbImapMailbox.setCurrentItem(0)
self.imap_mailbox_get_info(self.lvCyrus.currentItem(),"user")

}

void dKorreio::imap_gmailbox_clicked() {

self.cbImapMailbox.setCurrentItem(1)
self.imap_mailbox_get_info(self.lvCyrusGlobal.currentItem(),"")

}

void dKorreio::imap_mailbox_get_info( a0, a1 ) {

imap = self.imap_connect()
item = a0
if a1:
    mbtype = a1+imap.SEP
else:
    mbtype = a1

mailbox=item.text(0).ascii()
while item.parent() is not None:
    mailbox=item.parent().text(0).ascii()+imap.SEP+mailbox
    item=item.parent()

self.iImapMailbox.setText(mailbox)

if len(mailbox.split(imap.SEP)) == 1:
    self.pSetQuota.setEnabled(True)
else:
    self.pSetQuota.setEnabled(False)

quota = imap.lq(mbtype+mailbox.split(imap.SEP)[0])
self.iQuotaUsed.setText("%s" % quota[0])
self.iQuota.setText("%s" % quota[1])

self.lvImapAcl.clear()
for user,acl in imap.lam(mbtype+mailbox).items():
    item = QListViewItem(self.lvImapAcl)
    item.setText(0, user)
    item.setText(1, acl)

self.lvImapAcl.setCurrentItem(self.lvImapAcl.firstChild())
self.lvImapAcl.currentItem().setSelected(False)
self.imap_acl_clicked()

expire = imap.getannotation(mbtype+mailbox, "/vendor/cmu/cyrus-imapd/expire")
if expire[0]:
    self.iAnnotationExpire.setText(expire[1][mbtype+mailbox]["/vendor/cmu/cyrus-imapd/expire"])
else:
    self.iAnnotationExpire.setText("")

}

void dKorreio::imap_mailbox_doubleclicked() {

if self.lvCyrus.currentItem().parent() is not None:
    item = self.lvCyrus.currentItem()
    self.mailboxold = item.text(0).ascii()
    while item.parent() is not None:
        item=item.parent()        
        self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
    self.lvCyrus.currentItem().setRenameEnabled(0,True)
    self.lvCyrus.currentItem().startRename(0)
if self.cbUserACL.count() > 1:
    self.cbUserACL.popup()

}

void dKorreio::imap_gmailbox_doubleclicked() {

item = self.lvCyrusGlobal.currentItem()
self.mailboxold = item.text(0).ascii()
while item.parent() is not None:
    item=item.parent()        
    self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
self.lvCyrusGlobal.currentItem().setRenameEnabled(0,True)
self.lvCyrusGlobal.currentItem().startRename(0)

}

void dKorreio::ldap_connect() {

try:
    if self.cLdapCert.isChecked():
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
    else:
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,2)
    if self.cLdapRef.isChecked():
        ldap.set_option(ldap.OPT_REFERRALS,1)
    else:
        ldap.set_option(ldap.OPT_REFERRALS,0)
    server = "%s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii())
    l = ldap.initialize(server)
    l.protocol_version = ldap.VERSION3
    if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
        l.simple_bind(self.iLdapUser.text().ascii(), self.iLdapPass.text().ascii())
    else:
        l.simple_bind()
    self.console("Servidor %s/%s conectado com sucesso." % (server, self.iLdapUser.text().ascii()))
    return l
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)

}

void dKorreio::ldap_search() {

def create_nodes(dn):
    dnlist = dn.split(",")
    dnnode = ",".join(dnlist[1:])
    if not self.nodes.get(dnnode):
        if not dnnode == dnnode.split(",")[0]:
            create_nodes(dnnode)
        else:
            print "Erro fatal: servidor ldap retonou basedn diferente da consulta."
            print "            O servidor exige basedn case sensitive. Verifique."
    self.nodes[dn] = QListViewItem(self.nodes.get(dnnode))
    self.nodes[dn].setText(0,dnlist[0])

if self.cbLdapFilter.count() == 10:
    self.cbLdapFilter.removeItem(4)
self.cbLdapFilter.insertItem(self.cbLdapFilter.currentText().ascii())

basedn = self.cbLdapBaseDN.currentText().ascii()
try:
    olddn = self.ldap_get_dn()
except AttributeError, e:
    olddn = basedn

self.lvLdap.clear()
self.nodes = {}
self.nodes[basedn] = QListViewItem(self.lvLdap)
self.nodes[basedn].setText(0,basedn)
self.nodes[basedn].setOpen(True)

if not self.cbLdapFilter.currentText().ascii():
    filter = "(objectClass=*)"
else:
    filter = "(%s)" % iso2utf(self.cbLdapFilter.currentText().ascii())
self.ldap_cache_attr = self.ldap_query(filter)
if self.ldap_cache_attr is None:
    return

try:
    basednattrs = self.ldap_cache_attr.get(basedn)
    del self.ldap_cache_attr[basedn]
except KeyError, e:
    pass

for dn in self.ldap_cache_attr:
    if not self.nodes.get(dn):
        create_nodes(dn)

try:
    self.ldap_cache_attr[basedn] = basednattrs
except KeyError, e:
    pass

try:
    self.lvLdap.setCurrentItem(self.nodes[olddn])
    self.lvLdap.currentItem().setSelected(True)
except KeyError, e:
    pass

while olddn != basedn:
    try:
        self.nodes[olddn].setOpen(True)
    except KeyError, e:
        pass
    olddn = ",".join(olddn.split(",")[1:])
    if len(olddn) == 0:
        break

self.lvLdap.scrollBy(0,self.lvLdap.currentItem().itemPos())
self.ldap_dn_clicked()

}

void dKorreio::ldap_query( a0 ) {

try:
    l = self.ldap_connect()
    if l is None:
        return
    searchScope = ldap.SCOPE_SUBTREE
    searchFilter = a0
    retrieveAttributes = None
    ldap_result_id = l.search(self.cbLdapBaseDN.currentText().ascii(), searchScope, searchFilter, retrieveAttributes)
    ldap_result = {}
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if result_type == ldap.RES_SEARCH_RESULT:
            break
        elif result_type == ldap.RES_SEARCH_ENTRY:
            ldap_result[utf2iso(result_data[0][0])] = result_data[0][1]
        elif result_type == ldap.RES_SEARCH_REFERENCE:
            ldap_result[result_data[0][1][0].split("/")[3].split("?")[0]] = {'ref': [result_data[0][1][0]]}
        else:
            print "Result type not implemented. "+str(result_type)

    return ldap_result
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    if e[0]["desc"] == "Size limit exceeded":
        return ldap_result

}

void dKorreio::ldap_dn_clicked() {

self.lvLdapAttr.clear()
self.wsLdap.raiseWidget(0)
self.cbLdapStack.setCurrentItem(0)
dn = self.ldap_get_dn()
try:
    for attribute,values in self.ldap_cache_attr.get(dn).items():
        for value in values:
            item = QListViewItem(self.lvLdapAttr)
            item.setText(0,attribute)
            try:
                item.setText(1,utf2iso(value))
            except UnicodeDecodeError, e:
                item.setText(1,value)
except AttributeError, e:
    pass
item = self.lvLdap.currentItem()
if item.parent() is None or item.childCount() != 0:
    self.pLdapDelete.setEnabled(False)
else:
    self.pLdapDelete.setEnabled(True)

if self.lvLdapAttr.childCount() > 0:
    self.lvLdapAttr.setCurrentItem(self.lvLdapAttr.firstChild())
    self.lvLdapAttr.currentItem().setSelected(True)

}

void dKorreio::ldap_dn_doubleclicked() {

if self.lvLdap.currentItem().childCount() == 0:
    self.rdnold = iso2utf(self.ldap_get_dn())
    self.lvLdap.currentItem().setRenameEnabled(0,True)
    self.lvLdap.currentItem().startRename(0)

}

void dKorreio::ldap_insert_user() {

cn = iso2utf(self.iLdapCn.text().ascii())
dn = iso2utf("cn=%s,%s" % (self.iLdapCn.text().ascii(), self.ldap_get_dn()))
attrs = {}
attrs['objectClass'] = ['inetOrgPerson']
attrs['cn'] = [cn]
attrs['sn'] = [cn.split(" ")[-1]]
emails = self.iLdapMail.text().ascii().split(",")
attrs['mail'] = [emails[0]]
if len(emails) > 0:
    attrs['l'] = emails[1:]
salt = ''
for i in range(16):
    salt += choice(letters+digits)
attrs['userPassword'] = ["{SSHA}"+b2a_base64(sha.new(self.iLdapUserP.text().ascii() + salt).digest() + salt)[:-1]]
self.ldap_add(dn,attrs)

}

void dKorreio::ldap_add( a0, a1 ) {
# a0 = DN, a1 = attrs

try:
    ldif = modlist.addModlist(a1)
    l = self.ldap_connect()
    l.add_s(a0,ldif)
    l.unbind_s()
    self.ldap_cache_attr[utf2iso(a0)] = {}
    for tuple in ldif:
        self.ldap_cache_attr[utf2iso(a0)][tuple[0]] = tuple[1]
    item = QListViewItem(self.lvLdap.currentItem())
    item.setText(0, utf2iso(a0.split(',')[0]))
    self.console("Registro %s adicionado com sucesso." % a0)
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False

}

void dKorreio::ldap_modify_clicked() {

stack = self.cbLdapStack.currentItem()
if stack == 0:
    old = {}
    for attribute,values in self.ldap_cache_attr.get(self.ldap_get_dn()).items():
        if old.get(attribute):
           old[attribute].extend(values)
        else:
           old[attribute] = values

    new = {}
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if new.get(item.text(0).ascii()):
            new[item.text(0).ascii()].extend([iso2utf(item.text(1).ascii())])
        else:
            new[item.text(0).ascii()] = [iso2utf(item.text(1).ascii())]
        item = item.nextSibling()

    self.ldap_modify(self.ldap_get_dn(),old,new)

else:
    new = {}
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if item.isSelected():
            dn=iso2utf("%s=%s,%s" % (item.text(0).ascii(), item.text(1).ascii(), self.ldap_get_dn()))
        if new.get(item.text(0).ascii()):
            new[item.text(0).ascii()].extend([iso2utf(item.text(1).ascii())])
        else:
            new[item.text(0).ascii()] = [iso2utf(item.text(1).ascii())]
        item = item.nextSibling()
    try:
        self.ldap_add(dn,new)
    except UnboundLocalError, e:
        self.console("Atenção: selecione o DN entre os atributos.")

}

void dKorreio::ldap_insert_ou() {

dn = iso2utf("ou=%s,%s" % (self.iLdapOu.text().ascii(), self.ldap_get_dn()))
attrs = {}
attrs['objectClass'] = ['organizationalUnit']
attrs['ou'] = [iso2utf(self.iLdapOu.text().ascii())]
self.ldap_add(dn,attrs)

}

void dKorreio::ldap_remove_entry() {

dn =  iso2utf(self.ldap_get_dn())
if dn is not None:
    ok = QMessageBox.information( None, "Confirme!", utf2iso("Confirme a remoção do registro:\n\n    - %s\n\n" % dn), "Sim", utf2iso("Não") )
    if ok == 0:
        if self.ldap_del_entry(dn):
            self.console("Registro %s removido com sucesso." % dn)
            del self.ldap_cache_attr[utf2iso(dn)]
            self.lvLdap.currentItem().parent().takeItem(self.lvLdap.currentItem())
            self.lvLdap.currentItem().setSelected(True)
            self.ldap_dn_clicked()
    else:
        self.console("Remoção do registro %s cancelada." % dn)

}

void dKorreio::ldap_del_entry( a0 ) {

l = self.ldap_connect()
try:
    l.delete_s(a0)
    return True
except ldap.STRONG_AUTH_REQUIRED, e:
    self.parse_exception("LDAPError", e)
    return False

}

void dKorreio::ldap_remove_attr() {

self.lvLdapAttr.takeItem(self.lvLdapAttr.currentItem())
try:
    self.lvLdapAttr.currentItem().setSelected(True)
except AttributeError, e:
    pass

}

void dKorreio::ldap_rename_attr_value() {

if not self.lvLdap.currentItem().text(0).ascii() == "=".join([self.lvLdapAttr.currentItem().text(0).ascii(),self.lvLdapAttr.currentItem().text(1).ascii()]):
    self.lvLdapAttr.currentItem().setRenameEnabled(1,True)
    self.lvLdapAttr.currentItem().startRename(1)

}

void dKorreio::ldap_add_attr() {

attr=self.cbLdapAttr.currentText().ascii()
value=self.cbLdapValue.currentText().ascii()
if not attr:
    return True

attrs = [(attr,value)]

if attr.lower() == 'objectclass':
    if not value:
        return True
    item=self.lvConfLdap.firstChild()
    item=item.firstChild()
    while item is not None:
        subitem=item.firstChild()
        if item.text(0).ascii().lower() == value.lower():
            while subitem is not None:
                if subitem.text(1).ascii() is None: newvalue=""
                else: newvalue=subitem.text(1).ascii()
                attrs.extend([(subitem.text(0).ascii(),newvalue)])
                subitem=subitem.nextSibling()
        item=item.nextSibling()

for attr,value in attrs:
    item=self.lvLdapAttr.firstChild()
    jump=False
    while item is not None:
        if item.text(0).ascii() == attr and (item.text(1).ascii() == value or value == ''):
            jump=True
            break
        item=item.nextSibling()
    if jump:
        continue
    item = QListViewItem(self.lvLdapAttr)
    item.setText(0,attr)
    item.setText(1,value)
if self.cbLdapStack.currentItem() == 4:
    self.console("Atenção: ao criar o registro, pré-selecione um atributo para ser DN.")

}

void dKorreio::ldap_rename_rdn() {

rdnnew=iso2utf(self.lvLdap.currentItem().text(0).ascii())
if self.rdnold.split(",")[0] == rdnnew:
    return True
dnexist = 1
item = self.lvLdapAttr.firstChild()
while item is not None:
    if "%s=%s" % (item.text(0).ascii(), iso2utf(item.text(1).ascii())) == rdnnew:
        dnexist = 0
    item = item.nextSibling()
if self.ldap_modify_rdn(self.rdnold, rdnnew,dnexist):
    self.console("Registro %s alterado com sucesso." % self.rdnold)
    self.lvLdapAttr.clear()
    return True
else:
    self.lvLdap.currentItem().setText(0, self.rdnold.split(",")[0])
    return False

}

void dKorreio::ldap_modify_rdn( a0, a1, a2 ) {
#a0 = oldDN, a1 = newDN, a2 = newDNexist

try:
    l = self.ldap_connect()
    l.rename_s(a0,a1,None,a2)
    del self.ldap_cache_attr[utf2iso(a0)]
    l.unbind_s()
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False

}

void dKorreio::ldap_get_dn() {

item = self.lvLdap.currentItem()
dn = item.text(0).ascii()
while item.parent() is not None:
    dn = dn+","+item.parent().text(0).ascii()
    item = item.parent()
return dn

}

void dKorreio::ldap_change_widgetstack() {

selected_stack = self.cbLdapStack.currentItem()

if self.lvLdap.currentItem() is None:
    if selected_stack != 0:
        self.cbLdapStack.setCurrentItem(0)
        self.console("Atenção: selecione o registro para executar esta ação.")
    return True

if selected_stack < 4:
    self.wsLdap.raiseWidget(selected_stack)
    if selected_stack == 0:
        self.ldap_dn_clicked()
else:
    self.lvLdapAttr.clear()
    self.wsLdap.raiseWidget(0)
    self.console("Atenção: o registro será inserido na base %s." % self.ldap_get_dn())

}

void dKorreio::ldap_passwd() {

if not self.cbLdapUserPassword.isChecked() and not self.cbLdapSambaPassword.isChecked():
    self.console("Atenção: selecione ao menos uma opção.")
    return False

old={}
new={}

if self.cbLdapUserPassword.isChecked():

    salt = ''
    for i in range(16):
        salt += choice(letters+digits)

    old["userPassword"] = 'None'
    hash = self.cbUserPassword.currentText().ascii()
    if hash == "{SSHA}":
        new["userPassword"] = ["{SSHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]]
    elif hash == "{SHA}":
        new["userPassword"] = ["{SHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii()).digest())[:-1]]
    elif hash == "{SMD5}":
        new["userPassword"] = ["{SMD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]]
    elif hash == "{MD5}":
        new["userPassword"] = ["{MD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii()).digest())[:-1]]
    elif hash == "{CRYPT}":
        salt = ''
        for i in [0,1]:
            salt += choice(letters+digits)
        new["userPassword"] = ["{CRYPT}" + crypt.crypt(str(self.iLdapPasswd.text().ascii()),salt)]
    elif hash == "{PLAINTEXT}":
        new["userPassword"] = [self.iLdapPasswd.text().ascii()]
    else:
        self.console("Algoritmo não implementando.")
        return False

if self.cbLdapSambaPassword.isChecked():
    old["sambaNTPassword"] = 'None'
    new["sambaNTPassword"] = [smbpasswd.nthash(self.iLdapPasswd.text().ascii())]
    old["sambaLMPassword"] = 'None'
    new["sambaLMPassword"] = [smbpasswd.lmhash(self.iLdapPasswd.text().ascii())]

self.ldap_modify(self.ldap_get_dn(),old,new)

}

void dKorreio::ldap_modify( a0, a1, a2 ) {

dn=iso2utf(a0)
old=a1
new=a2
try:
    ldif = modlist.modifyModlist(old,new)
    l = self.ldap_connect()
    l.modify_s(dn,ldif)
    l.unbind_s()
    for tuple in ldif:
        if tuple[2] is not None:
            self.ldap_cache_attr[self.ldap_get_dn()][tuple[1]] = tuple[2]
    self.console("Registro %s alterado com sucesso." % dn)
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False

}

void dKorreio::ssh_open( a0 ) {

print_cmd=[]
try:
    self.console("Executando comando remoto: %s." % a0)
    child = pexpect.spawn('ssh -p%s %s@%s "%s"' % (self.iSshPort.text().ascii(), self.iSshUser.text().ascii(), self.iSshHost.text().ascii(), a0))
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        child.sendline('yes')
        child.expect('assword', timeout=2)
        child.sendline(self.iSshPass.text().ascii())
    for line in child:
        line = re.sub("(\n|\r)","",line)
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    self.console("Erro: conexão com %s terminada." % self.iSshHost.text().ascii())
except pexpect.TIMEOUT, t:
    self.console("Erro: conexão com %s sofreu timeout." % self.iSshHost.text().ascii())
return print_cmd

}

void dKorreio::ssh_connect() {

try:
    if self.ssh_connect_active_host != self.iSshHost.text().ascii() or self.ssh_connect_active_port != self.iSshPort.text().ascii() or self.ssh_connect_active_user != self.iSshUser.text().ascii():
        pass
    elif self.ssh:
        return self.ssh
except:
    pass

self.ssh = pxssh.pxssh()
if self.ssh.login ("-p%s %s" % (self.iSshPort.text().ascii(), self.iSshHost.text().ascii()), self.iSshUser.text().ascii(), self.iSshPass.text().ascii()):
    self.ssh_connect_active_host = self.iSshHost.text().ascii()
    self.ssh_connect_active_port = self.iSshPort.text().ascii()
    self.ssh_connect_active_user = self.iSshUser.text().ascii()
    return self.ssh
else:
    raise "Authentication error."

}

void dKorreio::ssh_exec( a0 ) {

s = self.ssh_connect()
s.sendline ("%s > /dev/null 2>&1 && echo OK" % a0)
s.prompt()
if re.search("\nOK", s.before):
    return True
else:
    return False

}

void dKorreio::scp_exec( a0 ) {

try:
    self.console("Salvando arquivo remoto: %s" % a0)
    child = pexpect.spawn('scp -P%s /tmp/korreio.tmp %s@%s:"%s"' % (self.iSshPort.text().ascii(), self.iSshUser.text().ascii(), self.iSshHost.text().ascii(), a0))
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        child.sendline('yes')
        child.expect('assword', timeout=2)
        child.sendline(self.iSshPass.text().ascii())
    print_cmd=[]
    for line in child:
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    self.console("Erro: conexão com %s terminada." % self.iSshHost.text().ascii())
except pexpect.TIMEOUT, t:
    self.console("Erro: conexão com %s sofreu timeout." % self.iSshHost.text().ascii())

}

void dKorreio::postfix_postconf() {

if self.rbPostconfN.isChecked():
    cmd = "postconf -n"
elif self.rbPostconfAll.isChecked():
    cmd = "postconf"
if self.rbPostconfD.isChecked():
    cmd = "postconf -d"
cmd = self.ssh_open(cmd)
self.postconf = {}
lastOpt = self.cbPostconf.currentText().ascii()
self.cbPostconf.clear()
i = 0
for config in cmd:
    if re.search("=",config):
        configlist = config.strip().split("=")
        configlist[0]=configlist[0].strip(" ")
        self.postconf[configlist[0]] = configlist[1]
        self.cbPostconf.insertItem(configlist[0])
        if configlist[0] == lastOpt:
            lastItem = i
        i = i + 1
try:
    self.cbPostconf.setCurrentItem(lastItem)
except UnboundLocalError, e:
    pass
self.postfix_postconf_changed()

}

void dKorreio::postfix_postconf_changed() {

value = self.postconf.get(self.cbPostconf.currentText().ascii())
value = re.sub("( )+"," ",value)
value = re.sub(", ",",",value)
value = re.sub(",",",\n",value)
value = re.sub("^ ","",value)
self.tePostconf.setText(value)

}

void dKorreio::postfix_postconf_save() {

value = re.sub(",",", ",self.tePostconf.text().ascii())
value = re.sub("( )+"," ",value)
value = re.sub("\n","",value)
value = re.sub("\r","",value)
option = self.cbPostconf.currentText().ascii()
if self.ssh_exec("postconf -e %s=%s" % (option, value) ):
    self.console("Opção %s configurada com sucesso." % option )
else:
    self.console("Erro ao configurar %s." % option )

}

void dKorreio::postfix_open_conf() {

value = self.ssh_open("cat "+self.iPostFileOpen.text().ascii())
values = ""
for line in value[1:]:
    values = values+line+"\n"
if re.search("^cat:",values):
    self.console("Arquivo %s nao encontrado." % self.iPostFileOpen.text().ascii())
    return True
self.tePostFileOpen.setText(values)

}

void dKorreio::postfix_save_conf() {

if self.tePostFileOpen.length () == 0:
    self.ssh_exec("rm -f "+self.iPostFileOpen.text().ascii())
    return True
f = open("/tmp/korreio.tmp", 'w')
for line in self.tePostFileOpen.text().ascii():
    f.write(line)
f.close()
self.scp_exec(self.iPostFileOpen.text().ascii())

}

void dKorreio::postfix_postmap() {

file = self.iPostFileOpen.text().ascii()
if self.ssh_exec("postmap %s" % file):
    self.console("Database %s.db gerada com sucesso." % file )
else:
    self.console("Erro ao gerar database %s.db." % file )

}

void dKorreio::postfix_stop() {

if self.ssh_exec("/etc/init.d/postfix stop"):
    self.console("Postfix parado com sucesso.")
else:
    self.console("Erro ao parar Postfix.")

}

void dKorreio::postfix_start() {

if self.ssh_exec("/etc/init.d/postfix start"):
    self.console("Postfix iniciado com sucesso.")
else:
    self.console("Erro ao iniciar Postfix.")

}

void dKorreio::postfix_restart() {

if self.ssh_exec("/etc/init.d/postfix restart"):
    self.console("Postfix reiniciado com sucesso.")
else:
    self.console("Erro ao reiniciar Postfix.")

}

void dKorreio::sieve_search() {

self.lvSieve.clear()
imap = self.imap_connect()
for user in imap.lm("user%s%s%%" % (imap.SEP, self.iSieveSearch.text().ascii())):
    user=user.split(imap.SEP)[1]
    item = QListViewItem(self.lvSieve)
    item.setText(0, user)
    if self.cSieveScript.isChecked():
        s = self.sieve_connect(user)
        scripts = s.listscripts()
        s.logout()
        if scripts[0] == 'OK':
            for script,active in scripts[1]:
                if active:
                    item.setText(1, script)
                    break

}

void dKorreio::sieve_connect( a0 ) {

admin = self.iCyrusUser.text().ascii().split("@")
if admin[0] != self.iCyrusUser.text().ascii():
    user = "%s@%s" % (a0, admin[1])
else:
    user = a0

msg = "sieve://%s:%s/%s" % (self.iCyrusHost.text().ascii(), self.iCyrusSievePort.text().ascii(), user)

s = sievelib.MANAGESIEVE(self.iCyrusHost.text().ascii(),int(self.iCyrusSievePort.text().ascii()))
if s.alive:
    if s.login('PLAIN',user,self.iCyrusPass.text().ascii(),self.iCyrusUser.text().ascii()):
        self.console("Servidor %s conectado com sucesso." % msg)
        return s
    else:
        self.console("Erro de conexão: %s (Usuário ou senha inválidos)." % msg)
else:
    self.console("Erro de conexão: %s (Conexão recusada)." % msg)

return False

}

void dKorreio::sieve_user_clicked() {

self.teSieveScript.clear()
self.cbSieveScript.clear()

item = self.lvSieve.currentItem()
if item is None:
    return True

s = self.sieve_connect(item.text(0).ascii())
scripts = s.listscripts()
s.logout()

if scripts[0] == 'OK':
    for script,active in scripts[1]:
        self.cbSieveScript.insertItem(script)
        if self.lvSieve.currentItem().text(1).ascii() == script:
            self.cbSieveScript.setCurrentText(script)

if self.cbSieveScript.count() > 0:
    self.sieve_get_script()

}

void dKorreio::sieve_get_script() {

s = self.sieve_connect(self.lvSieve.currentItem().text(0).ascii())
script = s.getscript(self.cbSieveScript.currentText().ascii())
s.logout()

self.teSieveScript.clear()
if script[0] == 'OK':
    self.teSieveScript.setText(script[1])

}

void dKorreio::sieve_set_script() {

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        if self.cbSieveScript.currentText().ascii():
            status = s.putscript(self.cbSieveScript.currentText().ascii(),self.teSieveScript.text().ascii().replace("#USER#",item.text(0).ascii()))
            if status == 'OK':
                item.setText(1,self.cbSieveScript.currentText().ascii())
                s.setactive(self.cbSieveScript.currentText().ascii())
        else:
            item.setText(1,"")
            s.setactive()
        s.logout()
    item=item.nextSibling()

self.sieve_get_script()

}

void dKorreio::sieve_unset_script() {

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        s.setactive()
        s.logout()
        item.setText(1,"")
    item=item.nextSibling()

}

void dKorreio::sieve_del_script() {

if not self.cbSieveScript.currentText().ascii():
    self.console("Digite o nome do script.")
    return True

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        if s.deletescript(self.cbSieveScript.currentText().ascii()) == 'OK':
            if self.cbSieveScript.currentText().ascii() == item.text(1).ascii():
                item.setText(1,"")
        s.logout()
    item=item.nextSibling()

self.sieve_get_script()

}

void dKorreio::sieve_select_all() {

self.lvSieve.selectAll(True)

}


void dKorreio::sieve_use_template() {

try:
    sep = self.m.SEP
except AttributeError, e:
    sep = "/"

self.cbSieveScript.setCurrentText("script.siv")
template = self.lbSieveScripts.currentItem()
if template == 0:
    self.teSieveScript.setText("redirect \"destinatario@exemplo.com.br\";\n")

elif template == 1:
    self.teSieveScript.setText("""redirect "destinatario@exemplo.com.br";
keep;
""".replace("        ",""))

elif template == 2:
    self.teSieveScript.setText("""require "fileinto";
if address :contains "from" "remetente1@exemplo.com.br" {
   fileinto "INBOX%(sep)sPasta1";
}
""".replace("        ","") % {'sep':sep})

elif template == 3:
    self.teSieveScript.setText("""require "fileinto";
if address :contains "from" ["from1@dom1.com","from2@dom2.com"] {
    fileinto "INBOX%(sep)sPasta1";
}
elsif address :contains "from" ["from3@dom3.com","from4@dom4.com"] {
    fileinto "INBOX%(sep)sPasta2";
}
""".replace("        ","") % {'sep':sep})

elif template == 4:
    self.teSieveScript.setText("""if header :contains "X-Spam-Flag" "YES" {
    discard;
}
""".replace("        ",""))

elif template == 5:
    self.teSieveScript.setText("""require "fileinto";
if header :contains "X-Spam-Flag" "YES" {
    fileinto "INBOX%(sep)sSpam";
}
""".replace("        ","") % {'sep':sep})

elif template == 6:
    self.console("A macro #USER# será substituida pelo respectivo usuário.")
    if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
        domain="dominio.com.br"
    else:
        domain=self.iCyrusUser.text().ascii().split("@")[1]
    self.teSieveScript.setText("""require ["vacation","fileinto"];

if header :contains "X-Spam-Flag" "YES" {
    fileinto "INBOX%(sep)sSpam";
    stop;
}

vacation :days 5
:subject "Estou ausente"
:addresses ["#USER#@%(domain)s"]
 "Estarei ausente entre os dias ....

 Obrigado,

 --
 xxxxxxxxxxxx";
""".replace("        ","") % {'sep':sep,'domain':domain})

elif template == 7:
    if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
        domain="exemplo.com.br"
    else:
        domain=self.iCyrusUser.text().ascii().split("@")[1]
    self.console("A macro #USER# será substituida pelo respectivo usuário.")
    self.teSieveScript.setText("""require "vacation";
vacation :days 5
:subject "Estou ausente."
:addresses ["#USER#@%s"]
 "Estarei ausente entre os dias ....

 Obrigado,

 --
 xxxxxxxxxxxx";
""".replace("        ","") % domain)
}

void dKorreio::queue_load() {

re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)\s+(\d+)\s([A-Z][a-z][a-z])\s([A-Z][a-z][a-z])\s+(\d+)\s(\d\d:\d\d:\d\d)\s+(.*)')
re_rcpt  = re.compile(r'\s+(.*@.*)\b')
re_log  = re.compile(r'(\s+)?\(.*\)')

self.iQueueMessage.clear()
self.lvQueue.clear()

itemFrom = {}
itemQueueID = {}
self.itemLog = {}

for line in self.ssh_open("postqueue -p"):
    match = re_queueid.match(line)
    if match is not None:
        tmp = ""
        #print "regexp: %s %s %s %s %s %s %s" % (match.group(1), match.group(2), match.group(3), match.group(4), match.group(5), match.group(6), match.group(7))
        mailFrom = match.group(7)
        if not itemFrom.get(mailFrom):
            itemFrom[mailFrom] = QListViewItem(self.lvQueue)
            itemFrom[mailFrom].setText(0,match.group(7))
        queueid = match.group(1)
        itemQueueID[queueid] = QListViewItem(itemFrom[mailFrom])
        itemQueueID[queueid].setText(0,"%s - %s Kb" % (queueid, int(match.group(2)) / 1024) )
        itemQueueID[queueid].setOpen(True)
        continue
    match = re_log.match(line)
    if match is not None:
        tmp = line
        continue
    match = re_rcpt.match(line)
    if match is not None:
        self.itemLog["%s:%s" % ( queueid, match.group(1) )] = tmp
        tmp = ""
        itemRcpt = QListViewItem(itemQueueID[queueid])
        itemRcpt.setText(0,match.group(1))

item = self.lvQueue.firstChild()
total = [0, 0]
while item is not None:
    count = item.childCount()
    subcount = 0
    if count > 0:
        subitem = item.firstChild()
        while subitem is not None:
            subcount = subcount + subitem.childCount()
            subitem.setText(1,"%s" % subitem.childCount())
            subitem = subitem.nextSibling()
    item.setText(1,"%s/%s" % (count, subcount))
    item = item.nextSibling()
    total[0] = total[0] + count
    total[1] = total[1] + subcount

self.console("A fila contém %s mensagens para %s destinatários." % (total[0], total[1]))
self.lvQueue.setColumnWidth(0, 300)
self.lvQueue.setColumnWidth(1, 70)

}

void dKorreio::queue_get_message() {

item = self.lvQueue.currentItem()

if item is None:
    self.pQueueDel.setEnabled(False)
    return True

if item.parent() is None:
    self.pQueueDel.setEnabled(True)
    return True

if item.childCount() == 0:
    self.pQueueDel.setEnabled(False)
    re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)')
    match = re_queueid.match(item.parent().text(0).ascii())
    self.iQueueMessage.setText(self.itemLog.get("%s:%s" % (match.group(1), item.text(0).ascii()) ) )
    return True

queueid = item.text(0).ascii()
re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
match = re_queueid.match(queueid)
if match is not None:
    self.pQueueDel.setEnabled(True)
    self.iQueueMessage.setText("\n".join(self.ssh_open("postcat -q %s" % match.group(1))[1:]))

}

void dKorreio::queue_del_message() {

self.iQueueMessage.clear()

item = self.lvQueue.currentItem()
re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')

if item.parent() is None:
    subitem = item.firstChild()
    success = False
    queuelist = []
    while subitem is not None:
        queuelist.append(re_queueid.match(subitem.text(0).ascii()).group(1))
        if len(queuelist) == 50 or subitem.nextSibling() is None:
            if self.ssh_exec("cat <<< \"%s\" | postsuper -d - " % "\n".join(queuelist)):
                success = True
            queuelist = []
        subitem = subitem.nextSibling()
    if success:
        self.console("%s mensagen(s) removida(s) com sucesso." % item.childCount())
    self.lvQueue.takeItem(item)
    return True

match = re_queueid.match(item.text(0).ascii())
if match is not None:
    if self.ssh_exec("postsuper -d %s" % match.group(1)):
        self.console("Mensagem %s removida com sucesso." % match.group(1))
    else:
        self.console("Não foi possível remover a mensagem %s." % match.group(1))
    count = item.parent().text(1).ascii().split("/")
    if int(count[0]) == 1:
        self.lvQueue.takeItem(item.parent())
    else:
        item.parent().setText(1 ,"%s/%s" % (str(int(count[0]) - 1), str(int(count[1]) - int(item.childCount()))))
        item.parent().takeItem(item)

}

