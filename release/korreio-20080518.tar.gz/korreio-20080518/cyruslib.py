# -*- coding: utf-8 -*-
#
# Cyruslib v0.8-20080216
# Copyright (C) 2007-2008 Reinaldo de Carvalho <reinaldoc@gmail.com>
# Copyright (C) 2003-2006 Gianluigi Tiesi <sherpya@netfarm.it>
# Copyright (C) 2003-2006 NetFarm S.r.l. [http://www.netfarm.it]
#
# Requires python >= 2.3
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.

__version__ = '0.8'
__all__ = [ 'CYRUS' ]
__doc__ = """Cyrus admin wrapper
Adds cyrus-specific commands to imaplib IMAP4 Class
and defines new CYRUS class for cyrus imapd commands

Changelog:
  * SSL support - <reinaldoc@gmail.com>
  * SETANNOTATION support - <reinaldoc@gmail.com>
  * LAM/SAM/LQ/SQ on shared mailboxes support - <reinaldoc@gmail.com>
  * Set unlimited quota support - <reinaldoc@gmail.com>

"""

from sys import stdout,exit
try:
    import imaplib
    import re
except ImportError, e:
    print e
    exit(1)

### Missing commands
# SETANNOTATION "" "/type" ("value.shared" "value")
# type can be motd|comment|admin|shutdown|expire|squat

# GETANNOTATION "" "*" "value.shared"
# result: ANNOTATION "" "/admin" ("value.shared" "admin_value")
# (1 type for each line)

Commands = {
    'SETQUOTA'     : ('AUTH',),
    'CREATE'       : ('AUTH',), # Override for partitions
    'RENAME'       : ('AUTH',), # Override for partitions
    'RECONSTRUCT'  : ('AUTH',),
    'NAMESPACE'    : ('AUTH',),
    'DUMP'         : ('AUTH',), # To check admin status
    'ID'           : ('AUTH',), # Only one ID allowed in non auth mode
    'GETANNOTATION': ('AUTH',),
    'SETANNOTATION': ('AUTH',)
    }

DEFAULT_SEP = '.'
QUOTE       = '"'
DQUOTE      = '""'

imaplib.Commands.update(Commands)

re_ns = re.compile(r'.*\(\(\".*(\.|/)\"\)\).*')
re_q0 = re.compile(r'(.*)\s\(\)')
re_q  = re.compile(r'(.*)\s\(STORAGE (\d+) (\d+)\)')
re_mb = re.compile(r'\((.*)\)\s\".\"\s(.*)')

def imap_ok(res):
    return res.upper().startswith('OK')

def quote(text, qchar=QUOTE):
    return text.join([qchar, qchar])

def unquote(text, qchar=QUOTE):
    return ''.join(text.split(qchar))

def getflags(test):
    flags = []
    for flag in test.split('\\'):
        flag = flag.strip()
        if len(flag): flags.append(flag)
    return flags

### A smart function to return an array of splitted strings
### and honours quoted strings
def splitquote(text):
    data = text.split(QUOTE)
    if len(data) == 1: # no quotes
        res = data[0].split()
    else:
        res = []
        for match in data:
            if len(match.strip()) == 0: continue
            if match[0] == ' ':
                res = res + match.strip().split()
            else:
                res.append(match)
    return res

### return a dictionary from a cyrus info response
def res2dict(data):
    data = splitquote(data)
    datalen = len(data)
    if datalen % 2: # Unmatched pair
        return False, {}
    res = {}
    for i in range(0, datalen, 2):
        res[data[i]] = data[i+1]
    return True, res

### Wrapped new/overloaded IMAP function
### returning False instead of raising an exception
class IMAP4(imaplib.IMAP4):
    def getsep(self):
        """Get mailbox separator"""
        ### yes, ugly but cyradm does it in the same way
        ### also more realable then calling NAMESPACE
        ### and it should be also compatibile with other servers
        try:
            return unquote(self.list(DQUOTE, DQUOTE)[1][0]).split()[1]
        except:
            return DEFAULT_SEP

    def isadmin(self):
        ### A trick to check if the user is admin or not
        ### normal users cannot use dump command
        try:
            res, msg = self._simple_command('DUMP', 'NIL')
            if msg[0].lower().find('denied') == -1:
                return True
        except:
            pass
        return False

    def id(self):
        name = 'ID'
        try:
            typ, dat = self._simple_command(name, 'NIL')
            res, dat = self._untagged_response(typ, dat, name)
        except:
            return False, dat[0]
        return imap_ok(res), dat[0]

    def getannotation(self, mailbox, pattern='*'):
        typ, dat = self._simple_command('GETANNOTATION', mailbox, quote(pattern), quote('value.shared'))
        return self._untagged_response(typ, dat, 'ANNOTATION')

    def setannotation(self, mailbox, desc, value):
        typ, dat = self._simple_command('SETANNOTATION', mailbox, quote(desc), "(%s %s)" % (quote('value.shared'),quote(value)) )
        return self._untagged_response(typ, dat, 'ANNOTATION')

    def setquota(self, mailbox, limit):
        """Set quota of a mailbox"""
        if limit == 0:
            quota = '()'
        else:
            quota = '(STORAGE %s)' % limit
        return self._simple_command('SETQUOTA', mailbox, quota)

    ### Overridden to support partition
    ### Pychecker will complain about non matching signature
    def create(self, mailbox, partition=None):
        """Create a mailbox, partition is optional"""
        if partition is not None:
            return self._simple_command('CREATE', mailbox, partition)
        else:
            return self._simple_command('CREATE', mailbox)

    ### Overridden to support partition
    ### Pychecker: same here
    def rename(self, from_mailbox, to_mailbox, partition=None):
        """Rename a from_mailbox to to_mailbox, partition is optional"""
        if partition is not None:
            return self._simple_command('RENAME', from_mailbox, to_mailbox, partition)
        else:
            return self._simple_command('RENAME', from_mailbox, to_mailbox)

    def reconstruct(self, mailbox):
        return self._simple_command('RECONSTRUCT', mailbox)

class IMAP4_SSL(imaplib.IMAP4_SSL):
    def getsep(self):
        """Get mailbox separator"""
        ### yes, ugly but cyradm does it in the same way
        ### also more realable then calling NAMESPACE
        ### and it should be also compatibile with other servers
        try:
            return unquote(self.list(DQUOTE, DQUOTE)[1][0]).split()[1]
        except:
            return DEFAULT_SEP

    def isadmin(self):
        ### A trick to check if the user is admin or not
        ### normal users cannot use dump command
        try:
            res, msg = self._simple_command('DUMP', 'NIL')
            if msg[0].lower().find('denied') == -1:
                return True
        except:
            pass
        return False

    def id(self):
        name = 'ID'
        try:
            typ, dat = self._simple_command(name, 'NIL')
            res, dat = self._untagged_response(typ, dat, name)
        except:
            return False, dat[0]
        return imap_ok(res), dat[0]

    def getannotation(self, mailbox, pattern='*'):
        typ, dat = self._simple_command('GETANNOTATION', mailbox, quote(pattern), quote('value.shared'))
        return self._untagged_response(typ, dat, 'ANNOTATION')

    def setannotation(self, mailbox, desc, value):
        typ, dat = self._simple_command('SETANNOTATION', mailbox, quote(desc), "(%s %s)" % (quote('value.shared'),quote(value)) )
        return self._untagged_response(typ, dat, 'ANNOTATION')

    def setquota(self, mailbox, limit):
        """Set quota of a mailbox"""
        if limit == 0:
            quota = '()'
        else:
            quota = '(STORAGE %s)' % limit
        return self._simple_command('SETQUOTA', mailbox, quota)

    ### Overridden to support partition
    ### Pychecker will complain about non matching signature
    def create(self, mailbox, partition=None):
        """Create a mailbox, partition is optional"""
        if partition is not None:
            return self._simple_command('CREATE', mailbox, partition)
        else:
            return self._simple_command('CREATE', mailbox)

    ### Overridden to support partition
    ### Pychecker: same here
    def rename(self, from_mailbox, to_mailbox, partition=None):
        """Rename a from_mailbox to to_mailbox, partition is optional"""
        if partition is not None:
            return self._simple_command('RENAME', from_mailbox, to_mailbox, partition)
        else:
            return self._simple_command('RENAME', from_mailbox, to_mailbox)

    def reconstruct(self, mailbox):
        return self._simple_command('RECONSTRUCT', mailbox)

class CYRUS:
    def __init__(self, host = '', port = imaplib.IMAP4_PORT, ssl = False):
        try:
            if ssl:
                self.m = IMAP4_SSL(host, port)
            else:
                self.m = IMAP4(host, port)
            self.ALIVE = True
        except:
            self.ALIVE = False
        self.AUTH = False
        self.VERBOSE = False
        self.ADMIN = None
        self.SEP = DEFAULT_SEP
        self.LOGFD = stdout

    def __del__(self):
        if self.AUTH:
            self.__verbose( '[LOGOUT] calling logout()' )
            self.logout()
    
    def __verbose(self, msg):
        if self.VERBOSE:
            print >> self.LOGFD, msg

    ### Login and store in self.ADMIN admin userid
    def login(self, username, password):
        try:
            res, msg = self.m.login(username, password)
            self.AUTH = True
            if self.m.isadmin():
                self.ADMIN = username
            else:
                self.ADMIN = None
            self.admin_acl = 'c'
            self.SEP = self.m.getsep()
            self.__verbose( '[LOGIN %s] %s: %s' % (username, res, msg[0]) )
            return True
        except Exception, info:
            error = info.args[0].split(':').pop().strip()
            self.__verbose( '[LOGIN %s] BAD: %s' % (username, error) )
            self.AUTH = False
            return False

    def logout(self):
        self.AUTH = False
        self.ADMIN = None
        try:
            res, msg = self.m.logout()
        except Exception, info:
            error = info.args[0].split(':').pop().strip()
            self.__verbose( '[LOGOUT] BAD: %s' % error )
            return False
        self.__verbose( '[LOGOUT] %s: %s' % (res, msg[0]) )
        return True

    def __noauth(self, command, result=False):
        self.__verbose( '[%s] Not in AUTH state' % command.upper() )
        return result

    ### Wrapper to catch exceptions
    def __docommand(self, function, *args):
        wrapped = getattr(self.m, function, None)
        if wrapped is None: return ['BAD', '%s command not implemented' % function.upper()]
        try:
            return wrapped(*args)
        except Exception, info:
            error = info.args[0].split(':').pop().strip()
            if error.upper().startswith('BAD'):
                error = error.split('BAD', 1).pop().strip()
                error = unquote(error[1:-1], '\'')
            return ['BAD', '%s command failed: %s' % (function.upper(), error)]

    ### Info about server
    def id(self):
        if not self.AUTH: return self.__noauth('id')
        res, data = self.m.id()
        data = data.strip()
        if not res or (len(data) < 3): return False, {}
        data = data[1:-1] # Strip ()
        res, rdata = res2dict(data)
        if not res:
            self.__verbose( '[ID] Umatched pairs in result' )
        return res, rdata

    def getannotation(self, mailbox, pattern='*'):
        if not self.AUTH: return self.__noauth('getannotation')
        res, data = self.__docommand('getannotation', mailbox, pattern)
        if not imap_ok(res):
            self.__verbose( '[GETANNOTATION %s] %s: %s' % (mailbox, res, data) )
            return False, {}
        if (len(data) == 1) and data[0] is None:
            self.__verbose( '[GETANNOTATION %s] No results' % (mailbox) )
            return False, {}
        ann = {}
        for annotation in data:
            annotation = annotation.split(' ', 2)
            if len(annotation) != 3:
                self.__verbose( '[GETANNOTATION] Invalid annotation entry' )
                continue
            mbx = unquote(annotation[0])
            key = unquote(annotation[1])
            value = unquote(annotation[2].split(' ', 1).pop()[:-1]).strip()
            self.__verbose( '[GETANNOTATION %s] %s: %s' % (mbx, key, value) )
            if not ann.has_key(mbx):
                ann[mbx] = {}
            if not ann[mbx].has_key(key):
                ann[mbx][key] = value
        return True, ann

    def setannotation(self, mailbox, desc, value):
        if not self.AUTH: return self.__noauth('setannotation')
        res, msg = self.m.setannotation(mailbox, desc, value)
        self.__verbose( '[SETANNOTATION %s] %s: %s' % (mailbox, res, msg[0]) )
        return imap_ok(res)

    def rename(self, fmailbox, tmailbox, partition=None):
        if not self.AUTH: return self.__noauth('rename')
        res, msg = self.m.rename(fmailbox, tmailbox, partition)
        self.__verbose( '[RENAME %s %s] %s: %s' % (fmailbox, tmailbox, res, msg[0]) )
        return imap_ok(res)

    def reconstruct(self, mailbox):
        if not self.AUTH: return self.__noauth('reconstruct')
        res, msg = self.m.reconstruct(mailbox)
        self.__verbose( '[RECONSTRUCT %s] %s: %s' % (mailbox, res, msg[0]) )
        return imap_ok(res)

    def cm(self, mailbox, partition=None):
        """Create mailbox"""
        if not self.AUTH: return self.__noauth('cm')
        res, msg = self.m.create(mailbox, partition)
        self.__verbose( '[CREATE %s partition=%s] %s: %s' % (mailbox, partition, res, msg[0]) )
        return imap_ok(res)

    def dm(self, mailbox):
        """Delete mailbox"""
        if not self.AUTH: return self.__noauth('dm')
        if self.ADMIN: self.m.setacl(mailbox, self.ADMIN, self.admin_acl)
        res, msg = self.m.delete(mailbox)
        self.__verbose( '[DELETE %s] %s: %s' % (mailbox, res, msg[0]) )
        return imap_ok(res)

    def lm(self, pattern="*"):
        """
        List mailboxes, returns dict with list of mailboxes

        To list all mailboxes                       lm()
        To list users top mailboxes                 lm("user/%")
        To list all users mailboxes                 lm("user/*")
        To list users mailboxes startwith a word    lm("user/word*")
        To list global top folders                  lm("%")
        To list global startwith a word             unsupported by server
          suggestion                                lm("word%")

        """
        if not self.AUTH: return self.__noauth('lm', {})
        if pattern == '': pattern = "*"
        if pattern == '%':
            res, ml = self.__docommand('list', '', '%')
        else:
            res, ml = self.__docommand('list', '*', pattern)

        if not imap_ok(res):
            self.__verbose( '[LIST] %s: %s' % (res, ml) )
            return []

        if (len(ml) == 1) and ml[0] is None:
            self.__verbose( '[LIST] No results' )
            return []

        mb = []
        for mailbox in ml:
            res = re_mb.match(mailbox)
            if res is None: continue
            mbe = unquote(res.group(2))
            if 'Noselect' in getflags(res.group(1)): continue
            mb.append(mbe)
        return mb

    def lam(self, mailbox):
        if not self.AUTH: return self.__noauth('lam', {})
        res, acl = self.m.getacl(mailbox)
        if not imap_ok(res):
            self.__verbose( '[GETACL %s] No results' % (mailbox) )
            return None
        acls = {}
        acl_list = splitquote(acl.pop().strip())
        del acl_list[0] # user/username
        for i in range(0, len(acl_list), 2):
            try:
                userid = acl_list[i]
                rights = acl_list[i + 1]
            except Exception, info:
                self.__verbose( '[GETACL %s] BAD: %s' % (mailbox, info.args[0]) )
                continue
            self.__verbose( '[GETACL %s] %s %s' % (mailbox, userid, rights) )
            acls[userid] = rights
        return acls

    def sam(self, mailbox, userid, rights):
        if not self.AUTH: return self.__noauth('sam')
        res, msg = self.m.setacl(mailbox, userid, rights)
        self.__verbose( '[SETACL %s %s %s] %s: %s' % (mailbox, userid, rights, res, msg[0]) )
        return imap_ok(res)

    def lq(self, mailbox):
        if not self.AUTH: return self.__noauth('lq', (-1, -1))
        res, msg = self.m.getquota(mailbox)
        if not imap_ok(res):
            self.__verbose( '[GETQUOTA %s] %s: %s' % (mailbox, res, msg[0]) )
            return 0, 0

        match = re_q0.match(msg[0])
        if match:
            self.__verbose( '[GETQUOTA %s] QUOTA (Unlimited)' % mailbox )
            return 0, 0

        match = re_q.match(msg[0])
        if match is None:
            self.__verbose( '[GETQUOTA %s] BAD: RegExp not matched, please report' % mailbox )
            return 0, 0

        try:
            used = int(match.group(2))
            quota = int(match.group(3))
            self.__verbose( '[GETQUOTA %s] %s: QUOTA (%d/%d)' % (mailbox, res, used, quota) )
            return used, quota
        except:
            self.__verbose( '[GETQUOTA %s] BAD: Error while parsing values' % mailbox )
            return 0, 0

    def sq(self, mailbox, limit):
        if not self.AUTH: return self.__noauth('sq')
        try:
            limit = int(limit)
        except:
            self.__verbose( '[SETQUOTA %s] BAD: Invalid argument %s' % (mailbox, limit) )
            return False
        res, msg = self.m.setquota(mailbox, limit)
        self.__verbose( '[SETQUOTA %s %s] %s: %s' % (mailbox, limit, res, msg[0]) )
        return imap_ok(res)
