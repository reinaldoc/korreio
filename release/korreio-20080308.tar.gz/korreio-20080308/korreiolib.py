# -*- coding: utf-8 -*-
# Korreio v0.1-20080308
# Copyright (c) 2007-2008 -  Reinaldo Carvalho <reinaldoc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.

from qt import *


class dKorreio(QMainWindow):
    def __init__(self,parent = None,name = None,fl = 0):
        QMainWindow.__init__(self,parent,name,fl)
        self.statusBar()

        if not name:
            self.setName("dKorreio")


        self.setCentralWidget(QWidget(self,"qt_central_widget"))
        dKorreioLayout = QGridLayout(self.centralWidget(),1,1,8,6,"dKorreioLayout")

        self.wKorreio = QTabWidget(self.centralWidget(),"wKorreio")
        self.wKorreio.setMinimumSize(QSize(0,550))

        self.tabLdap = QWidget(self.wKorreio,"tabLdap")
        tabLdapLayout = QGridLayout(self.tabLdap,1,1,8,6,"tabLdapLayout")

        self.wsLdap = QWidgetStack(self.tabLdap,"wsLdap")
        self.wsLdap.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Minimum,0,0,self.wsLdap.sizePolicy().hasHeightForWidth()))
        self.wsLdap.setMargin(-8)

        self.WStackPage = QWidget(self.wsLdap,"WStackPage")
        WStackPageLayout = QGridLayout(self.WStackPage,1,1,8,6,"WStackPageLayout")

        self.lvLdapAttr = QListView(self.WStackPage,"lvLdapAttr")
        self.lvLdapAttr.addColumn(self.__tr("Atributo"))
        self.lvLdapAttr.addColumn(self.__tr("Valor"))
        self.lvLdapAttr.setAllColumnsShowFocus(1)
        self.lvLdapAttr.setShowSortIndicator(1)
        self.lvLdapAttr.setResizeMode(QListView.LastColumn)
        self.lvLdapAttr.setDefaultRenameAction(QListView.Accept)

        WStackPageLayout.addMultiCellWidget(self.lvLdapAttr,0,0,0,5)
        spacer2 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout.addItem(spacer2,1,4)

        self.cbLdapAttr = QComboBox(0,self.WStackPage,"cbLdapAttr")
        self.cbLdapAttr.setEditable(1)
        self.cbLdapAttr.setAutoCompletion(1)

        WStackPageLayout.addWidget(self.cbLdapAttr,1,0)

        self.cbLdapValue = QComboBox(0,self.WStackPage,"cbLdapValue")
        self.cbLdapValue.setEditable(1)
        self.cbLdapValue.setAutoCompletion(1)

        WStackPageLayout.addWidget(self.cbLdapValue,1,1)

        self.pLdapAddAttr = QPushButton(self.WStackPage,"pLdapAddAttr")
        self.pLdapAddAttr.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pLdapAddAttr.sizePolicy().hasHeightForWidth()))
        self.pLdapAddAttr.setMaximumSize(QSize(30,32767))

        WStackPageLayout.addWidget(self.pLdapAddAttr,1,2)

        self.pLdapDeleteAttr = QPushButton(self.WStackPage,"pLdapDeleteAttr")
        self.pLdapDeleteAttr.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pLdapDeleteAttr.sizePolicy().hasHeightForWidth()))
        self.pLdapDeleteAttr.setMaximumSize(QSize(30,32767))

        WStackPageLayout.addWidget(self.pLdapDeleteAttr,1,3)

        self.pLdapModify = QPushButton(self.WStackPage,"pLdapModify")

        WStackPageLayout.addWidget(self.pLdapModify,1,5)
        self.wsLdap.addWidget(self.WStackPage,0)

        self.WStackPage_2 = QWidget(self.wsLdap,"WStackPage_2")
        WStackPageLayout_2 = QGridLayout(self.WStackPage_2,1,1,8,6,"WStackPageLayout_2")

        self.KorreioAdd = QGroupBox(self.WStackPage_2,"KorreioAdd")
        self.KorreioAdd.setColumnLayout(0,Qt.Vertical)
        self.KorreioAdd.layout().setSpacing(6)
        self.KorreioAdd.layout().setMargin(8)
        KorreioAddLayout = QGridLayout(self.KorreioAdd.layout())
        KorreioAddLayout.setAlignment(Qt.AlignTop)
        spacer10 = QSpacerItem(170,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        KorreioAddLayout.addItem(spacer10,3,0)

        self.pLdapAddUser = QPushButton(self.KorreioAdd,"pLdapAddUser")

        KorreioAddLayout.addWidget(self.pLdapAddUser,3,1)
        spacer11 = QSpacerItem(130,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        KorreioAddLayout.addMultiCell(spacer11,3,3,2,3)
        spacer28 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        KorreioAddLayout.addMultiCell(spacer28,1,2,3,3)

        self.iLdapCn = QLineEdit(self.KorreioAdd,"iLdapCn")
        self.iLdapCn.setMinimumSize(QSize(220,0))

        KorreioAddLayout.addMultiCellWidget(self.iLdapCn,0,0,1,2)

        self.iLdapMail = QLineEdit(self.KorreioAdd,"iLdapMail")
        self.iLdapMail.setMinimumSize(QSize(220,0))

        KorreioAddLayout.addMultiCellWidget(self.iLdapMail,1,1,1,2)

        self.iLdapUserP = QLineEdit(self.KorreioAdd,"iLdapUserP")
        self.iLdapUserP.setMinimumSize(QSize(220,0))
        self.iLdapUserP.setEchoMode(QLineEdit.Password)

        KorreioAddLayout.addMultiCellWidget(self.iLdapUserP,2,2,1,2)

        self.textLabel3_2 = QLabel(self.KorreioAdd,"textLabel3_2")

        KorreioAddLayout.addWidget(self.textLabel3_2,0,0)

        self.textLabel5 = QLabel(self.KorreioAdd,"textLabel5")

        KorreioAddLayout.addWidget(self.textLabel5,1,0)

        self.textLabel1_3 = QLabel(self.KorreioAdd,"textLabel1_3")

        KorreioAddLayout.addWidget(self.textLabel1_3,2,0)

        WStackPageLayout_2.addWidget(self.KorreioAdd,0,0)
        self.wsLdap.addWidget(self.WStackPage_2,1)

        self.WStackPage_3 = QWidget(self.wsLdap,"WStackPage_3")
        WStackPageLayout_3 = QGridLayout(self.WStackPage_3,1,1,8,6,"WStackPageLayout_3")

        self.groupBox12 = QGroupBox(self.WStackPage_3,"groupBox12")
        self.groupBox12.setColumnLayout(0,Qt.Vertical)
        self.groupBox12.layout().setSpacing(6)
        self.groupBox12.layout().setMargin(8)
        groupBox12Layout = QGridLayout(self.groupBox12.layout())
        groupBox12Layout.setAlignment(Qt.AlignTop)

        self.textLabel2_3 = QLabel(self.groupBox12,"textLabel2_3")

        groupBox12Layout.addWidget(self.textLabel2_3,0,0)

        self.iLdapOu = QLineEdit(self.groupBox12,"iLdapOu")

        groupBox12Layout.addMultiCellWidget(self.iLdapOu,0,0,1,2)

        self.pLdapAddOu = QPushButton(self.groupBox12,"pLdapAddOu")

        groupBox12Layout.addWidget(self.pLdapAddOu,1,1)
        spacer33 = QSpacerItem(71,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox12Layout.addItem(spacer33,1,0)
        spacer31 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox12Layout.addItem(spacer31,0,3)
        spacer32 = QSpacerItem(90,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox12Layout.addMultiCell(spacer32,1,1,2,3)

        WStackPageLayout_3.addWidget(self.groupBox12,0,0)
        self.wsLdap.addWidget(self.WStackPage_3,2)

        self.WStackPage_4 = QWidget(self.wsLdap,"WStackPage_4")
        WStackPageLayout_4 = QGridLayout(self.WStackPage_4,1,1,8,6,"WStackPageLayout_4")

        self.groupBox11 = QGroupBox(self.WStackPage_4,"groupBox11")
        self.groupBox11.setColumnLayout(0,Qt.Vertical)
        self.groupBox11.layout().setSpacing(6)
        self.groupBox11.layout().setMargin(8)
        groupBox11Layout = QGridLayout(self.groupBox11.layout())
        groupBox11Layout.setAlignment(Qt.AlignTop)
        spacer10_2 = QSpacerItem(90,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox11Layout.addItem(spacer10_2,3,0)

        self.textLabel1_3_2 = QLabel(self.groupBox11,"textLabel1_3_2")

        groupBox11Layout.addWidget(self.textLabel1_3_2,2,0)

        self.pLdapPasswd = QPushButton(self.groupBox11,"pLdapPasswd")
        self.pLdapPasswd.setMinimumSize(QSize(100,0))

        groupBox11Layout.addWidget(self.pLdapPasswd,3,1)

        self.cbUserPassword = QComboBox(0,self.groupBox11,"cbUserPassword")
        self.cbUserPassword.setEnabled(1)
        self.cbUserPassword.setMinimumSize(QSize(0,23))
        self.cbUserPassword.setMaximumSize(QSize(100,32767))

        groupBox11Layout.addWidget(self.cbUserPassword,0,3)

        self.cbLdapSambaPassword = QCheckBox(self.groupBox11,"cbLdapSambaPassword")
        self.cbLdapSambaPassword.setMinimumSize(QSize(0,50))

        groupBox11Layout.addMultiCellWidget(self.cbLdapSambaPassword,1,1,1,2)

        self.cbLdapUserPassword = QCheckBox(self.groupBox11,"cbLdapUserPassword")
        self.cbLdapUserPassword.setChecked(1)

        groupBox11Layout.addMultiCellWidget(self.cbLdapUserPassword,0,0,1,2)
        spacer30_2_2 = QSpacerItem(110,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addItem(spacer30_2_2,1,3)
        spacer30_3 = QSpacerItem(170,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addMultiCell(spacer30_3,3,3,2,3)
        spacer11_2 = QSpacerItem(170,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addItem(spacer11_2,3,4)
        spacer30_2 = QSpacerItem(170,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addItem(spacer30_2,1,4)
        spacer30 = QSpacerItem(170,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addItem(spacer30,0,4)
        spacer28_2 = QSpacerItem(170,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addItem(spacer28_2,2,4)

        self.iLdapPasswd = QLineEdit(self.groupBox11,"iLdapPasswd")
        self.iLdapPasswd.setMinimumSize(QSize(270,0))
        self.iLdapPasswd.setMaximumSize(QSize(270,32767))
        self.iLdapPasswd.setEchoMode(QLineEdit.Password)

        groupBox11Layout.addMultiCellWidget(self.iLdapPasswd,2,2,1,3)

        WStackPageLayout_4.addWidget(self.groupBox11,0,0)
        self.wsLdap.addWidget(self.WStackPage_4,3)

        tabLdapLayout.addMultiCellWidget(self.wsLdap,1,2,2,4)

        self.pLdapSearch = QPushButton(self.tabLdap,"pLdapSearch")
        self.pLdapSearch.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pLdapSearch.sizePolicy().hasHeightForWidth()))

        tabLdapLayout.addWidget(self.pLdapSearch,0,2)

        self.pLdapDelete = QPushButton(self.tabLdap,"pLdapDelete")
        self.pLdapDelete.setEnabled(0)
        self.pLdapDelete.setMinimumSize(QSize(80,0))
        self.pLdapDelete.setMaximumSize(QSize(130,26))

        tabLdapLayout.addWidget(self.pLdapDelete,2,0)

        self.lvLdap = QListView(self.tabLdap,"lvLdap")
        self.lvLdap.addColumn(self.__tr("Distinguished Name"))
        self.lvLdap.setMinimumSize(QSize(320,0))
        self.lvLdap.setMaximumSize(QSize(500,32767))
        self.lvLdap.setRootIsDecorated(1)
        self.lvLdap.setResizeMode(QListView.AllColumns)

        tabLdapLayout.addWidget(self.lvLdap,1,0)

        self.lineDiv = QFrame(self.tabLdap,"lineDiv")
        self.lineDiv.setFrameShape(QFrame.VLine)
        self.lineDiv.setFrameShadow(QFrame.Sunken)
        self.lineDiv.setMargin(0)
        self.lineDiv.setFrameShape(QFrame.VLine)

        tabLdapLayout.addMultiCellWidget(self.lineDiv,0,2,1,1)

        self.cbLdapFilter = QComboBox(0,self.tabLdap,"cbLdapFilter")
        self.cbLdapFilter.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed,0,0,self.cbLdapFilter.sizePolicy().hasHeightForWidth()))
        self.cbLdapFilter.setMinimumSize(QSize(320,0))
        self.cbLdapFilter.setMaximumSize(QSize(500,32767))
        self.cbLdapFilter.setAcceptDrops(1)
        self.cbLdapFilter.setEditable(1)
        self.cbLdapFilter.setAutoCompletion(1)
        self.cbLdapFilter.setDuplicatesEnabled(0)

        tabLdapLayout.addWidget(self.cbLdapFilter,0,0)
        spacer26_2 = QSpacerItem(270,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabLdapLayout.addItem(spacer26_2,0,3)

        self.cbLdapStack = QComboBox(0,self.tabLdap,"cbLdapStack")
        self.cbLdapStack.setMinimumSize(QSize(0,25))

        tabLdapLayout.addWidget(self.cbLdapStack,0,4)
        self.wKorreio.insertTab(self.tabLdap,QString.fromLatin1(""))

        self.tabCyrus = QWidget(self.wKorreio,"tabCyrus")
        tabCyrusLayout = QGridLayout(self.tabCyrus,1,1,8,6,"tabCyrusLayout")

        self.tCyrUser = QLabel(self.tabCyrus,"tCyrUser")
        self.tCyrUser.setMinimumSize(QSize(65,0))

        tabCyrusLayout.addWidget(self.tCyrUser,0,0)

        self.textLabel1_2 = QLabel(self.tabCyrus,"textLabel1_2")
        self.textLabel1_2.setMinimumSize(QSize(65,0))

        tabCyrusLayout.addWidget(self.textLabel1_2,2,0)

        self.cbImapMailbox = QComboBox(0,self.tabCyrus,"cbImapMailbox")
        self.cbImapMailbox.setMinimumSize(QSize(75,0))
        self.cbImapMailbox.setMaximumSize(QSize(75,32767))

        tabCyrusLayout.addWidget(self.cbImapMailbox,2,1)

        self.iImapSearch = QLineEdit(self.tabCyrus,"iImapSearch")
        self.iImapSearch.setMinimumSize(QSize(220,0))
        self.iImapSearch.setMaximumSize(QSize(220,32767))

        tabCyrusLayout.addMultiCellWidget(self.iImapSearch,0,0,1,2)

        self.pImapSearch = QPushButton(self.tabCyrus,"pImapSearch")

        tabCyrusLayout.addWidget(self.pImapSearch,0,3)

        self.iImapMailbox = QLineEdit(self.tabCyrus,"iImapMailbox")
        self.iImapMailbox.setEnabled(1)
        self.iImapMailbox.setMinimumSize(QSize(300,0))
        self.iImapMailbox.setMaximumSize(QSize(300,32767))

        tabCyrusLayout.addMultiCellWidget(self.iImapMailbox,2,2,2,4)
        spacer38 = QSpacerItem(140,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabCyrusLayout.addItem(spacer38,2,5)

        self.gbACL = QGroupBox(self.tabCyrus,"gbACL")
        self.gbACL.setMinimumSize(QSize(600,0))
        self.gbACL.setColumnLayout(0,Qt.Vertical)
        self.gbACL.layout().setSpacing(6)
        self.gbACL.layout().setMargin(8)
        gbACLLayout = QGridLayout(self.gbACL.layout())
        gbACLLayout.setAlignment(Qt.AlignTop)

        layout8 = QGridLayout(None,1,1,0,6,"layout8")

        layout7 = QHBoxLayout(None,0,6,"layout7")
        spacer7_2 = QSpacerItem(59,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        layout7.addItem(spacer7_2)

        self.pCyrSetAcl = QPushButton(self.gbACL,"pCyrSetAcl")
        self.pCyrSetAcl.setMinimumSize(QSize(131,0))
        self.pCyrSetAcl.setMaximumSize(QSize(130,25))
        layout7.addWidget(self.pCyrSetAcl)
        spacer8 = QSpacerItem(71,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout7.addItem(spacer8)

        layout8.addLayout(layout7,4,0)

        self.cCyrPermD = QCheckBox(self.gbACL,"cCyrPermD")

        layout8.addWidget(self.cCyrPermD,2,0)

        self.cCyrPermA = QCheckBox(self.gbACL,"cCyrPermA")

        layout8.addWidget(self.cCyrPermA,3,0)

        self.cCyrPermP = QCheckBox(self.gbACL,"cCyrPermP")

        layout8.addWidget(self.cCyrPermP,0,0)

        self.cCyrPermC = QCheckBox(self.gbACL,"cCyrPermC")

        layout8.addWidget(self.cCyrPermC,1,0)

        gbACLLayout.addLayout(layout8,1,1)

        layout9 = QVBoxLayout(None,0,6,"layout9")

        self.cCyrPermL = QCheckBox(self.gbACL,"cCyrPermL")
        self.cCyrPermL.setMinimumSize(QSize(200,0))
        layout9.addWidget(self.cCyrPermL)

        self.cCyrPermR = QCheckBox(self.gbACL,"cCyrPermR")
        layout9.addWidget(self.cCyrPermR)

        self.cCyrPermS = QCheckBox(self.gbACL,"cCyrPermS")
        layout9.addWidget(self.cCyrPermS)

        self.cCyrPermW = QCheckBox(self.gbACL,"cCyrPermW")
        layout9.addWidget(self.cCyrPermW)

        self.cCyrPermI = QCheckBox(self.gbACL,"cCyrPermI")
        layout9.addWidget(self.cCyrPermI)

        gbACLLayout.addLayout(layout9,1,0)

        layout11 = QHBoxLayout(None,0,6,"layout11")

        self.textLabel3 = QLabel(self.gbACL,"textLabel3")
        layout11.addWidget(self.textLabel3)

        self.cbUserACL = QComboBox(0,self.gbACL,"cbUserACL")
        self.cbUserACL.setMinimumSize(QSize(270,0))
        self.cbUserACL.setAcceptDrops(1)
        self.cbUserACL.setEditable(1)
        self.cbUserACL.setAutoCompletion(1)
        self.cbUserACL.setDuplicatesEnabled(0)
        layout11.addWidget(self.cbUserACL)

        self.tlImapACl = QLabel(self.gbACL,"tlImapACl")
        layout11.addWidget(self.tlImapACl)

        self.pCyrNewAcl = QPushButton(self.gbACL,"pCyrNewAcl")
        layout11.addWidget(self.pCyrNewAcl)
        spacer5 = QSpacerItem(56,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout11.addItem(spacer5)

        gbACLLayout.addMultiCellLayout(layout11,0,0,0,1)

        tabCyrusLayout.addMultiCellWidget(self.gbACL,3,3,0,5)

        self.lvCyrus = QListView(self.tabCyrus,"lvCyrus")
        self.lvCyrus.addColumn(self.__tr("IMAP Mailboxes"))
        self.lvCyrus.setShowSortIndicator(1)
        self.lvCyrus.setRootIsDecorated(1)
        self.lvCyrus.setResizeMode(QListView.AllColumns)

        tabCyrusLayout.addMultiCellWidget(self.lvCyrus,1,1,0,5)
        spacer72 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabCyrusLayout.addItem(spacer72,2,6)

        self.pCyrAdd = QPushButton(self.tabCyrus,"pCyrAdd")

        tabCyrusLayout.addWidget(self.pCyrAdd,2,7)

        self.pCyrDelete = QPushButton(self.tabCyrus,"pCyrDelete")
        self.pCyrDelete.setEnabled(1)

        tabCyrusLayout.addWidget(self.pCyrDelete,2,8)

        self.pCyrReconstruct = QPushButton(self.tabCyrus,"pCyrReconstruct")

        tabCyrusLayout.addWidget(self.pCyrReconstruct,2,9)

        self.gbAction = QGroupBox(self.tabCyrus,"gbAction")
        self.gbAction.setColumnLayout(0,Qt.Vertical)
        self.gbAction.layout().setSpacing(6)
        self.gbAction.layout().setMargin(8)
        gbActionLayout = QGridLayout(self.gbAction.layout())
        gbActionLayout.setAlignment(Qt.AlignTop)

        self.textLabel1 = QLabel(self.gbAction,"textLabel1")

        gbActionLayout.addWidget(self.textLabel1,0,0)

        self.textLabel2_2 = QLabel(self.gbAction,"textLabel2_2")

        gbActionLayout.addWidget(self.textLabel2_2,1,0)
        spacer35 = QSpacerItem(125,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        gbActionLayout.addMultiCell(spacer35,2,2,2,4)

        self.iQuotaUsed = QLineEdit(self.gbAction,"iQuotaUsed")
        self.iQuotaUsed.setMinimumSize(QSize(90,25))
        self.iQuotaUsed.setMaximumSize(QSize(90,25))
        self.iQuotaUsed.setAlignment(QLineEdit.AlignRight)
        self.iQuotaUsed.setReadOnly(1)

        gbActionLayout.addWidget(self.iQuotaUsed,0,1)

        self.iQuota = QLineEdit(self.gbAction,"iQuota")
        self.iQuota.setMinimumSize(QSize(90,0))
        self.iQuota.setMaximumSize(QSize(90,32767))
        self.iQuota.setAlignment(QLineEdit.AlignRight)

        gbActionLayout.addWidget(self.iQuota,1,1)

        self.pSetQuota = QPushButton(self.gbAction,"pSetQuota")
        self.pSetQuota.setMaximumSize(QSize(90,32767))

        gbActionLayout.addWidget(self.pSetQuota,2,1)

        self.pSetExpire = QPushButton(self.gbAction,"pSetExpire")
        self.pSetExpire.setMaximumSize(QSize(90,32767))

        gbActionLayout.addWidget(self.pSetExpire,7,1)

        self.iAnnotationExpire = QLineEdit(self.gbAction,"iAnnotationExpire")
        self.iAnnotationExpire.setMaximumSize(QSize(90,32767))
        self.iAnnotationExpire.setAlignment(QLineEdit.AlignRight)

        gbActionLayout.addWidget(self.iAnnotationExpire,6,1)

        self.textLabel2_5 = QLabel(self.gbAction,"textLabel2_5")

        gbActionLayout.addWidget(self.textLabel2_5,6,0)

        self.line3 = QFrame(self.gbAction,"line3")
        self.line3.setFrameShape(QFrame.HLine)
        self.line3.setFrameShadow(QFrame.Sunken)
        self.line3.setFrameShape(QFrame.HLine)

        gbActionLayout.addMultiCellWidget(self.line3,3,5,0,4)
        spacer36 = QSpacerItem(77,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        gbActionLayout.addMultiCell(spacer36,4,6,4,4)
        spacer37 = QSpacerItem(125,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        gbActionLayout.addMultiCell(spacer37,7,7,2,4)

        self.textLabel2_4 = QLabel(self.gbAction,"textLabel2_4")

        gbActionLayout.addWidget(self.textLabel2_4,0,2)
        spacer33_2 = QSpacerItem(87,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        gbActionLayout.addMultiCell(spacer33_2,0,0,3,4)
        spacer34 = QSpacerItem(87,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        gbActionLayout.addMultiCell(spacer34,1,1,3,4)

        self.textLabel2 = QLabel(self.gbAction,"textLabel2")

        gbActionLayout.addWidget(self.textLabel2,1,2)

        self.textLabel1_6 = QLabel(self.gbAction,"textLabel1_6")

        gbActionLayout.addMultiCellWidget(self.textLabel1_6,5,6,2,2)

        tabCyrusLayout.addMultiCellWidget(self.gbAction,3,3,6,9)

        self.lvCyrusGlobal = QListView(self.tabCyrus,"lvCyrusGlobal")
        self.lvCyrusGlobal.addColumn(self.__tr("Global IMAP Mailboxes"))
        self.lvCyrusGlobal.setShowSortIndicator(1)
        self.lvCyrusGlobal.setRootIsDecorated(1)
        self.lvCyrusGlobal.setResizeMode(QListView.AllColumns)

        tabCyrusLayout.addMultiCellWidget(self.lvCyrusGlobal,1,1,6,9)
        spacer1 = QSpacerItem(470,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabCyrusLayout.addMultiCell(spacer1,0,0,4,9)
        self.wKorreio.insertTab(self.tabCyrus,QString.fromLatin1(""))

        self.TabPage = QWidget(self.wKorreio,"TabPage")
        TabPageLayout = QGridLayout(self.TabPage,1,1,8,6,"TabPageLayout")

        self.pImapSelectAll = QPushButton(self.TabPage,"pImapSelectAll")

        TabPageLayout.addWidget(self.pImapSelectAll,0,5)

        self.textLabel1_2_2 = QLabel(self.TabPage,"textLabel1_2_2")
        self.textLabel1_2_2.setMinimumSize(QSize(65,0))

        TabPageLayout.addWidget(self.textLabel1_2_2,2,0)

        self.cbImapPartition = QComboBox(0,self.TabPage,"cbImapPartition")
        self.cbImapPartition.setMinimumSize(QSize(220,0))
        self.cbImapPartition.setMaximumSize(QSize(220,32767))
        self.cbImapPartition.setEditable(1)
        self.cbImapPartition.setAutoCompletion(1)
        self.cbImapPartition.setDuplicatesEnabled(0)

        TabPageLayout.addWidget(self.cbImapPartition,2,1)

        self.tCyrUser_2 = QLabel(self.TabPage,"tCyrUser_2")
        self.tCyrUser_2.setMinimumSize(QSize(65,0))

        TabPageLayout.addWidget(self.tCyrUser_2,0,0)

        self.lvImapPartitionGlobal = QListView(self.TabPage,"lvImapPartitionGlobal")
        self.lvImapPartitionGlobal.addColumn(self.__tr("Global IMAP Mailboxes"))
        self.lvImapPartitionGlobal.addColumn(self.__tr("Partition"))
        self.lvImapPartitionGlobal.setSelectionMode(QListView.Extended)
        self.lvImapPartitionGlobal.setAllColumnsShowFocus(1)
        self.lvImapPartitionGlobal.setShowSortIndicator(1)
        self.lvImapPartitionGlobal.setRootIsDecorated(1)
        self.lvImapPartitionGlobal.setResizeMode(QListView.LastColumn)

        TabPageLayout.addMultiCellWidget(self.lvImapPartitionGlobal,1,1,4,5)
        spacer1_2 = QSpacerItem(290,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout.addItem(spacer1_2,0,4)
        spacer38_2 = QSpacerItem(450,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout.addMultiCell(spacer38_2,2,2,4,5)
        spacer40 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout.addItem(spacer40,0,3)

        self.lvImapPartition = QListView(self.TabPage,"lvImapPartition")
        self.lvImapPartition.addColumn(self.__tr("IMAP Mailboxes"))
        self.lvImapPartition.addColumn(self.__tr("Partition"))
        self.lvImapPartition.setSelectionMode(QListView.Extended)
        self.lvImapPartition.setAllColumnsShowFocus(1)
        self.lvImapPartition.setShowSortIndicator(1)
        self.lvImapPartition.setRootIsDecorated(1)
        self.lvImapPartition.setResizeMode(QListView.LastColumn)

        TabPageLayout.addMultiCellWidget(self.lvImapPartition,1,1,0,3)

        self.iImapPartitionSearch = QLineEdit(self.TabPage,"iImapPartitionSearch")
        self.iImapPartitionSearch.setMinimumSize(QSize(220,0))
        self.iImapPartitionSearch.setMaximumSize(QSize(220,32767))

        TabPageLayout.addWidget(self.iImapPartitionSearch,0,1)

        self.pImapPartitionSearch = QPushButton(self.TabPage,"pImapPartitionSearch")

        TabPageLayout.addWidget(self.pImapPartitionSearch,0,2)
        spacer78 = QSpacerItem(60,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout.addItem(spacer78,2,3)

        self.pImapPartitionMove = QPushButton(self.TabPage,"pImapPartitionMove")
        self.pImapPartitionMove.setMinimumSize(QSize(100,0))
        self.pImapPartitionMove.setMaximumSize(QSize(100,32767))

        TabPageLayout.addWidget(self.pImapPartitionMove,2,2)
        self.wKorreio.insertTab(self.TabPage,QString.fromLatin1(""))

        self.TabPage_2 = QWidget(self.wKorreio,"TabPage_2")
        TabPageLayout_2 = QGridLayout(self.TabPage_2,1,1,8,6,"TabPageLayout_2")

        self.tCyrUser_2_2 = QLabel(self.TabPage_2,"tCyrUser_2_2")
        self.tCyrUser_2_2.setMinimumSize(QSize(65,0))
        self.tCyrUser_2_2.setMaximumSize(QSize(60,32767))

        TabPageLayout_2.addWidget(self.tCyrUser_2_2,0,0)

        self.iSieveSearch = QLineEdit(self.TabPage_2,"iSieveSearch")
        self.iSieveSearch.setMinimumSize(QSize(220,0))
        self.iSieveSearch.setMaximumSize(QSize(220,32767))

        TabPageLayout_2.addWidget(self.iSieveSearch,0,1)

        self.lvSieve = QListView(self.TabPage_2,"lvSieve")
        self.lvSieve.addColumn(self.__tr("IMAP Users"))
        self.lvSieve.addColumn(self.__tr("Script ativo"))
        self.lvSieve.setSelectionMode(QListView.Extended)
        self.lvSieve.setAllColumnsShowFocus(1)
        self.lvSieve.setShowSortIndicator(1)
        self.lvSieve.setRootIsDecorated(1)
        self.lvSieve.setResizeMode(QListView.LastColumn)

        TabPageLayout_2.addMultiCellWidget(self.lvSieve,1,1,0,8)

        self.teSieveScript = QTextEdit(self.TabPage_2,"teSieveScript")
        self.teSieveScript.setMinimumSize(QSize(0,220))

        TabPageLayout_2.addMultiCellWidget(self.teSieveScript,3,4,0,5)
        spacer61_2 = QSpacerItem(200,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout_2.addMultiCell(spacer61_2,2,2,6,8)

        self.cSieveScript = QCheckBox(self.TabPage_2,"cSieveScript")
        self.cSieveScript.setChecked(1)

        TabPageLayout_2.addMultiCellWidget(self.cSieveScript,0,0,3,5)

        self.pSieveSearch = QPushButton(self.TabPage_2,"pSieveSearch")

        TabPageLayout_2.addWidget(self.pSieveSearch,0,2)

        self.pSieveSelectAll = QPushButton(self.TabPage_2,"pSieveSelectAll")

        TabPageLayout_2.addWidget(self.pSieveSelectAll,0,8)
        spacer61 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout_2.addMultiCell(spacer61,0,0,6,7)

        self.textLabel1_2_2_2 = QLabel(self.TabPage_2,"textLabel1_2_2_2")
        self.textLabel1_2_2_2.setMinimumSize(QSize(65,0))

        TabPageLayout_2.addWidget(self.textLabel1_2_2_2,2,0)

        self.cbSieveScript = QComboBox(0,self.TabPage_2,"cbSieveScript")
        self.cbSieveScript.setEditable(1)
        self.cbSieveScript.setAutoCompletion(1)
        self.cbSieveScript.setDuplicatesEnabled(0)

        TabPageLayout_2.addWidget(self.cbSieveScript,2,1)

        self.textLabel1_8 = QLabel(self.TabPage_2,"textLabel1_8")

        TabPageLayout_2.addWidget(self.textLabel1_8,3,6)
        spacer129 = QSpacerItem(121,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout_2.addMultiCell(spacer129,3,3,7,8)

        self.lbSieveScripts = QListBox(self.TabPage_2,"lbSieveScripts")

        TabPageLayout_2.addMultiCellWidget(self.lbSieveScripts,4,4,6,8)

        self.pSieveScriptActive = QPushButton(self.TabPage_2,"pSieveScriptActive")
        self.pSieveScriptActive.setMinimumSize(QSize(100,0))
        self.pSieveScriptActive.setMaximumSize(QSize(100,32767))

        TabPageLayout_2.addWidget(self.pSieveScriptActive,2,2)

        self.pSieveScriptRemove = QPushButton(self.TabPage_2,"pSieveScriptRemove")
        self.pSieveScriptRemove.setMinimumSize(QSize(120,0))
        self.pSieveScriptRemove.setMaximumSize(QSize(120,32767))

        TabPageLayout_2.addWidget(self.pSieveScriptRemove,2,4)

        self.pSieveScriptDisable = QPushButton(self.TabPage_2,"pSieveScriptDisable")
        self.pSieveScriptDisable.setMinimumSize(QSize(110,0))
        self.pSieveScriptDisable.setMaximumSize(QSize(110,32767))

        TabPageLayout_2.addWidget(self.pSieveScriptDisable,2,3)
        spacer61_2_2 = QSpacerItem(100,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout_2.addItem(spacer61_2_2,2,5)
        self.wKorreio.insertTab(self.TabPage_2,QString.fromLatin1(""))

        self.TabPage_3 = QWidget(self.wKorreio,"TabPage_3")
        TabPageLayout_3 = QGridLayout(self.TabPage_3,1,1,8,6,"TabPageLayout_3")

        layout7_2 = QHBoxLayout(None,0,6,"layout7_2")

        self.pPostStart = QPushButton(self.TabPage_3,"pPostStart")
        layout7_2.addWidget(self.pPostStart)

        self.pPostStop = QPushButton(self.TabPage_3,"pPostStop")
        layout7_2.addWidget(self.pPostStop)

        self.pPostRestart = QPushButton(self.TabPage_3,"pPostRestart")
        layout7_2.addWidget(self.pPostRestart)
        spacer27 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout7_2.addItem(spacer27)

        TabPageLayout_3.addLayout(layout7_2,2,0)

        self.buttonGroup2 = QButtonGroup(self.TabPage_3,"buttonGroup2")
        self.buttonGroup2.setColumnLayout(0,Qt.Vertical)
        self.buttonGroup2.layout().setSpacing(6)
        self.buttonGroup2.layout().setMargin(8)
        buttonGroup2Layout = QGridLayout(self.buttonGroup2.layout())
        buttonGroup2Layout.setAlignment(Qt.AlignTop)

        self.pPostMainSave = QPushButton(self.buttonGroup2,"pPostMainSave")

        buttonGroup2Layout.addWidget(self.pPostMainSave,1,6)
        spacer18 = QSpacerItem(81,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2Layout.addMultiCell(spacer18,2,2,0,1)

        self.textLabel6 = QLabel(self.buttonGroup2,"textLabel6")

        buttonGroup2Layout.addWidget(self.textLabel6,1,0)
        spacer31_2 = QSpacerItem(192,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer31_2,0,7)

        self.rbPostconfD = QRadioButton(self.buttonGroup2,"rbPostconfD")

        buttonGroup2Layout.addMultiCellWidget(self.rbPostconfD,0,0,4,6)
        spacer19 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer19,1,1)
        spacer20 = QSpacerItem(20,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer20,1,5)

        self.cbPostconf = QComboBox(0,self.buttonGroup2,"cbPostconf")
        self.cbPostconf.setMinimumSize(QSize(340,0))

        buttonGroup2Layout.addMultiCellWidget(self.cbPostconf,1,1,2,4)

        self.tePostconf = QTextEdit(self.buttonGroup2,"tePostconf")

        buttonGroup2Layout.addMultiCellWidget(self.tePostconf,2,2,2,7)

        self.rbPostconfAll = QRadioButton(self.buttonGroup2,"rbPostconfAll")

        buttonGroup2Layout.addWidget(self.rbPostconfAll,0,3)

        self.textLabel1_4 = QLabel(self.buttonGroup2,"textLabel1_4")

        buttonGroup2Layout.addWidget(self.textLabel1_4,0,0)
        spacer19_2 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer19_2,0,1)
        spacer21 = QSpacerItem(192,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer21,1,7)

        self.rbPostconfN = QRadioButton(self.buttonGroup2,"rbPostconfN")
        self.rbPostconfN.setAutoMask(1)

        buttonGroup2Layout.addWidget(self.rbPostconfN,0,2)

        TabPageLayout_3.addWidget(self.buttonGroup2,0,0)

        self.groupBox10 = QGroupBox(self.TabPage_3,"groupBox10")
        self.groupBox10.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,0,0,self.groupBox10.sizePolicy().hasHeightForWidth()))
        self.groupBox10.setColumnLayout(0,Qt.Vertical)
        self.groupBox10.layout().setSpacing(6)
        self.groupBox10.layout().setMargin(8)
        groupBox10Layout = QGridLayout(self.groupBox10.layout())
        groupBox10Layout.setAlignment(Qt.AlignTop)

        self.textLabel7 = QLabel(self.groupBox10,"textLabel7")

        groupBox10Layout.addWidget(self.textLabel7,0,0)
        spacer14 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer14,0,1)
        spacer15 = QSpacerItem(80,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addMultiCell(spacer15,1,1,0,1)

        self.pPostFileOpen = QPushButton(self.groupBox10,"pPostFileOpen")

        groupBox10Layout.addWidget(self.pPostFileOpen,0,4)
        spacer12 = QSpacerItem(20,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer12,0,3)

        self.tePostFileOpen = QTextEdit(self.groupBox10,"tePostFileOpen")

        groupBox10Layout.addMultiCellWidget(self.tePostFileOpen,1,1,2,9)

        self.iPostFileOpen = QLineEdit(self.groupBox10,"iPostFileOpen")
        self.iPostFileOpen.setMinimumSize(QSize(340,0))

        groupBox10Layout.addWidget(self.iPostFileOpen,0,2)
        spacer13 = QSpacerItem(20,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer13,0,5)
        spacer13_2 = QSpacerItem(20,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer13_2,0,7)

        self.pPostFileSave = QPushButton(self.groupBox10,"pPostFileSave")

        groupBox10Layout.addWidget(self.pPostFileSave,0,6)

        self.pPostFilePostmap = QPushButton(self.groupBox10,"pPostFilePostmap")

        groupBox10Layout.addWidget(self.pPostFilePostmap,0,8)
        spacer17 = QSpacerItem(110,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer17,0,9)

        TabPageLayout_3.addWidget(self.groupBox10,1,0)
        self.wKorreio.insertTab(self.TabPage_3,QString.fromLatin1(""))

        self.TabPage_4 = QWidget(self.wKorreio,"TabPage_4")
        TabPageLayout_4 = QGridLayout(self.TabPage_4,1,1,8,6,"TabPageLayout_4")

        self.iQueueMessage = QTextEdit(self.TabPage_4,"iQueueMessage")

        TabPageLayout_4.addMultiCellWidget(self.iQueueMessage,0,0,1,2)
        spacer2_2 = QSpacerItem(227,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout_4.addItem(spacer2_2,1,1)

        self.pQueueLoad = QPushButton(self.TabPage_4,"pQueueLoad")
        self.pQueueLoad.setMinimumSize(QSize(87,0))
        self.pQueueLoad.setMaximumSize(QSize(87,32767))

        TabPageLayout_4.addWidget(self.pQueueLoad,1,0)

        self.pQueueDel = QPushButton(self.TabPage_4,"pQueueDel")

        TabPageLayout_4.addWidget(self.pQueueDel,1,2)

        self.lvQueue = QListView(self.TabPage_4,"lvQueue")
        self.lvQueue.addColumn(self.__tr("Remetente"))
        self.lvQueue.addColumn(self.__tr("Items"))
        self.lvQueue.setMinimumSize(QSize(400,0))
        self.lvQueue.setAllColumnsShowFocus(1)
        self.lvQueue.setShowSortIndicator(1)
        self.lvQueue.setRootIsDecorated(1)
        self.lvQueue.setResizeMode(QListView.LastColumn)

        TabPageLayout_4.addWidget(self.lvQueue,0,0)
        self.wKorreio.insertTab(self.TabPage_4,QString.fromLatin1(""))

        self.tabConfig = QWidget(self.wKorreio,"tabConfig")
        tabConfigLayout = QGridLayout(self.tabConfig,1,1,8,6,"tabConfigLayout")
        spacer7 = QSpacerItem(410,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabConfigLayout.addItem(spacer7,1,2)

        self.pSaveConfig = QPushButton(self.tabConfig,"pSaveConfig")
        self.pSaveConfig.setMinimumSize(QSize(135,0))
        self.pSaveConfig.setMaximumSize(QSize(135,32767))

        tabConfigLayout.addWidget(self.pSaveConfig,1,1)
        spacer6 = QSpacerItem(260,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        tabConfigLayout.addItem(spacer6,1,0)

        self.lvConfig = QListView(self.tabConfig,"lvConfig")
        self.lvConfig.addColumn(self.__tr("Menu"))
        self.lvConfig.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Expanding,0,0,self.lvConfig.sizePolicy().hasHeightForWidth()))
        self.lvConfig.setShowSortIndicator(1)
        self.lvConfig.setRootIsDecorated(1)
        self.lvConfig.setResizeMode(QListView.LastColumn)

        tabConfigLayout.addWidget(self.lvConfig,0,0)

        self.wsConfig = QWidgetStack(self.tabConfig,"wsConfig")
        self.wsConfig.setFrameShape(QWidgetStack.StyledPanel)
        self.wsConfig.setFrameShadow(QWidgetStack.Raised)
        self.wsConfig.setMargin(0)

        self.sServLdap = QWidget(self.wsConfig,"sServLdap")
        sServLdapLayout = QGridLayout(self.sServLdap,1,1,8,6,"sServLdapLayout")

        self.frame8 = QFrame(self.sServLdap,"frame8")
        self.frame8.setFrameShape(QFrame.NoFrame)
        self.frame8.setFrameShadow(QFrame.Raised)
        frame8Layout = QGridLayout(self.frame8,1,1,12,6,"frame8Layout")

        self.textLabel4 = QLabel(self.frame8,"textLabel4")
        self.textLabel4.setMinimumSize(QSize(100,0))
        self.textLabel4.setMaximumSize(QSize(100,32767))

        frame8Layout.addWidget(self.textLabel4,0,0)

        self.line5 = QFrame(self.frame8,"line5")
        self.line5.setFrameShape(QFrame.HLine)
        self.line5.setFrameShadow(QFrame.Sunken)
        self.line5.setFrameShape(QFrame.HLine)

        frame8Layout.addMultiCellWidget(self.line5,1,1,0,6)

        self.tLdapUser = QLabel(self.frame8,"tLdapUser")

        frame8Layout.addWidget(self.tLdapUser,5,0)
        spacer42 = QSpacerItem(75,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame8Layout.addItem(spacer42,3,6)

        self.tLdapPass = QLabel(self.frame8,"tLdapPass")

        frame8Layout.addWidget(self.tLdapPass,6,0)

        self.tLdapName = QLabel(self.frame8,"tLdapName")

        frame8Layout.addWidget(self.tLdapName,2,0)

        self.tLdapHost = QLabel(self.frame8,"tLdapHost")

        frame8Layout.addWidget(self.tLdapHost,3,0)

        self.tLdapPort = QLabel(self.frame8,"tLdapPort")

        frame8Layout.addWidget(self.tLdapPort,3,4)
        spacer42_2 = QSpacerItem(75,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame8Layout.addItem(spacer42_2,4,6)
        spacer41 = QSpacerItem(20,140,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame8Layout.addItem(spacer41,9,1)

        self.tLdapBaseDN = QLabel(self.frame8,"tLdapBaseDN")

        frame8Layout.addWidget(self.tLdapBaseDN,4,0)

        self.cbLdapConnection = QComboBox(0,self.frame8,"cbLdapConnection")
        self.cbLdapConnection.setMinimumSize(QSize(230,0))
        self.cbLdapConnection.setMaximumSize(QSize(230,32767))

        frame8Layout.addMultiCellWidget(self.cbLdapConnection,0,0,1,2)

        self.pConfDelLdapConnection = QPushButton(self.frame8,"pConfDelLdapConnection")
        self.pConfDelLdapConnection.setMinimumSize(QSize(40,0))
        self.pConfDelLdapConnection.setMaximumSize(QSize(40,32767))

        frame8Layout.addWidget(self.pConfDelLdapConnection,0,3)

        self.iLdapConnection = QLineEdit(self.frame8,"iLdapConnection")

        frame8Layout.addMultiCellWidget(self.iLdapConnection,2,2,1,3)

        self.cbLdapMode = QComboBox(0,self.frame8,"cbLdapMode")
        self.cbLdapMode.setMaximumSize(QSize(80,32767))

        frame8Layout.addWidget(self.cbLdapMode,3,1)

        self.iLdapHost = QLineEdit(self.frame8,"iLdapHost")

        frame8Layout.addMultiCellWidget(self.iLdapHost,3,3,2,3)

        self.iLdapPort = QLineEdit(self.frame8,"iLdapPort")
        self.iLdapPort.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed,0,0,self.iLdapPort.sizePolicy().hasHeightForWidth()))
        self.iLdapPort.setMinimumSize(QSize(50,0))
        self.iLdapPort.setMaximumSize(QSize(50,32767))

        frame8Layout.addWidget(self.iLdapPort,3,5)

        self.cbLdapBaseDN = QComboBox(0,self.frame8,"cbLdapBaseDN")
        self.cbLdapBaseDN.setEditable(1)

        frame8Layout.addMultiCellWidget(self.cbLdapBaseDN,4,4,1,3)

        self.pGetBaseDN = QPushButton(self.frame8,"pGetBaseDN")
        self.pGetBaseDN.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed,0,0,self.pGetBaseDN.sizePolicy().hasHeightForWidth()))

        frame8Layout.addMultiCellWidget(self.pGetBaseDN,4,4,4,5)

        self.iLdapUser = QLineEdit(self.frame8,"iLdapUser")

        frame8Layout.addMultiCellWidget(self.iLdapUser,5,5,1,3)

        self.iLdapPass = QLineEdit(self.frame8,"iLdapPass")
        self.iLdapPass.setEchoMode(QLineEdit.Password)

        frame8Layout.addMultiCellWidget(self.iLdapPass,6,6,1,3)

        self.cLdapRef = QCheckBox(self.frame8,"cLdapRef")

        frame8Layout.addMultiCellWidget(self.cLdapRef,7,7,0,1)

        self.cLdapCert = QCheckBox(self.frame8,"cLdapCert")

        frame8Layout.addMultiCellWidget(self.cLdapCert,8,8,0,3)

        sServLdapLayout.addWidget(self.frame8,1,0)

        self.textLabel3_3_3 = QLabel(self.sServLdap,"textLabel3_3_3")
        self.textLabel3_3_3.setMaximumSize(QSize(32767,21))

        sServLdapLayout.addWidget(self.textLabel3_3_3,0,0)
        self.wsConfig.addWidget(self.sServLdap,0)

        self.WStackPage_5 = QWidget(self.wsConfig,"WStackPage_5")
        WStackPageLayout_5 = QGridLayout(self.WStackPage_5,1,1,8,6,"WStackPageLayout_5")

        self.textLabel3_3_2 = QLabel(self.WStackPage_5,"textLabel3_3_2")
        self.textLabel3_3_2.setMaximumSize(QSize(32767,21))

        WStackPageLayout_5.addWidget(self.textLabel3_3_2,0,0)

        self.frame7 = QFrame(self.WStackPage_5,"frame7")
        self.frame7.setFrameShape(QFrame.NoFrame)
        self.frame7.setFrameShadow(QFrame.Raised)
        frame7Layout = QGridLayout(self.frame7,1,1,12,6,"frame7Layout")

        self.textLabel6_2 = QLabel(self.frame7,"textLabel6_2")
        self.textLabel6_2.setMinimumSize(QSize(100,0))
        self.textLabel6_2.setMaximumSize(QSize(100,32767))

        frame7Layout.addWidget(self.textLabel6_2,0,0)

        self.tCyrusPartition_3 = QLabel(self.frame7,"tCyrusPartition_3")

        frame7Layout.addWidget(self.tCyrusPartition_3,7,0)

        self.tCyrusPartition = QLabel(self.frame7,"tCyrusPartition")

        frame7Layout.addWidget(self.tCyrusPartition,6,0)

        self.tCyrusUser = QLabel(self.frame7,"tCyrusUser")

        frame7Layout.addWidget(self.tCyrusUser,4,0)

        self.tCyrusPass = QLabel(self.frame7,"tCyrusPass")

        frame7Layout.addWidget(self.tCyrusPass,5,0)
        spacer49 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7Layout.addItem(spacer49,3,7)
        spacer69 = QSpacerItem(16,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        frame7Layout.addItem(spacer69,7,2)

        self.textLabel7_2 = QLabel(self.frame7,"textLabel7_2")

        frame7Layout.addWidget(self.textLabel7_2,2,0)
        spacer71 = QSpacerItem(180,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7Layout.addMultiCell(spacer71,7,7,3,4)

        self.tCyrusHost = QLabel(self.frame7,"tCyrusHost")

        frame7Layout.addWidget(self.tCyrusHost,3,0)

        self.tCyrusPort = QLabel(self.frame7,"tCyrusPort")

        frame7Layout.addWidget(self.tCyrusPort,3,5)

        self.line6 = QFrame(self.frame7,"line6")
        self.line6.setFrameShape(QFrame.HLine)
        self.line6.setFrameShadow(QFrame.Sunken)
        self.line6.setFrameShape(QFrame.HLine)

        frame7Layout.addMultiCellWidget(self.line6,1,1,0,7)
        spacer48 = QSpacerItem(21,240,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame7Layout.addItem(spacer48,8,3)

        self.cbCyrusConnection = QComboBox(0,self.frame7,"cbCyrusConnection")
        self.cbCyrusConnection.setMaximumSize(QSize(230,32767))

        frame7Layout.addMultiCellWidget(self.cbCyrusConnection,0,0,1,3)

        self.pConfDelImapConnection = QPushButton(self.frame7,"pConfDelImapConnection")
        self.pConfDelImapConnection.setMinimumSize(QSize(40,0))
        self.pConfDelImapConnection.setMaximumSize(QSize(40,32767))

        frame7Layout.addWidget(self.pConfDelImapConnection,0,4)

        self.iCyrusConnection = QLineEdit(self.frame7,"iCyrusConnection")

        frame7Layout.addMultiCellWidget(self.iCyrusConnection,2,2,1,4)

        self.cbCyrusMode = QComboBox(0,self.frame7,"cbCyrusMode")

        frame7Layout.addMultiCellWidget(self.cbCyrusMode,3,3,1,2)

        self.iCyrusHost = QLineEdit(self.frame7,"iCyrusHost")

        frame7Layout.addMultiCellWidget(self.iCyrusHost,3,3,3,4)

        self.iCyrusPort = QLineEdit(self.frame7,"iCyrusPort")
        self.iCyrusPort.setMinimumSize(QSize(50,0))
        self.iCyrusPort.setMaximumSize(QSize(50,32767))

        frame7Layout.addWidget(self.iCyrusPort,3,6)

        self.iCyrusUser = QLineEdit(self.frame7,"iCyrusUser")

        frame7Layout.addMultiCellWidget(self.iCyrusUser,4,4,1,4)

        self.iCyrusPass = QLineEdit(self.frame7,"iCyrusPass")
        self.iCyrusPass.setEchoMode(QLineEdit.Password)

        frame7Layout.addMultiCellWidget(self.iCyrusPass,5,5,1,4)

        self.iCyrusPart = QLineEdit(self.frame7,"iCyrusPart")

        frame7Layout.addMultiCellWidget(self.iCyrusPart,6,6,1,4)

        self.iCyrusSievePort = QLineEdit(self.frame7,"iCyrusSievePort")
        self.iCyrusSievePort.setMinimumSize(QSize(60,0))
        self.iCyrusSievePort.setMaximumSize(QSize(60,32767))

        frame7Layout.addWidget(self.iCyrusSievePort,7,1)

        WStackPageLayout_5.addWidget(self.frame7,1,0)
        self.wsConfig.addWidget(self.WStackPage_5,1)

        self.WStackPage_6 = QWidget(self.wsConfig,"WStackPage_6")
        WStackPageLayout_6 = QGridLayout(self.WStackPage_6,1,1,8,6,"WStackPageLayout_6")

        self.textLabel3_3 = QLabel(self.WStackPage_6,"textLabel3_3")
        self.textLabel3_3.setMaximumSize(QSize(32767,21))

        WStackPageLayout_6.addWidget(self.textLabel3_3,0,0)

        self.frame4 = QFrame(self.WStackPage_6,"frame4")
        self.frame4.setFrameShape(QFrame.NoFrame)
        self.frame4.setFrameShadow(QFrame.Raised)
        frame4Layout = QGridLayout(self.frame4,1,1,12,6,"frame4Layout")

        self.line7 = QFrame(self.frame4,"line7")
        self.line7.setFrameShape(QFrame.HLine)
        self.line7.setFrameShadow(QFrame.Sunken)
        self.line7.setFrameShape(QFrame.HLine)

        frame4Layout.addMultiCellWidget(self.line7,1,1,0,5)

        self.textLabel8 = QLabel(self.frame4,"textLabel8")
        self.textLabel8.setMinimumSize(QSize(100,0))

        frame4Layout.addWidget(self.textLabel8,0,0)
        spacer51 = QSpacerItem(20,220,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame4Layout.addItem(spacer51,6,1)

        self.tCyrusPass_2 = QLabel(self.frame4,"tCyrusPass_2")

        frame4Layout.addWidget(self.tCyrusPass_2,5,0)

        self.textLabel9 = QLabel(self.frame4,"textLabel9")

        frame4Layout.addWidget(self.textLabel9,2,0)

        self.tCyrusHost_2 = QLabel(self.frame4,"tCyrusHost_2")

        frame4Layout.addWidget(self.tCyrusHost_2,3,0)

        self.tCyrusPort_2 = QLabel(self.frame4,"tCyrusPort_2")

        frame4Layout.addWidget(self.tCyrusPort_2,3,3)

        self.tCyrusUser_2 = QLabel(self.frame4,"tCyrusUser_2")

        frame4Layout.addWidget(self.tCyrusUser_2,4,0)
        spacer52 = QSpacerItem(60,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame4Layout.addItem(spacer52,3,5)

        self.cbSSHConnection = QComboBox(0,self.frame4,"cbSSHConnection")
        self.cbSSHConnection.setMinimumSize(QSize(230,0))

        frame4Layout.addWidget(self.cbSSHConnection,0,1)

        self.pConfDelSshConnection = QPushButton(self.frame4,"pConfDelSshConnection")
        self.pConfDelSshConnection.setMinimumSize(QSize(40,0))
        self.pConfDelSshConnection.setMaximumSize(QSize(40,32767))

        frame4Layout.addWidget(self.pConfDelSshConnection,0,2)

        self.iSSHConnection = QLineEdit(self.frame4,"iSSHConnection")

        frame4Layout.addMultiCellWidget(self.iSSHConnection,2,2,1,2)

        self.iSshHost = QLineEdit(self.frame4,"iSshHost")

        frame4Layout.addMultiCellWidget(self.iSshHost,3,3,1,2)

        self.iSshPort = QLineEdit(self.frame4,"iSshPort")
        self.iSshPort.setMinimumSize(QSize(50,0))
        self.iSshPort.setMaximumSize(QSize(50,32767))

        frame4Layout.addWidget(self.iSshPort,3,4)

        self.iSshUser = QLineEdit(self.frame4,"iSshUser")

        frame4Layout.addMultiCellWidget(self.iSshUser,4,4,1,2)

        self.iSshPass = QLineEdit(self.frame4,"iSshPass")
        self.iSshPass.setEchoMode(QLineEdit.Password)

        frame4Layout.addMultiCellWidget(self.iSshPass,5,5,1,2)

        WStackPageLayout_6.addWidget(self.frame4,1,0)
        self.wsConfig.addWidget(self.WStackPage_6,2)

        self.WStackPage_7 = QWidget(self.wsConfig,"WStackPage_7")
        WStackPageLayout_7 = QGridLayout(self.WStackPage_7,1,1,8,6,"WStackPageLayout_7")
        spacer101 = QSpacerItem(20,21,QSizePolicy.Minimum,QSizePolicy.Fixed)
        WStackPageLayout_7.addItem(spacer101,0,0)

        self.textLabel10 = QLabel(self.WStackPage_7,"textLabel10")
        self.textLabel10.setMaximumSize(QSize(32767,20))

        WStackPageLayout_7.addMultiCellWidget(self.textLabel10,1,1,0,1)

        self.frame9 = QFrame(self.WStackPage_7,"frame9")
        self.frame9.setFrameShape(QFrame.NoFrame)
        self.frame9.setFrameShadow(QFrame.Raised)
        frame9Layout = QGridLayout(self.frame9,1,1,16,6,"frame9Layout")

        self.tConfShowImapServer = QLabel(self.frame9,"tConfShowImapServer")

        frame9Layout.addWidget(self.tConfShowImapServer,0,0)

        self.tConfShowImapUser = QLabel(self.frame9,"tConfShowImapUser")

        frame9Layout.addWidget(self.tConfShowImapUser,1,0)

        self.tConfShowImapSep = QLabel(self.frame9,"tConfShowImapSep")

        frame9Layout.addWidget(self.tConfShowImapSep,2,0)

        WStackPageLayout_7.addMultiCellWidget(self.frame9,2,2,0,1)
        spacer102 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_7.addItem(spacer102,7,1)

        self.textLabel10_3 = QLabel(self.WStackPage_7,"textLabel10_3")
        self.textLabel10_3.setMaximumSize(QSize(32767,20))

        WStackPageLayout_7.addMultiCellWidget(self.textLabel10_3,5,5,0,1)

        self.frame11 = QFrame(self.WStackPage_7,"frame11")
        self.frame11.setFrameShape(QFrame.NoFrame)
        self.frame11.setFrameShadow(QFrame.Raised)
        frame11Layout = QGridLayout(self.frame11,1,1,16,6,"frame11Layout")

        self.tConfShowSshServer = QLabel(self.frame11,"tConfShowSshServer")

        frame11Layout.addWidget(self.tConfShowSshServer,0,0)

        self.tConfShowSshUser = QLabel(self.frame11,"tConfShowSshUser")

        frame11Layout.addWidget(self.tConfShowSshUser,1,0)

        WStackPageLayout_7.addMultiCellWidget(self.frame11,6,6,0,1)

        self.textLabel10_2 = QLabel(self.WStackPage_7,"textLabel10_2")
        self.textLabel10_2.setMaximumSize(QSize(32767,20))

        WStackPageLayout_7.addMultiCellWidget(self.textLabel10_2,3,3,0,1)

        self.frame10 = QFrame(self.WStackPage_7,"frame10")
        self.frame10.setFrameShape(QFrame.NoFrame)
        self.frame10.setFrameShadow(QFrame.Raised)
        frame10Layout = QGridLayout(self.frame10,1,1,16,6,"frame10Layout")

        self.tConfShowLdapServer = QLabel(self.frame10,"tConfShowLdapServer")

        frame10Layout.addWidget(self.tConfShowLdapServer,0,0)

        self.tConfShowLdapUser = QLabel(self.frame10,"tConfShowLdapUser")

        frame10Layout.addWidget(self.tConfShowLdapUser,1,0)

        self.tConfShowLdapBaseDN = QLabel(self.frame10,"tConfShowLdapBaseDN")

        frame10Layout.addWidget(self.tConfShowLdapBaseDN,2,0)

        WStackPageLayout_7.addMultiCellWidget(self.frame10,4,4,0,1)
        self.wsConfig.addWidget(self.WStackPage_7,3)

        self.WStackPage_8 = QWidget(self.wsConfig,"WStackPage_8")
        WStackPageLayout_8 = QGridLayout(self.WStackPage_8,1,1,8,6,"WStackPageLayout_8")

        self.textLabel3_3_2_2 = QLabel(self.WStackPage_8,"textLabel3_3_2_2")
        self.textLabel3_3_2_2.setMaximumSize(QSize(32767,21))

        WStackPageLayout_8.addWidget(self.textLabel3_3_2_2,0,0)

        self.frame7_2 = QFrame(self.WStackPage_8,"frame7_2")
        self.frame7_2.setFrameShape(QFrame.NoFrame)
        self.frame7_2.setFrameShadow(QFrame.Raised)
        frame7_2Layout = QGridLayout(self.frame7_2,1,1,12,6,"frame7_2Layout")
        spacer62 = QSpacerItem(41,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_2Layout.addItem(spacer62,2,4)

        self.line6_2 = QFrame(self.frame7_2,"line6_2")
        self.line6_2.setFrameShape(QFrame.HLine)
        self.line6_2.setFrameShadow(QFrame.Sunken)
        self.line6_2.setFrameShape(QFrame.HLine)

        frame7_2Layout.addMultiCellWidget(self.line6_2,3,3,0,4)

        self.textLabel1_9 = QLabel(self.frame7_2,"textLabel1_9")

        frame7_2Layout.addMultiCellWidget(self.textLabel1_9,0,0,0,3)

        self.lvConfLdap = QListView(self.frame7_2,"lvConfLdap")
        self.lvConfLdap.addColumn(self.__tr("Attributo"))
        self.lvConfLdap.addColumn(self.__tr("Valor"))
        self.lvConfLdap.setMinimumSize(QSize(0,250))
        self.lvConfLdap.setAllColumnsShowFocus(1)
        self.lvConfLdap.setRootIsDecorated(1)
        self.lvConfLdap.setResizeMode(QListView.AllColumns)

        frame7_2Layout.addMultiCellWidget(self.lvConfLdap,1,1,0,4)

        self.iConfLdapAttr = QLineEdit(self.frame7_2,"iConfLdapAttr")

        frame7_2Layout.addWidget(self.iConfLdapAttr,2,0)

        self.iConfLdapValue = QLineEdit(self.frame7_2,"iConfLdapValue")

        frame7_2Layout.addWidget(self.iConfLdapValue,2,1)

        self.pConfLdapAddItem = QPushButton(self.frame7_2,"pConfLdapAddItem")
        self.pConfLdapAddItem.setMinimumSize(QSize(30,0))
        self.pConfLdapAddItem.setMaximumSize(QSize(30,32767))

        frame7_2Layout.addWidget(self.pConfLdapAddItem,2,2)

        self.pConfLdapDelItem = QPushButton(self.frame7_2,"pConfLdapDelItem")
        self.pConfLdapDelItem.setMinimumSize(QSize(30,0))
        self.pConfLdapDelItem.setMaximumSize(QSize(30,32767))

        frame7_2Layout.addWidget(self.pConfLdapDelItem,2,3)
        spacer48_2 = QSpacerItem(21,130,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame7_2Layout.addItem(spacer48_2,4,0)

        WStackPageLayout_8.addWidget(self.frame7_2,1,0)
        self.wsConfig.addWidget(self.WStackPage_8,4)

        self.WStackPage_9 = QWidget(self.wsConfig,"WStackPage_9")
        WStackPageLayout_9 = QGridLayout(self.WStackPage_9,1,1,8,6,"WStackPageLayout_9")

        self.textLabel3_3_2_3 = QLabel(self.WStackPage_9,"textLabel3_3_2_3")
        self.textLabel3_3_2_3.setMaximumSize(QSize(32767,21))

        WStackPageLayout_9.addWidget(self.textLabel3_3_2_3,0,0)

        self.frame7_3 = QFrame(self.WStackPage_9,"frame7_3")
        self.frame7_3.setFrameShape(QFrame.NoFrame)
        self.frame7_3.setFrameShadow(QFrame.Raised)
        frame7_3Layout = QGridLayout(self.frame7_3,1,1,12,6,"frame7_3Layout")

        self.textLabel6_2_3 = QLabel(self.frame7_3,"textLabel6_2_3")
        self.textLabel6_2_3.setMinimumSize(QSize(100,0))

        frame7_3Layout.addWidget(self.textLabel6_2_3,0,0)
        spacer57 = QSpacerItem(150,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addMultiCell(spacer57,1,1,4,6)

        self.textLabel7_2_3 = QLabel(self.frame7_3,"textLabel7_2_3")

        frame7_3Layout.addWidget(self.textLabel7_2_3,3,0)
        spacer58 = QSpacerItem(171,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addMultiCell(spacer58,3,3,3,6)

        self.textLabel1_7 = QLabel(self.frame7_3,"textLabel1_7")

        frame7_3Layout.addWidget(self.textLabel1_7,3,2)

        self.tCyrusHost_4 = QLabel(self.frame7_3,"tCyrusHost_4")

        frame7_3Layout.addWidget(self.tCyrusHost_4,5,0)
        spacer49_3 = QSpacerItem(62,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addItem(spacer49_3,5,6)
        spacer48_3 = QSpacerItem(21,80,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame7_3Layout.addItem(spacer48_3,8,1)
        spacer59 = QSpacerItem(211,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addMultiCell(spacer59,7,7,2,6)

        self.tCyrusUser_4 = QLabel(self.frame7_3,"tCyrusUser_4")

        frame7_3Layout.addWidget(self.tCyrusUser_4,7,0)

        self.tCyrusPort_4_2 = QLabel(self.frame7_3,"tCyrusPort_4_2")

        frame7_3Layout.addWidget(self.tCyrusPort_4_2,5,5)

        self.tCyrusPort_4 = QLabel(self.frame7_3,"tCyrusPort_4")

        frame7_3Layout.addWidget(self.tCyrusPort_4,5,2)

        self.line6_3 = QFrame(self.frame7_3,"line6_3")
        self.line6_3.setFrameShape(QFrame.HLine)
        self.line6_3.setFrameShadow(QFrame.Sunken)
        self.line6_3.setFrameShape(QFrame.HLine)

        frame7_3Layout.addMultiCellWidget(self.line6_3,2,2,0,6)

        self.line8 = QFrame(self.frame7_3,"line8")
        self.line8.setFrameShape(QFrame.HLine)
        self.line8.setFrameShadow(QFrame.Sunken)
        self.line8.setFrameShape(QFrame.HLine)

        frame7_3Layout.addMultiCellWidget(self.line8,4,4,0,6)

        self.line9 = QFrame(self.frame7_3,"line9")
        self.line9.setFrameShape(QFrame.HLine)
        self.line9.setFrameShadow(QFrame.Sunken)
        self.line9.setFrameShape(QFrame.HLine)

        frame7_3Layout.addMultiCellWidget(self.line9,6,6,0,6)

        self.lbConfImapFolders = QListBox(self.frame7_3,"lbConfImapFolders")
        self.lbConfImapFolders.setMinimumSize(QSize(0,100))
        self.lbConfImapFolders.setMaximumSize(QSize(32767,100))

        frame7_3Layout.addMultiCellWidget(self.lbConfImapFolders,0,0,1,2)

        self.iConfImapFolder = QLineEdit(self.frame7_3,"iConfImapFolder")

        frame7_3Layout.addMultiCellWidget(self.iConfImapFolder,1,1,1,2)

        self.pConfImapFoldersDel = QPushButton(self.frame7_3,"pConfImapFoldersDel")
        self.pConfImapFoldersDel.setMinimumSize(QSize(30,0))
        self.pConfImapFoldersDel.setMaximumSize(QSize(30,32767))

        frame7_3Layout.addWidget(self.pConfImapFoldersDel,0,3)

        self.pConfImapFoldersAdd = QPushButton(self.frame7_3,"pConfImapFoldersAdd")
        self.pConfImapFoldersAdd.setMinimumSize(QSize(30,0))
        self.pConfImapFoldersAdd.setMaximumSize(QSize(30,32767))

        frame7_3Layout.addWidget(self.pConfImapFoldersAdd,1,3)

        self.iConfImapQuota = QLineEdit(self.frame7_3,"iConfImapQuota")

        frame7_3Layout.addWidget(self.iConfImapQuota,3,1)

        self.iConfImapExpire = QLineEdit(self.frame7_3,"iConfImapExpire")

        frame7_3Layout.addWidget(self.iConfImapExpire,5,1)

        self.iConfImapExpireDays = QLineEdit(self.frame7_3,"iConfImapExpireDays")
        self.iConfImapExpireDays.setMinimumSize(QSize(50,0))
        self.iConfImapExpireDays.setMaximumSize(QSize(50,32767))

        frame7_3Layout.addMultiCellWidget(self.iConfImapExpireDays,5,5,3,4)

        self.iConfImapACLp = QLineEdit(self.frame7_3,"iConfImapACLp")

        frame7_3Layout.addWidget(self.iConfImapACLp,7,1)

        WStackPageLayout_9.addWidget(self.frame7_3,1,0)
        self.wsConfig.addWidget(self.WStackPage_9,5)

        tabConfigLayout.addMultiCellWidget(self.wsConfig,0,0,1,2)
        self.wKorreio.insertTab(self.tabConfig,QString.fromLatin1(""))

        dKorreioLayout.addWidget(self.wKorreio,0,0)

        self.tlConsole = QLabel(self.centralWidget(),"tlConsole")
        self.tlConsole.setMinimumSize(QSize(0,24))
        self.tlConsole.setFrameShape(QLabel.StyledPanel)
        self.tlConsole.setFrameShadow(QLabel.Sunken)

        dKorreioLayout.addWidget(self.tlConsole,1,0)



        self.languageChange()

        self.resize(QSize(955,621).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)

        self.connect(self.cbCyrusConnection,SIGNAL("activated(const QString&)"),self.action_config_imap_connection)
        self.connect(self.cbCyrusMode,SIGNAL("activated(const QString&)"),self.action_imap_selectall)
        self.connect(self.cbLdapConnection,SIGNAL("activated(const QString&)"),self.action_config_ldap_connection)
        self.connect(self.cbLdapMode,SIGNAL("activated(const QString&)"),self.action_ldap_set_port)
        self.connect(self.cbLdapStack,SIGNAL("activated(const QString&)"),self.action_ldap_change_widgetstack)
        self.connect(self.cbPostconf,SIGNAL("activated(const QString&)"),self.postconf_changed)
        self.connect(self.cbSieveScript,SIGNAL("activated(int)"),self.sieve_get_script)
        self.connect(self.cbSSHConnection,SIGNAL("activated(const QString&)"),self.action_config_ssh_connection)
        self.connect(self.cbUserACL,SIGNAL("activated(const QString&)"),self.action_imap_show_permissions)
        self.connect(self.lbSieveScripts,SIGNAL("selectionChanged()"),self.sieve_use_template)
        self.connect(self.lbSieveScripts,SIGNAL("clicked(QListBoxItem*)"),self.sieve_use_template)
        self.connect(self.lvConfig,SIGNAL("selectionChanged()"),self.action_config_change_widgetstack)
        self.connect(self.lvCyrus,SIGNAL("currentChanged(QListViewItem*)"),self.action_imap_mailbox_clicked)
        self.connect(self.lvCyrus,SIGNAL("doubleClicked(QListViewItem*)"),self.action_mailbox_doubleclicked)
        self.connect(self.lvCyrus,SIGNAL("itemRenamed(QListViewItem*,int)"),self.imap_rename_mailbox)
        self.connect(self.lvCyrusGlobal,SIGNAL("doubleClicked(QListViewItem*)"),self.action_gmailbox_doubleclicked)
        self.connect(self.lvCyrusGlobal,SIGNAL("currentChanged(QListViewItem*)"),self.action_imap_gmailbox_clicked)
        self.connect(self.lvCyrusGlobal,SIGNAL("itemRenamed(QListViewItem*,int)"),self.imap_gmailbox_rename)
        self.connect(self.lvLdap,SIGNAL("selectionChanged()"),self.ldap_dn_clicked)
        self.connect(self.lvLdap,SIGNAL("doubleClicked(QListViewItem*)"),self.ldap_dn_doubleclicked)
        self.connect(self.lvLdap,SIGNAL("itemRenamed(QListViewItem*,int)"),self.ldap_rename_rdn)
        self.connect(self.lvLdapAttr,SIGNAL("doubleClicked(QListViewItem*)"),self.ldap_rename_attr_value)
        self.connect(self.lvQueue,SIGNAL("currentChanged(QListViewItem*)"),self.queue_get_message)
        self.connect(self.lvSieve,SIGNAL("clicked(QListViewItem*)"),self.sieve_user_clicked)
        self.connect(self.pConfDelImapConnection,SIGNAL("clicked()"),self.action_del_imap_connection)
        self.connect(self.pConfDelLdapConnection,SIGNAL("clicked()"),self.action_del_ldap_connection)
        self.connect(self.pConfDelSshConnection,SIGNAL("clicked()"),self.action_del_ssh_connection)
        self.connect(self.pConfImapFoldersAdd,SIGNAL("clicked()"),self.action_conf_imap_add_default_folder)
        self.connect(self.pConfImapFoldersDel,SIGNAL("clicked()"),self.action_conf_imap_del_default_folder)
        self.connect(self.pConfLdapAddItem,SIGNAL("clicked()"),self.action_conf_ldap_add_attr)
        self.connect(self.pConfLdapDelItem,SIGNAL("clicked()"),self.action_conf_ldap_del_attr)
        self.connect(self.pCyrAdd,SIGNAL("clicked()"),self.imap_create_mailbox)
        self.connect(self.pCyrDelete,SIGNAL("clicked()"),self.imap_delete_mailbox)
        self.connect(self.pCyrNewAcl,SIGNAL("clicked()"),self.imap_new_acl)
        self.connect(self.pCyrReconstruct,SIGNAL("clicked()"),self.imap_reconstruct)
        self.connect(self.pCyrSetAcl,SIGNAL("clicked()"),self.imap_set_acl)
        self.connect(self.pGetBaseDN,SIGNAL("clicked()"),self.get_ldap_basedn)
        self.connect(self.pImapPartitionMove,SIGNAL("clicked()"),self.imap_partition_move)
        self.connect(self.pImapPartitionSearch,SIGNAL("clicked()"),self.imap_partition_search)
        self.connect(self.pImapSearch,SIGNAL("clicked()"),self.imap_search)
        self.connect(self.pImapSelectAll,SIGNAL("clicked()"),self.action_imap_selectall)
        self.connect(self.pLdapAddAttr,SIGNAL("clicked()"),self.ldap_add_attr)
        self.connect(self.pLdapAddOu,SIGNAL("clicked()"),self.ldap_insert_ou)
        self.connect(self.pLdapAddUser,SIGNAL("clicked()"),self.ldap_insert_user)
        self.connect(self.pLdapDelete,SIGNAL("clicked()"),self.ldap_remove_entry)
        self.connect(self.pLdapDeleteAttr,SIGNAL("clicked()"),self.ldap_remove_attr)
        self.connect(self.pLdapModify,SIGNAL("clicked()"),self.action_ldap_modify)
        self.connect(self.pLdapPasswd,SIGNAL("clicked()"),self.ldap_passwd)
        self.connect(self.pLdapSearch,SIGNAL("clicked()"),self.ldap_search)
        self.connect(self.pPostFileOpen,SIGNAL("clicked()"),self.postfix_open_conf)
        self.connect(self.pPostFilePostmap,SIGNAL("clicked()"),self.postfix_postmap)
        self.connect(self.pPostFileSave,SIGNAL("clicked()"),self.postfix_save_conf)
        self.connect(self.pPostMainSave,SIGNAL("clicked()"),self.postconf_save)
        self.connect(self.pPostRestart,SIGNAL("clicked()"),self.postfix_restart)
        self.connect(self.pPostStart,SIGNAL("clicked()"),self.postfix_start)
        self.connect(self.pPostStop,SIGNAL("clicked()"),self.postfix_stop)
        self.connect(self.pQueueDel,SIGNAL("clicked()"),self.queue_del_message)
        self.connect(self.pQueueLoad,SIGNAL("clicked()"),self.queue_load)
        self.connect(self.pSaveConfig,SIGNAL("clicked()"),self.save_config)
        self.connect(self.pSetExpire,SIGNAL("clicked()"),self.imap_set_annotation_expire)
        self.connect(self.pSetQuota,SIGNAL("clicked()"),self.imap_set_quota)
        self.connect(self.pSieveScriptActive,SIGNAL("clicked()"),self.sieve_set_script)
        self.connect(self.pSieveScriptDisable,SIGNAL("clicked()"),self.sieve_unset_script)
        self.connect(self.pSieveScriptRemove,SIGNAL("clicked()"),self.sieve_del_script)
        self.connect(self.pSieveSearch,SIGNAL("clicked()"),self.sieve_search)
        self.connect(self.pSieveSelectAll,SIGNAL("clicked()"),self.sieve_select_all)
        self.connect(self.rbPostconfAll,SIGNAL("clicked()"),self.postfix_postconf)
        self.connect(self.rbPostconfD,SIGNAL("clicked()"),self.postfix_postconf)
        self.connect(self.rbPostconfN,SIGNAL("clicked()"),self.postfix_postconf)
        self.connect(self.wKorreio,SIGNAL("currentChanged(QWidget*)"),self.action_module_changed)

        self.init()


    def languageChange(self):
        self.setCaption(self.__trUtf8("\x4b\x6f\x72\x72\x65\x69\x6f\x20\x2d\x20\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\xc3\xa7\xc3\xa3\x6f\x20\x64\x65\x20\x43\x6f\x72\x72\x65\x69\x6f\x20\x45\x6c\x65\x74\x72\xc3\xb4\x6e\x69\x63\x6f"))
        self.lvLdapAttr.header().setLabel(0,self.__tr("Atributo"))
        self.lvLdapAttr.header().setLabel(1,self.__tr("Valor"))
        self.cbLdapAttr.clear()
        self.cbLdapAttr.insertItem(QString.null)
        self.cbLdapAttr.insertItem(self.__tr("objectClass"))
        self.cbLdapAttr.insertItem(self.__tr("structuralObjectClass"))
        self.cbLdapAttr.insertItem(self.__tr("uid"))
        self.cbLdapAttr.insertItem(self.__tr("cn"))
        self.cbLdapAttr.insertItem(self.__tr("sn"))
        self.cbLdapAttr.insertItem(self.__tr("mail"))
        self.cbLdapAttr.insertItem(self.__tr("gecos"))
        self.cbLdapAttr.insertItem(self.__tr("description"))
        self.cbLdapAttr.insertItem(self.__tr("homeDirectory"))
        self.cbLdapAttr.insertItem(self.__tr("loginShell"))
        self.cbLdapAttr.insertItem(self.__tr("uidNumber"))
        self.cbLdapAttr.insertItem(self.__tr("gidNumber"))
        self.cbLdapAttr.insertItem(self.__tr("userPassword"))
        self.cbLdapAttr.insertItem(self.__tr("shadowLastChange"))
        self.cbLdapAttr.insertItem(self.__tr("shadowMin"))
        self.cbLdapAttr.insertItem(self.__tr("shadowMax"))
        self.cbLdapAttr.insertItem(self.__tr("shadowWarning"))
        self.cbLdapAttr.insertItem(self.__tr("shadowInactive"))
        self.cbLdapAttr.insertItem(self.__tr("shadowExpire"))
        self.cbLdapAttr.insertItem(self.__tr("shadowFlag"))
        self.cbLdapAttr.insertItem(self.__tr("carLicense"))
        self.cbLdapAttr.insertItem(self.__tr("displayName"))
        self.cbLdapAttr.insertItem(self.__tr("homePhone"))
        self.cbLdapAttr.insertItem(self.__tr("l"))
        self.cbLdapAttr.insertItem(self.__tr("street"))
        self.cbLdapAttr.insertItem(self.__tr("postalCode"))
        self.cbLdapAttr.insertItem(self.__tr("o"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLMPassword"))
        self.cbLdapAttr.insertItem(self.__tr("sambaNTPassword"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdLastSet"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogoffTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaKickoffTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdCanChange"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdMustChange"))
        self.cbLdapAttr.insertItem(self.__tr("sambaAcctFlags"))
        self.cbLdapAttr.insertItem(self.__tr("sambaHomePath"))
        self.cbLdapAttr.insertItem(self.__tr("sambaHomeDrive"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonScript"))
        self.cbLdapAttr.insertItem(self.__tr("sambaProfilePath"))
        self.cbLdapAttr.insertItem(self.__tr("sambaUserWorkstations"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPrimaryGroupSID"))
        self.cbLdapAttr.insertItem(self.__tr("sambaDomainName"))
        self.cbLdapAttr.insertItem(self.__tr("sambaMungedDial"))
        self.cbLdapAttr.insertItem(self.__tr("sambaBadPasswordCount"))
        self.cbLdapAttr.insertItem(self.__tr("sambaBadPasswordTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPasswordHistory"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonHours"))
        self.cbLdapAttr.insertItem(self.__tr("mailAlternateAddress"))
        self.cbLdapAttr.insertItem(self.__tr("ipHostNumber"))
        self.cbLdapAttr.insertItem(self.__tr("owner"))
        self.cbLdapAttr.insertItem(self.__tr("manager"))
        self.cbLdapAttr.insertItem(self.__tr("serialNumber"))
        self.cbLdapAttr.insertItem(self.__tr("member"))
        self.cbLdapValue.clear()
        self.cbLdapValue.insertItem(QString.null)
        self.cbLdapValue.insertItem(self.__tr("inetOrgPerson"))
        self.cbLdapValue.insertItem(self.__tr("posixAccount"))
        self.cbLdapValue.insertItem(self.__tr("sambaSamAccount"))
        self.cbLdapValue.insertItem(self.__tr("shadowAccount"))
        self.cbLdapValue.insertItem(self.__tr("top"))
        self.cbLdapValue.insertItem(self.__tr("simpleSecurityObject"))
        self.cbLdapValue.insertItem(self.__tr("organization"))
        self.cbLdapValue.insertItem(self.__tr("organizationalUnit"))
        self.cbLdapValue.insertItem(self.__tr("organizationalRole"))
        self.cbLdapValue.insertItem(self.__tr("groupOfNames"))
        self.cbLdapValue.insertItem(self.__tr("device"))
        self.cbLdapValue.insertItem(self.__tr("ipHost"))
        self.cbLdapValue.insertItem(self.__tr("ipNetwork"))
        self.cbLdapValue.insertItem(self.__tr("referral"))
        self.cbLdapValue.insertItem(self.__tr("extensibleObject"))
        self.pLdapAddAttr.setText(self.__tr("+"))
        self.pLdapDeleteAttr.setText(self.__tr("-"))
        self.pLdapModify.setText(self.__tr("Aplicar"))
        self.KorreioAdd.setTitle(self.__trUtf8("\x43\x61\x64\x61\x73\x74\x72\x61\x72\x20\x55\x73\x75\xc3\xa1\x72\x69\x6f"))
        self.pLdapAddUser.setText(self.__tr("Cadastrar"))
        self.textLabel3_2.setText(self.__tr("Nome (cn):"))
        self.textLabel5.setText(self.__tr("E-mail (mail):"))
        self.textLabel1_3.setText(self.__tr("Senha (userPassword):"))
        self.groupBox12.setTitle(self.__tr("Cadastrar Unidade"))
        self.textLabel2_3.setText(self.__tr("Unidade (ou):"))
        self.pLdapAddOu.setText(self.__tr("Cadastrar"))
        self.groupBox11.setTitle(self.__tr("Trocar senha"))
        self.textLabel1_3_2.setText(self.__tr("Senha:"))
        self.pLdapPasswd.setText(self.__tr("Trocar"))
        self.cbUserPassword.clear()
        self.cbUserPassword.insertItem(self.__tr("{SSHA}"))
        self.cbUserPassword.insertItem(self.__tr("{SMD5}"))
        self.cbUserPassword.insertItem(self.__tr("{CRYPT}"))
        self.cbUserPassword.insertItem(self.__tr("{SHA}"))
        self.cbUserPassword.insertItem(self.__tr("{MD5}"))
        self.cbUserPassword.insertItem(self.__tr("{TEXT}"))
        self.cbLdapSambaPassword.setText(self.__tr("sambaLMPassword\n"
"sambaNTPassword"))
        self.cbLdapUserPassword.setText(self.__tr("userPassword"))
        self.pLdapSearch.setText(self.__tr("Pesquisar"))
        self.pLdapDelete.setText(self.__tr("Remover"))
        self.lvLdap.header().setLabel(0,self.__tr("Distinguished Name"))
        self.cbLdapFilter.clear()
        self.cbLdapFilter.insertItem(self.__tr("objectClass=*"))
        self.cbLdapFilter.insertItem(self.__tr("ou=*"))
        self.cbLdapFilter.insertItem(self.__tr("cn=*"))
        self.cbLdapFilter.insertItem(self.__tr("uid=*"))
        self.cbLdapFilter.insertItem(self.__tr("mail=*"))
        self.cbLdapStack.clear()
        self.cbLdapStack.insertItem(self.__tr("Ldap Browser"))
        self.cbLdapStack.insertItem(self.__trUtf8("\x4e\x6f\x76\x6f\x20\x55\x73\x75\xc3\xa1\x72\x69\x6f\x20\x64\x65\x20\x45\x2d\x6d\x61\x69\x6c"))
        self.cbLdapStack.insertItem(self.__tr("Nova Unidade"))
        self.cbLdapStack.insertItem(self.__tr("Trocar Senha"))
        self.cbLdapStack.insertItem(self.__tr("Novo registro LDAP"))
        self.wKorreio.changeTab(self.tabLdap,self.__tr("LDAP Manager"))
        self.tCyrUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.textLabel1_2.setText(self.__tr("Mailbox:"))
        self.cbImapMailbox.clear()
        self.cbImapMailbox.insertItem(self.__tr("user"))
        self.cbImapMailbox.insertItem(self.__tr("global"))
        self.pImapSearch.setText(self.__tr("Pesquisar"))
        self.gbACL.setTitle(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xb5\x65\x73\x20\x64\x65\x20\x61\x63\x65\x73\x73\x6f\x20\x61\x20\x4d\x61\x69\x6c\x62\x6f\x78"))
        self.pCyrSetAcl.setText(self.__tr("Aplicar"))
        self.cCyrPermD.setText(self.__tr("D: Remover mailbox ou mensagens*"))
        self.cCyrPermA.setText(self.__trUtf8("\x41\x3a\x20\x41\x6c\x74\x65\x72\x61\x72\x20\x6f\x70\xc3\xa7\xc3\xb5\x65\x73\x20\x64\x65\x20\x61\x63\x65\x73\x73\x6f"))
        self.cCyrPermP.setText(self.__tr("P: Permitir submission (user+mailbox@)"))
        self.cCyrPermC.setText(self.__tr("C: Criar mailbox filhas"))
        self.cCyrPermL.setText(self.__trUtf8("\x4c\x3a\x20\x4c\x69\x73\x74\xc3\xa1\x76\x65\x6c"))
        self.cCyrPermR.setText(self.__tr("R: Ler Mensagens"))
        self.cCyrPermS.setText(self.__tr("S: Ler Flags"))
        self.cCyrPermW.setText(self.__tr("W: Alterar Flags"))
        self.cCyrPermI.setText(self.__tr("I: Inserir Mensagem"))
        self.textLabel3.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.tlImapACl.setText(self.__tr("(0)"))
        self.pCyrNewAcl.setText(self.__tr("Nova ACL"))
        self.lvCyrus.header().setLabel(0,self.__tr("IMAP Mailboxes"))
        self.pCyrAdd.setText(self.__tr("Criar"))
        self.pCyrDelete.setText(self.__tr("Remover"))
        self.pCyrReconstruct.setText(self.__tr("Reconstruir"))
        self.gbAction.setTitle(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xb5\x65\x73"))
        self.textLabel1.setText(self.__tr("Utilizado:"))
        self.textLabel2_2.setText(self.__tr("Limite:"))
        self.pSetQuota.setText(self.__tr("Aplicar"))
        self.pSetExpire.setText(self.__tr("Aplicar"))
        self.textLabel2_5.setText(self.__tr("Expirar:"))
        self.textLabel2_4.setText(self.__tr("Kbytes"))
        self.textLabel2.setText(self.__tr("Kbytes"))
        self.textLabel1_6.setText(self.__tr("dias"))
        self.lvCyrusGlobal.header().setLabel(0,self.__tr("Global IMAP Mailboxes"))
        self.wKorreio.changeTab(self.tabCyrus,self.__tr("Imap Manager"))
        self.pImapSelectAll.setText(self.__tr("Selecionar todos"))
        self.textLabel1_2_2.setText(self.__tr("Partition:"))
        self.tCyrUser_2.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.lvImapPartitionGlobal.header().setLabel(0,self.__tr("Global IMAP Mailboxes"))
        self.lvImapPartitionGlobal.header().setLabel(1,self.__tr("Partition"))
        self.lvImapPartition.header().setLabel(0,self.__tr("IMAP Mailboxes"))
        self.lvImapPartition.header().setLabel(1,self.__tr("Partition"))
        self.pImapPartitionSearch.setText(self.__tr("Pesquisar"))
        self.pImapPartitionMove.setText(self.__tr("Mover"))
        self.wKorreio.changeTab(self.TabPage,self.__tr("Imap Partitions"))
        self.tCyrUser_2_2.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.lvSieve.header().setLabel(0,self.__tr("IMAP Users"))
        self.lvSieve.header().setLabel(1,self.__tr("Script ativo"))
        self.cSieveScript.setText(self.__tr("Pesquisar script ativo"))
        self.pSieveSearch.setText(self.__tr("Pesquisar"))
        self.pSieveSelectAll.setText(self.__tr("Selecionar todos"))
        self.textLabel1_2_2_2.setText(self.__tr("Script:"))
        self.textLabel1_8.setText(self.__tr("<b>Modelos:</b>"))
        self.lbSieveScripts.clear()
        self.lbSieveScripts.insertItem(self.__tr("Encaminhar"))
        self.lbSieveScripts.insertItem(self.__tr("Encaminhar e salvar"))
        self.lbSieveScripts.insertItem(self.__tr("Mover por remetente"))
        self.lbSieveScripts.insertItem(self.__tr("Mover por remetentes"))
        self.lbSieveScripts.insertItem(self.__tr("Descartar Spam"))
        self.lbSieveScripts.insertItem(self.__tr("Mover Spam"))
        self.lbSieveScripts.insertItem(self.__trUtf8("\x46\xc3\xa9\x72\x69\x61\x73\x2c\x20\x73\x65\x20\x6e\xc3\xa3\x6f\x2d\x53\x70\x61\x6d"))
        self.lbSieveScripts.insertItem(self.__trUtf8("\x46\xc3\xa9\x72\x69\x61\x73"))
        self.pSieveScriptActive.setText(self.__tr("Ativar"))
        self.pSieveScriptRemove.setText(self.__tr("Remover"))
        self.pSieveScriptDisable.setText(self.__tr("Desativar"))
        self.wKorreio.changeTab(self.TabPage_2,self.__tr("Sieve Manager"))
        self.pPostStart.setText(self.__tr("Start Postfix"))
        self.pPostStop.setText(self.__tr("Stop Postfix"))
        self.pPostRestart.setText(self.__tr("Restart Postfix"))
        self.buttonGroup2.setTitle(self.__tr("main.cf"))
        self.pPostMainSave.setText(self.__tr("Salvar"))
        self.textLabel6.setText(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xa3\x6f\x3a"))
        self.rbPostconfD.setText(self.__trUtf8("\x56\x61\x6c\x6f\x72\x65\x73\x20\x70\x61\x64\x72\xc3\xb5\x65\x73"))
        self.rbPostconfAll.setText(self.__trUtf8("\x54\x6f\x64\x61\x73\x20\x6f\x70\xc3\xa7\xc3\xb5\x65\x73"))
        self.textLabel1_4.setText(self.__tr("Modo:"))
        self.rbPostconfN.setText(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xb5\x65\x73\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x64\x61\x73"))
        self.groupBox10.setTitle(self.__tr("Editor de arquivos"))
        self.textLabel7.setText(self.__tr("Arquivo:"))
        self.pPostFileOpen.setText(self.__tr("Abrir"))
        self.iPostFileOpen.setText(self.__tr("/etc/postfix/"))
        self.pPostFileSave.setText(self.__tr("Salvar"))
        self.pPostFilePostmap.setText(self.__tr("Postmap"))
        self.wKorreio.changeTab(self.TabPage_3,self.__tr("Postfix Manager"))
        self.pQueueLoad.setText(self.__tr("Atualizar"))
        self.pQueueDel.setText(self.__tr("Remover"))
        self.lvQueue.header().setLabel(0,self.__tr("Remetente"))
        self.lvQueue.header().setLabel(1,self.__tr("Items"))
        self.wKorreio.changeTab(self.TabPage_4,self.__tr("Queue Manager"))
        self.pSaveConfig.setText(self.__tr("Salvar"))
        self.lvConfig.header().setLabel(0,self.__tr("Menu"))
        self.lvConfig.clear()
        item_2 = QListViewItem(self.lvConfig,None)
        item_2.setOpen(1)
        item = QListViewItem(item_2,None)
        item.setText(0,self.__tr("LDAP"))
        item_2.setOpen(1)
        item = QListViewItem(item_2,item)
        item.setText(0,self.__tr("IMAP"))
        item_2.setOpen(1)
        item = QListViewItem(item_2,item)
        item.setText(0,self.__tr("SSH"))
        item_2.setText(0,self.__tr("Servidores"))

        item_3 = QListViewItem(self.lvConfig,item_2)
        item_3.setOpen(1)
        item = QListViewItem(item_3,item_2)
        item.setText(0,self.__tr("LDAP"))
        item_3.setOpen(1)
        item = QListViewItem(item_3,item)
        item.setText(0,self.__tr("IMAP"))
        item_3.setText(0,self.__trUtf8("\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73"))

        self.textLabel4.setText(self.__trUtf8("\x43\x6f\x6e\x65\x78\xc3\xa3\x6f\x3a"))
        self.tLdapUser.setText(self.__tr("User Admin:"))
        self.tLdapPass.setText(self.__tr("Senha:"))
        self.tLdapName.setText(self.__tr("Nome:"))
        self.tLdapHost.setText(self.__tr("Host:"))
        self.tLdapPort.setText(self.__tr("Port:"))
        self.tLdapBaseDN.setText(self.__tr("BaseDN:"))
        self.pConfDelLdapConnection.setText(self.__tr("Del"))
        self.cbLdapMode.clear()
        self.cbLdapMode.insertItem(self.__tr("ldap://"))
        self.cbLdapMode.insertItem(self.__tr("ldaps://"))
        self.iLdapPort.setText(self.__tr("389"))
        self.pGetBaseDN.setText(self.__tr("Get It"))
        self.cLdapRef.setText(self.__tr("Consultar referrals"))
        self.cLdapCert.setText(self.__trUtf8("\x4e\xc3\xa3\x6f\x20\x76\x65\x72\x69\x66\x69\x63\x61\x72\x20\x63\x65\x72\x74\x69\x66\x69\x63\x61\x64\x6f\x20\x53\x53\x4c\x20\x28\x72\x65\x69\x6e\x69\x63\x69\x65\x20\x6f\x20\x6b\x6f\x72\x72\x65\x69\x6f\x29"))
        self.textLabel3_3_3.setText(self.__tr("<b>Servidor LDAP</b>"))
        self.textLabel3_3_2.setText(self.__tr("<b>Servidor IMAP</b>"))
        self.textLabel6_2.setText(self.__trUtf8("\x43\x6f\x6e\x65\x78\xc3\xa3\x6f\x3a"))
        self.tCyrusPartition_3.setText(self.__tr("Sieve port:"))
        self.tCyrusPartition.setText(self.__tr("Partition:"))
        self.tCyrusUser.setText(self.__tr("User Admin:"))
        self.tCyrusPass.setText(self.__tr("Senha:"))
        self.textLabel7_2.setText(self.__tr("Nome:"))
        self.tCyrusHost.setText(self.__tr("Host:"))
        self.tCyrusPort.setText(self.__tr("Port:"))
        self.pConfDelImapConnection.setText(self.__tr("Del"))
        self.cbCyrusMode.clear()
        self.cbCyrusMode.insertItem(self.__tr("imap://"))
        self.cbCyrusMode.insertItem(self.__tr("imaps://"))
        self.iCyrusPort.setText(self.__tr("143"))
        self.iCyrusPart.setText(QString.null)
        self.iCyrusSievePort.setText(self.__tr("2000"))
        self.textLabel3_3.setText(self.__tr("<b>Servidor SSH</b>"))
        self.textLabel8.setText(self.__trUtf8("\x43\x6f\x6e\x65\x78\xc3\xa3\x6f\x3a"))
        self.tCyrusPass_2.setText(self.__tr("Senha:"))
        self.textLabel9.setText(self.__tr("Nome:"))
        self.tCyrusHost_2.setText(self.__tr("Host:"))
        self.tCyrusPort_2.setText(self.__tr("Port:"))
        self.tCyrusUser_2.setText(self.__tr("User:"))
        self.pConfDelSshConnection.setText(self.__tr("Del"))
        self.iSshPort.setText(self.__tr("22"))
        self.textLabel10.setText(self.__tr("<b>Servidor IMAP:</b>"))
        self.tConfShowImapServer.setText(self.__tr("Host:"))
        self.tConfShowImapUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.tConfShowImapSep.setText(self.__tr("Imap delimiter: desconectado"))
        self.textLabel10_3.setText(self.__tr("<b>Servidor SSH:</b>"))
        self.tConfShowSshServer.setText(self.__tr("Host:"))
        self.tConfShowSshUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.textLabel10_2.setText(self.__tr("<b>Servidor LDAP:</b>"))
        self.tConfShowLdapServer.setText(self.__tr("Host:"))
        self.tConfShowLdapUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.tConfShowLdapBaseDN.setText(self.__tr("Base:"))
        self.textLabel3_3_2_2.setText(self.__trUtf8("\x3c\x62\x3e\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73\x20\x4c\x44\x41\x50\x3c\x2f\x62\x3e"))
        self.textLabel1_9.setText(self.__tr("Adicionar atributos automaticamente a objectClass's:"))
        self.lvConfLdap.header().setLabel(0,self.__tr("Attributo"))
        self.lvConfLdap.header().setLabel(1,self.__tr("Valor"))
        self.lvConfLdap.clear()
        item_4 = QListViewItem(self.lvConfLdap,None)
        item_4.setOpen(1)
        item_5 = QListViewItem(item_4,None)
        item_5.setOpen(1)
        item = QListViewItem(item_5,None)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("extensibleObject"))
        item_5.setText(0,self.__tr("referral"))
        item_4.setOpen(1)
        item_6 = QListViewItem(item_4,item_5)
        item_6.setOpen(1)
        item = QListViewItem(item_6,item_5)
        item.setText(0,self.__tr("displayName"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaSID"))
        item.setText(1,self.__tr("S-0-0-00-0000000000-0000000000-0000000000-0000"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaPwdMustChange"))
        item.setText(1,self.__tr("2147483647"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaPwdLastSet"))
        item.setText(1,self.__tr("1"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaPwdCanChange"))
        item.setText(1,self.__tr("0"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaProfilePath"))
        item.setText(1,self.__tr("\\\\PDC\\profiles\\#UID#"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaPrimaryGroupSID"))
        item.setText(1,self.__tr("S-0-0-00-0000000000-0000000000-0000000000-514"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaNTPassword"))
        item.setText(1,self.__tr("XXX"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaLogonTime"))
        item.setText(1,self.__tr("0"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaLogonScript"))
        item.setText(1,self.__tr("logon.bat"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaLogoffTime"))
        item.setText(1,self.__tr("2147483647"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaLMPassword"))
        item.setText(1,self.__tr("XXX"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaKickoffTime"))
        item.setText(1,self.__tr("2147483647"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaHomePath"))
        item.setText(1,self.__tr("\\\\PDC-SRV\\#UID#"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaHomeDrive"))
        item.setText(1,self.__tr("H:"))
        item_6.setOpen(1)
        item = QListViewItem(item_6,item)
        item.setText(0,self.__tr("sambaAccFlags"))
        item.setText(1,self.__tr("[UX]"))
        item_6.setText(0,self.__tr("sambaSamAccount"))
        item_4.setOpen(1)
        item_7 = QListViewItem(item_4,item_6)
        item_7.setOpen(1)
        item = QListViewItem(item_7,item_6)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("shadowAccount"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("sn"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("cn"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("inetOrgPerson"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("loginShell"))
        item.setText(1,self.__tr("/bin/bash"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("homeDirectory"))
        item.setText(1,self.__tr("/home/"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("gidNumber"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("uidNumber"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("uid"))
        item_7.setText(0,self.__tr("posixAccount"))
        item_4.setOpen(1)
        item_8 = QListViewItem(item_4,item_7)
        item_8.setOpen(1)
        item = QListViewItem(item_8,item_7)
        item.setText(0,self.__tr("cn"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sn"))
        item_8.setText(0,self.__tr("inetOrgPerson"))
        item_4.setText(0,self.__tr("objectClass"))

        self.pConfLdapAddItem.setText(self.__tr("+"))
        self.pConfLdapDelItem.setText(self.__tr("-"))
        self.textLabel3_3_2_3.setText(self.__trUtf8("\x3c\x62\x3e\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73\x20\x49\x4d\x41\x50\x3c\x2f\x62\x3e"))
        self.textLabel6_2_3.setText(self.__trUtf8("\x50\x61\x73\x74\x61\x73\x20\x70\x61\x64\x72\xc3\xb5\x65\x73\x3a"))
        self.textLabel7_2_3.setText(self.__trUtf8("\x51\x75\x6f\x74\x61\x20\x70\x61\x64\x72\xc3\xa3\x6f\x3a"))
        self.textLabel1_7.setText(self.__tr("KB"))
        self.tCyrusHost_4.setText(self.__tr("Auto expire:"))
        self.tCyrusUser_4.setText(self.__tr("Permitir submission:"))
        self.tCyrusPort_4_2.setText(self.__tr("dias"))
        self.tCyrusPort_4.setText(self.__tr("em"))
        self.lbConfImapFolders.clear()
        self.lbConfImapFolders.insertItem(self.__tr("Drafts"))
        self.lbConfImapFolders.insertItem(self.__tr("Sent"))
        self.lbConfImapFolders.insertItem(self.__tr("Spam"))
        self.lbConfImapFolders.insertItem(self.__tr("Trash"))
        self.pConfImapFoldersDel.setText(self.__tr("-"))
        self.pConfImapFoldersAdd.setText(self.__tr("+"))
        self.iConfImapExpire.setText(self.__tr("Spam"))
        self.iConfImapExpireDays.setText(self.__tr("30"))
        self.iConfImapACLp.setText(self.__tr("Spam"))
        self.wKorreio.changeTab(self.tabConfig,self.__trUtf8("\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\xc3\xa7\xc3\xb5\x65\x73"))
        self.tlConsole.setText(self.__tr("Korreio (c) Copyleft 2008 - Reinaldo de Carvalho <reinaldoc@gmail.com>"))


    def init(self):
        
        global re, datetime, sys, os
        import re, datetime, sys, os.path
        
        reload(sys)
        sys.setdefaultencoding("utf-8")
        
        modfailed = []
        
        try:
            global ldap, modlist
            import ldap, ldap.modlist as modlist
        except:
            self.wKorreio.page(0).setEnabled(False)
            self.pGetBaseDN.setEnabled(False)
            modfailed.append("ldap")
        
        try:
            global  sha, md5, smbpasswd, b2a_base64, choice, letters, digits
            import sha, md5, smbpasswd
            from binascii import b2a_base64
            from random import choice
            from string import letters, digits
        except:
            self.wsLdap.widget(3).setEnabled(False)
            modfailed.append("smbpasswd")
        
        try:
            global cyruslib
            import cyruslib
        except:
            self.wKorreio.page(1).setEnabled(False)
            self.wKorreio.page(2).setEnabled(False)
            modfailed.append("cyrus")
        
        try:
            global sievelib
            import sievelib
        except:
            self.wKorreio.page(3).setEnabled(False)
            modfailed.append("sieve")
        
        try:
            global pexpect, pxssh
            import pexpect, pxssh
        except:
            self.wKorreio.page(4).setEnabled(False)
            self.wKorreio.page(5).setEnabled(False)
            modfailed.append("pexpect")
        
        if modfailed:
            msg = ""
            for mod in modfailed:
                msg = "%s%s\n" % (msg, "    - python-%s" % mod)
            QMessageBox.warning(None, "Modulos falharam", "Os seguintes módulos não foram carregados:\n%s".encode('iso-8859-1') % msg)
        
        

    def customEvent(self,a0):
        event = a0
        if event.type() == "set_console_text":
            self.console(event.data())
        

    def statusBar(self):
        pass
        

    def imap_connect(self):
        
        def imap_connect_now():
            if self.cbCyrusMode.currentText().ascii() == "imaps://": ssl = True
            else: ssl = False
            self.m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),ssl)
            if self.m.ALIVE:
                if self.m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii()):
                    if self.m.ADMIN is not None:
                        self.console("Servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+" conectado com sucesso.")
                    else:
                        self.m.logout()
                        self.console("Erro ao conectar no servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+". (Usuário não possui direito de administrador)".encode('iso-8859-1'))
                else:
                    self.console("Erro ao conectar no servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+". (Usuário ou senha inválidos)".encode('iso-8859-1'))
            else:
                self.console("Erro ao conectar no servidor "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii()+". (Conexão recusada)".encode('iso-8859-1'))
        
        try:
            # Is connected?
            if self.m.m.isadmin():
                # Server changed?
                if self.imap_connect_active_mode != self.cbCyrusMode.currentText().ascii() or self.imap_connect_active_host != self.iCyrusHost.text().ascii() or self.imap_connect_active_port != self.iCyrusPort.text().ascii() or self.imap_connect_active_user != self.iCyrusUser.text().ascii():
                    imap_connect_now()
            else:
                imap_connect_now()
        except AttributeError, e:
            # First connection
            imap_connect_now()
        
        self.imap_connect_active_mode = self.cbCyrusMode.currentText().ascii()
        self.imap_connect_active_host = self.iCyrusHost.text().ascii()
        self.imap_connect_active_port = self.iCyrusPort.text().ascii()
        self.imap_connect_active_user = self.iCyrusUser.text().ascii()
        
        self.tConfShowImapSep.setText("Imap delimiter: "+self.m.SEP)
        
        return self.m
        

    def imap_search(self):
        
        # Save current selection
        oldmailbox=['','']
        if self.lvCyrus.childCount() > 1:
            item=self.lvCyrus.currentItem()
            oldmailbox[0]=item.text(0).ascii()
            while item.parent() is not None:
                oldmailbox[0]=item.parent().text(0).ascii()
                item=item.parent()
        
        if self.lvCyrusGlobal.childCount() > 1:
            item=self.lvCyrusGlobal.currentItem()
            oldmailbox[1]=item.text(0).ascii()
            while item.parent() is not None:
                oldmailbox[1]=item.parent().text(0).ascii()
                item=item.parent()
        
        self.lvCyrus.clear()
        self.lvCyrusGlobal.clear()
        self.iImapMailbox.clear()
        self.cbUserACL.clear()
        self.iQuota.clear()
        self.iQuotaUsed.clear()
        self.iAnnotationExpire.clear()
        
        # Imap query
        imap = self.imap_connect()
        if self.iImapSearch.text().ascii():
            pattern = "user"+imap.SEP+self.iImapSearch.text().ascii()+"*"
        else:
            pattern = "*"
        mailboxes = imap.lm(pattern)
        
        def create_nodes(dn):
            dnlist = dn.split(imap.SEP)
            dnnode = imap.SEP.join(dnlist[:-1])
            if not self.tree.get(dnnode):
                create_nodes(dnnode)
            self.tree[dn] = QListViewItem(self.tree.get(dnnode))
            self.tree[dn].setText(0,dnlist[-1])
        
        try:
            self.tree = {}
            for id in mailboxes:
                idlist = id.split(imap.SEP)
                if re.search("^user",id):
                    id = imap.SEP.join(idlist[1:])
                    if len(idlist) == 2:
                        self.tree[id] = QListViewItem(self.lvCyrus)
                        self.tree[id].setText(0, id)
                        continue
                elif len(idlist) == 1:
                    self.tree[id] = QListViewItem(self.lvCyrusGlobal)
                    self.tree[id].setText(0, idlist[0])
                    continue
                idlist = id.split(imap.SEP)
                if not self.tree.get(id):
                    create_nodes(id)
                else:
                    print "Erro obtendo "+ idlist[-1]
        except KeyError, e:
            pass
        
        try:
            def selectItem(item):
                self.lvCyrus.setCurrentItem(item)
                item.setOpen(True)
                item.setSelected(True)
        
            item=self.lvCyrus.firstChild()
            if oldmailbox[0] == '':
                selectItem(item)
            else:
                while item is not None:
                    if item.text(0).ascii() == oldmailbox[0]:
                        selectItem(item)
                        self.lvCyrus.scrollBy(0,item.itemPos())
                        break
                    item=item.nextSibling()
                if item is None:
                    selectItem(self.lvCyrus.firstChild())
        except AttributeError, e:
            pass
        
        try:
            def selectItem(item):
                self.lvCyrusGlobal.setCurrentItem(item)
                item.setOpen(True)
                item.setSelected(True)
        
            item=self.lvCyrusGlobal.firstChild()
            if oldmailbox[1] == '':
                selectItem(item)
            else:
                item=self.lvCyrusGlobal.firstChild()
                while item is not None:
                    if item.text(0).ascii() == oldmailbox[1]:
                        selectItem(item)
                        self.lvCyrusGlobal.scrollBy(0,item.itemPos())
                        break
                    item=item.nextSibling()
                if item is None:
                    selectItem(self.lvCyrusGlobal.firstChild())
        
        except AttributeError, e:
            pass
        
        if self.lvCyrus.childCount() > 0:
            self.action_imap_mailbox_clicked()
        

    def imap_create_mailbox(self):
        
        def create_mailbox(mailbox, partition=None):
            if imap.cm(mailbox, partition):
                self.console("Mailbox %s criada com sucesso." % mailbox)
            else:
                self.console("Erro ao criar mailbox %s." % mailbox)
                raise "Error creating mailbox %s" % mailbox
            
        mailbox = self.iImapMailbox.text().ascii()
        
        if not mailbox:
            self.console("Informe a mailbox para ser criada.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        if self.iCyrusPart.text().ascii():
            create_mailbox("%s%s" % (mbtype, mailbox), self.iCyrusPart.text().ascii())
        else:
            create_mailbox("%s%s" % (mbtype, mailbox))
        
        if self.iConfImapQuota.text().ascii():
            imap.sq("%s%s" % (mbtype, mailbox), self.iConfImapQuota.text().ascii())
        
        if self.cbImapMailbox.currentItem() == 0:
            if len(mailbox.split(imap.SEP)) == 1:
                folders=self.confDict.get("imap.dflfolders").split(",")
                for folder in folders:
                    if len(folder) == 0: continue
                    create_mailbox("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, folder))
                    if folder == self.iConfImapACLp.text().ascii():
                        imap.sam("user"+imap.SEP+mailbox+imap.SEP+folder, "anyone", "p")
                    if folder == self.iConfImapExpire.text().ascii():
                        imap.setannotation("user"+imap.SEP+mailbox+imap.SEP+folder,"/vendor/cmu/cyrus-imapd/expire",self.iConfImapExpireDays.text().ascii())
        
        self.imap_search()
        
        if self.cbImapMailbox.currentItem() == 1:
            self.action_imap_gmailbox_clicked()
            self.lvCyrusGlobal.currentItem().setSelected(True)
        

    def imap_delete_mailbox(self):
        
        def delete_mailbox(mailbox):
            imap.sam(mailbox, self.iCyrusUser.text().ascii(), "c")
            if imap.dm(mailbox):
                self.console("Mailbox %s removida com sucesso." % mailbox)
            else:
                self.console("Erro ao remover Mailbox %s." % mailbox)
                raise "Error deleting mailbox %s" % mailbox
        
        mailbox = self.iImapMailbox.text().ascii()
        
        if not mailbox:
            self.console("Selecione a mailbox para exclusão.".encode('iso-8859-1'))
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        if QMessageBox.information( None, "Confirme!",
                                                       "Confirme a remoção da caixa postal:\n\n    - %s%s\n\n".encode('iso-8859-1') % (mbtype, mailbox),
                                                       "Sim",
                                                       "Não".encode('iso-8859-1') ) != 0:
            self.console("Remoção da mailbox %s%s cancelada.".encode('iso-8859-1') % (mbtype, mailbox) )
            return True
        
        # Cyrus is not recursive for subfolders
        if len(mailbox.split(imap.SEP)) > 1:
            for mbox in imap.lm(mbtype+mailbox+imap.SEP+"*"):
                delete_mailbox(mbox)
        delete_mailbox(mbtype+mailbox)
        
        if self.cbImapMailbox.currentItem() == 0:
            if self.lvCyrus.currentItem().parent() is None:
                self.lvCyrus.takeItem(self.lvCyrus.currentItem())
            else:
                self.lvCyrus.currentItem().parent().takeItem(self.lvCyrus.currentItem())
            self.lvCyrus.currentItem().setSelected(True)
            self.action_imap_mailbox_clicked()
        else:
            if self.lvCyrusGlobal.currentItem().parent() is None:
                self.lvCyrusGlobal.takeItem(self.lvCyrusGlobal.currentItem())
            else:
                self.lvCyrusGlobal.currentItem().parent().takeItem(self.lvCyrusGlobal.currentItem())
            self.lvCyrusGlobal.currentItem().setSelected(True)
            self.action_imap_gmailbox_clicked()
        
        

    def imap_set_quota(self):
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("Selecione a mailbox para aplicar a quota.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        if imap.sq(mbtype+self.iImapMailbox.text().ascii(),self.iQuota.text().ascii()):
            self.console("Quota de "+self.iQuota.text().ascii()+"Kbytes configurada com sucesso para o usuário ".encode('iso-8859-1')+self.iImapMailbox.text().ascii()+".")
        else:
            self.console("Erro ao configurar quota para o usuário ".encode('iso-8859-1')+self.iImapMailbox.text().ascii()+".")
        

    def imap_set_acl(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("Selecione a mailbox para aplicar a ACL.")
            return True
        
        perm=""
        if self.cCyrPermL.isChecked():
            perm="l"
        if self.cCyrPermR.isChecked():
            perm=perm+"r"
        if self.cCyrPermS.isChecked():
            perm=perm+"s"
        if self.cCyrPermW.isChecked():
            perm=perm+"w"
        if self.cCyrPermI.isChecked():
            perm=perm+"i"
        if self.cCyrPermP.isChecked():
            perm=perm+"p"
        if self.cCyrPermC.isChecked():
            perm=perm+"c"
        if self.cCyrPermD.isChecked():
            perm=perm+"d"
        if self.cCyrPermA.isChecked():
            perm=perm+"a"
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        if imap.sam(mbtype+self.iImapMailbox.text().ascii(), self.cbUserACL.currentText().ascii(), perm):
            self.console("Mailbox "+self.iImapMailbox.text().ascii()+": ACL "+perm+" aplicada para usuário ".encode('iso-8859-1')+self.cbUserACL.currentText().ascii())
        else:
            self.console("Mailbox "+self.iImapMailbox.text().ascii()+": erro ao aplicar ACL "+perm+" para usuário "+self.cbUserACL.currentText().ascii())
        

    def imap_new_acl(self):
        self.cbUserACL.setCurrentText("")
        self.cbUserACL.setFocus()
        self.cCyrPermL.setChecked(True)
        self.cCyrPermR.setChecked(True)
        self.cCyrPermS.setChecked(True)
        self.cCyrPermW.setChecked(True)
        self.cCyrPermI.setChecked(False)
        self.cCyrPermP.setChecked(False)
        self.cCyrPermC.setChecked(False)
        self.cCyrPermD.setChecked(False)
        self.cCyrPermA.setChecked(False)
        

    def imap_reconstruct(self):
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("Selecione a mailbox para reconstruir.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        if imap.reconstruct(mbtype+self.iImapMailbox.text().ascii()):
            self.console("Mailbox "+self.iImapMailbox.text().ascii()+" esta sendo reconstruida.")
        else:
            self.console("Erro ao reconstruir "+self.iImapMailbox.text().ascii()+".")
        

    def imap_set_annotation_expire(self):
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("Selecione a mailbox para aplica o auto-expire.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        if imap.setannotation(mbtype+self.iImapMailbox.text().ascii(),"/vendor/cmu/cyrus-imapd/expire",self.iAnnotationExpire.text().ascii()):
            self.console("Auto-expire de "+self.iAnnotationExpire.text().ascii()+" dias configurado com sucesso para mailbox ".encode('iso-8859-1')+self.iImapMailbox.text().ascii()+".")
        else:
            self.console("Erro ao configurar auto-expirea para mailbox ".encode('iso-8859-1')+self.iImapMailbox.text().ascii()+".")
        
        

    def imap_partition_search(self):
        
        self.lvImapPartition.clear()
        self.lvImapPartitionGlobal.clear()
        self.cbImapPartition.clear()
        
        partitions = {}
        
        imap = self.imap_connect()
        
        mailboxes = imap.getannotation("user"+imap.SEP+self.iImapPartitionSearch.text().ascii()+"%","/vendor/cmu/cyrus-imapd/partition")
        if mailboxes[0] == True:
            for mailbox in mailboxes[1]:
                idlist = mailbox.split(imap.SEP)
                item = QListViewItem(self.lvImapPartition)
                item.setText(0, imap.SEP.join(idlist[1:]))
                item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
                partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""
        
        mailboxes = imap.getannotation(self.iImapPartitionSearch.text().ascii()+"%","/vendor/cmu/cyrus-imapd/partition")
        if mailboxes[0] == True:
            for mailbox in mailboxes[1]:
                item = QListViewItem(self.lvImapPartitionGlobal)
                item.setText(0, mailbox)
                item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
                partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""
        
        for i in partitions:
            self.cbImapPartition.insertItem(i)
        

    def imap_partition_move(self):
        
        imap = self.imap_connect()
        item = self.lvImapPartition.firstChild()
        while item is not None:
            if item.isSelected():
                self.console("Movendo "+item.text(0).ascii()+" para imap-partition: "+self.cbImapPartition.currentText().ascii())
                mailbox="user"+imap.SEP+item.text(0).ascii()
                imap.rename(mailbox, mailbox, self.cbImapPartition.currentText().ascii())
            item=item.nextSibling()
        
        item = self.lvImapPartitionGlobal.firstChild()
        while item is not None:
            if item.isSelected():
                self.console("Movendo "+item.text(0).ascii()+" para imap-partition: "+self.cbImapPartition.currentText().ascii())
                imap.rename(item.text(0).ascii(), item.text(0).ascii(), self.cbImapPartition.currentText().ascii())
            item=item.nextSibling()
        
        self.imap_partition_search()
        
        

    def imap_rename(self,a0,a1):
        
        currentItem = a0
        
        imap = self.imap_connect()
        item = a0
        new = item.text(0).ascii()
        while item.parent() is not None:
            item=item.parent()        
            new = item.text(0).ascii()+imap.SEP+new
        
        if self.mailboxold != new:
            if len(imap.lm(a1+new)) > 0:
                self.console("Mailbox "+new+" já existe.".encode('iso-8859-1'))
                currentItem.setText(0,self.mailboxold.split(m.SEP)[-1])
                return True
            if imap.rename(a1+self.mailboxold,a1+new):
                self.console("Mailbox "+self.mailboxold+" renomeada com sucesso para "+new+".")
            else:
                self.console("Não foi possível renomear "+self.mailboxold+" para "+new+".")
                currentItem.setText(0,self.mailboxold.split(imap.SEP)[-1])
        

    def imap_rename_mailbox(self):
            self.imap_rename(self.lvCyrus.currentItem(),"user"+self.m.SEP)
        

    def imap_gmailbox_rename(self):
            self.imap_rename(self.lvCyrusGlobal.currentItem(),"")
        

    def save_config(self):
        
        try:
            try:
                self.confDict
            except AttributeError, e:
                self.confDict = {}
        
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')
        
        #
        # LDAP Connection
        #
        
            if not self.iLdapConnection.text().ascii():
                self.console("Preencha o nome da conexão LDAP.")
            else:
                i=0
                while self.confDict.get("ldap"+str(i)+".name"):
                    if self.confDict.get("ldap"+str(i)+".name") == self.iLdapConnection.text().ascii():
                        break
                    i=i+1
                tmpLast=i
                f.write('ldap.last=ldap'+str(i)+'\n')
        
                self.confDict["ldap"+str(i)+".name"]=self.iLdapConnection.text().ascii()
                self.confDict["ldap"+str(i)+".mode"]=self.cbLdapMode.currentText().ascii()
                self.confDict["ldap"+str(i)+".host"]=self.iLdapHost.text().ascii()
                self.confDict["ldap"+str(i)+".port"]=self.iLdapPort.text().ascii()
                self.confDict["ldap"+str(i)+".basedn"]=self.cbLdapBaseDN.currentText().ascii()
                self.confDict["ldap"+str(i)+".user"]=self.iLdapUser.text().ascii()
                self.confDict["ldap"+str(i)+".pass"]=self.iLdapPass.text().ascii()
                self.confDict["ldap"+str(i)+".ref"]=str(self.cLdapRef.isChecked())
                self.confDict["ldap"+str(i)+".cert"]=str(self.cLdapCert.isChecked())
        
                i=0
                self.cbLdapConnection.clear()
                while self.confDict.get("ldap"+str(i)+".name"):
                    self.cbLdapConnection.insertItem(self.confDict.get("ldap"+str(i)+".name"))
                    for j in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                        opt='ldap'+str(i)+'.'+j
                        f.write(opt+"="+self.confDict.get(opt)+'\n')
                    i=i+1
                self.cbLdapConnection.setCurrentItem(tmpLast)
        
        #
        # IMAP Connection
        #
        
            if not self.iCyrusConnection.text().ascii():
                self.console("Preencha o nome da conexão IMAP.")
            else:
                i=0
                while self.confDict.get("imap"+str(i)+".name"):
                    if self.confDict.get("imap"+str(i)+".name") == self.iCyrusConnection.text().ascii():
                        break
                    i=i+1
                tmpLast=i
                f.write('imap.last=imap'+str(i)+'\n')
        
                self.confDict["imap"+str(i)+".name"]=self.iCyrusConnection.text().ascii()
                self.confDict["imap"+str(i)+".mode"]=self.cbCyrusMode.currentText().ascii()
                self.confDict["imap"+str(i)+".host"]=self.iCyrusHost.text().ascii()
                self.confDict["imap"+str(i)+".port"]=self.iCyrusPort.text().ascii()
                self.confDict["imap"+str(i)+".sieport"]=self.iCyrusSievePort.text().ascii()
                self.confDict["imap"+str(i)+".user"]=self.iCyrusUser.text().ascii()
                self.confDict["imap"+str(i)+".pass"]=self.iCyrusPass.text().ascii()
                self.confDict["imap"+str(i)+".part"]=self.iCyrusPart.text().ascii()
        
                i=0
                self.cbCyrusConnection.clear()
                while self.confDict.get("imap"+str(i)+".name"):
                    self.cbCyrusConnection.insertItem(self.confDict.get("imap"+str(i)+".name"))
                    for j in ['name','mode','host','port','sieport','user','pass','part']:
                        opt='imap'+str(i)+'.'+j
                        f.write(opt+"="+self.confDict.get(opt)+'\n')
                    i=i+1
                self.cbCyrusConnection.setCurrentItem(tmpLast)
        
        #
        # SSH Connection
        #
        
            if not self.iSSHConnection.text().ascii():
                self.console("Preencha o nome da conexão SSH.")
            else:
                i=0
                while self.confDict.get("ssh"+str(i)+".name"):
                    if self.confDict.get("ssh"+str(i)+".name") == self.iSSHConnection.text().ascii():
                        break
                    i=i+1
                tmpLast=i
                f.write('ssh.last=ssh'+str(i)+'\n')
        
                self.confDict["ssh"+str(i)+".name"]=self.iSSHConnection.text().ascii()
                self.confDict["ssh"+str(i)+".host"]=self.iSshHost.text().ascii()
                self.confDict["ssh"+str(i)+".port"]=self.iSshPort.text().ascii()
                self.confDict["ssh"+str(i)+".user"]=self.iSshUser.text().ascii()
                self.confDict["ssh"+str(i)+".pass"]=self.iSshPass.text().ascii()
        
                i=0
                self.cbSSHConnection.clear()
                while self.confDict.get("ssh"+str(i)+".name"):
                    self.cbSSHConnection.insertItem(self.confDict.get("ssh"+str(i)+".name"))
                    for j in ['name','host','port','user','pass']:
                        opt='ssh'+str(i)+'.'+j
                        f.write(opt+"="+self.confDict.get(opt)+'\n')
                    i=i+1
                self.cbSSHConnection.setCurrentItem(tmpLast)
        
        #
        # IMAP Prefs
        #
        
            folders=[]
            for folder in range(0,self.lbConfImapFolders.count()):
                folders.extend([self.lbConfImapFolders.item(folder).text().ascii()])
            f.write('imap.dflfolders='+",".join(folders)+'\n')
            f.write('imap.dflquota='+self.iConfImapQuota.text().ascii()+'\n')
            f.write('imap.dflexpirefolder='+self.iConfImapExpire.text().ascii()+'\n')
            f.write('imap.dflexpiredays='+self.iConfImapExpireDays.text().ascii()+'\n')
            f.write('imap.addaclp='+self.iConfImapACLp.text().ascii()+'\n')
        
        
        #
        # LDAP Prefs
        #
            item=self.lvConfLdap.firstChild()
            item=item.firstChild()
            i=0
            while item is not None:
                subitem=item.firstChild()
                while subitem is not None:
                    if subitem.text(1).ascii() is None: value=""
                    else: value=subitem.text(1).ascii()
                    f.write("ldap.objectclass"+str(i)+"="+item.text(0).ascii()+"."+subitem.text(0).ascii()+"."+value+'\n')
                    subitem=subitem.nextSibling()
                    i=i+1
                item=item.nextSibling()
        #
        # End
        #
            f.close()
            os.chmod(os.path.expanduser("~/.korreio/korreio.conf"), 0600)
            self.console("Configuração salva.".encode('iso-8859-1'))
        except OSError, e:
            self.parse_exception("OSError", e)
        
        

    def load_config(self):
        
        try:
            os.mkdir(os.path.expanduser("~/.korreio"),0700)
        except OSError, e:
            if e[0] != 17:
                self.console("Error creating ~/.korreio "+e)
                print "Error creating ~/.korreio "+e
                return False
        
        try:
            if not os.path.isfile(os.path.expanduser("~/.korreio/korreio.conf")):
                self.save_config()
        except OSError, e:
            pass
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
            conf=f.read()
            f.close()
        except IOError, e:
            return True
        
        confList = conf.split("\n")
        confList.pop()
        self.confDict = {}
        
        for line in confList:
           key=line.split("=")
           self.confDict[key[0]] = "=".join(key[1:])
        
        #
        # LDAP Connection
        #
        
        i=0
        self.cbLdapConnection.clear()
        while self.confDict.get("ldap"+str(i)+".name"):
            self.cbLdapConnection.insertItem(self.confDict.get("ldap"+str(i)+".name"))
            i=i+1
        
        lastConn=self.confDict.get("ldap.last")
        if lastConn:
            self.cbLdapConnection.setCurrentText(self.confDict.get(lastConn+".name"))
            self.iLdapConnection.setText(self.confDict.get(lastConn+".name"))
            self.cbLdapMode.setCurrentText(self.confDict.get(lastConn+".mode"))
            self.iLdapHost.setText(self.confDict.get(lastConn+".host"))
            self.iLdapPort.setText(self.confDict.get(lastConn+".port"))
            self.cbLdapBaseDN.clear()
            self.cbLdapBaseDN.insertItem(self.confDict.get(lastConn+".basedn"))
            self.iLdapUser.setText(self.confDict.get(lastConn+".user"))
            self.iLdapPass.setText(self.confDict.get(lastConn+".pass"))
            if self.confDict.get(lastConn+".ref") == "True":
                self.cLdapRef.setChecked(True)
            if self.confDict.get(lastConn+".cert") == "True":
                self.cLdapCert.setChecked(True)
        
        #
        # IMAP Connection
        #
        
        i=0
        self.cbCyrusConnection.clear()
        while self.confDict.get("imap"+str(i)+".name"):
            self.cbCyrusConnection.insertItem(self.confDict.get("imap"+str(i)+".name"))
            i=i+1
        
        lastConn=self.confDict.get("imap.last")
        if lastConn:
            self.cbCyrusConnection.setCurrentText(self.confDict.get(lastConn+".name"))
            self.iCyrusConnection.setText(self.confDict.get(lastConn+".name"))
            self.cbCyrusMode.setCurrentText(self.confDict.get(lastConn+".mode"))
            self.iCyrusHost.setText(self.confDict.get(lastConn+".host"))
            self.iCyrusPort.setText(self.confDict.get(lastConn+".port"))
            self.iCyrusSievePort.setText(self.confDict.get(lastConn+".sieport"))
            self.iCyrusUser.setText(self.confDict.get(lastConn+".user"))
            self.iCyrusPass.setText(self.confDict.get(lastConn+".pass"))
            self.iCyrusPart.setText(self.confDict.get(lastConn+".part"))
        
        #
        # SSH Connection
        #
        
        i=0
        self.cbSSHConnection.clear()
        while self.confDict.get("ssh"+str(i)+".name"):
            self.cbSSHConnection.insertItem(self.confDict.get("ssh"+str(i)+".name"))
            i=i+1
        
        lastConn=self.confDict.get("ssh.last")
        if lastConn:
            self.cbSSHConnection.setCurrentText(self.confDict.get(lastConn+".name"))
            self.iSSHConnection.setText(self.confDict.get(lastConn+".name"))
            self.iSshHost.setText(self.confDict.get(lastConn+".host"))
            self.iSshPort.setText(self.confDict.get(lastConn+".port"))
            self.iSshUser.setText(self.confDict.get(lastConn+".user"))
            self.iSshPass.setText(self.confDict.get(lastConn+".pass"))
        
        #
        # IMAP Prefs
        #
        
        self.lbConfImapFolders.clear()
        for folder in self.confDict.get("imap.dflfolders").split(","):
            self.lbConfImapFolders.insertItem(folder)
        self.iConfImapQuota.setText(self.confDict.get("imap.dflquota"))
        self.iConfImapExpire.setText(self.confDict.get("imap.dflexpirefolder"))
        self.iConfImapExpireDays.setText(self.confDict.get("imap.dflexpiredays"))
        self.iConfImapACLp.setText(self.confDict.get("imap.addaclp"))
        
        #
        # LDAP Prefs
        #
        
        self.lvConfLdap.clear()
        item = QListViewItem(self.lvConfLdap)
        item.setText(0,'objectClass')
        item.setOpen(True)
        objnodes = {}
        i=0
        while self.confDict.get("ldap.objectclass"+str(i)):
            objclass = self.confDict.get("ldap.objectclass"+str(i)).split(".")
            if not objnodes.get(objclass[0]):
                objnodes[objclass[0]] = QListViewItem(item)
                objnodes[objclass[0]].setText(0,objclass[0])
            subitem=QListViewItem(objnodes[objclass[0]])
            subitem.setText(0,objclass[1])
            subitem.setText(1,".".join(objclass[2:]))
            i=i+1
        
        

    def action_module_changed(self):
        menu=str(self.wKorreio.tabLabel(self.wKorreio.currentPage()))
        if menu == "LDAP Manager":
            try:
                self.loadconfig
            except:
                self.loadconfig = 1
                self.load_config()
        elif menu == "Configurações":
            self.action_config_change_widgetstack()
        

    def action_imap_mailbox_clicked(self):
        self.cbImapMailbox.setCurrentItem(0)
        self.action_imap_mailbox_get_info(self.lvCyrus.currentItem(),"user")
        

    def action_imap_gmailbox_clicked(self):
        self.cbImapMailbox.setCurrentItem(1)
        self.action_imap_mailbox_get_info(self.lvCyrusGlobal.currentItem(),"")
        

    def action_imap_mailbox_get_info(self,a0,a1):
        
        imap = self.imap_connect()
        item = a0
        if a1:
            mbtype = a1+imap.SEP
        else:
            mbtype = a1
        
        mailbox=item.text(0).ascii()
        while item.parent() is not None:
            mailbox=item.parent().text(0).ascii()+imap.SEP+mailbox
            item=item.parent()
        
        self.iImapMailbox.setText(mailbox)
        
        if len(mailbox.split(imap.SEP)) == 1:
            self.pSetQuota.setEnabled(True)
        else:
            self.pSetQuota.setEnabled(False)
        
        quota = imap.lq(mbtype+mailbox.split(imap.SEP)[0])
        self.iQuotaUsed.setText("%s" % quota[0])
        self.iQuota.setText("%s" % quota[1])
        
        self.permissions = imap.lam(mbtype+mailbox)
        self.cbUserACL.clear()
        i=0
        for acl in self.permissions:
            self.cbUserACL.insertItem(acl)
            i=i+1
        self.tlImapACl.setText("{"+str(i)+"}")
        self.action_imap_show_permissions()
        
        expire = imap.getannotation(mbtype+mailbox,"/vendor/cmu/cyrus-imapd/expire")
        if expire[0]:
            self.iAnnotationExpire.setText(expire[1][mbtype+mailbox]["/vendor/cmu/cyrus-imapd/expire"])
        else:
            self.iAnnotationExpire.setText("")
        
        

    def action_imap_show_permissions(self):
        
        mailbox_perm = self.permissions[self.cbUserACL.currentText().ascii()]
        if re.search("l",mailbox_perm): self.cCyrPermL.setChecked(True)
        else: self.cCyrPermL.setChecked(False)
        if re.search("r",mailbox_perm): self.cCyrPermR.setChecked(True)
        else: self.cCyrPermR.setChecked(False)
        if re.search("s",mailbox_perm): self.cCyrPermS.setChecked(True)
        else: self.cCyrPermS.setChecked(False)
        if re.search("w",mailbox_perm): self.cCyrPermW.setChecked(True)
        else: self.cCyrPermW.setChecked(False)
        if re.search("i",mailbox_perm): self.cCyrPermI.setChecked(True)
        else: self.cCyrPermI.setChecked(False)
        if re.search("p",mailbox_perm): self.cCyrPermP.setChecked(True)
        else: self.cCyrPermP.setChecked(False)
        if re.search("c",mailbox_perm): self.cCyrPermC.setChecked(True)
        else: self.cCyrPermC.setChecked(False)
        if re.search("d",mailbox_perm): self.cCyrPermD.setChecked(True)
        else: self.cCyrPermD.setChecked(False)
        if re.search("a",mailbox_perm): self.cCyrPermA.setChecked(True)
        else: self.cCyrPermA.setChecked(False)
        

    def get_ldap_basedn(self):
        try:
            if self.cLdapCert.isChecked():
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
            l = ldap.initialize(self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
            if self.cLdapRef.isChecked():
                ldap.set_option(ldap.OPT_REFERRALS,1)
            else:
                ldap.set_option(ldap.OPT_REFERRALS,0)
            l.protocol_version = ldap.VERSION3
            if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
                l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
            else:
                l.simple_bind()
            searchScope = ldap.SCOPE_BASE
            searchFilter = "objectclass=*"
            retrieveAttributes = ["namingContexts"]
            ldap_result_id = l.search("", searchScope, searchFilter, retrieveAttributes)
            self.cbLdapBaseDN.clear()
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                if (result_data == []):
                    break
                else:
                    if result_type == ldap.RES_SEARCH_ENTRY:
                        for j in result_data:
                             for root in j[1]["namingContexts"]:
                                 self.cbLdapBaseDN.insertItem(root)
                                 if not self.iLdapUser.text().ascii():
                                     self.iLdapUser.setText("cn=admin,"+root)
            if self.cbLdapBaseDN.count() > 1:
                    self.cbLdapBaseDN.popup()
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
        

    def action_imap_set_port(self,a0):
        print a0
        if self.cbCyrusMode.currentText().ascii() == "imap://":
            self.iCyrusPort.setText("143")
        else:
            self.iCyrusPort.setText("993")
        

    def ldap_connect(self):
        try:
            if self.cLdapCert.isChecked():
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
            else:
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,2)
            if self.cLdapRef.isChecked():
                ldap.set_option(ldap.OPT_REFERRALS,1)
            else:
                ldap.set_option(ldap.OPT_REFERRALS,0)
            l = ldap.initialize(self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
            l.protocol_version = ldap.VERSION3
            l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
            return l
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
        

    def ldap_search(self):
        
        def create_nodes(dn):
            dnlist = dn.split(",")
            dnnode = ",".join(dnlist[1:])
            if not self.nodes.get(dnnode):
                if not dnnode == dnnode.split(",")[0]:
                    create_nodes(dnnode)
                else:
                    print "Erro fatal: servidor ldap retonou basedn diferente da consulta."
                    print "            O servidor exige basedn case sensitive. Verifique."
            self.nodes[dn] = QListViewItem(self.nodes.get(dnnode))
            self.nodes[dn].setText(0,dnlist[0])
        
        if self.cbLdapFilter.count() == 10:
            self.cbLdapFilter.removeItem(4)
        self.cbLdapFilter.insertItem(self.cbLdapFilter.currentText().ascii())
        
        basedn = self.cbLdapBaseDN.currentText().ascii()
        try:
            olddn = self.ldap_get_dn()
        except AttributeError, e:
            olddn = basedn
        
        self.lvLdap.clear()
        self.nodes = {}
        self.nodes[basedn] = QListViewItem(self.lvLdap)
        self.nodes[basedn].setText(0,basedn)
        self.nodes[basedn].setOpen(True)
        
        if not self.cbLdapFilter.currentText().ascii():
            filter = "(objectClass=*)"
        else:
            filter = "("+str(self.__tr(self.cbLdapFilter.currentText().ascii()))+")"
        self.ldap_attr = self.ldap_result(filter)
        
        try:
            basednattrs = self.ldap_attr.get(basedn)
            del self.ldap_attr[basedn]
        except KeyError, e:
            pass
        
        for dn in self.ldap_attr:
            if not self.nodes.get(dn):
                create_nodes(dn)
        try:
            self.ldap_attr[basedn] = basednattrs
        except KeyError, e:
            pass
        
        try:
            self.lvLdap.setCurrentItem(self.nodes[olddn])
            self.lvLdap.currentItem().setSelected(True)
        except KeyError, e:
            pass
        
        while olddn != basedn:
            try:
                self.nodes[olddn].setOpen(True)
            except KeyError, e:
                pass
            olddn = ",".join(olddn.split(",")[1:])
            if len(olddn) == 0:
                break
        
        self.lvLdap.scrollBy(0,self.lvLdap.currentItem().itemPos())
        self.ldap_dn_clicked()
        
        

    def ldap_result(self,a0):
        try:
            l = self.ldap_connect()
            searchScope = ldap.SCOPE_SUBTREE
            searchFilter = a0
            retrieveAttributes = None
            ldap_result_id = l.search(self.cbLdapBaseDN.currentText().ascii(), searchScope, searchFilter, retrieveAttributes)
            ldap_result = {}
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                if result_type == ldap.RES_SEARCH_RESULT:
                    break
                elif result_type == ldap.RES_SEARCH_ENTRY:
                    ldap_result[result_data[0][0].encode('iso-8859-1')] = result_data[0][1]
                elif result_type == ldap.RES_SEARCH_REFERENCE:
                    ldap_result[result_data[0][1][0].split("/")[3].split("?")[0]] = {'ref': [result_data[0][1][0]]}
                else:
                    print "Result type not implemented. "+str(result_type)
        
            return ldap_result
        except ldap.LDAPError, e:
            if e[0]["desc"] == "Size limit exceeded":
                self.console("Quantidade de registros excedido. Utilize um filtro mais restritivo.")
                return ldap_result
            else:
                self.parse_exception("LDAPError", e)
        

    def ldap_dn_clicked(self):
        self.lvLdapAttr.clear()
        self.wsLdap.raiseWidget(0)
        self.cbLdapStack.setCurrentItem(0)
        dn = self.ldap_get_dn()
        try:
            for attribute,values in self.ldap_attr.get(dn).items():
                for value in values:
                    item = QListViewItem(self.lvLdapAttr)
                    item.setText(0,attribute)
                    try:
                        item.setText(1,value.encode('iso-8859-1'))
                    except UnicodeDecodeError, e:
                        item.setText(1,value)
        except AttributeError, e:
            pass
        item = self.lvLdap.currentItem()
        if item.parent() is None or item.childCount() != 0:
            self.pLdapDelete.setEnabled(False)
        else:
            self.pLdapDelete.setEnabled(True)
        
        if self.lvLdapAttr.childCount() > 0:
            self.lvLdapAttr.setCurrentItem(self.lvLdapAttr.firstChild())
            self.lvLdapAttr.currentItem().setSelected(True)
        

    def ldap_dn_doubleclicked(self):
        if self.lvLdap.currentItem().childCount() == 0:
            self.rdnold = str(self.__tr(self.ldap_get_dn()))
            self.lvLdap.currentItem().setRenameEnabled(0,True)
            self.lvLdap.currentItem().startRename(0)
        

    def ldap_insert_user(self):
        
        cn=str(self.__tr(self.iLdapCn.text().ascii()))
        dn = str(self.__tr("cn="+self.iLdapCn.text().ascii()+","+self.ldap_get_dn()))
        attrs = {}
        attrs['objectclass'] = ['inetOrgPerson']
        attrs['cn'] = cn
        attrs['sn'] = cn.split(" ")[-1]
        emails = self.iLdapMail.text().ascii().split(",")
        attrs['mail'] = emails[0]
        if len(emails) > 0:
            attrs['l'] = emails[1:]
        salt = ''
        for i in range(16):
            salt += choice(letters+digits)
        attrs['userPassword'] = "{SSHA}"+b2a_base64(sha.new(self.iLdapUserP.text().ascii() + salt).digest() + salt)[:-1]
        self.ldap_add(dn,attrs)
        self.ldap_search()
        self.wsLdap.raiseWidget(1)
        

    def ldap_add(self,a0,a1):
        # a0 = DN, a1 = attrs
        try:
            ldif = modlist.addModlist(a1)
            l = self.ldap_connect()
            l.add_s(a0,ldif)
            l.unbind_s()
            self.console("Registro "+a0.encode('iso-8859-1')+" adicionado com sucesso.")
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        

    def action_ldap_modify(self):
        stack = self.cbLdapStack.currentItem()
        if stack == 0:
            old = {}
            for attribute,values in self.ldap_attr.get(self.ldap_get_dn()).items():
                if old.get(attribute):
                   old[attribute].extend(values)
                else:
                   old[attribute] = values
        
            new = {}
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if new.get(item.text(0).ascii()):
                    new[item.text(0).ascii()].extend([str(self.__tr(item.text(1).ascii()))])
                else:
                    new[item.text(0).ascii()] = [str(self.__tr(item.text(1).ascii()))]
                item = item.nextSibling()
        
            if not self.ldap_modify(self.ldap_get_dn(),old,new):
                return False
        else:
            new = {}
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if item.isSelected():
                    dn=item.text(0).ascii()+"="+item.text(1).ascii()+","+self.ldap_get_dn()
                if new.get(item.text(0).ascii()):
                    new[item.text(0).ascii()].extend([item.text(1).ascii()])
                else:
                    new[item.text(0).ascii()] = [item.text(1).ascii()]
                item = item.nextSibling()
            try:
                if not self.ldap_add(dn,new):
                    return False
            except UnboundLocalError, e:
                self.console("Selecione o DN entre os atributos.")
                return False
        
        self.ldap_search()
        

    def ldap_insert_ou(self):
        dn = "ou="+self.iLdapOu.text().ascii()+","+self.ldap_get_dn()
        attrs = {}
        attrs['objectclass'] = ['organizationalUnit']
        attrs['ou'] = self.iLdapOu.text().ascii()
        self.ldap_add(dn,attrs)
        self.ldap_search()
        self.wsLdap.raiseWidget(2)
        

    def ldap_remove_entry(self):
        
        dn = str(self.__tr(self.ldap_get_dn()))
        if dn is not None:
            ok = QMessageBox.information( None, "Confirme!", "Confirme a remoção do registro:\n\n    - %s\n\n".encode('iso-8859-1') % dn, "Sim", "Não".encode('iso-8859-1') )
            if ok == 0:
                if self.ldap_del_entry(dn):
                    self.console("Registro "+dn.encode('iso-8859-1')+" removido com sucesso.")
                    self.lvLdap.currentItem().parent().takeItem(self.lvLdap.currentItem())
                    self.lvLdap.currentItem().setSelected(True)
                    self.ldap_dn_clicked()
            else:
                self.console("Remoção do registro %s cancelada.".encode('iso-8859-1') % dn)
        
        

    def ldap_remove_attr(self):
        self.lvLdapAttr.takeItem(self.lvLdapAttr.currentItem())
        try:
            self.lvLdapAttr.currentItem().setSelected(True)
        except AttributeError, e:
            pass
        

    def ldap_rename_attr_value(self):
        if not self.lvLdap.currentItem().text(0).ascii() == "=".join([self.lvLdapAttr.currentItem().text(0).ascii(),self.lvLdapAttr.currentItem().text(1).ascii()]):
            self.lvLdapAttr.currentItem().setRenameEnabled(1,True)
            self.lvLdapAttr.currentItem().startRename(1)
        

    def ldap_add_attr(self):
        attr=self.cbLdapAttr.currentText().ascii()
        value=self.cbLdapValue.currentText().ascii()
        if attr == '':
            return True
        
        attrs = [(attr,value)]
        
        if attr.lower() == 'objectclass':
            if value == '':
                return True
            item=self.lvConfLdap.firstChild()
            item=item.firstChild()
            while item is not None:
                subitem=item.firstChild()
                if item.text(0).ascii().lower() == value.lower():
                    while subitem is not None:
                        if subitem.text(1).ascii() is None: newvalue=""
                        else: newvalue=subitem.text(1).ascii()
                        attrs.extend([(subitem.text(0).ascii(),newvalue)])
                        subitem=subitem.nextSibling()
                item=item.nextSibling()
        
        for attr,value in attrs:
            item=self.lvLdapAttr.firstChild()
            jump=False
            while item is not None:
                if item.text(0).ascii() == attr and (item.text(1).ascii() == value or value == ''):
                    jump=True
                    break
                item=item.nextSibling()
            if jump:
                continue
            item = QListViewItem(self.lvLdapAttr)
            item.setText(0,attr)
            item.setText(1,value)
        if self.cbLdapStack.currentItem() == 4:
            self.console("Por favor, selecione um dos atributos para ser o DN do novo registro antes de criá-lo.".encode('iso-8859-1'))
        
        

    def ldap_rename_rdn(self):
        rdnnew=str(self.__tr(self.lvLdap.currentItem().text(0).ascii()))
        if self.rdnold.split(",")[0] == rdnnew:
            return True
        dnexist = 1
        item = self.lvLdapAttr.firstChild()
        while item is not None:
            if item.text(0).ascii()+"="+str(self.__tr(item.text(1).ascii())) == rdnnew:
                dnexist = 0
            item = item.nextSibling()
        if self.ldap_modify_rdn(self.rdnold, rdnnew,dnexist):
            self.console("Registro "+self.rdnold.encode('iso-8859-1')+" alterado com sucesso.")
            self.lvLdapAttr.clear()
            return True
        else:
            self.lvLdap.currentItem().setText(0, self.rdnold.split(",")[0])
            return False
        

    def ldap_modify_rdn(self,a0,a1,a2):
        #a0 = oldDN, a1 = newDN, a2 = newDNexist
        try:
            l = self.ldap_connect()
            l.rename_s(a0,a1,None,a2)
            l.unbind_s()
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        

    def ldap_del_entry(self,a0):
        l = self.ldap_connect()
        try:
            l.delete_s(a0)
            return True
        except ldap.STRONG_AUTH_REQUIRED, e:
            self.console("Permissão negada para remover registro: ".encode('iso-8859-1')+a0)
            return False
        

    def postfix_postconf(self):
        if self.rbPostconfN.isChecked():
            cmd = "postconf -n"
        elif self.rbPostconfAll.isChecked():
            cmd = "postconf"
        if self.rbPostconfD.isChecked():
            cmd = "postconf -d"
        cmd = self.ssh_open(cmd)
        self.postconf = {}
        lastOpt = self.cbPostconf.currentText().ascii()
        self.cbPostconf.clear()
        i = 0
        for config in cmd:
            if re.search("=",config):
                configlist = config.strip().split("=")
                configlist[0]=configlist[0].strip(" ")
                self.postconf[configlist[0]] = configlist[1]
                self.cbPostconf.insertItem(configlist[0])
                if configlist[0] == lastOpt:
                    lastItem = i
                i = i + 1
        try:
            self.cbPostconf.setCurrentItem(lastItem)
        except UnboundLocalError, e:
            pass
        self.postconf_changed()
        

    def ssh_open(self,a0):
        print_cmd=[]
        try:
            self.console("Executando comando remoto: "+a0)
            child = pexpect.spawn('ssh -p'+self.iSshPort.text().ascii()+' '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+' "'+a0+'"')
            i = child.expect(['assword','want to continue connecting'], timeout=5)
            if i==0:
                self.console("Realizando login no SSH.")
                child.sendline(self.iSshPass.text().ascii())
            elif i==1:
                self.console("Aceitando SSH fingerprint")
                child.sendline('yes')
                child.expect('assword', timeout=2)
                self.console("Realizando login no SSH.")
                child.sendline(self.iSshPass.text().ascii())
            for line in child:
                line = re.sub("(\n|\r)","",line)
                print_cmd.append(line)
            child.kill(0)
        except pexpect.EOF, t:
            self.console("Erro na conexão: ".encode('iso8859-1')+self.iSshHost.text().ascii())
        except pexpect.TIMEOUT, t:
           self.console("Timeout na conexão: ".encode('iso8859-1')+self.iSshHost.text().ascii())
        return print_cmd
        

    def ssh_connect(self):
        try:
            if self.ssh_connect_active_host != self.iSshHost.text().ascii() or self.ssh_connect_active_port != self.iSshPort.text().ascii() or self.ssh_connect_active_user != self.iSshUser.text().ascii():
                pass
            elif self.ssh:
                return self.ssh
        except:
            pass
        
        self.ssh = pxssh.pxssh()
        if self.ssh.login ("-p%s %s" % (self.iSshPort.text().ascii(), self.iSshHost.text().ascii()), self.iSshUser.text().ascii(), self.iSshPass.text().ascii()):
            self.ssh_connect_active_host = self.iSshHost.text().ascii()
            self.ssh_connect_active_port = self.iSshPort.text().ascii()
            self.ssh_connect_active_user = self.iSshUser.text().ascii()
            return self.ssh
        else:
            raise "Authentication error."
        

    def ssh_exec(self,a0):
        
        s = self.ssh_connect()
        s.sendline ("%s > /dev/null 2>&1 && echo OK" % a0)
        s.prompt()
        if re.search("\nOK", s.before):
            return True
        else:
            return False
        

    def postconf_changed(self):
        
        value = self.postconf.get(self.cbPostconf.currentText().ascii())
        value = re.sub("( )+"," ",value)
        value = re.sub(", ",",",value)
        value = re.sub(",",",\n",value)
        value = re.sub("^ ","",value)
        self.tePostconf.setText(value)
        

    def postconf_save(self):
        
        value = re.sub(",",", ",self.tePostconf.text().ascii())
        value = re.sub("( )+"," ",value)
        value = re.sub("\n","",value)
        value = re.sub("\r","",value)
        option = self.cbPostconf.currentText().ascii()
        if self.ssh_exec("postconf -e %s=%s" % (option, value) ):
            self.console("Opção %s configurada com sucesso.".encode('iso-8859-1') % option )
        else:
            self.console("Erro ao configurar %s." % option )
        
        

    def postfix_open_conf(self):
        
        value = self.ssh_open("cat "+self.iPostFileOpen.text().ascii())
        values = ""
        for line in value[1:]:
            values = values+line+"\n"
        if re.search("^cat:",values):
            self.console("Arquivo "+self.iPostFileOpen.text().ascii()+" nao encontrado.")
            return True
        self.tePostFileOpen.setText(values)
        

    def postfix_save_conf(self):
        if self.tePostFileOpen.length () == 0:
            self.ssh_exec("rm -f "+self.iPostFileOpen.text().ascii())
            return True
        f = open("/tmp/korreio.tmp", 'w')
        for line in self.tePostFileOpen.text().ascii():
            f.write(line)
        f.close()
        self.scp_cmd(self.iPostFileOpen.text().ascii())
        

    def scp_cmd(self,a0):
        
        try:
            self.console("Salvando arquivo remoto: "+a0)
            child = pexpect.spawn('scp -P'+self.iSshPort.text().ascii()+' /tmp/korreio.tmp '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+':"'+a0+'"')
            i = child.expect(['assword','want to continue connecting'], timeout=5)
            if i==0:
                self.console("Realizando login no SSH.")
                child.sendline(self.iSshPass.text().ascii())
            elif i==1:
                self.console("Aceitando SSH fingerprint")
                child.sendline('yes')
                child.expect('assword', timeout=2)
                self.console("Realizando login no SSH.")
                child.sendline(self.iSshPass.text().ascii())
            print_cmd=[]
            for line in child:
                print_cmd.append(line)
            child.kill(0)
        except pexpect.EOF, t:
            self.console("Erro na conexão: "+self.iSshHost.text().ascii())
        except pexpect.TIMEOUT, t:
            self.console("Timeout na conexão: "+self.iSshHost.text().ascii())
        
        

    def postfix_postmap(self):
        file = self.iPostFileOpen.text().ascii()
        if self.ssh_exec("postmap %s" % file):
            self.console("Database %s.db gerada com sucesso." % file )
        else:
            self.console("Erro ao gerar database %s.db." % file )
        

    def postfix_stop(self):
        if self.ssh_exec("/etc/init.d/postfix stop"):
            self.console("Postfix parado com sucesso.")
        else:
            self.console("Erro ao parar Postfix.")
        

    def postfix_start(self):
        if self.ssh_exec("/etc/init.d/postfix start"):
            self.console("Postfix iniciado com sucesso.")
        else:
            self.console("Erro ao iniciar Postfix.")
        

    def postfix_restart(self):
        if self.ssh_exec("/etc/init.d/postfix restart"):
            self.console("Postfix reiniciado com sucesso.")
        else:
            self.console("Erro ao reiniciar Postfix.")
        

    def ldap_get_dn(self):
        item = self.lvLdap.currentItem()
        dn = item.text(0).ascii()
        while item.parent() is not None:
            dn = dn+","+item.parent().text(0).ascii()
            item = item.parent()
        return dn
        

    def action_ldap_set_port(self):
        if self.cbLdapMode.currentText().ascii() == "ldap://":
            self.iLdapPort.setText("389")
        else:
            self.iLdapPort.setText("636")
        

    def action_ldap_change_widgetstack(self):
        
        selected_stack = self.cbLdapStack.currentItem()
        
        if self.lvLdap.currentItem() is None:
            if selected_stack != 0:
                self.cbLdapStack.setCurrentItem(0)
                self.console("Selecione o registro para executar esta ação.".encode('iso-8859-1'))
            return True
        
        if selected_stack < 4:
            self.wsLdap.raiseWidget(selected_stack)
            if selected_stack == 0:
                self.ldap_dn_clicked()
        else:
            self.lvLdapAttr.clear()
            self.wsLdap.raiseWidget(0)
            self.console("O novo registro será inserido na base: ".encode('iso8859-1')+self.ldap_get_dn()+".")
        

    def ldap_passwd(self):
        
        if not self.cbLdapUserPassword.isChecked() and not self.cbLdapSambaPassword.isChecked():
            self.console("Selecione ao menos uma opção.".encode('iso-8859-1'))
            return False
        
        old={}
        new={}
        
        if self.cbLdapUserPassword.isChecked():
        
            salt = ''
            for i in range(16):
                salt += choice(letters+digits)
        
            old["userPassword"] = 'None'
            hash = self.cbUserPassword.currentText().ascii()
            if hash == "{SSHA}":
                new["userPassword"] = "{SSHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]
            elif hash == "{SHA}":
                new["userPassword"] = "{SHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii()).digest())[:-1]
            elif hash == "{SMD5}":
                new["userPassword"] = "{SMD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]
            elif hash == "{MD5}":
                new["userPassword"] = "{MD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii()).digest())[:-1]
            elif hash == "{CRYPT}":
                salt = ''
                for i in [0,1]:
                    salt += choice(letters+digits)
                new["userPassword"] = "{CRYPT}" + crypt.crypt(str(self.iLdapPasswd.text().ascii()),salt)
            elif hash == "{PLAINTEXT}":
                new["userPassword"] = self.iLdapPasswd.text().ascii()
            else:
                self.console("Algoritmo não implementando.".encode('iso-8859-1'))
                return False
        
        if self.cbLdapSambaPassword.isChecked():
            old["sambaNTPassword"] = 'None'
            new["sambaNTPassword"] = smbpasswd.nthash(self.iLdapPasswd.text().ascii())
            old["sambaLMPassword"] = 'None'
            new["sambaLMPassword"] = smbpasswd.lmhash(self.iLdapPasswd.text().ascii())
        
        self.ldap_modify(self.ldap_get_dn(),old,new)
        

    def ldap_modify(self,a0,a1,a2):
        dn=str(self.__tr(a0))
        old=a1
        new=a2
        try:
            ldif = modlist.modifyModlist(old,new)
            l = self.ldap_connect()
            l.modify_s(dn,ldif)
            l.unbind_s()
            self.console("Registro "+dn.encode('iso-8859-1')+" alterado com sucesso.")
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        

    def console(self,a0):
        text=datetime.datetime.now().strftime("%d %b %Y %H:%M:%S ")+a0
        self.tlConsole.setText(text)
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.log"), 'a')
            f.write(text+'\n')
            f.close()
        except OSError, e:
            print e
        

    def parse_exception(self,a0,a1):
        if a0 == "LDAPError":
            if a1[0]['desc'] == "Object class violation":
                self.console(a1[0]['info'])
            elif a1[0]['desc'] == "Naming violation":
                self.console(a1[0]['info'])
            elif a1[0]['desc'] == "Can't contact LDAP server":
                self.console("Erro ao conectar host "+self.iLdapHost.text().ascii())
            elif a1[0]['info'] == "no write access to parent":
                self.console("Sem permissão de escrita no referral, autentique-se nesta raiz: ".encode('iso-8859-1')+self.ldap_get_dn())
            elif a1[0]['desc'] == "No such attribute":
                self.console(a1[0]['info'])
            else:
                self.console(str(a1))
        else:
            self.console(str(a1))
        
        

    def action_mailbox_doubleclicked(self):
        if self.lvCyrus.currentItem().parent() is not None:
            item = self.lvCyrus.currentItem()
            self.mailboxold = item.text(0).ascii()
            while item.parent() is not None:
                item=item.parent()        
                self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
            self.lvCyrus.currentItem().setRenameEnabled(0,True)
            self.lvCyrus.currentItem().startRename(0)
        if self.cbUserACL.count() > 1:
            self.cbUserACL.popup()
        
        

    def action_gmailbox_doubleclicked(self):
        item = self.lvCyrusGlobal.currentItem()
        self.mailboxold = item.text(0).ascii()
        while item.parent() is not None:
            item=item.parent()        
            self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
        self.lvCyrusGlobal.currentItem().setRenameEnabled(0,True)
        self.lvCyrusGlobal.currentItem().startRename(0)
        
        

    def action_config_change_widgetstack(self):
        item=self.lvConfig.currentItem()
        if item.parent() is None:
           if  item.text(0).ascii() == "Servidores":
                self.wsConfig.raiseWidget(3)
                self.tConfShowLdapServer.setText("Host: "+self.cbLdapMode.currentText().ascii()+self.iLdapHost.text().ascii()+":"+self.iLdapPort.text().ascii())
                self.tConfShowLdapUser.setText("User: "+self.iLdapUser.text().ascii())
                self.tConfShowLdapBaseDN.setText("Base: "+self.cbLdapBaseDN.currentText().ascii())
                self.tConfShowImapServer.setText("Host: "+self.cbCyrusMode.currentText().ascii()+self.iCyrusHost.text().ascii()+":"+self.iCyrusPort.text().ascii())
                self.tConfShowImapUser.setText("User: "+self.iCyrusUser.text().ascii())
                self.tConfShowSshServer.setText("Host: ssh://"+self.iSshHost.text().ascii()+":"+self.iSshPort.text().ascii())
                self.tConfShowSshUser.setText("User: "+self.iSshUser.text().ascii())
        elif item.parent().text(0).ascii()+"."+item.text(0).ascii() == "Servidores.LDAP":
            self.wsConfig.raiseWidget(0)
        elif item.parent().text(0).ascii()+"."+item.text(0).ascii() == "Servidores.IMAP":
            self.wsConfig.raiseWidget(1)
        elif item.parent().text(0).ascii()+"."+item.text(0).ascii() == "Servidores.SSH":
            self.wsConfig.raiseWidget(2)
        elif str(self.__tr(item.parent().text(0).ascii()))+"."+item.text(0).ascii() == "Preferências.LDAP":
            self.wsConfig.raiseWidget(4)
        elif str(self.__tr(item.parent().text(0).ascii()))+"."+item.text(0).ascii() == "Preferências.IMAP":
            self.wsConfig.raiseWidget(5)
        

    def action_config_ldap_connection(self):
        i=0
        while self.confDict.get("ldap"+str(i)+".name"):
            if self.confDict.get("ldap"+str(i)+".name") == self.cbLdapConnection.currentText().ascii():
                lastConn="ldap"+str(i)
            i=i+1
        
        self.iLdapConnection.setText(self.confDict.get(lastConn+".name"))
        self.cbLdapMode.setCurrentText(self.confDict.get(lastConn+".mode"))
        self.iLdapHost.setText(self.confDict.get(lastConn+".host"))
        self.iLdapPort.setText(self.confDict.get(lastConn+".port"))
        self.cbLdapBaseDN.clear()
        self.cbLdapBaseDN.insertItem(self.confDict.get(lastConn+".basedn"))
        self.iLdapUser.setText(self.confDict.get(lastConn+".user"))
        self.iLdapPass.setText(self.confDict.get(lastConn+".pass"))
        if self.confDict.get(lastConn+".ref") == "True":
            self.cLdapRef.setChecked(True)
        else:
            self.cLdapRef.setChecked(False)
        if self.confDict.get(lastConn+".cert") == "True":
            self.cLdapCert.setChecked(True)
        else:
            self.cLdapCert.setChecked(False)
        
        

    def action_config_imap_connection(self):
        i=0
        while self.confDict.get("imap"+str(i)+".name"):
            if self.confDict.get("imap"+str(i)+".name") == self.cbCyrusConnection.currentText().ascii():
                lastConn="imap"+str(i)
            i=i+1
        
        self.iCyrusConnection.setText(self.confDict.get(lastConn+".name"))
        self.cbCyrusMode.setCurrentText(self.confDict.get(lastConn+".mode"))
        self.iCyrusHost.setText(self.confDict.get(lastConn+".host"))
        self.iCyrusPort.setText(self.confDict.get(lastConn+".port"))
        self.iCyrusSievePort.setText(self.confDict.get(lastConn+".sieport"))
        self.iCyrusUser.setText(self.confDict.get(lastConn+".user"))
        self.iCyrusPass.setText(self.confDict.get(lastConn+".pass"))
        self.iCyrusPart.setText(self.confDict.get(lastConn+".part"))
        

    def action_config_ssh_connection(self):
        i=0
        while self.confDict.get("ssh"+str(i)+".name"):
            if self.confDict.get("ssh"+str(i)+".name") == self.cbSSHConnection.currentText().ascii():
                lastConn="ssh"+str(i)
            i=i+1
        self.iSSHConnection.setText(self.confDict.get(lastConn+".name"))
        self.iSshHost.setText(self.confDict.get(lastConn+".host"))
        self.iSshPort.setText(self.confDict.get(lastConn+".port"))
        self.iSshUser.setText(self.confDict.get(lastConn+".user"))
        self.iSshPass.setText(self.confDict.get(lastConn+".pass"))
        

    def action_del_ldap_connection(self):
            if not self.cbLdapConnection.currentText().ascii():
                return True
            i=0
            while self.confDict.get("ldap"+str(i)+".name"):
                if self.confDict.get("ldap"+str(i)+".name") == self.cbLdapConnection.currentText().ascii():
                    j=i+1
                    while self.confDict.get("ldap"+str(j)+".name"):
                        for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                            self.confDict["ldap"+str(j-1)+"."+opt]=self.confDict.get("ldap"+str(j)+"."+opt)
                        j=j+1
                i=i+1
            for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                del self.confDict["ldap"+str(i-1)+"."+opt]
        
            i=self.cbLdapConnection.currentItem()
            self.cbLdapConnection.removeItem(i)
            if i > 0:
                self.cbLdapConnection.setCurrentItem(i-1)
                self.action_config_ldap_connection()
            elif self.cbLdapConnection.count() > 0:
                self.cbLdapConnection.setCurrentItem(0)
                self.action_config_ldap_connection()
            else:
                self.iLdapConnection.clear()
                self.cbLdapMode.setCurrentText("ldap://")
                self.iLdapHost.clear()
                self.iLdapPort.setText("389")
                self.cbLdapBaseDN.clear()
                self.iLdapUser.clear()
                self.iLdapPass.clear()
                self.cLdapRef.setChecked(False)
                self.cLdapCert.setChecked(False)
        
        

    def action_del_imap_connection(self):
            if not self.cbCyrusConnection.currentText().ascii():
                return True
            i=0
            while self.confDict.get("imap"+str(i)+".name"):
                if self.confDict.get("imap"+str(i)+".name") == self.cbCyrusConnection.currentText().ascii():
                    j=i+1
                    while self.confDict.get("imap"+str(j)+".name"):
                        for opt in ['name','mode','host','port','sieport','user','pass','part']:
                            self.confDict["imap"+str(j-1)+"."+opt]=self.confDict.get("imap"+str(j)+"."+opt)
                        j=j+1
                i=i+1
            for opt in ['name','mode','host','port','sieport','user','pass','part']:
                del self.confDict["imap"+str(i-1)+"."+opt]
        
            i=self.cbCyrusConnection.currentItem()
            self.cbCyrusConnection.removeItem(i)
            if i > 0:
                self.cbCyrusConnection.setCurrentItem(i-1)
                self.action_config_imap_connection()
            elif self.cbCyrusConnection.count() > 0:
                self.cbCyrusConnection.setCurrentItem(0)
                self.action_config_imap_connection()
            else:
                self.iCyrusConnection.clear()
                self.cbCyrusMode.setCurrentText("imap://")
                self.iCyrusHost.clear()
                self.iCyrusPort.setText("143")
                self.iCyrusSievePort.setText("2000")
                self.iCyrusUser.clear()
                self.iCyrusPass.clear()
                self.iCyrusPart.clear()
        

    def action_del_ssh_connection(self):
            if not self.cbSSHConnection.currentText().ascii():
                return True
            i=0
            while self.confDict.get("ssh"+str(i)+".name"):
                if self.confDict.get("ssh"+str(i)+".name") == self.cbSSHConnection.currentText().ascii():
                    j=i+1
                    while self.confDict.get("ssh"+str(j)+".name"):
                        for opt in ['name','host','port','user','pass']:
                            self.confDict["ssh"+str(j-1)+"."+opt]=self.confDict.get("ssh"+str(j)+"."+opt)
                        j=j+1
                i=i+1
            for opt in ['name','host','port','user','pass']:
                del self.confDict["ssh"+str(i-1)+"."+opt]
        
            i=self.cbSSHConnection.currentItem()
            self.cbSSHConnection.removeItem(i)
            if i > 0:
                self.cbSSHConnection.setCurrentItem(i-1)
                self.action_config_ssh_connection()
            elif self.cbSSHConnection.count() > 0:
                self.cbSSHConnection.setCurrentItem(0)
                self.action_config_ssh_connection()
            else:
                self.iSSHConnection.clear()
                self.iSshHost.clear()
                self.iSshPort.setText("22")
                self.iSshUser.clear()
                self.iSshPass.clear()
        
        

    def action_conf_imap_add_default_folder(self):
        self.lbConfImapFolders.insertItem(self.iConfImapFolder.text().ascii())
        self.iConfImapFolder.clear()
        

    def action_conf_imap_del_default_folder(self):
        self.lbConfImapFolders.removeItem(self.lbConfImapFolders.currentItem())
        

    def sieve_search(self):
        
        self.lvSieve.clear()
        imap = self.imap_connect()
        for user in imap.lm("user"+imap.SEP+self.iSieveSearch.text().ascii()+"%"):
            user=user.split(imap.SEP)[1]
            item = QListViewItem(self.lvSieve)
            item.setText(0, user)
            if self.cSieveScript.isChecked():
                s = self.sieve_connect(user)
                scripts = s.listscripts()
                s.logout()
                if scripts[0] == 'OK':
                    for script,active in scripts[1]:
                        if active:
                            item.setText(1, script)
                            break
        

    def sieve_connect(self,a0):
        
        admin = self.iCyrusUser.text().ascii().split("@")
        if admin[0] != self.iCyrusUser.text().ascii():
            user = a0+"@"+admin[1]
        else:
            user = a0
        
        s = sievelib.MANAGESIEVE(self.iCyrusHost.text().ascii(),int(self.iCyrusSievePort.text().ascii()))
        if s.alive:
            if s.login('PLAIN',user,self.iCyrusPass.text().ascii(),self.iCyrusUser.text().ascii()):
                self.console("Servidor sieve://"+self.iCyrusHost.text().ascii()+":"+self.iCyrusSievePort.text().ascii()+"/"+user+" conectado com sucesso.")
            else:
                self.console("Erro ao conectar no servidor sieve://"+self.iCyrusHost.text().ascii()+":"+self.iCyrusSievePort.text().ascii()+"/"+user+". (Usuário ou senha inválidos)".encode('iso-8859-1'))
        else:
            self.console("Erro ao conectar no servidor sieve://"+self.iCyrusHost.text().ascii()+":"+self.iCyrusSievePort.text().ascii()+"/"+user+". (Conexão recusada)".encode('iso-8859-1'))
            
        return s
        
        

    def sieve_user_clicked(self):
        
        self.teSieveScript.clear()
        self.cbSieveScript.clear()
        
        item = self.lvSieve.currentItem()
        if item is None:
            return True
        
        s = self.sieve_connect(item.text(0).ascii())
        scripts = s.listscripts()
        s.logout()
        
        if scripts[0] == 'OK':
            for script,active in scripts[1]:
                self.cbSieveScript.insertItem(script)
                if self.lvSieve.currentItem().text(1).ascii() == script:
                    self.cbSieveScript.setCurrentText(script)
        
        if self.cbSieveScript.count() > 0:
            self.sieve_get_script()
        
        

    def sieve_get_script(self):
        s = self.sieve_connect(self.lvSieve.currentItem().text(0).ascii())
        script = s.getscript(self.cbSieveScript.currentText().ascii())
        s.logout()
        
        self.teSieveScript.clear()
        if script[0] == 'OK':
            self.teSieveScript.setText(script[1])
        

    def sieve_set_script(self):
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                if self.cbSieveScript.currentText().ascii():
                    status = s.putscript(self.cbSieveScript.currentText().ascii(),self.teSieveScript.text().ascii().replace("#USER#",item.text(0).ascii()))
                    if status == 'OK':
                        item.setText(1,self.cbSieveScript.currentText().ascii())
                        s.setactive(self.cbSieveScript.currentText().ascii())
                else:
                    item.setText(1,"")
                    s.setactive()
                s.logout()
            item=item.nextSibling()
        
        self.sieve_get_script()
        

    def sieve_unset_script(self):
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                s.setactive()
                s.logout()
                item.setText(1,"")
            item=item.nextSibling()
        
        

    def sieve_del_script(self):
        if not self.cbSieveScript.currentText().ascii():
            self.console("Digite o nome do script.")
            return True
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                if s.deletescript(self.cbSieveScript.currentText().ascii()) == 'OK':
                    if self.cbSieveScript.currentText().ascii() == item.text(1).ascii():
                        item.setText(1,"")
                s.logout()
            item=item.nextSibling()
        
        self.sieve_get_script()
        
        

    def sieve_select_all(self):
        self.lvSieve.selectAll(True)
        

    def sieve_use_template(self):
        
        try:
            sep = self.m.SEP
        except AttributeError, e:
            sep = "/"
        
        self.cbSieveScript.setCurrentText("script.siv")
        template = self.lbSieveScripts.currentItem()
        if template == 0:
            self.teSieveScript.setText("redirect \"destinatario@dominio.com\";\n")
        
        elif template == 1:
            self.teSieveScript.setText("""redirect "destinatario@dominio.com";
        keep;
        """.replace("        ",""))
        
        elif template == 2:
            self.teSieveScript.setText("""require "fileinto";
        if address :contains "from" "remetente1@dominio1.com.br" {
           fileinto "INBOX%(sep)sPasta1";
        }
        """.replace("        ","") % {'sep':sep})
        
        elif template == 3:
            self.teSieveScript.setText("""require "fileinto";
        if address :contains "from" ["from1@dom1.com","from2@dom2.com"] {
            fileinto "INBOX%(sep)sPasta1";
        }
        elsif address :contains "from" ["from3@dom3.com","from4@dom4.com"] {
            fileinto "INBOX%(sep)sPasta2";
        }
        """.replace("        ","") % {'sep':sep})
        
        elif template == 4:
            self.teSieveScript.setText("""if header :contains "X-Spam-Flag" "YES" {
            discard;
        }
        """.replace("        ",""))
        
        elif template == 5:
            self.teSieveScript.setText("""require "fileinto";
        if header :contains "X-Spam-Flag" "YES" {
            fileinto "INBOX%(sep)sSpam";
        }
        """.replace("        ","") % {'sep':sep})
        
        elif template == 6:
            self.console("A macro #USER# será substituida pelo respectivo usuário.".encode('iso-8859-1'))
            if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
                domain="dominio.com.br"
            else:
                domain=self.iCyrusUser.text().ascii().split("@")[1]
            self.teSieveScript.setText("""require ["vacation","fileinto"];
        
        if header :contains "X-Spam-Flag" "YES" {
            fileinto "INBOX%(sep)sSpam";
            stop;
        }
        
        vacation :days 5
        :subject "Estou ausente"
        :addresses ["#USER#@%(domain)s"]
         "Estarei ausente entre os dias ....
        
         Obrigado,
        
         --
         xxxxxxxxxxxx";
        """.replace("        ","") % {'sep':sep,'domain':domain})
        
        elif template == 7:
            if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
                domain="dominio.com.br"
            else:
                domain=self.iCyrusUser.text().ascii().split("@")[1]
            self.console("A macro #USER# será substituida pelo respectivo usuário.".encode('iso-8859-1'))
            self.teSieveScript.setText("""require "vacation";
        vacation :days 5
        :subject "Estou ausente."
        :addresses ["#USER#@%(domain)s"]
         "Estarei ausente entre os dias ....
        
         Obrigado,
        
         --
         xxxxxxxxxxxx";
        """.replace("        ","") % {'domain':domain})
        

    def action_conf_ldap_add_attr(self):
        
        itemroot=self.lvConfLdap.firstChild()
        if itemroot.isSelected():
            newitem=QListViewItem(itemroot)
            newitem.setText(0,self.iConfLdapAttr.text().ascii())
            newitem.setText(1,self.iConfLdapValue.text().ascii())
            return True
        item=itemroot.firstChild()
        while item is not None:
            if item.isSelected():
                item.setOpen(True)
                newitem=QListViewItem(item)
                newitem.setText(0,self.iConfLdapAttr.text().ascii())
                newitem.setText(1,self.iConfLdapValue.text().ascii())
                return True
            subitem=item.firstChild()
            while subitem is not None:
                if subitem.isSelected():
                    subitem.setOpen(True)
                    newitem=QListViewItem(item)
                    newitem.setText(0,self.iConfLdapAttr.text().ascii())
                    newitem.setText(1,self.iConfLdapValue.text().ascii())
                    return True
                subitem=subitem.nextSibling()
            item=item.nextSibling()
        
        

    def action_conf_ldap_del_attr(self):
        
        itemroot=self.lvConfLdap.firstChild()
        item=itemroot.firstChild()
        while item is not None:
            if item.isSelected():
                itemroot.takeItem(item)
                self.lvConfLdap.currentItem().setSelected(True)
                return True
            subitem=item.firstChild()
            while subitem is not None:
                if subitem.isSelected():
                    item.takeItem(subitem)
                    self.lvConfLdap.currentItem().setSelected(True)
                    return True
                subitem=subitem.nextSibling()
            item=item.nextSibling()
        
        

    def action_imap_selectall(self):
        
        if self.lvImapPartition.hasFocus():
            self.lvImapPartition.selectAll(True)
            self.lvImapPartitionGlobal.selectAll(False)
        else:
            self.lvImapPartitionGlobal.selectAll(True)
            self.lvImapPartition.selectAll(False)
        
        

    def queue_load(self):
        
        re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)\s+(\d+)\s([A-Z][a-z][a-z])\s([A-Z][a-z][a-z])\s+(\d+)\s(\d\d:\d\d:\d\d)\s+(.*)')
        re_rcpt  = re.compile(r'\s+(.*@.*)\b')
        re_log  = re.compile(r'(\s+)?\(.*\)')
        
        self.iQueueMessage.clear()
        self.lvQueue.clear()
        
        itemFrom = {}
        itemQueueID = {}
        self.itemLog = {}
        
        for line in self.ssh_open("postqueue -p"):
            if re.search("\s\d\d:\d\d:\d\d", line):
                tmp = ""
                match = re_queueid.match(line)
                if match is not None:
                    #print "regexp: %s %s %s %s %s %s %s" % (match.group(1), match.group(2), match.group(3), match.group(4), match.group(5), match.group(6), match.group(7))
                    mailFrom = match.group(7)
                    if not itemFrom.get(mailFrom):
                        itemFrom[mailFrom] = QListViewItem(self.lvQueue)
                        itemFrom[mailFrom].setText(0,match.group(7))
                    queueid = match.group(1)
                    itemQueueID[queueid] = QListViewItem(itemFrom[mailFrom])
                    itemQueueID[queueid].setText(0,match.group(1))
                    itemQueueID[queueid].setOpen(True)
                    continue
            match = re_log.match(line)
            if match is not None:
                tmp = line
                continue
            match = re_rcpt.match(line)
            if match is not None:
                self.itemLog["%s:%s" % ( queueid, match.group(1) )] = tmp
                tmp = ""
                itemRcpt = QListViewItem(itemQueueID[queueid])
                itemRcpt.setText(0,match.group(1))
        
        item = self.lvQueue.firstChild()
        total = [0, 0]
        while item is not None:
            count = item.childCount()
            subcount = 0
            if count > 0:
                subitem = item.firstChild()
                while subitem is not None:
                    subcount = subcount + subitem.childCount()
                    subitem.setText(1,"%s" % subitem.childCount())
                    subitem = subitem.nextSibling()
            item.setText(1,"%s/%s" % (count, subcount))
            item = item.nextSibling()
            total[0] = total[0] + count
            total[1] = total[1] + subcount
        
        self.console("A fila contém %s mensagens para %s destinatários.".encode('iso-8859-1') % (total[0], total[1]))
        self.lvQueue.setColumnWidth(0, 300)
        self.lvQueue.setColumnWidth(1, 70)
        
        

    def queue_get_message(self):
        
        item = self.lvQueue.currentItem()
        
        if item is None:
            self.pQueueDel.setEnabled(False)
            return True
        
        if item.parent() is None:
            self.pQueueDel.setEnabled(True)
            return True
        
        if item.childCount() == 0:
            self.pQueueDel.setEnabled(False)
            self.iQueueMessage.setText(self.itemLog.get("%s:%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) ) )
            return True
        
        queueid = item.text(0).ascii()
        re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
        match = re_queueid.match(queueid)
        if match is not None:
            self.pQueueDel.setEnabled(True)
            self.iQueueMessage.setText("\n".join(self.ssh_open("postcat -q %s" % match.group(1))[1:]))
        
        

    def queue_del_message(self):
        
        self.iQueueMessage.clear()
        
        item = self.lvQueue.currentItem()
        re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
        
        if item.parent() is None:
            subitem = item.firstChild()
            success = False
            queuelist = []
            while subitem is not None:
                queuelist.append(re_queueid.match(subitem.text(0).ascii()).group(1))
                if len(queuelist) == 50 or subitem.nextSibling() is None:
                    if self.ssh_exec("cat <<< \"%s\" | postsuper -d - " % "\n".join(queuelist)):
                        success = True
                    queuelist = []
                subitem = subitem.nextSibling()
            if success:
                self.console("%s mensagen(s) removida(s) com sucesso." % item.childCount())
            self.lvQueue.takeItem(item)
            return True
        
        match = re_queueid.match(item.text(0).ascii())
        if match is not None:
            if self.ssh_exec("postsuper -d %s" % match.group(1)):
                self.console("Mensagem %s removida com sucesso." % match.group(1))
            else:
                self.console("Não foi possível remover a mensagem %s.".encode('iso-8859-1') % match.group(1))
            count = item.parent().text(1).ascii().split("/")
            if int(count[0]) == 1:
                self.lvQueue.takeItem(item.parent())
            else:
                item.parent().setText(1 ,"%s/%s" % (str(int(count[0]) - 1), str(int(count[1]) - int(item.childCount()))))
                item.parent().takeItem(item)
        
        

    def __tr(self,s,c = None):
        return qApp.translate("dKorreio",s,c)

    def __trUtf8(self,s,c = None):
        return qApp.translate("dKorreio",s,c,QApplication.UnicodeUTF8)
