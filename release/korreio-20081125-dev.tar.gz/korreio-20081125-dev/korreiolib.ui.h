# Copyright (c) 2007-2008 -  Reinaldo de Carvalho <reinaldoc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.

void dKorreio::init() {

global iso2utf, utf2iso

def iso2utf(string):
    return str(self.__tr(string))

def utf2iso(string):
    return string.encode('iso8859-1')

try:
    global sys, re, datetime, os
    import sys, re, datetime, os.path

    reload(sys)
    sys.setdefaultencoding("utf-8")

    global  sha, md5, b2a_base64, choice, letters, digits
    import sha, md5
    from binascii import b2a_base64
    from random import choice
    from string import letters, digits
except:
    print "Error importing core modules."
    sys.exit()

modfailed = []

try:
    global ldap, modlist
    import ldap, ldap.modlist as modlist
except:
    self.wKorreio.page(0).setEnabled(False)
    self.pGetBaseDN.setEnabled(False)
    modfailed.append("ldap")

try:
    global  smbpasswd
    import smbpasswd
except:
    self.cbLdapSambaPassword.setEnabled(False)
    self.pLdapSambaPopulate.setEnabled(False)
    self.cLdapFormSamba.setEnabled(False)
    modfailed.append("smbpasswd")

try:
    global cyruslib
    import cyruslib
except:
    self.wKorreio.page(1).setEnabled(False)
    self.wKorreio.page(2).setEnabled(False)
    modfailed.append("cyrus")

try:
    global sievelib
    import sievelib
except:
    self.wKorreio.page(3).setEnabled(False)
    modfailed.append("sieve")

try:
    global pexpect, pxssh
    import pexpect, pxssh
except:
    self.wKorreio.page(4).setEnabled(False)
    self.wKorreio.page(5).setEnabled(False)
    modfailed.append("pexpect")

if modfailed:
    msg = ""
    for mod in modfailed:
        msg = "%s%s\n" % (msg, "    - python-%s" % mod)
    QMessageBox.warning(None, "Modulos falharam", utf2iso("Os seguintes módulos não foram carregados:\n%s" % msg))

global active_conn
active_conn = {}

#
# Servers Menu
#

self.lvServersImapMenu = QPopupMenu(self)
self.lvServersLdapMenu = QPopupMenu(self)
self.lvServersSSHMenu = QPopupMenu(self)

self.connect(self.lvServersImapMenu, SIGNAL('activated(int)'), self.korreio_servers_menu_set_imap)
self.connect(self.lvServersLdapMenu, SIGNAL('activated(int)'), self.korreio_servers_menu_set_ldap)
self.connect(self.lvServersSSHMenu, SIGNAL('activated(int)'), self.korreio_servers_menu_set_ssh)

self.lvServersMenu = QPopupMenu(self)
self.lvServersMenu.insertItem('&IMAP', self.lvServersImapMenu, 0)
self.lvServersMenu.insertItem('&LDAP', self.lvServersLdapMenu, 1)
self.lvServersMenu.insertItem('&SSH', self.lvServersSSHMenu, 2)
self.lvServersMenu.insertSeparator()

#
# LDAP Menu
#

self.lvLdapSubMenu1 = QPopupMenu(self)
self.lvLdapSubMenu1.insertItem('&Registro', 0)
self.lvLdapSubMenu1.insertItem(utf2iso('Registro de &Usuário'), 1)
self.lvLdapSubMenu1.insertItem(utf2iso('Registro de &Diretório'), 2)

self.lvLdapMenu = QPopupMenu(self)
self.lvLdapMenu.clipBoard = "None"
self.lvLdapMenu.insertItem('&Novo', self.lvLdapSubMenu1, 0)
self.lvLdapMenu.insertItem('&Editar', 1)
self.lvLdapMenu.insertSeparator()
self.lvLdapMenu.insertItem('&Copiar', 2)
self.lvLdapMenu.insertItem('Recort&ar', 3)
self.lvLdapMenu.insertItem('C&olar', 4)
self.lvLdapMenu.insertItem('&Remover', 5)
self.lvLdapMenu.insertSeparator()
self.lvLdapMenu.insertItem('&Trocar senha', 6)
self.lvLdapMenu.insertItem('&Samba populate', 7)
self.lvLdapMenu.insertSeparator()
self.lvLdapMenu.insertItem('&Usar como base', 8)
self.lvLdapMenu.insertItem('Retornar a &base', 9)
self.lvLdapMenu.insertSeparator()
self.lvLdapMenu.insertItem('&Servidor', self.lvServersLdapMenu, 10)

self.connect(self.lvLdapMenu, SIGNAL('activated(int)'), self.ldap_menu_clicked)
self.connect(self.lvLdapSubMenu1, SIGNAL('activated(int)'), self.ldap_submenu1_clicked)

#
# IMAP Menu
#

self.lvImapMenu = QPopupMenu(self)
self.lvImapMenu.insertItem('&Renomear', 0)
self.lvImapMenu.insertItem('&Remover', 1)
self.lvImapMenu.insertItem('&Reconstruir', 2)
self.lvImapMenu.insertSeparator()
self.lvImapMenu.insertItem('&Servidor', self.lvServersImapMenu, 3)

self.connect(self.lvImapMenu, SIGNAL('activated(int)'), self.imap_menu_clicked)

#
# IMAP Partition Menu
#

self.lvImapPartMenu = QPopupMenu(self)
self.lvImapPartMenu.insertItem('Selecionar &todas', 0)
self.lvImapPartMenu.insertItem('&Definir Limite (Quota)', 1)
self.lvImapPartMenu.insertSeparator()
self.lvImapPartMenu.insertItem('&Servidor', self.lvServersImapMenu, 2)

self.connect(self.lvImapPartMenu, SIGNAL('activated(int)'), self.imap_partition_menu_clicked)

#
# Sieve Menu
#

self.lvSieveMenu = QPopupMenu(self)
self.lvSieveMenu.insertItem('Selecionar &todas', 0)
self.lvSieveMenu.insertSeparator()
self.lvSieveMenu.insertItem('&Servidor', self.lvServersImapMenu, 1)

self.connect(self.lvSieveMenu, SIGNAL('activated(int)'), self.sieve_menu_clicked)

#
# Services Menu
#

self.lvServicesMenu = QPopupMenu(self)
self.lvServicesMenu.insertItem('&Servidor', self.lvServersSSHMenu, 0)

#
# Queue Menu
#

self.lvQueueSubMenu1 = QPopupMenu(self)
self.lvQueueSubMenu1.insertItem('&Flush', 0)
self.lvQueueSubMenu1.insertItem('&Hold', 1)
self.lvQueueSubMenu1.insertItem('&Unhold', 2)
self.lvQueueSubMenu1.insertItem('Re&queue', 3)
self.lvQueueSubMenu1.insertItem('&Remover', 4)

self.lvQueueMenu = QPopupMenu(self)
self.lvQueueMenu.insertItem('&Atualizar', 0)
self.lvQueueMenu.insertSeparator()
self.lvQueueMenu.insertItem('&Ver mensagem', 1)
self.lvQueueMenu.insertItem('&Hold', 2)
self.lvQueueMenu.insertItem('&Unhold', 3)
self.lvQueueMenu.insertItem('Re&queue', 4)
self.lvQueueMenu.insertItem('&Remover', 5)
self.lvQueueMenu.insertSeparator()
self.lvQueueMenu.insertItem('&Todas', self.lvQueueSubMenu1, 6)
self.lvQueueMenu.insertSeparator()
self.lvQueueMenu.insertItem('&Servidor', self.lvServersSSHMenu, 7)

self.connect(self.lvQueueMenu, SIGNAL('activated(int)'), self.queue_menu_clicked)
self.connect(self.lvQueueSubMenu1, SIGNAL('activated(int)'), self.queue_submenu1_clicked)

#
# End Menu
#

self.ldap_cache_attr = {}
self.ldap_cache_items = {}

self.imap_annotation_mode(None)
self.config_load()

}

void dKorreio::statusBar() {
pass
}

void dKorreio::customEvent( a0 ) {
event = a0
if event.type() == "set_console_text":
    self.console(event.data())
}

void dKorreio::console( a0 ) {

msg = datetime.datetime.now().strftime("%d %b %Y %H:%M:%S :/# ")+a0
self.tlConsole.setText("&nbsp;%s" %utf2iso(msg))
self.tlConsole.setIndent(0)

msg = re.sub("(</?b>)","",msg)
self.lbLog.insertItem(utf2iso(msg))
self.lbLog.setCurrentItem(self.lbLog.count() - 1)
self.lbLog.ensureCurrentVisible()

try:
    f = open(os.path.expanduser("~/.korreio/korreio.log"), 'a')
    f.write("%s\n" % msg)
    f.close()
except OSError, e:
    print e

}

void dKorreio::console_debug( a0 ) {

print "#\n# Korreio Debug Started\n#\n\n", a0, "\n\n#\n# Korreio Debug Stopped\n#\n"

}

void dKorreio::parse_exception( a0, a1 ) {
# a0=type, a1=reason

if a0 == "LDAPError":
    if a1[0]["desc"] == "Size limit exceeded":
        self.console("<b>Atenção:</b> quantidade de registros excedido. Utilize um filtro mais restritivo.")
    elif a1[0]["desc"] == "Bad search filter":
        self.console("<b>Erro:</b> sintaxe inválida para filtro de pesquisa.")
    elif a1[0]["desc"] == "No such object":
        self.console("<b>Atenção:</b> a pesquisa não retornou resultados.")
    elif a1[0]["desc"] == "Already exists":
        self.console("<b>Erro:</b> o registro já existe.")
    elif a1[0]['desc'] == "Object class violation":
        errList = a1[0]['info'].split("'")
        if len(errList) == 4:
            self.console("<b>Erro:</b> o objectClass '%s' exige o attributo '%s'." % (errList[1], errList[3]))
        elif len(errList) == 3:
            self.console("<b>Erro:</b> o atributo '%s' não é suportado por estes objectClasses." % (errList[1]))
        else:
            errList = a1[0]['info'].split("/")
            if len(errList) == 2:
                self.console("<b>Erro:</b> objectClasses incompativeis '%s' e '%s'." % (errList[0].split("(")[1], errList[1].split(")")[0]) )
    elif a1[0]['desc'] == "Naming violation":
        self.console(a1[0]['info'])
    elif a1[0]['desc'] == "Can't contact LDAP server":
        self.console("<b>Erro:</b> conexão ao host %s:%s recusada." % (self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii()))
        try:
            del self.l
        except:
            pass
    elif a1[0]['desc'] == "Undefined attribute type":
        self.console("<b>Erro:</b> registro '%s' não esta definido no schema." % a1[0]['info'].split(":")[0])
    elif a1[0]['info'] == "no write access to parent":
        self.console("<b>Erro:</b> sem permissão de escrita no referral, autentique-se na raiz %s." % iso2utf(self.ldap_current_dn()))
    elif a1[0]['info'] == "modifications require authentication":
        user = self.iLdapUser.text().ascii()
        if not user: user = "anonymous"
        self.console("<b>Erro:</b> usuário '%s' sem permissão de escrita ou senha incorreta." % user)
    elif a1[0]['desc'] == "No such attribute":
        self.console(a1[0]['info'])
    else:
        self.console(str(a1))
elif a0 == "pexpect.EOF":
    server = "ssh://%s:%s" % (self.iSshHost.text().ascii(), self.iSshPort.text().ascii())
    if re.search("Connection refused", "%s" % a1):
        self.console("<b>Erro:</b> conexão %s recusada." % server)
    if re.search("Host key verification failed", "%s" % a1):
        self.console("<b>Erro:</b> conexão ssh://%s:%s com fingerprint inválido (man-in-the-middle attack)." % server)
    else:
        self.console("<b>Erro:</b> conexão com %s terminada." % server)
        self.console_debug(a1)
elif a0 == "pexpect.TIMEOUT":
    server = "ssh://%s:%s" % (self.iSshHost.text().ascii(), self.iSshPort.text().ascii())
    self.console("<b>Erro:</b> conexão com %s sofreu timeout." % server)
    self.console_debug(a1)
else:
    self.console(str(a1))

}

void dKorreio::korreio_update_servers_menu() {

self.lvServersImapMenu.clear()
self.lvServersLdapMenu.clear()
self.lvServersSSHMenu.clear()

for server in range(0, self.cbCyrusConnection.count()):
    self.lvServersImapMenu.insertItem(self.cbCyrusConnection.text(server).ascii(), int(server))

for server in range(0, self.cbLdapConnection.count()):
    self.lvServersLdapMenu.insertItem(self.cbLdapConnection.text(server).ascii(), int(server))

for server in range(0, self.cbSSHConnection.count()):
    self.lvServersSSHMenu.insertItem(self.cbSSHConnection.text(server).ascii(), int(server))

}

void dKorreio::korreio_servers_menu_set_ldap( a0 ) {

self.cbLdapConnection.setCurrentItem(a0)
self.config_ldap_set_connection()

}


void dKorreio::korreio_servers_menu_set_imap( a0 ) {

self.cbCyrusConnection.setCurrentItem(a0)
self.config_imap_set_connection()

}

void dKorreio::korreio_servers_menu_set_ssh( a0 ) {

self.cbSSHConnection.setCurrentItem(a0)
self.config_ssh_set_connection()

}

void dKorreio::korreio_set_server() {

self.lvServersMenu.popup(a1)

}

void dKorreio::korreio_module_clear( a0 ) {

if a0 == "ldap":
    self.lvLdap.clear()
    self.lvLdapAttr.clear()
elif a0 == "imap":
    self.lvImap.clear()
    self.iImapMailbox.clear()
    self.lvImapAcl.clear()
    self.iImapAclUser.clear()
    self.cbACL.setCurrentItem(0)
    self.iQuota.clear()
    self.iQuotaUsed.clear()
    self.imap_annotation_mode(None)
    self.cbImapAnnotation.setCurrentItem(0)
    self.iAnnotationValue.clear()
elif a0 == "imap-partition":
    self.lvImapPartition.clear()
    self.cbImapPartition.clear()
    self.pImapPartitionMove.setEnabled(False)
elif a0 == "sieve":
    self.lvSieve.clear()
    self.cbSieveScript.clear()
    self.teSieveScript.clear()
elif a0 == "ssh":
    self.cbPostconf.clear()
    self.tePostconf.clear()
    self.tePostFileOpen.clear()
    self.lvQueue.clear()
    self.iQueueMessage.clear()
    self.tlQueueMsgs.setText("0/0")
elif a0 == "ldap.form":
    self.iLdapFormCn.setFocus()
    self.iLdapFormCn.clear()
    self.iLdapFormMail.clear()
    self.iLdapFormStreet.clear()
    self.iLdapFormL.clear()
    self.iLdapFormPostalCode.clear()
    self.iLdapFormHomePhone.clear()
    self.iLdapFormUserP.clear()
    self.iLdapFormUserP2.clear()
    self.cLdapFormPosix.setChecked(False)
    self.fLdapFormPosix.setEnabled(False)
    self.iLdapFormUid.clear()
    self.iLdapFormUidNumber.setText("1000")
    self.iLdapFormGidNumber.setText("100")
    self.iLdapFormLoginShell.setText("/bin/bash")
    self.iLdapFormHomeDirectory.setText("/home")
    self.cLdapFormSamba.setChecked(False)
    self.fLdapFormSamba.setEnabled(False)
    self.cbLdapFormSambaDomain.clear()
    self.cbLdapFormPrimaryGroup.setCurrentItem(0)
    self.iLdapFormSambaPwdMustChange.setChecked(True)
    self.pLdapFormSmbShow.setText(">>")
    self.wsLdapFormSmb.raiseWidget(0)
    self.cbLdapFormProfileType.setCurrentItem(0)
    self.iLdapFormProfilePath.clear()
    self.iLdapFormProfilePath.setEnabled(False)
    self.iLdapFormHomeDrive.clear()
    self.iLdapFormDrivePath.clear()
    self.iLdapFormLogonScript.clear()
    self.cLdapFormAst.setChecked(False)
    self.fLdapFormAst.setEnabled(False)
    self.iLdapFormAstUsername.clear()
    self.iLdapFormAstName.setText("1000")
    self.cLdapFormRadius.setChecked(False)
    self.fLdapFormRadius.setEnabled(False)
    self.iLdapFormRadiusGroup.clear()
    self.wsLdapForm.raiseWidget(0)
elif a0 == "ldap.form.unit":
    self.iLdapFormUnit.setFocus()
    self.cbLdapFormUnit.setCurrentItem(0)
    self.iLdapFormUnit.clear()
    self.iLdapFormUnitStreet.clear()
    self.iLdapFormUnitL.clear()
    self.iLdapFormUnitPostalCode.clear()
    self.iLdapFormUnitTelephoneNumber.clear()
elif a0 == "ldap.form.password":
    self.iLdapPasswd.setFocus()
    self.cbLdapUserPassword.setChecked(True)
    self.cbUserPassword.setCurrentItem(0)
    self.iLdapPasswd.clear()
    self.iLdapPasswd2.clear()
elif a0 == "ldap.smb.populate":
    self.iLdapSMBdomain.setFocus()
    self.iLdapSMBdomain.clear()
    self.iLdapSMBSID.clear()
    self.iLdapSMBpassword.clear()
    self.iLdapSMBuidNumber.setText(self.iConfLdapSMBuidNumber.text().ascii())
    self.iLdapSMBgidNumber.setText(self.iConfLdapSMBgidNumber.text().ascii())
    self.iLdapSMBminPwdLength.setText(self.iConfLdapSMBminPwdLength.text().ascii())
    self.iLdapSMBpwdHistLenght.setText(self.iConfLdapSMBpwdHistLenght.text().ascii())
    self.iLdapSMBmaxPwdAge.setText(self.iConfLdapSMBmaxPwdAge.text().ascii())
    self.cbLdapSMBmaxPwdAge.setCurrentItem(self.cbConfLdapSMBmaxPwdAge.currentItem())
    self.iLdapSMBminPwdAge.setText(self.iConfLdapSMBminPwdAge.text().ascii())
    self.cbLdapSMBminPwdAge.setCurrentItem(self.cbConfLdapSMBminPwdAge.currentItem())
    self.iLdapSMBlockout.setText(self.iConfLdapSMBlockout.text().ascii())
    self.iLdapSMBlockoutDuration.setText(self.iConfLdapSMBlockoutDuration.text().ascii())
    self.cbLdapSMBlockoutDuration.setCurrentItem(self.cbConfLdapSMBlockoutDuration.currentItem())
    self.iLdapSMBlockoutWindow.setText(self.iConfLdapSMBlockoutWindow.text().ascii())
    self.cbLdapSMBlockoutWindow.setCurrentItem(self.cbConfLdapSMBlockoutWindow.currentItem())

}

void dKorreio::korreio_module_changed() {

page = self.wKorreio.currentPageIndex()

if page == 0:
    try:
        self.startup
    except:
        self.startup = 1
        self.wsConfig.raiseWidget(3)
#        self.spImap.setSizes([395, 473])
elif page == 4:
    if self.cbSSHsudo.currentItem() == 0:
        self.pPostFileSave.setEnabled(True)
    else:
        self.pPostFileSave.setEnabled(False)
    self.lvServices.setColumnWidth(1, 0)
    self.lvServices.setColumnWidth(0, self.lvServices.width() - 4)
elif page == 6:
    self.lvConfig.setColumnWidth(1, 0)
    self.lvConfig.setColumnWidth(0, self.lvServices.width() - 4)
    self.config_change_widgetstack()

}

void dKorreio::config_load() {

try:
    os.mkdir(os.path.expanduser("~/.korreio"),0700)
except OSError, e:
    if e[0] != 17:
        self.console("<b>Erro:</b> não foi possível criar ~/.korreio. %s" % e)
        print "Error creating ~/.korreio "+e
        return False

try:
    if not os.path.isfile(os.path.expanduser("~/.korreio/korreio.conf")):
        self.config_save()
except OSError, e:
    pass

try:
    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
    conf=f.read()
    f.close()
except IOError, e:
    return True

confList = conf.split("\n")
confList.pop()
confDict = {}

for line in confList:
   key=line.split("=")
   confDict[key[0]] = "=".join(key[1:])

self.confDict = confDict

#
# LDAP Connection
#

i=0
self.cbLdapConnection.clear()
while confDict.get("ldap%s.name" % i):
    self.cbLdapConnection.insertItem(confDict.get("ldap%s.name" % i))
    i+=1

lastConn=confDict.get("ldap.last")
if lastConn:
    self.cbLdapConnection.setCurrentText(confDict.get("%s.name" % lastConn))
    self.iLdapConnection.setText(confDict.get("%s.name" % lastConn))
    self.cbLdapMode.setCurrentText(confDict.get("%s.mode" % lastConn))
    self.iLdapHost.setText(confDict.get("%s.host" % lastConn))
    self.iLdapPort.setText(confDict.get("%s.port" % lastConn))
    self.cbLdapBaseDN.clear()
    self.cbLdapBaseDN.insertItem(confDict.get("%s.basedn" % lastConn))
    self.iLdapUser.setText(confDict.get("%s.user" % lastConn))
    self.iLdapPass.setText(confDict.get("%s.pass" % lastConn))
    if confDict.get("%s.ref" % lastConn) == "True":
        self.cLdapRef.setChecked(True)
    if confDict.get("%s.cert" % lastConn) == "True":
        self.cLdapCert.setChecked(True)

#
# IMAP Connection
#

i=0
self.cbCyrusConnection.clear()
while confDict.get("imap%s.name" % i):
    self.cbCyrusConnection.insertItem(confDict.get("imap%s.name" % i))
    i+=1

lastConn=confDict.get("imap.last")
if lastConn:
    self.cbCyrusConnection.setCurrentText(confDict.get("%s.name" % lastConn))
    self.iCyrusConnection.setText(confDict.get("%s.name" % lastConn))
    self.cbCyrusMode.setCurrentText(confDict.get("%s.mode" % lastConn))
    self.iCyrusHost.setText(confDict.get("%s.host" % lastConn))
    self.iCyrusPort.setText(confDict.get("%s.port" % lastConn))
    self.iCyrusSievePort.setText(confDict.get("%s.sieport" % lastConn))
    self.iCyrusUser.setText(confDict.get("%s.user" % lastConn))
    self.iCyrusPass.setText(confDict.get("%s.pass" % lastConn))
    self.iCyrusPart.setText(confDict.get("%s.part" % lastConn))

#
# SSH Connection
#

i=0
self.cbSSHConnection.clear()
while confDict.get("ssh%s.name" % i):
    self.cbSSHConnection.insertItem(confDict.get("ssh%s.name" % i))
    i+=1

lastConn=confDict.get("ssh.last")
if lastConn:
    self.cbSSHConnection.setCurrentText(confDict.get("%s.name" % lastConn))
    self.iSSHConnection.setText(confDict.get("%s.name" % lastConn))
    self.iSshHost.setText(confDict.get("%s.host" % lastConn))
    self.iSshPort.setText(confDict.get("%s.port" % lastConn))
    self.iSshUser.setText(confDict.get("%s.user" % lastConn))
    self.iSshPass.setText(confDict.get("%s.pass" % lastConn))
try:
    self.cbSSHsudo.setCurrentItem(int(confDict.get("%s.sudo" % lastConn)))
except:
    pass

#
# IMAP Prefs
#


self.lvConfImapFolders.clear()
i=0
while confDict.get("imap.defaultfolder%s" % i):
    folderList = confDict.get("imap.defaultfolder%s" % i).split(":")
    item = QListViewItem(self.lvConfImapFolders)
    item.setText(0, folderList[0])
    if folderList[1] != "None" and folderList[1] != "0":
        item.setText(1, folderList[1])
    if folderList[2] != "None":
        item.setText(2, folderList[2])
    i+=1

if confDict.get("imap.defaultquota"):
    self.iConfImapQuotaMbytes.setText(confDict.get("imap.defaultquota"))

#
# LDAP Prefs
#

if confDict.get("ldap.admin.autocomplete"):
    self.cbConfLdapCompleteUser.setCurrentText(confDict.get("ldap.admin.autocomplete"))

if confDict.get("ldap.passwd.sambaPwdMustChange") == "True":
    self.cConfLdapsambaPwdMustChange.setChecked(True)
else:
    self.cConfLdapsambaPwdMustChange.setChecked(False)

self.lvConfLdapSchema.clear()
item = QListViewItem(self.lvConfLdapSchema)
item.setText(0,'objectClass')
item.setOpen(True)
objnodes = {}
i=0
while confDict.get("ldap.objectclass%s" % i):
    objclass = confDict.get("ldap.objectclass%s" % i).split(".")
    if not objnodes.get(objclass[0]):
        objnodes[objclass[0]] = QListViewItem(item)
        objnodes[objclass[0]].setText(0,objclass[0])
    subitem=QListViewItem(objnodes[objclass[0]])
    subitem.setText(0,objclass[1])
    subitem.setText(1,".".join(objclass[2:]))
    i+=1


if confDict.get("ldap.schema.addattrs") == "True" or not confDict.get("ldap.schema.addattrs"):
    self.cConfLdapSchemaAddAttr.setChecked(True)
else:
    self.cConfLdapSchemaAddAttr.setChecked(False)

if confDict.get("ldap.schema.delattrs") == "True" or not confDict.get("ldap.schema.delattrs"):
    self.cConfLdapSchemaDelAttr.setChecked(True)
else:
    self.cConfLdapSchemaDelAttr.setChecked(False)

self.lbConfLdapFilter.clear()
self.cbLdapFilter.clear()
i=0
while confDict.get("ldap.filter%s" % i):
    self.lbConfLdapFilter.insertItem(confDict.get("ldap.filter%s" % i))
    self.cbLdapFilter.insertItem(confDict.get("ldap.filter%s" % i))
    i+=1

#
# LDAP SMB Prefs
#

i=0
self.cbConfLdapSmbDomain.clear()
while confDict.get("ldap.smb%s.domain" % i):
    self.cbConfLdapSmbDomain.insertItem(confDict.get("ldap.smb%s.domain" % i))
    i+=1

lastConn=confDict.get("ldap.smb.last")
if lastConn:
    self.cbConfLdapSmbDomain.setCurrentText(confDict.get("%s.domain" % lastConn))
    self.iConfLdapSmbDomain.setText(confDict.get("%s.domain" % lastConn))
    if confDict.get("%s.SIDEntry" % lastConn):
        self.cbConfLdapSmbSIDEntry.clear()
        self.cbConfLdapSmbSIDEntry.insertItem(confDict.get("%s.SIDEntry" % lastConn))
    self.cbConfLdapSmbSIDEntry.insertItem("")
    self.cbConfLdapSmbCounterEntry.clear()
    if confDict.get("%s.counterEntry" % lastConn):
        self.cbConfLdapSmbCounterEntry.clear()
        self.cbConfLdapSmbCounterEntry.insertItem(confDict.get("%s.counterEntry" % lastConn))
    self.cbConfLdapSmbCounterEntry.insertItem("")
    self.cbConfLdapSmbProfileType.setCurrentItem(int(confDict.get("%s.profileType" % lastConn)))
    if int(confDict.get("%s.profileType" % lastConn)) == 0:
        self.cbConfLdapSmbProfilePath.setEnabled(False)
    else:
        self.cbConfLdapSmbProfilePath.setEnabled(True)
    self.cbConfLdapSmbProfilePath.setCurrentText(confDict.get("%s.profilePath" % lastConn))
    self.iConfLdapSmbHomeDrive.setText(confDict.get("%s.homeDrive" % lastConn))
    self.iConfLdapSmbDrivePath.setText(confDict.get("%s.drivePath" % lastConn))
    self.cbConfLdapSmbLogonScript.setCurrentText(confDict.get("%s.logonScript" % lastConn))
    if confDict.get("%s.pwdMustChange" % lastConn) == "True":
        self.cConfLdapSmbPwdMustChange.setChecked(True)
    else:
        self.cConfLdapSmbPwdMustChange.setChecked(False)
    self.cbConfLdapSmbPrimaryGroup.setCurrentItem(int(confDict.get("%s.primaryGroup" % lastConn)))

#
# LDAP SMB Populate Prefs
#

if confDict.get("ldap.smb.populate.1stUidNumber"):
    self.iConfLdapSMBuidNumber.setText(confDict.get("ldap.smb.populate.1stUidNumber"))

if confDict.get("ldap.smb.populate.1stGidNumber"):
    self.iConfLdapSMBgidNumber.setText(confDict.get("ldap.smb.populate.1stGidNumber"))

if confDict.get("ldap.smb.populate.sambaMinPwdLenght"):
    self.iConfLdapSMBminPwdLength.setText(confDict.get("ldap.smb.populate.sambaMinPwdLenght"))

if confDict.get("ldap.smb.populate.sambaPwdHistoryLenght"):
    self.iConfLdapSMBpwdHistLenght.setText(confDict.get("ldap.smb.populate.sambaPwdHistoryLenght"))

if confDict.get("ldap.smb.populate.sambaMaxPwdAge"):
    self.iConfLdapSMBmaxPwdAge.setText(confDict.get("ldap.smb.populate.sambaMaxPwdAge"))

if confDict.get("ldap.smb.populate.sambaMaxPwdAgeTime"):
    self.cbConfLdapSMBmaxPwdAge.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaMaxPwdAgeTime")))

if confDict.get("ldap.smb.populate.sambaMinPwdAge"):
    self.iConfLdapSMBminPwdAge.setText(confDict.get("ldap.smb.populate.sambaMinPwdAge"))

if confDict.get("ldap.smb.populate.sambaMinPwdAgeTime"):
    self.cbConfLdapSMBminPwdAge.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaMinPwdAgeTime")))

if confDict.get("ldap.smb.populate.sambaLockoutThreshold"):
    self.iConfLdapSMBlockout.setText(confDict.get("ldap.smb.populate.sambaLockoutThreshold"))

if confDict.get("ldap.smb.populate.sambaLockoutDuration"):
    self.iConfLdapSMBlockoutDuration.setText(confDict.get("ldap.smb.populate.sambaLockoutDuration"))

if confDict.get("ldap.smb.populate.sambaLockoutDurationTime"):
    self.cbConfLdapSMBlockoutDuration.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaLockoutDurationTime")))

if confDict.get("ldap.smb.populate.sambaLockoutObservationWindow"):
    self.iConfLdapSMBlockoutWindow.setText(confDict.get("ldap.smb.populate.sambaLockoutObservationWindow"))

if confDict.get("ldap.smb.populate.sambaLockoutObservationWindowTime"):
    self.cbConfLdapSMBlockoutWindow.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaLockoutObservationWindowTime")))

}

void dKorreio::config_save() {

try:
    self.confDict
except AttributeError, e:
    self.confDict = {}

confList = []

#
# LDAP Connection
#

i=0
while self.confDict.get("ldap%s.name" % i):
    if self.confDict.get("ldap%s.name" % i) == self.iLdapConnection.text().ascii():
        break
    i+=1

if self.iLdapConnection.text().ascii():
    confList.append("ldap.last=ldap%s" % i)
    self.confDict["ldap%s.name" % i]=self.iLdapConnection.text().ascii()
    self.confDict["ldap%s.mode" % i]=self.cbLdapMode.currentText().ascii()
    self.confDict["ldap%s.host" % i]=self.iLdapHost.text().ascii()
    self.confDict["ldap%s.port" % i]=self.iLdapPort.text().ascii()
    self.confDict["ldap%s.basedn" % i]=self.cbLdapBaseDN.currentText().ascii()
    self.confDict["ldap%s.user" % i]=self.iLdapUser.text().ascii()
    self.confDict["ldap%s.pass" % i]=self.iLdapPass.text().ascii()
    self.confDict["ldap%s.ref" % i]=str(self.cLdapRef.isChecked())
    self.confDict["ldap%s.cert" % i]=str(self.cLdapCert.isChecked())

k=0
self.cbLdapConnection.clear()
while self.confDict.get("ldap%s.name" % k):
    self.cbLdapConnection.insertItem(self.confDict.get("ldap%s.name" % k))
    for j in ['name','mode','host','port','basedn','user','pass','ref','cert']:
        opt = "ldap%s.%s" % (k, j)
        confList.append("%s=%s" % (opt, self.confDict.get(opt)))
    k+=1

self.cbLdapConnection.setCurrentItem(i)

#
# IMAP Connection
#

i=0
while self.confDict.get("imap%s.name" % i):
    if self.confDict.get("imap%s.name" % i) == self.iCyrusConnection.text().ascii():
        break
    i+=1

if self.iCyrusConnection.text().ascii():
    confList.append("imap.last=imap%s" % i)
    self.confDict["imap%s.name" % i]=self.iCyrusConnection.text().ascii()
    self.confDict["imap%s.mode" % i]=self.cbCyrusMode.currentText().ascii()
    self.confDict["imap%s.host" % i]=self.iCyrusHost.text().ascii()
    self.confDict["imap%s.port" % i]=self.iCyrusPort.text().ascii()
    self.confDict["imap%s.sieport" % i]=self.iCyrusSievePort.text().ascii()
    self.confDict["imap%s.user" % i]=self.iCyrusUser.text().ascii()
    self.confDict["imap%s.pass" % i]=self.iCyrusPass.text().ascii()
    self.confDict["imap%s.part" % i]=self.iCyrusPart.text().ascii()

k=0
self.cbCyrusConnection.clear()
while self.confDict.get("imap%s.name" % k):
    self.cbCyrusConnection.insertItem(self.confDict.get("imap%s.name" % k))
    for j in ['name','mode','host','port','sieport','user','pass','part']:
        opt = "imap%s.%s" % (k, j)
        confList.append("%s=%s" % (opt, self.confDict.get(opt)))
    k+=1

self.cbCyrusConnection.setCurrentItem(i)

#
# SSH Connection
#

i=0
while self.confDict.get("ssh%s.name" % i):
    if self.confDict.get("ssh%s.name" % i) == self.iSSHConnection.text().ascii():
        break
    i+=1

if self.iSSHConnection.text().ascii():
    confList.append("ssh.last=ssh%s" % i)
    self.confDict["ssh%s.name" % i]=self.iSSHConnection.text().ascii()
    self.confDict["ssh%s.host" % i]=self.iSshHost.text().ascii()
    self.confDict["ssh%s.port" % i]=self.iSshPort.text().ascii()
    self.confDict["ssh%s.user" % i]=self.iSshUser.text().ascii()
    self.confDict["ssh%s.pass" % i]=self.iSshPass.text().ascii()
    self.confDict["ssh%s.sudo" % i]=self.cbSSHsudo.currentItem()

k=0
self.cbSSHConnection.clear()
while self.confDict.get("ssh%s.name" % k):
    self.cbSSHConnection.insertItem(self.confDict.get("ssh%s.name" % k))
    for j in ['name','host','port','user','pass','sudo']:
        opt="ssh%s.%s" % (k, j)
        confList.append("%s=%s" % (opt, self.confDict.get(opt)))
    k+=1

self.cbSSHConnection.setCurrentItem(i)

#
# IMAP Prefs
#

i=0
item = self.lvConfImapFolders.firstChild()
while item is not None:
    confList.append("imap.defaultfolder%s=%s:%s:%s" % (i, item.text(0).ascii(), item.text(1).ascii(), item.text(2).ascii()))
    item = item.nextSibling()
    i+=1
confList.append("imap.defaultquota=%s" % self.iConfImapQuotaMbytes.text().ascii())

#
# LDAP Prefs
#

confList.append("ldap.admin.autocomplete=%s" % self.cbConfLdapCompleteUser.currentText().ascii())
confList.append("ldap.passwd.sambaPwdMustChange=%s" % self.cConfLdapsambaPwdMustChange.isChecked())
confList.append("ldap.schema.addattrs=%s" % self.cConfLdapSchemaAddAttr.isChecked())
confList.append("ldap.schema.delattrs=%s" % self.cConfLdapSchemaDelAttr.isChecked())

item=self.lvConfLdapSchema.firstChild()
item=item.firstChild()
i=0
while item is not None:
    subitem=item.firstChild()
    while subitem is not None:
        if subitem.text(1).ascii() is None: value=""
        else: value=subitem.text(1).ascii()
        confList.append("ldap.objectclass%s=%s.%s.%s" % (i, item.text(0).ascii(), subitem.text(0).ascii(), value))
        subitem=subitem.nextSibling()
        i+=1
    item=item.nextSibling()

i=0
item = self.lbConfLdapFilter.firstItem()
while item is not None:
    confList.append("ldap.filter%s=%s" % (i, item.text().ascii()))
    i+=1
    item = item.next()

#
# LDAP SMB Prefs
#

i=0
while self.confDict.get("ldap.smb%s.domain" % i):
    if self.confDict.get("ldap.smb%s.domain" % i) == self.iConfLdapSmbDomain.text().ascii():
        break
    i+=1

if self.iConfLdapSmbDomain.text().ascii():
    confList.append("ldap.smb.last=ldap.smb%s" % i)
    self.confDict["ldap.smb%s.domain" % i]=self.iConfLdapSmbDomain.text().ascii()
    self.confDict["ldap.smb%s.SIDEntry" % i]=self.cbConfLdapSmbSIDEntry.currentText().ascii()
    self.confDict["ldap.smb%s.counterEntry" % i]=self.cbConfLdapSmbCounterEntry.currentText().ascii()
    self.confDict["ldap.smb%s.profileType" % i]="%s" % self.cbConfLdapSmbProfileType.currentItem()
    self.confDict["ldap.smb%s.profilePath" % i]=self.cbConfLdapSmbProfilePath.currentText().ascii()
    self.confDict["ldap.smb%s.homeDrive" % i]=self.iConfLdapSmbHomeDrive.text().ascii()
    self.confDict["ldap.smb%s.drivePath" % i]=self.iConfLdapSmbDrivePath.text().ascii()
    self.confDict["ldap.smb%s.logonScript" % i]=self.cbConfLdapSmbLogonScript.currentText().ascii()
    self.confDict["ldap.smb%s.pwdMustChange" % i]=self.cConfLdapSmbPwdMustChange.isChecked()
    self.confDict["ldap.smb%s.primaryGroup" % i]=self.cbConfLdapSmbPrimaryGroup.currentItem()

k=0
self.cbConfLdapSmbDomain.clear()
while self.confDict.get("ldap.smb%s.domain" % k):
    self.cbConfLdapSmbDomain.insertItem(self.confDict.get("ldap.smb%s.domain" % k))
    for j in ['domain', 'SIDEntry', 'counterEntry', 'profileType', 'profilePath', 'homeDrive', 'drivePath', 'logonScript', 'pwdMustChange', 'primaryGroup']:
        opt = "ldap.smb%s.%s" % (k, j)
        confList.append("%s=%s" % (opt, self.confDict.get(opt)))
    k+=1

self.cbConfLdapSmbDomain.setCurrentItem(i)

#
# LDAP SMB Populate Prefs
#

confList.append("ldap.smb.populate.1stUidNumber=%s" % self.iConfLdapSMBuidNumber.text().ascii())
confList.append("ldap.smb.populate.1stGidNumber=%s" % self.iConfLdapSMBgidNumber.text().ascii())
confList.append("ldap.smb.populate.sambaMinPwdLenght=%s" % self.iConfLdapSMBminPwdLength.text().ascii())
confList.append("ldap.smb.populate.sambaPwdHistoryLenght=%s" % self.iConfLdapSMBpwdHistLenght.text().ascii())
confList.append("ldap.smb.populate.sambaMaxPwdAge=%s" % self.iConfLdapSMBmaxPwdAge.text().ascii())
confList.append("ldap.smb.populate.sambaMaxPwdAgeTime=%s" % self.cbConfLdapSMBmaxPwdAge.currentItem())
confList.append("ldap.smb.populate.sambaMinPwdAge=%s" % self.iConfLdapSMBminPwdAge.text().ascii())
confList.append("ldap.smb.populate.sambaMinPwdAgeTime=%s" % self.cbConfLdapSMBminPwdAge.currentItem())
confList.append("ldap.smb.populate.sambaLockoutThreshold=%s" % self.iConfLdapSMBlockout.text().ascii())
confList.append("ldap.smb.populate.sambaLockoutDuration=%s" % self.iConfLdapSMBlockoutDuration.text().ascii())
confList.append("ldap.smb.populate.sambaLockoutDurationTime=%s" % self.cbConfLdapSMBlockoutDuration.currentItem())
confList.append("ldap.smb.populate.sambaLockoutObservationWindow=%s" % self.iConfLdapSMBlockoutWindow.text().ascii())
confList.append("ldap.smb.populate.sambaLockoutObservationWindowTime=%s" % self.cbConfLdapSMBlockoutWindow.currentItem())

#
# End
#

try:
    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')
    f.write("\n".join(confList))
    f.write("\n")
    f.close()
    os.chmod(os.path.expanduser("~/.korreio/korreio.conf"), 0600)
    self.console("<b>Ok:</b> configuração salva.")
except OSError, e:
    self.parse_exception("OSError", e)

}

void dKorreio::config_log_mode() {

self.lbLog.clear()
try:
    if os.path.isfile(os.path.expanduser("~/.korreio/korreio.log")):
        f = open(os.path.expanduser("~/.korreio/korreio.log"), 'r')
        if self.rbConfLogModeRecent.isChecked():
            f.seek(-1000, 2)
        for line in f.xreadlines():
            line=line.strip('\n')
            try:
                self.lbLog.insertItem(utf2iso(line))
            except:
                pass
        f.close()
        if self.rbConfLogModeRecent.isChecked():
            self.lbLog.removeItem(0)
        self.lbLog.setCurrentItem(self.lbLog.count() - 1)
        self.lbLog.ensureCurrentVisible()
except:
    pass

}

void dKorreio::config_change_widgetstack() {

self.pSaveConfig.setEnabled(True)

try:
    self.config1st
except:
    item = self.lvConfig.firstChild()
    while item is not None:
        if item.text(1).ascii() == "2":
            self.lvConfig.setCurrentItem(item)
        item = item.nextSibling()
    self.config1st = 1

item=self.lvConfig.currentItem()
if item.text(1).ascii() == "1":
    self.wsConfig.raiseWidget(9)
elif  item.text(1).ascii() == "2":
    self.wsConfig.raiseWidget(3)
    self.tConfShowLdapServer.setText("Host: %s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii()))
    self.tConfShowLdapUser.setText("User: %s" % self.iLdapUser.text().ascii())
    self.tConfShowLdapBaseDN.setText("Base: %s" % self.cbLdapBaseDN.currentText().ascii())
    self.tConfShowImapServer.setText("Host: %s%s:%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii()))
    self.tConfShowImapUser.setText("User: %s" % self.iCyrusUser.text().ascii())
    self.tConfShowSshServer.setText("Host: ssh://%s:%s" % (self.iSshHost.text().ascii(), self.iSshPort.text().ascii()))
    self.tConfShowSshUser.setText("User: %s" % self.iSshUser.text().ascii())
elif  item.text(1).ascii() == "2.1":
    self.wsConfig.raiseWidget(0)
elif  item.text(1).ascii() == "2.2":
    self.wsConfig.raiseWidget(1)
elif  item.text(1).ascii() == "2.3":
    self.wsConfig.raiseWidget(2)
elif  item.text(1).ascii() == "4.1":
    self.wsConfig.raiseWidget(4)
elif  item.text(1).ascii() == "4.2":
    self.wsConfig.raiseWidget(5)
elif  item.text(1).ascii() == "4.1.1":
    self.wsConfig.raiseWidget(6)
elif  item.text(1).ascii() == "4.1.1.1":
    self.wsConfig.raiseWidget(7)
elif  item.text(1).ascii() == "4.1.2":
    self.wsConfig.raiseWidget(8)
elif  item.text(1).ascii() == "2.2.1":
    self.wsConfig.raiseWidget(10)
    self.pSaveConfig.setEnabled(False)
    self.cbImapAnnotationServer.setCurrentItem(0)
    self.iAnnotationValueServer.clear()
}

void dKorreio::config_imap_set_port() {

if self.cbCyrusMode.currentText().ascii() == "imap://":
    self.iCyrusPort.setText("143")
else:
    self.iCyrusPort.setText("993")

}

void dKorreio::config_ldap_set_port() {
if self.cbLdapMode.currentText().ascii() == "ldap://":
    self.iLdapPort.setText("389")
else:
    self.iLdapPort.setText("636")
}

void dKorreio::config_ldap_get_basedn() {

try:
    l = self.ldap_connect()
    ldap_result_id = l.search("", ldap.SCOPE_BASE, "objectclass=*", ["namingContexts"])
    self.cbLdapBaseDN.clear()
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if (result_data == []):
            break
        else:
            if result_type == ldap.RES_SEARCH_ENTRY:
                for j in result_data:
                     for root in j[1]["namingContexts"]:
                         self.cbLdapBaseDN.insertItem(root)

    bases = self.cbLdapBaseDN.count()
    if bases > 1:
            self.cbLdapBaseDN.popup()
    elif bases != 0:
            self.iLdapUser.setText("%s,%s" % (self.cbConfLdapCompleteUser.currentText().ascii(), root))

except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)

}

void dKorreio::config_ldap_schema() {

item = self.lvConfLdapSchema.currentItem()
if item.parent() is None:
    self.iConfLdapSchemaValue.setEnabled(False)
    self.pConfLdapSchemaDelItem.setEnabled(False)
    self.iConfLdapSchemaAttr.clear()
    self.iConfLdapSchemaValue.clear()
else:
    self.iConfLdapSchemaValue.setEnabled(True)
    self.pConfLdapSchemaDelItem.setEnabled(True)
    if item.parent().parent() is None:
        self.iConfLdapSchemaAttr.clear()
        self.iConfLdapSchemaValue.clear()
    else:
        if item.text(0).ascii() is not None:
            self.iConfLdapSchemaAttr.setText(item.text(0).ascii())
        if item.text(1).ascii() is not None:
            self.iConfLdapSchemaValue.setText(item.text(1).ascii())

}

void dKorreio::config_ldap_schema_checked() {

if not self.cConfLdapSchemaAddAttr.isChecked() and not self.cConfLdapSchemaDelAttr.isChecked():
    self.fConfLdapSchema.setEnabled(False)
else:
    self.fConfLdapSchema.setEnabled(True)

}

void dKorreio::config_ldap_schema_add_attr() {

if not self.iConfLdapSchemaAttr.text().ascii():
    self.console("<b>Atenção:</b> informe o objectClass/atributo.")
    self.iConfLdapSchemaAttr.setFocus()
    return True

item = self.lvConfLdapSchema.currentItem()

if item.parent() is None or item.parent().parent() is None:
    item.setOpen(True)
    newitem=QListViewItem(item)
else:
    if self.iConfLdapSchemaAttr.text().ascii() == item.text(0).ascii():
        item.setText(1, self.iConfLdapSchemaValue.text().ascii())
        return True
    newitem=QListViewItem(item.parent())

newitem.setText(0, self.iConfLdapSchemaAttr.text().ascii())
newitem.setText(1, self.iConfLdapSchemaValue.text().ascii())

}

void dKorreio::config_ldap_schema_del_attr() {

item = self.lvConfLdapSchema.currentItem()

if item.parent() is not None:
    item.parent().takeItem(item)
    self.lvConfLdapSchema.currentItem().setSelected(True)

}

void dKorreio::config_ldap_smb_perfil_changed() {

if self.cbConfLdapSmbProfileType.currentItem() == 0:
    self.cbConfLdapSmbProfilePath.setEnabled(False)
else:
    self.cbConfLdapSmbProfilePath.setEnabled(True)

}

void dKorreio::config_ldap_smb_get_sambaUnixIdPool() {

self.cbConfLdapSmbCounterEntry.clear()
self.cbConfLdapSmbCounterEntry.insertItem("")
ldap_result = self.ldap_query("objectClass=sambaUnixIdPool", None)
if ldap_result is not None:
    for dn in ldap_result:
        self.cbConfLdapSmbCounterEntry.insertItem(dn)

if self.cbConfLdapSmbCounterEntry.count() > 1:
    self.cbConfLdapSmbCounterEntry.popup()

}

void dKorreio::config_ldap_smb_get_sambaDomain() {

self.cbConfLdapSmbSIDEntry.clear()
self.cbConfLdapSmbSIDEntry.insertItem("")
ldap_result = self.ldap_query("objectClass=sambaDomain", None)
if ldap_result is not None:
    for dn in ldap_result:
        self.cbConfLdapSmbSIDEntry.insertItem(dn)

if self.cbConfLdapSmbSIDEntry.count() > 1:
    self.cbConfLdapSmbSIDEntry.popup()

}

void dKorreio::config_ldap_smb_sambaDomain_clicked() {

domain = self.cbConfLdapSmbSIDEntry.currentText().ascii()
if domain:
    self.iConfLdapSmbDomain.setText(domain.split(",")[0].split("=")[1].lower())
else:
    self.iConfLdapSmbDomain.clear()

}


void dKorreio::config_ldap_set_admin() {

    self.iLdapUser.setText("%s,%s" % (self.cbConfLdapCompleteUser.currentText().ascii(), self.cbLdapBaseDN.currentText().ascii()))

}

void dKorreio::config_imap_add_default_folder() {

if not self.iConfImapFolder.text().ascii():
    return False

item = self.lvConfImapFolders.firstChild()
while item is not None:
    if item.text(0).ascii() == self.iConfImapFolder.text().ascii():
        tmp = item.nextSibling()
        self.lvConfImapFolders.takeItem(item)
        item = tmp
    else:
        item = item.nextSibling()

item = QListViewItem(self.lvConfImapFolders)
item.setText(0, self.iConfImapFolder.text().ascii())
item.setText(1, self.iConfImapExpire.text().ascii())
if self.cbConfImapACLp.currentItem() == 1:
    item.setText(2, "p")

}

void dKorreio::config_imap_del_default_folder() {

self.lvConfImapFolders.takeItem(self.lvConfImapFolders.currentItem())

}

void dKorreio::config_ldap_set_connection() {

i=0
while self.confDict.get("ldap%s.name" % i):
    if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
        lastConn="ldap%s" % i
    i+=1

self.iLdapConnection.setText(self.confDict.get("%s.name" % lastConn))
self.cbLdapMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
self.iLdapHost.setText(self.confDict.get("%s.host" % lastConn))
self.iLdapPort.setText(self.confDict.get("%s.port" % lastConn))
self.cbLdapBaseDN.clear()
self.cbLdapBaseDN.insertItem(self.confDict.get("%s.basedn" % lastConn))
self.iLdapUser.setText(self.confDict.get("%s.user" % lastConn))
self.iLdapPass.setText(self.confDict.get("%s.pass" % lastConn))
if self.confDict.get("%s.ref" % lastConn) == "True":
    self.cLdapRef.setChecked(True)
else:
    self.cLdapRef.setChecked(False)
if self.confDict.get("%s.cert" % lastConn) == "True":
    self.cLdapCert.setChecked(True)
else:
    self.cLdapCert.setChecked(False)

self.korreio_module_clear("ldap")

}

void dKorreio::config_imap_set_connection() {

i=0
while self.confDict.get("imap%s.name" % i):
    if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
        lastConn="imap%s" % i
    i+=1

self.iCyrusConnection.setText(self.confDict.get("%s.name" % lastConn))
self.cbCyrusMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
self.iCyrusHost.setText(self.confDict.get("%s.host" % lastConn))
self.iCyrusPort.setText(self.confDict.get("%s.port" % lastConn))
self.iCyrusSievePort.setText(self.confDict.get("%s.sieport" % lastConn))
self.iCyrusUser.setText(self.confDict.get("%s.user" % lastConn))
self.iCyrusPass.setText(self.confDict.get("%s.pass" % lastConn))
self.iCyrusPart.setText(self.confDict.get("%s.part" % lastConn))

self.korreio_module_clear("imap")
self.korreio_module_clear("imap-partition")
self.korreio_module_clear("sieve")

}

void dKorreio::config_ssh_set_connection() {

i=0
while self.confDict.get("ssh%s.name" % i):
    if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
        lastConn="ssh%s" % i
    i+=1
self.iSSHConnection.setText(self.confDict.get("%s.name" % lastConn))
self.iSshHost.setText(self.confDict.get("%s.host" % lastConn))
self.iSshPort.setText(self.confDict.get("%s.port" % lastConn))
self.iSshUser.setText(self.confDict.get("%s.user" % lastConn))
self.iSshPass.setText(self.confDict.get("%s.pass" % lastConn))
try:
    self.cbSSHsudo.setCurrentItem(int(self.confDict.get("%s.sudo" % lastConn)))
except:
    self.cbSSHsudo.setCurrentItem(0)

self.korreio_module_clear("ssh")

}

void dKorreio::config_smb_set_domain() {

i=0
while self.confDict.get("ldap.smb%s.domain" % i):
    if self.confDict.get("ldap.smb%s.domain" % i) == self.cbConfLdapSmbDomain.currentText().ascii():
        lastConn="ldap.smb%s" % i
    i+=1

self.iConfLdapSmbDomain.setText(self.confDict.get("%s.domain" % lastConn))

self.cbConfLdapSmbSIDEntry.clear()
self.cbConfLdapSmbSIDEntry.insertItem(self.confDict.get("%s.SIDEntry" % lastConn))
self.cbConfLdapSmbSIDEntry.insertItem("")

self.cbConfLdapSmbCounterEntry.clear()
if self.confDict.get("%s.counterEntry" % lastConn) != "None":
    self.cbConfLdapSmbCounterEntry.insertItem(self.confDict.get("%s.counterEntry" % lastConn))
self.cbConfLdapSmbProfileType.setCurrentItem(int(self.confDict.get("%s.profileType" % lastConn)))
if int(self.confDict.get("%s.profileType" % lastConn)) == 0:
    self.cbConfLdapSmbProfilePath.setEnabled(False)
else:
    self.cbConfLdapSmbProfilePath.setEnabled(True)
self.cbConfLdapSmbProfilePath.setCurrentText(self.confDict.get("%s.profilePath" % lastConn))
self.iConfLdapSmbHomeDrive.setText(self.confDict.get("%s.homeDrive" % lastConn))
self.iConfLdapSmbDrivePath.setText(self.confDict.get("%s.drivePath" % lastConn))
self.cbConfLdapSmbLogonScript.setCurrentText(self.confDict.get("%s.logonScript" % lastConn))
if self.confDict.get("%s.pwdMustChange" % lastConn) == "True":
    self.cConfLdapSmbPwdMustChange.setChecked(True)
else:
    self.cConfLdapSmbPwdMustChange.setChecked(False)
self.cbConfLdapSmbPrimaryGroup.setCurrentItem(int(self.confDict.get("%s.primaryGroup" % lastConn)))

}

void dKorreio::config_ldap_del_connection() {

if not self.cbLdapConnection.currentText().ascii():
    return True

i=0
while self.confDict.get("ldap%s.name" % i):
    if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
        j=i+1
        while self.confDict.get("ldap%s.name" % j):
            for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                self.confDict["ldap%s.%s" % ((j-1), opt)]=self.confDict.get("ldap%s.%s" % (j, opt))
            j+=1
    i+=1

for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
    del self.confDict["ldap%s.%s" % ((i-1), opt)]

i=self.cbLdapConnection.currentItem()
self.cbLdapConnection.removeItem(i)
if i > 0:
    self.cbLdapConnection.setCurrentItem(i-1)
    self.config_ldap_set_connection()
elif self.cbLdapConnection.count() > 0:
    self.cbLdapConnection.setCurrentItem(0)
    self.config_ldap_set_connection()
else:
    self.iLdapConnection.clear()
    self.cbLdapMode.setCurrentText("ldap://")
    self.iLdapHost.clear()
    self.iLdapPort.setText("389")
    self.cbLdapBaseDN.clear()
    self.iLdapUser.clear()
    self.iLdapPass.clear()
    self.cLdapRef.setChecked(False)
    self.cLdapCert.setChecked(False)

}

void dKorreio::config_imap_del_connection() {

if not self.cbCyrusConnection.currentText().ascii():
    return True

i=0
while self.confDict.get("imap%s.name" % i):
    if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
        j=i+1
        while self.confDict.get("imap%s.name" % j):
            for opt in ['name','mode','host','port','sieport','user','pass','part']:
                self.confDict["imap%s.%s" % ((j-1), opt)]=self.confDict.get("imap%s.%s" % (j, opt))
            j+=1
    i+=1

for opt in ['name','mode','host','port','sieport','user','pass','part']:
    del self.confDict["imap%s.%s" % ((i-1), opt)]

i=self.cbCyrusConnection.currentItem()
self.cbCyrusConnection.removeItem(i)
if i > 0:
    self.cbCyrusConnection.setCurrentItem(i-1)
    self.config_imap_set_connection()
elif self.cbCyrusConnection.count() > 0:
    self.cbCyrusConnection.setCurrentItem(0)
    self.config_imap_set_connection()
else:
    self.iCyrusConnection.clear()
    self.cbCyrusMode.setCurrentText("imap://")
    self.iCyrusHost.clear()
    self.iCyrusPort.setText("143")
    self.iCyrusSievePort.setText("2000")
    self.iCyrusUser.clear()
    self.iCyrusPass.clear()
    self.iCyrusPart.clear()

}

void dKorreio::config_ssh_del_connection() {

if not self.cbSSHConnection.currentText().ascii():
    return True
i=0
while self.confDict.get("ssh%s.name" % i):
    if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
        j=i+1
        while self.confDict.get("ssh%s.name" % j):
            for opt in ['name','host','port','user','pass']:
                self.confDict["ssh%s.%s" % ((j-1), opt)]=self.confDict.get("ssh%s.%s" % (j, opt))
            j+=1
    i+=1

for opt in ['name','host','port','user','pass']:
    del self.confDict["ssh%s.%s" % ((i-1), opt)]

i=self.cbSSHConnection.currentItem()
self.cbSSHConnection.removeItem(i)
if i > 0:
    self.cbSSHConnection.setCurrentItem(i-1)
    self.config_ssh_set_connection()
elif self.cbSSHConnection.count() > 0:
    self.cbSSHConnection.setCurrentItem(0)
    self.config_ssh_set_connection()
else:
    self.iSSHConnection.clear()
    self.iSshHost.clear()
    self.iSshPort.setText("22")
    self.iSshUser.clear()
    self.iSshPass.clear()

}

void dKorreio::config_smb_del_domain() {

if not self.cbConfLdapSmbDomain.currentText().ascii():
    return True
i=0
while self.confDict.get("ldap.smb%s.domain" % i):
    if self.confDict.get("ldap.smb%s.domain" % i) == self.cbConfLdapSmbDomain.currentText().ascii():
        j=i+1
        while self.confDict.get("ldap.smb%s.domain" % j):
            for opt in['domain', 'SIDEntry', 'counterEntry', 'profileType', 'profilePath', 'homeDrive', 'drivePath', 'logonScript', 'pwdMustChange', 'primaryGroup']:
                self.confDict["ldap.smb%s.%s" % ((j-1), opt)]=self.confDict.get("ldap.smb%s.%s" % (j, opt))
            j+=1
    i+=1

for opt in ['domain', 'SIDEntry', 'counterEntry', 'profileType', 'profilePath', 'homeDrive', 'drivePath', 'logonScript', 'pwdMustChange', 'primaryGroup']:
    del self.confDict["ldap.smb%s.%s" % ((i-1), opt)]

i=self.cbConfLdapSmbDomain.currentItem()
self.cbConfLdapSmbDomain.removeItem(i)
if i > 0:
    self.cbConfLdapSmbDomain.setCurrentItem(i-1)
    self.config_smb_set_domain()
elif self.cbConfLdapSmbDomain.count() > 0:
    self.cbConfLdapSmbDomain.setCurrentItem(0)
    self.config_smb_set_domain()
else:
    self.cbConfLdapSmbDomain.clear()
    self.iConfLdapSmbDomain.clear()
    self.cbConfLdapSmbSIDEntry.clear()
    self.cbConfLdapSmbCounterEntry.clear()
    self.cbConfLdapSmbProfileType.setCurrentItem(0)
    self.cbConfLdapSmbProfilePath.setEnabled(False)
    self.cbConfLdapSmbProfilePath.setCurrentText("\servidor\profiles\#UID#")
    self.iConfLdapSmbHomeDrive.setText("Z:")
    self.iConfLdapSmbDrivePath.setText("\servidor\#UID#")
    self.cbConfLdapSmbLogonScript.setCurrentText("netlogon.bat")
    self.cConfLdapSmbPwdMustChange.setChecked(True)
    self.cbConfLdapSmbPrimaryGroup.setCurrentItem(0)

}

void dKorreio::config_ldap_filter_add() {

self.lbConfLdapFilter.insertItem(self.iConfLdapFilter.text().ascii())

self.config_ldap_filter_sync()

}


void dKorreio::config_ldap_filter_del() {

for filter in range(self.lbConfLdapFilter.count()-1, -1, -1):
    if self.lbConfLdapFilter.item(filter).isSelected():
        self.lbConfLdapFilter.removeItem(filter)

self.config_ldap_filter_sync()
  
}


void dKorreio::config_ldap_filter_sync() {

self.cbLdapFilter.clear()
for filter in range(0, self.lbConfLdapFilter.count()):
    self.cbLdapFilter.insertItem(self.lbConfLdapFilter.item(filter).text().ascii())

}

void dKorreio::imap_connect() {

def __server_changed():
    if active_conn.get("imap.mode") != self.cbCyrusMode.currentText().ascii() or active_conn.get("imap.host") != self.iCyrusHost.text().ascii() or active_conn.get("imap.port") != self.iCyrusPort.text().ascii() or active_conn.get("imap.user") != self.iCyrusUser.text().ascii() or active_conn.get("imap.pass") != self.iCyrusPass.text().ascii():
        return True
    return False

def __imap_connect():
    try:
        server = "%s%s:%s/%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii(), self.iCyrusUser.text().ascii())
        ssl = False
        if self.cbCyrusMode.currentText().ascii() == "imaps://":
            ssl = True
        self.m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(), int(self.iCyrusPort.text().ascii()), ssl)
        self.m.login(self.iCyrusUser.text().ascii(), self.iCyrusPass.text().ascii())
        self.console("<b>Ok:</b> servidor %s conectado." % server)
    except cyruslib.CYRUSError, e:
        try:
            del self.m
        except:
            pass
        self.console("<b>Erro:</b> %s (%s)." % (server, e[2]))
        raise cyruslib.CYRUSError, e

try:
    # connected?
    if not self.m.m.isadmin() or __server_changed():
        __imap_connect()
except AttributeError, e:
    __imap_connect()

active_conn["imap.mode"] = self.cbCyrusMode.currentText().ascii()
active_conn["imap.host"] = self.iCyrusHost.text().ascii()
active_conn["imap.port"] = self.iCyrusPort.text().ascii()
active_conn["imap.user"] = self.iCyrusUser.text().ascii()
active_conn["imap.pass"] = self.iCyrusPass.text().ascii()

self.tConfShowImapSep.setText("Imap delimiter: %s" % self.m.SEP)

return self.m

}

void dKorreio::imap_mode() {

self.korreio_module_clear("imap")

if self.cbImapMailbox.currentItem() == 0:
    self.iImapSearch.setEnabled(True)
else:
    self.iImapSearch.clear()
    self.iImapSearch.setEnabled(False)

}

void dKorreio::imap_current_mailbox( a0 ) {
# a0: Imap delimiter

SEP = a0

item = self.lvImap.currentItem()
if item is None:
    raise "KORREIOError", "Mailbox not selected"

mailbox = item.text(0).ascii()
while item.parent() is not None:
    mailbox = "%s%s%s" % (item.parent().text(0).ascii(), SEP, mailbox)
    item = item.parent()

if self.rbImapMailboxMode.isChecked():
    mailbox = "user%s%s" % (SEP, mailbox)

return mailbox

}

void dKorreio::imap_search() {

imap = self.imap_connect()

#
# Save current selection
#
try:
    oldMailbox = re.sub("^user%s" % imap.SEP, "", self.imap_current_mailbox(imap.SEP))
except:
    oldMailbox = None
self.korreio_module_clear("imap")

#
# Imap query
#
if self.iImapSearch.text().ascii():
    query = "user%s%s*" % (imap.SEP, self.iImapSearch.text().ascii())
else:
    if self.rbImapMailboxMode.isChecked():
        query = "user%s*" % imap.SEP
    else:
        query = "*"

mailbox = imap.lm(query)

#
# Select global folders (query not supported)
#
if self.rbImapMailboxMode2.isChecked():
    globalList = []
    for mbx in mailbox:
        if not re.search("^user%s" % imap.SEP, mbx):
            globalList.append(mbx)
    mailbox = globalList

#
# Create Tree Item
#
def __create_item(mbx):
    if self.imap_cache_items.get(mbx):
        return True
    mbxList = mbx.split(imap.SEP)
    if len(mbxList) == 1:
        self.imap_cache_items[mbx] = QListViewItem(self.lvImap)
        self.imap_cache_items[mbx].setText(0, mbx)
        return True
    mbxParent = imap.SEP.join(mbxList[:-1])
    if not self.imap_cache_items.get(mbxParent):
        __create_item(mbParent)
    self.imap_cache_items[mbx] = QListViewItem(self.imap_cache_items.get(mbxParent))
    self.imap_cache_items[mbx].setText(0, mbxList[-1])

self.imap_cache_items = {}
for mbx in mailbox:
    mbx = re.sub("^user%s" % imap.SEP, "", mbx)
    __create_item(mbx)

#
# Set last selection
#
if self.imap_cache_items.get(oldMailbox):
        self.lvImap.setCurrentItem(self.imap_cache_items.get(oldMailbox))
        self.imap_cache_items[oldMailbox].setSelected(True)
        while self.imap_cache_items.get(oldMailbox).parent() is not None:
            self.imap_cache_items[oldMailbox].parent().setOpen(True)
            oldMailbox = imap.SEP.join(oldMailbox.split(imap.SEP)[:-1])

#
# Get selection information
#
self.imap_mailbox_clicked()
self.lvImap.setFocus()

}

void dKorreio::imap_add() {

def __imap_add(mailbox, partition=None):
    mbxList = mailbox.split(imap.SEP)
    if mbxList[0] == "user":
        mbxItem = imap.SEP.join(mbxList[1:])
        mbxParent = None
        if len(mbxList) != 2:
            mbxParent = imap.SEP.join(mbxList[1:-1])
            if not self.imap_cache_items.get(mbxParent):
                self.console("<b>Erro:</b> caixa postal %s não existe." % mbParent)
                return False
    else:
        mbxItem = mailbox
        if len(mbxList) == 1:
            mbxParent = None
        else:
            mbxParent = imap.SEP.join(mbxList[:-1])

    imap.cm(mailbox, partition)
    if mbxParent is None:
        self.imap_cache_items[mbxItem] = QListViewItem(self.lvImap)
        self.lvImap.ensureItemVisible(self.imap_cache_items.get(mbxItem))
    else:
        self.imap_cache_items[mbxItem] = QListViewItem(self.imap_cache_items.get(mbxParent))
        self.imap_cache_items[mbxParent].setOpen(True)
        self.lvImap.ensureItemVisible(self.imap_cache_items.get(mbxParent))
    self.imap_cache_items[mbxItem].setText(0, mbxList[-1])
    self.console("<b>Ok:</b>caixa postal %s criada." % mailbox)
    
mailbox = self.iImapMailbox.text().ascii()

if not mailbox:
    self.console("<b>Atenção:</b> informe a caixa postal para ser criada.")
    return True

if self.imap_cache_items.get(mailbox):
    self.console("<b>Atenção:</b> caixa postal %s já existe." % mailbox)
    return True

imap = self.imap_connect()
if self.rbImapMailboxMode.isChecked():
    mbPath = "user%s%s" % (imap.SEP, mailbox)
else:
    mbPath = mailbox

partition = None
if self.iCyrusPart.text().ascii():
    partition = self.iCyrusPart.text().ascii()

try:
    __imap_add(mbPath, partition)
except cyruslib.CYRUSError, e:
    self.console("<b>Erro:</b> não foi possível criar caixa postal %s." % mailbox)
    raise cyruslib.CYRUSError, e

if len(mailbox.split(imap.SEP)) == 1:
    if self.iConfImapQuotaMbytes.text().ascii():
        imap.sq(mbPath, (int(self.iConfImapQuotaMbytes.text().ascii()) * 1024))
    if self.rbImapMailboxMode.isChecked():
        item = self.lvConfImapFolders.firstChild()
        while item is not None:
            __imap_add("%s%s%s" % (mbPath, imap.SEP, item.text(0).ascii()))
            if item.text(1).ascii() and item.text(1).ascii() != "0":
                imap.setannotation("%s%s%s" % (mbPath, imap.SEP, item.text(0).ascii()), "/vendor/cmu/cyrus-imapd/expire", item.text(1).ascii())
            if item.text(2).ascii():
                imap.sam("%s%s%s" % (mbPath, imap.SEP, item.text(0).ascii()), "anyone", "p")
            item = item.nextSibling()

self.imap_mailbox_clicked()

}

void dKorreio::imap_delete() {

imap = self.imap_connect()
try:
    mailbox = self.imap_current_mailbox(imap.SEP)
except:
    self.console("<b>Atenção:</b> selecione a caixa postal para exclusão.")
    return True

if QMessageBox.information( None, "Confirme!",
                                               utf2iso("Confirme a remoção da caixa postal:\n\n    - %s\n\n" % mailbox),
                                               "&Sim",
                                               utf2iso("&Não") ) != 0:
    self.console("<b>Atenção:</b> a remoção da caixa postal %s foi cancelada." % mailbox )
    return True

#
# Delete Imap Mailbox
#
try:
    imap.dm(mailbox)
    del self.imap_cache_items[re.sub("^user%s" % imap.SEP, "", mailbox)]
    self.console("<b>Ok:</b> caixa postal %s removida." % mailbox)
except cyruslib.CYRUSError, e:
    self.console("<b>Erro:</b> a caixa postal %s não foi removida. (%s)" % (mailbox, e[2]))
    return False

#
# Delete Interface item
#
item = self.lvImap.currentItem()
if item is not None:
    if item.parent() is None:
        self.lvImap.takeItem(item)
    else:
        item.parent().takeItem(item)

item = self.lvImap.currentItem()
if item is not None:
    item.setSelected(True)

}

void dKorreio::imap_set_quota() {

imap = self.imap_connect()

try:
    mailbox = self.imap_current_mailbox(imap.SEP)
except:
    self.console("<b>Atenção:</b> selecione a caixa postal para aplicar a quota.")
    return True

try:
    imap.sq(mailbox, self.iQuota.text().ascii())
    self.console("<b>Ok:</b> caixa postal %s limitada a %s Kbytes." % (mailbox, self.iQuota.text().ascii()))
except:
    self.console("<b>Erro:</b> não foi possível limitar a caixa postal %s" % mailbox)

}

void dKorreio::imap_reconstruct() {

imap = self.imap_connect()

try:
    mailbox = self.imap_current_mailbox(imap.SEP)
except:
    self.console("<b>Atenção:</b> selecione a caixa postal para reconstruir.")
    return True

try:
    imap.reconstruct(mailbox)
    self.console("<b>Ok:</b> caixa postal %s esta sendo reconstruida." % mailbox)
except:
    self.console("<b>Erro:</b> não foi possível reconstruir a caixa postal %s." % mailbox)

}

void dKorreio::imap_edit() {

imap = self.imap_connect()
self.mailboxOld = self.imap_current_mailbox(imap.SEP)
self.lvImap.currentItem().setRenameEnabled(0, True)
self.lvImap.currentItem().startRename(0)

}

void dKorreio::imap_rename() {

imap = self.imap_connect()
mailbox = self.imap_current_mailbox(imap.SEP)

if self.mailboxOld == mailbox:
    return True

if len(imap.lm(mailbox)) > 0:
    self.console("<b>Atenção:</b> caixa postal %s já existe." % mailbox)
    self.lvImap.currentItem().setText(0, self.mailboxOld.split(imap.SEP)[-1])
    return True

try:
    partition = imap.getannotation(self.mailboxOld, "/vendor/cmu/cyrus-imapd/partition")
    partition = partition[self.mailboxOld]["/vendor/cmu/cyrus-imapd/partition"]
except:
    self.console("<b>Erro:</b> erro ao detectar partição atual para %s." % mailbox)
    self.lvImap.currentItem().setText(0, self.mailboxOld.split(imap.SEP)[-1])
    return True

try:
    msg = "    Atenção: cetifique-se de que este usuário não esta logado através\nde POP ou IMAP antes de proseguir.\n"
    if len(re.sub("user%s" % imap.SEP,"", self.mailboxOld).split(imap.SEP)) == 1:
        msg += "\nA opção \"allowusermoves: yes\" deve estar configurada no imap.conf."
    res = QMessageBox.information( None, "Aviso!", utf2iso(msg), "&Ok")
    print res
    if res != 0:
        self.console("<b>Atenção:</b> edição cancelada.")
        self.lvImap.currentItem().setText(0, self.mailboxOld.split(imap.SEP)[-1])
    else:
        imap.rename(self.mailboxOld, mailbox, partition)
        self.console("<b>Ok:</b> caixa postal %s renomeada para %s." % (self.mailboxOld, mailbox))
except Exception, e:
    print e
    self.console("<b>Erro:</b> não foi possível renomear %s. Verifique a opção: \"allowusermoves: yes\"." % self.mailboxOld)
    self.lvImap.currentItem().setText(0,self.mailboxOld.split(imap.SEP)[-1])

self.imap_mailbox_clicked()

}

void dKorreio::imap_annotation_mode() {

if a0:
    self.imap_annotation_get()
}

void dKorreio::imap_annotation_set(a0, a1, a2) {

mailbox = a0
annot = a1
annotvalue = a2

imap = self.imap_connect()

if not annot:
    self.console("<b>Atenção:</b> informe a annotation")
    return False

try:
    imap.setannotation(mailbox, annot, annotvalue)
    self.console("<b>Ok:</b> annotation '%s' configurado em '%s' para %s." % (annot, annotvalue, mailbox))
except cyruslib.CYRUSError, e:
    self.console("<b>Erro:</b> annotation '%s' para %s (%s)." % (annot, mailbox, e[2]))

}

void dKorreio::imap_annotation_user_set() {

imap = self.imap_connect()

try:
    mailbox = self.imap_current_mailbox(imap.SEP)
except:
    self.console("<b>Atenção:</b> selecione a caixa postal para aplicar a annotation.")
    return True

self.imap_annotation_set(mailbox, self.cbImapAnnotation.currentText().ascii(), self.iAnnotationValue.text().ascii())

}

void dKorreio::imap_annotation_server_set() {

self.imap_annotation_set("", self.cbImapAnnotationServer.currentText().ascii(), self.iAnnotationValueServer.text().ascii())

}

void dKorreio::imap_annotation_get(a0, a1) {

mailbox = a0
annot = a1

imap = self.imap_connect()

if not annot:
    self.console("<b>Atenção:</b> annotation não especificada.")
    return False

try:
    annotation = imap.getannotation(mailbox, annot)
    return annotation.get(mailbox).get(annot)
except cyruslib.CYRUSError, e:
    self.console("<b>Erro:</b> não foi possível obter annotation '%s' para %s (%s)." % (annot, mailbox, e[2]))
    return ""
except:
    return ""

}

void dKorreio::imap_annotation_user_get() {

imap = self.imap_connect()

try:
    mailbox = self.imap_current_mailbox(imap.SEP)
except:
    self.console("<b>Atenção:</b> selecione a caixa postal.")
    return True

annot = self.imap_annotation_get(mailbox, self.cbImapAnnotation.currentText().ascii())
if annot:
    self.iAnnotationValue.setText(annot)
else:
    self.iAnnotationValue.setText("")

}

void dKorreio::imap_annotation_server_get() {

annot = self.imap_annotation_get("", self.cbImapAnnotationServer.currentText().ascii())
if annot:
    self.iAnnotationValueServer.setText(annot)
else:
    self.iAnnotationValueServer.setText("")

}

void dKorreio::imap_acl_wizard() {

if self.cbACL.currentItem() == 1:
    self.cbACL.setCurrentText("lrsw")
elif self.cbACL.currentItem() == 2:
    self.cbACL.setCurrentText("lrswi")
elif self.cbACL.currentItem() == 3:
    self.cbACL.setCurrentText("lrswicd")
elif self.cbACL.currentItem() == 4:
    self.cbACL.setCurrentText("p")
elif self.cbACL.currentItem() == 5:
    self.cbACL.setCurrentText("lrswipcda")

}

void dKorreio::imap_acl_del() {

imap = self.imap_connect()

try:
    mailbox = self.imap_current_mailbox(imap.SEP)
except:
    self.console("<b>Atenção:</b> selecione a caixa postal para remover a ACL.")
    return True

def __acl_del(user):
    try:
        imap.sam(mailbox, user, "")
        self.console("<b>Ok:</b> caixa postal %s: ACL de %s removida." % (mailbox, user))
        return True
    except:
        self.console("<b>Erro:</b> não foi possível remover ACL de %s em %s." % (user, mailbox))
        return False

itemDel = []
item = self.lvImapAcl.firstChild()
while item is not None:
    if item.isSelected():
        if __acl_del(item.text(0).ascii()):
            itemDel.append(item)
    item = item.nextSibling()

for item in itemDel:
    self.lvImapAcl.takeItem(item)

}

void dKorreio::imap_acl_add() {

imap = self.imap_connect()

try:
    mailbox = self.imap_current_mailbox(imap.SEP)
except:
    self.console("<b>Atenção:</b> selecione a caixa postal para aplicar a ACL.")
    return True

AclUser = re.sub(" ", "", self.iImapAclUser.text().ascii())
Acl = self.cbACL.currentText().ascii()

for user in AclUser.split(","):
    try:
        imap.sam(mailbox, user, Acl)
        self.console("<b>Ok:</b> caixa postal %s: ACL %s -> %s " % (mailbox, Acl, AclUser))
        item = self.lvImapAcl.firstChild()
        while item is not None:
            if item.text(0).ascii() == user:
                self.lvImapAcl.takeItem(item)
                break
            item = item.nextSibling()
        item = QListViewItem(self.lvImapAcl)
        item.setText(0, user)
        item.setText(1, Acl)
        self.lvImapAcl.setCurrentItem(item)
    except:
        self.console("<b>Erro:</b> não foi possível aplicar ACL %s -> %s em %s." % (Acl, AclUser, self.iImapMailbox.text().ascii()))

}

void dKorreio::imap_acl_clicked() {
# a0: current ACL item

item = a0
if item is not None:
    self.iImapAclUser.setText(item.text(0).ascii())
    self.cbACL.setCurrentText(item.text(1).ascii())
else:
    self.iImapAclUser.clear()
    self.cbACL.setCurrentItem(0)

}

void dKorreio::imap_mailbox_clicked() {

imap = self.imap_connect()

#
# Mailbox Path
#
mailbox = self.imap_current_mailbox(imap.SEP)

mbxtop = re.sub("^user%s" % imap.SEP, "", mailbox)
self.iImapMailbox.setText(mbxtop)

#
# Quota
#
if len(mbxtop.split(imap.SEP)) == 1:
    self.pImapQuota.setEnabled(True)
else:
    self.pImapQuota.setEnabled(False)

if re.search("^user%s" % imap.SEP, mailbox):
    mbxtop = "user%s%s" % (imap.SEP, mailbox.split(imap.SEP)[1])
else:
    mbxtop = mailbox.split(imap.SEP)[0]

try:
    quota = imap.lq(mbxtop)
except:
    quota = (0, 0)
self.iQuotaUsed.setText("%s" % quota[0])
self.iQuota.setText("%s" % quota[1])

#
# ACL
#
self.lvImapAcl.clear()
for user, acl in imap.lam(mailbox).items():
    item = QListViewItem(self.lvImapAcl)
    item.setText(0, user)
    item.setText(1, acl)

item = self.lvImapAcl.firstChild()
if item is not None:
    self.lvImapAcl.setCurrentItem(item)
    item.setSelected(False)
    self.imap_acl_clicked(item)

#
# Annotation
#
self.imap_annotation_user_get()

}

void dKorreio::imap_menu() {
# a0: item, a1: pos-xy

item = a0
pos = a1

if item is None:
    self.lvImapMenu.setItemEnabled(0, False)
    self.lvImapMenu.setItemEnabled(1, False)
    self.lvImapMenu.setItemEnabled(2, False)
else:
    self.lvImapMenu.setItemEnabled(0, True)
    self.lvImapMenu.setItemEnabled(1, True)
    self.lvImapMenu.setItemEnabled(2, True)

self.korreio_update_servers_menu()
self.lvImapMenu.popup(pos)

}

void dKorreio::imap_menu_clicked( a0 ) {

if a0 == 0:
    self.imap_edit()
elif a0 == 1:
    self.imap_delete()
elif a0 == 2:
    self.imap_reconstruct()

}

void dKorreio::imap_form_clear() {
self.korreio_module_clear("imap")
}

void dKorreio::imap_partition_search() {

self.lvImapPartition.clear()
self.cbImapPartition.clear()
partitions = {}

imap = self.imap_connect()

if self.rbImapPartMailboxMode.isChecked():
    query = "user%s%s%%" % (imap.SEP, self.iImapPartitionSearch.text().ascii())
else:
    query = "%s%%" % (self.iImapPartitionSearch.text().ascii())

try:
    annot = imap.getannotation(query, "/vendor/cmu/cyrus-imapd/partition")
except:
    return False

for mailbox in annot:
    partitions[annot[mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = None
    item = QListViewItem(self.lvImapPartition)
    item.setText(0, re.sub("^user%s" % imap.SEP, "", mailbox))
    item.setText(1, annot[mailbox]["/vendor/cmu/cyrus-imapd/partition"])
    if self.cImapSize.isChecked():
        try:
            limit = imap.lq(mailbox)
            item.setText(2, "%s" % limit[0])
            item.setText(3, "%s" % limit[1])
            item.setText(4, "%s%%" % (limit[0] * 100 / limit[1]) )
            continue
        except:
            item.setText(2, "-")
            item.setText(3, "-")
            item.setText(4, "0%")
    else:
        item.setText(2, "-")
        item.setText(3, "-")
        item.setText(4, "0%")

if self.lvImapPartition.childCount() > 0:
    self.pImapPartitionMove.setEnabled(True)
else:
    self.pImapPartitionMove.setEnabled(False)

for part in partitions:
    self.cbImapPartition.insertItem(part)

}

void dKorreio::imap_partition_move() {

partition = self.cbImapPartition.currentText().ascii()
if partition == "" or re.search(" ", partition):
    self.cbImapPartition.setFocus()
    self.console("<b>Info:</b> informe a partição IMAP.")
    return False

imap = self.imap_connect()

item = self.lvImapPartition.firstChild()
while item is not None:
    if item.isSelected():
        if self.rbImapPartMailboxMode.isChecked():
            mailbox = "user%s%s" % (imap.SEP, item.text(0).ascii())
        else:
            mailbox = item.text(0).ascii()
        
        try:
            imap.rename(mailbox, mailbox, partition)
            item.setText(1, partition)
            self.console("<b>Ok:</b> caixa postal %s movida para partição IMAP %s." % (item.text(0).ascii(), partition))
        except cyruslib.CYRUSError, e:
            self.console("<b>Erro:</b> não foi possível alterar a caixa postal %s para partição IMAP %s. (%s)" % (item.text(0).ascii(), partition, e[2]))
    item=item.nextSibling()

}

void dKorreio::imap_partition_size() {

if not self.cImapSizeUpdate.isChecked():
    self.tlImapSize.setText("0 Mbytes")
    return True

size = 0
percent = 0
count = 0
item = self.lvImapPartition.firstChild()
while item is not None:
    if item.isSelected() and item.text(2).ascii() != "-":
        size += int(item.text(2).ascii())
        percent += int(item.text(4).ascii().replace("%", ""))
        count += 1
    item=item.nextSibling()

if count == 0:
    count = 1

self.tlImapSize.setText("%s Mbytes ~ %s%%" % ((size / 1024), (percent / count)))

}

void dKorreio::imap_partition_menu() {
# a0: item, a1: pos-xy

self.korreio_update_servers_menu()
self.lvImapPartMenu.popup(a1)

}

void dKorreio::imap_partition_menu_clicked( a0 ) {

if a0 == 0:
    # Select All
    self.lvImapPartition.selectAll(True)
elif a0 == 1:
    # Set quota
    try:
        dflquota = int(self.iConfImapQuotaMbytes.text().ascii()) * 1024
    except:
        dflquota = 0
    quota, msg = QInputDialog.getInteger("Quota", utf2iso("Informe o limite (Kbytes):"), dflquota, 0, 2147483647, 512)
    if msg:
        imap = self.imap_connect()
        item = self.lvImapPartition.firstChild()
        while item is not None:
            if item.isSelected():
                if self.rbImapPartMailboxMode.isChecked():
                    mbx = "user%s%s" % (imap.SEP, item.text(0).ascii())
                else:
                    mbx = item.text(0).ascii()
                try:
                    imap.sq(mbx, quota)
                    item.setText(3, str(quota))
                    self.console("<b>Ok:</b> quota definida para %s em %s Kbytes." % (item.text(0).ascii(), str(quota)))
                except:
                    self.console("<b>Erro:</b> não foi possível definir quota para %s." % item.text(0).ascii())
            item=item.nextSibling()
    else:
        self.console("<b>Info:</b> definição de quota cancelada.")
}

void dKorreio::imap_partition_form_clear() {

self.korreio_module_clear("imap-partition")

}

void dKorreio::ldap_connect() {

try:
    if self.l:
        if active_conn.get("ldap.mode") == self.cbLdapMode.currentText().ascii() and active_conn.get("ldap.host") == self.iLdapHost.text().ascii() and active_conn.get("ldap.port") == self.iLdapPort.text().ascii() and active_conn.get("ldap.user") == self.iLdapUser.text().ascii() and active_conn.get("ldap.pass") == self.iLdapPass.text().ascii() and active_conn.get("ldap.ref") == "%s" % self.cLdapRef.isChecked():
            return self.l
except:
    pass

active_conn["ldap.mode"] = self.cbLdapMode.currentText().ascii()
active_conn["ldap.host"] = self.iLdapHost.text().ascii()
active_conn["ldap.port"] = self.iLdapPort.text().ascii()
active_conn["ldap.user"] = self.iLdapUser.text().ascii()
active_conn["ldap.pass"] = self.iLdapPass.text().ascii()
active_conn["ldap.ref"] = "%s" % self.cLdapRef.isChecked()

try:
    if self.cLdapCert.isChecked():
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
    else:
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,2)
    if self.cLdapRef.isChecked():
        ldap.set_option(ldap.OPT_REFERRALS,1)
    else:
        ldap.set_option(ldap.OPT_REFERRALS,0)
    server = "%s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii())
    self.l = ldap.initialize(server)
    self.l.protocol_version = ldap.VERSION3
    if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
        self.l.simple_bind(self.iLdapUser.text().ascii(), self.iLdapPass.text().ascii())
    else:
        self.l.simple_bind()
    self.console("<b>Ok:</b> servidor %s/%s conectado." % (server, self.iLdapUser.text().ascii()))
    return self.l
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    try:
        del self.l
    except:
        pass

}

void dKorreio::ldap_search() {

def __create_item(dn):
    dnList = dn.split(",")
    dnParent = ",".join(dnList[1:])
    if not self.ldap_cache_items.get(dnParent.lower()):
        if len(dnParent) > 1:
            __create_item(dnParent)
        else:
            print "Erro fatal: servidor ldap retonou basedn diferente (case sensitive?) da consulta."
            print "            Verifique se o servidor exige basedn case sensitive."
    self.ldap_cache_items[dn.lower()] = QListViewItem(self.ldap_cache_items.get(dnParent.lower()))
    self.ldap_cache_items[dn.lower()].setText(0, dnList[0])

if self.cbLdapFilter.count() > self.lbConfLdapFilter.count() + 4:
    self.cbLdapFilter.removeItem(self.lbConfLdapFilter.count())
self.cbLdapFilter.insertItem(self.cbLdapFilter.currentText().ascii())


basedn = self.cbLdapBaseDN.currentText().ascii()
try:
    dnOld = "%s" % self.ldap_current_dn()
except AttributeError, e:
    dnOld = basedn

self.lvLdap.clear()
self.lvLdapAttr.clear()

if not self.cbLdapFilter.currentText().ascii():
    filter = "(objectClass=*)"
else:
    filter = "(%s)" % iso2utf(self.cbLdapFilter.currentText().ascii())
self.ldap_cache_attr = self.ldap_query(filter, None)
if self.ldap_cache_attr is None:
    self.ldap_cache_attr = {}
    return

self.ldap_cache_items = {}
self.ldap_cache_items[basedn.lower()] = QListViewItem(self.lvLdap)
self.ldap_cache_items[basedn.lower()].setText(0,basedn)
self.ldap_cache_items[basedn.lower()].setOpen(True)

for dn in self.ldap_cache_attr.keys():
    if self.ldap_cache_items.get(dn.lower()):
        self.ldap_cache_items.get(dn.lower()).setText(0, dn.split(",")[0])
    else:
        __create_item(dn)
    if dn != dn.lower():
        self.ldap_cache_attr[dn.lower()] = self.ldap_cache_attr.get(dn)
        del self.ldap_cache_attr[dn]

self.lvLdap.firstChild().setText(0, basedn)

try:
    self.lvLdap.setCurrentItem(self.ldap_cache_items[dnOld.lower()])
    self.lvLdap.currentItem().setSelected(True)
except KeyError, e:
    pass

while dnOld.lower() != basedn.lower():
    try:
        self.ldap_cache_items[dnOld.lower()].setOpen(True)
    except KeyError, e:
        pass
    dnOld = ",".join(dnOld.split(",")[1:])
    if len(dnOld) == 0:
        break

self.lvLdap.scrollBy(0,self.lvLdap.currentItem().itemPos()-30)

self.ldap_dn_clicked()
self.lvLdap.setFocus()

}

void dKorreio::ldap_query( a0, a1 ) {
# a0: ldap_filter, a1: retrive attributes (List or None)

try:
    l = self.ldap_connect()
    if l is None:
        return
    ldap_result_id = l.search(self.cbLdapBaseDN.currentText().ascii(), ldap.SCOPE_SUBTREE, a0, a1)
    ldap_result = {}
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if result_type == ldap.RES_SEARCH_RESULT:
            break
        elif result_type == ldap.RES_SEARCH_ENTRY:
            ldap_result[utf2iso(result_data[0][0])] = result_data[0][1]
        elif result_type == ldap.RES_SEARCH_REFERENCE:
            ldap_result[result_data[0][1][0].split("/")[3].split("?")[0]] = {'ref': [result_data[0][1][0]]}
        else:
            print "Result type not implemented. "+str(result_type)

    return ldap_result
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    if e[0]["desc"] == "Size limit exceeded":
        return ldap_result

}

void dKorreio::ldap_dn_clicked() {

self.lvLdapAttr.clear()
self.wsLdap.raiseWidget(0)
self.cbLdapStack.setCurrentItem(0)

dn = self.ldap_current_dn()
if dn is None:
    return True

try:
    for attribute,values in self.ldap_cache_attr.get(dn.lower()).items():
        for value in values:
            item = QListViewItem(self.lvLdapAttr)
            item.setText(0,attribute)
            try:
                item.setText(1,utf2iso(value))
            except UnicodeDecodeError, e:
                item.setText(1,value)
except AttributeError, e:
    pass
item = self.lvLdap.currentItem()

if self.lvLdapAttr.childCount() > 0:
    self.lvLdapAttr.setCurrentItem(self.lvLdapAttr.firstChild())
    self.lvLdapAttr.currentItem().setSelected(True)

}

void dKorreio::ldap_form_next() {

    self.wsLdapForm.raiseWidget(self.wsLdapForm.id(self.wsLdapForm.visibleWidget()) + 1)

}


void dKorreio::ldap_form_back() {

    self.wsLdapForm.raiseWidget(self.wsLdapForm.id(self.wsLdapForm.visibleWidget()) - 1)

}

void dKorreio::ldap_form_posixAccount_enable() {

    if self.cLdapFormPosix.isChecked():
        self.fLdapFormPosix.setEnabled(True)
    else:
        self.fLdapFormPosix.setEnabled(False)
        self.fLdapFormSamba.setEnabled(False)
        self.cLdapFormSamba.setChecked(False)

}

void dKorreio::ldap_form_posixAccount_get_uidNumber() {

try:
    uidNumbers = self.ldap_query("(&(uidNumber=*)(!(objectClass=sambaUnixIdPool)))", ["uidNumber"])
    if uidNumbers:
        nextUidNumber = 999
        for item in uidNumbers:
            uidNumber = uidNumbers.get(item).get("uidNumber")[0]
            if int(uidNumber) > nextUidNumber:
                nextUidNumber = int(uidNumber)

        if nextUidNumber > 998:
            self.iLdapFormUidNumber.setText("%s" % (nextUidNumber + 1))
    
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)

}

void dKorreio::ldap_form_sambaSamAccount_enable() {

if self.cLdapFormSamba.isChecked():
    i=0
    domains = []
    while self.confDict.get("ldap.smb%s.domain" % i):
        domains.append(self.confDict.get("ldap.smb%s.domain" % i))
        i+=1

    self.cbLdapFormSambaDomain.clear()
    domains.sort()
    for domain in domains:
        self.cbLdapFormSambaDomain.insertItem(domain)

    if self.cbLdapFormSambaDomain.count() == 0:
        self.console("<b>Atenção:</b> cadastre domínios netbios.")
        self.cLdapFormSamba.setChecked(False)
    else:
        self.cLdapFormPosix.setChecked(True)
        self.fLdapFormPosix.setEnabled(True)
        self.iLdapFormUidNumber.setEnabled(False)
        self.pLdapGetUidNumber.setEnabled(False)
        self.iLdapFormGidNumber.setEnabled(False)
        self.fLdapFormSamba.setEnabled(True)
        self.ldap_form_sambaSamAccount_domain_clicked()
else:
    self.fLdapFormSamba.setEnabled(False)
    self.iLdapFormUidNumber.setEnabled(True)
    self.pLdapGetUidNumber.setEnabled(True)
    self.iLdapFormGidNumber.setEnabled(True)
    self.iLdapFormGidNumber.setText("100")

}

void dKorreio::ldap_form_sambaSamAccount_domain_clicked() {

domain = self.cbLdapFormSambaDomain.currentText().ascii()
i=0
while self.confDict.get("ldap.smb%s.domain" % i):
    if self.confDict.get("ldap.smb%s.domain" % i) == domain:
        break
    i+=1

if self.confDict["ldap.smb%s.profileType" % i] == "0":
    self.cbLdapFormProfileType.setCurrentItem(0)
    self.iLdapFormProfilePath.setEnabled(False)
else:
    self.cbLdapFormProfileType.setCurrentItem(1)
    self.iLdapFormProfilePath.setEnabled(True)

self.iLdapFormProfilePath.setText(re.sub("#UID#", self.iLdapFormUid.text().ascii(), self.confDict["ldap.smb%s.profilePath" % i]))

self.cbLdapFormPrimaryGroup.setCurrentItem(int(self.confDict["ldap.smb%s.primaryGroup" % i]))

self.iLdapFormGidNumber.setText(self.cbLdapFormPrimaryGroup.currentText().ascii().split("(")[1].split(")")[0])

self.iLdapFormHomeDrive.setText(self.confDict["ldap.smb%s.homeDrive" % i])
self.iLdapFormDrivePath.setText(re.sub("#UID#", self.iLdapFormUid.text().ascii(), self.confDict["ldap.smb%s.drivePath" % i]))
self.iLdapFormLogonScript.setText(re.sub("#UID#", self.iLdapFormUid.text().ascii(), self.confDict["ldap.smb%s.logonScript" % i]))
if self.confDict["ldap.smb%s.pwdMustChange" % i] == "True":
    self.iLdapFormSambaPwdMustChange.setChecked(True)
else:
    self.iLdapFormSambaPwdMustChange.setChecked(False)

}

void dKorreio::ldap_form_sambaSamAccount_perfil_clicked() {

    if self.cbLdapFormProfileType.currentItem() == 0:
        self.iLdapFormProfilePath.setEnabled(False)
    else:
        self.iLdapFormProfilePath.setEnabled(True)

}

void dKorreio::ldap_form_sambaSamAccount_show_frame() {

if self.wsLdapFormSmb.id(self.wsLdapFormSmb.visibleWidget()) == 0:
    self.wsLdapFormSmb.raiseWidget(1)
    self.pLdapFormSmbShow.setText("<<")
else:
    self.wsLdapFormSmb.raiseWidget(0)
    self.pLdapFormSmbShow.setText(">>")

}

void dKorreio::ldap_form_astSipUser_enable() {

    if self.cLdapFormAst.isChecked():
        self.fLdapFormAst.setEnabled(True)
    else:
        self.fLdapFormAst.setEnabled(False)

}

void dKorreio::ldap_form_radiusProfile_enable() {

    if self.cLdapFormRadius.isChecked():
        self.fLdapFormRadius.setEnabled(True)
    else:
        self.fLdapFormRadius.setEnabled(False)

}

void dKorreio::ldap_form_uid_changed() {

    self.iLdapFormHomeDirectory.setText("/home/%s" % self.iLdapFormUid.text().ascii())
    self.iLdapFormAstUsername.setText(self.iLdapFormUid.text().ascii())

}

void dKorreio::ldap_form_inetOrgPerson_mail_changed() {

    self.iLdapFormUid.setText(self.iLdapFormMail.text().ascii().split("@")[0])

}

void dKorreio::ldap_form_insert_user() {

if not self.iLdapFormCn.text().ascii():
    self.console("<b>Atenção:</b> informe o nome do usuário.")
    self.wsLdapForm.raiseWidget(0)
    self.iLdapFormCn.setFocus()
    return False

cn = iso2utf(self.iLdapFormCn.text().ascii())
dn = iso2utf("cn=%s,%s" % (self.iLdapFormCn.text().ascii(), self.ldap_current_dn()))

attrs = {}
attrs['objectClass'] = ['inetOrgPerson']
attrs['cn'] = [cn]
attrs['sn'] = [cn.split(" ")[-1]]
if self.iLdapFormMail.text().ascii():
    attrs['mail'] = [self.iLdapFormMail.text().ascii()]

if self.iLdapFormStreet.text().ascii():
    attrs['street'] = [iso2utf(self.iLdapFormStreet.text().ascii())]

if self.iLdapFormL.text().ascii():
    attrs['l'] = [iso2utf(self.iLdapFormL.text().ascii())]

if self.iLdapFormPostalCode.text().ascii():
    attrs['postalCode'] = [self.iLdapFormPostalCode.text().ascii()]

if self.iLdapFormHomePhone.text().ascii():
    attrs['homePhone'] = [self.iLdapFormHomePhone.text().ascii()]

if self.iLdapFormUserP.text().ascii() != self.iLdapFormUserP2.text().ascii():
    self.console("<b>Atenção:</b> as senhas não conferem, digite novamente.")
    self.wsLdapForm.raiseWidget(0)
    self.iLdapFormUserP.clear()
    self.iLdapFormUserP2.clear()
    self.iLdapFormUserP.setFocus()
    return False

if self.iLdapFormUserP.text().ascii():
    salt = ''
    for i in range(16):
        salt += choice(letters+digits)
    attrs['userPassword'] = ["{SSHA}%s"  % b2a_base64(sha.new(self.iLdapFormUserP.text().ascii() + salt).digest() + salt)[:-1]]

if self.cLdapFormPosix.isChecked():
    attrs['objectClass'].extend(['posixAccount', 'shadowAccount'])

    if not self.iLdapFormUid.text().ascii():
        self.console("<b>Atenção:</b> informe o login do usuário.")
        self.iLdapFormUid.setFocus()
        return False
    attrs['uid'] = [iso2utf(self.iLdapFormUid.text().ascii())]

    if not self.iLdapFormUidNumber.text().ascii():
        self.console("<b>Atenção:</b> informe o uidNumber do usuário.")
        self.iLdapFormUidNumber.setFocus()
        return False
    attrs['uidNumber'] = [self.iLdapFormUidNumber.text().ascii()]

    if not self.iLdapFormGidNumber.text().ascii():
        self.console("<b>Atenção:</b> informe o gidNumber do usuário.")
        self.iLdapFormGidNumber.setFocus()
        return False
    attrs['gidNumber'] = [self.iLdapFormGidNumber.text().ascii()]

    if self.iLdapFormLoginShell.text().ascii():
        attrs['loginShell'] = [iso2utf(self.iLdapFormLoginShell.text().ascii())]

    if not self.iLdapFormHomeDirectory.text().ascii():
        self.console("<b>Atenção:</b> informe o diretório home do usuário.")
        self.iLdapFormHomeDirectory.setFocus()
        return False
    attrs['homeDirectory'] = [iso2utf(self.iLdapFormHomeDirectory.text().ascii())]

if self.cLdapFormSamba.isChecked():
    attrs['objectClass'].extend(['sambaSamAccount'])
    attrs['uid'] = [iso2utf(self.iLdapFormUid.text().ascii())]

    domain = self.cbLdapFormSambaDomain.currentText().ascii()
    i=0
    while self.confDict.get("ldap.smb%s.domain" % i):
        if self.confDict.get("ldap.smb%s.domain" % i) == domain:
            break
        i+=1

    if not self.confDict.get("ldap.smb%s.domain" % i):
        self.console("<b>Atenção:</b> o domínio %s não esta configurado." % domain)
        self.wsLdapForm.raiseWidget(2)
        return False

    SIDEntry = self.confDict["ldap.smb%s.SIDEntry" % i]
    if not SIDEntry:
        self.console("<b>Atenção:</b> o registro de domínio netbios 'SIDdn' não esta configurado." % domain)
        self.wsLdapForm.raiseWidget(2)
        return False
    SID = self.ldap_query(SIDEntry.split(",")[0], None).get(SIDEntry).get("sambaSID")[0]

    profileType = self.confDict["ldap.smb%s.profileType" % i]
    profilePath = self.confDict["ldap.smb%s.profilePath" % i]
    homeDrive = self.confDict["ldap.smb%s.homeDrive" % i]
    drivePath = self.confDict["ldap.smb%s.drivePath" % i]
    logonScript = self.confDict["ldap.smb%s.logonScript" % i]

    uidCounter = self.confDict["ldap.smb%s.counterEntry" % i]
    if not uidCounter:
        self.console("<b>Atenção:</b> o contador de uidNumber do domínio %s não esta configurado." % domain)
        self.wsLdapForm.raiseWidget(2)
        return False

    attrs['uidNumber'] = ["%s" % self.ldap_query(uidCounter.split(",")[0], None).get(uidCounter).get("uidNumber")[0]]
    attrs['sambaSID'] = ["%s-%s" % (SID, int(attrs.get("uidNumber")[0]) * 2 + 1000)]
    gidNumber = self.cbLdapFormPrimaryGroup.currentText().ascii().split("(")[1].split(")")[0]
    attrs['gidNumber'] = [gidNumber]
    attrs['sambaPrimaryGroupSID'] = ["%s-%s" % (SID, gidNumber)]

    attrs['sambaLogonTime'] = ["0"]
    attrs['sambaLogoffTime'] = ["2147483647"]
    attrs['sambaKickoffTime'] = ["2147483647"]
    attrs['sambaPwdCanChange'] = ["0"]
    attrs['sambaAcctFlags'] = ["[U          ]"]
    attrs['sambaPwdLastSet'] = ["1"]

    if self.iLdapFormSambaPwdMustChange.isChecked():
        attrs['sambaPwdMustChange'] = ["1"]
    else:
        attrs['sambaPwdMustChange'] = ["2147483647"]

    if profileType == "1":
        attrs['sambaProfilePath'] = [re.sub("#UID#", attrs.get("uid")[0], profilePath)]

    if homeDrive:
        attrs['sambaHomeDrive'] = [homeDrive]

    if drivePath:
        attrs['sambaHomePath'] = [re.sub("#UID#", attrs.get("uid")[0], drivePath)]

    if logonScript:
        attrs['sambaLogonScript'] = [re.sub("#UID#", attrs.get("uid")[0], logonScript)]

    if self.iLdapFormUserP.text().ascii():
        attrs['sambaNTPassword'] = [smbpasswd.nthash(self.iLdapFormUserP.text().ascii())]
        attrs['sambaLMPassword'] = [smbpasswd.lmhash(self.iLdapFormUserP.text().ascii())]

if self.cLdapFormAst.isChecked():
    attrs['objectClass'].extend(['astSipGeneric', 'astSipPeer'])
    attrs['astContext'] = ["from-sip"]
    attrs['astRegseconds'] = ["10"]
    attrs['astLanguage'] = ["en"]
    attrs['astHost'] = ["dynamic"]

    if not self.iLdapFormAstUsername.text().ascii():
        self.console("<b>Atenção:</b> informe o usuário do asterisk.")
        self.wsLdapForm.raiseWidget(3)
        self.iLdapFormAstUsername.setFocus()
        return False
    attrs['astUsername'] = [iso2utf(self.iLdapFormAstUsername.text().ascii())]

    if not self.iLdapFormAstName.text().ascii():
        self.console("<b>Atenção:</b> informe o ramal do asterisk.")
        self.wsLdapForm.raiseWidget(3)
        self.iLdapFormAstName.setFocus()
        return False
    attrs['astName'] = [iso2utf(self.iLdapFormAstName.text().ascii())]

    if not self.iLdapFormAstPort.text().ascii():
        self.console("<b>Atenção:</b> informe a porta do asterisk.")
        self.wsLdapForm.raiseWidget(3)
        self.iLdapFormAstPort.setFocus()
        return False
    attrs['astPort'] = [iso2utf(self.iLdapFormAstPort.text().ascii())]

    if self.cLdapFormAstSecret.isChecked():
        attrs['astSecret'] = [iso2utf(self.iLdapFormUserP.text().ascii())]

if self.cLdapFormRadius.isChecked():
    attrs['objectClass'].extend(['radiusProfile'])
    if not self.iLdapFormRadiusGroup.text().ascii():
        self.console("<b>Atenção:</b> informe o grupo do radius.")
        self.wsLdapForm.raiseWidget(4)
        self.iLdapFormRadiusGroup.setFocus()
        return False
    attrs['radiusGroupName'] = [iso2utf(self.iLdapFormRadiusGroup.text().ascii())]

if self.ldap_add(dn, attrs):
    if self.cLdapFormSamba.isChecked():
        attrsOld = {}
        attrsOld['uidNumber'] = [attrs.get("uidNumber")[0]]
        attrsNew = {}
        attrsNew['uidNumber'] = ["%s" % (int(attrs.get("uidNumber")[0]) + 1)]
        self.ldap_modify(uidCounter, attrsOld, attrsNew)
    self.korreio_module_clear("ldap.form")

}

void dKorreio::ldap_add( a0, a1 ) {
# a0 = DN, a1 = attrs

dn = utf2iso(a0)

try:
    ldif = modlist.addModlist(a1)
    l = self.ldap_connect()
    l.add_s(a0,ldif)
    self.ldap_cache_attr[dn.lower()] = {}
    for tuple in ldif:
        self.ldap_cache_attr[dn.lower()][tuple[0]] = tuple[1]
    dnList = dn.split(",")
    if len(dnList) == 1:
        item = QListViewItem(self.lvLdap)
    else:
        itemParent = self.ldap_cache_items[",".join(dnList[1:]).lower()]
        itemParent.setOpen(True)
        item = QListViewItem(itemParent)
    item.setText(0, dnList[0])
    self.lvLdap.ensureItemVisible(item)
    self.ldap_cache_items[dn.lower()] = item
    self.console("<b>Ok:</b> registro %s adicionado." % a0)
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False

}

void dKorreio::ldap_modify( a0, a1, a2 ) {
# a0 = DN, a1 = attrold, a2 = attrnew

dn = iso2utf(a0)

try:
    ldif = modlist.modifyModlist(a1, a2)
    l = self.ldap_connect()
    l.modify_s(dn, ldif)
    for tuple in ldif:
        if tuple[2] is not None:
            self.ldap_cache_attr[a0.lower()][tuple[1]] = tuple[2]
    self.console("<b>Ok:</b> registro %s alterado." % dn)
    return True
except ldap.LDAPError, e:
    print e
    self.parse_exception("LDAPError", e)
    return False

}

void dKorreio::ldap_modify_clicked() {

stack = self.cbLdapStack.currentItem()

if stack == 0:
    if self.lvLdap.currentItem() is None:
        self.console("<b>Atenção:</b> selecione o registro para executar esta ação.")
        return True

    attrsOld = {}
    for attribute,values in self.ldap_cache_attr.get(self.ldap_current_dn().lower()).items():
        if attrsOld.get(attribute):
           attrsOld[attribute].extend(values)
        else:
           attrsOld[attribute] = values

    attrsNew = {}
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if attrsNew.get(item.text(0).ascii()):
            attrsNew[item.text(0).ascii()].extend([iso2utf(item.text(1).ascii())])
        else:
            attrsNew[item.text(0).ascii()] = [iso2utf(item.text(1).ascii())]
        item = item.nextSibling()

    self.ldap_modify(self.ldap_current_dn(), attrsOld, attrsNew)

else:
    attrs = {}
    item = self.lvLdapAttr.firstChild()
    dnParent = self.ldap_current_dn()
    while item is not None:
        if item.isSelected():
            if dnParent is None:
                dn = iso2utf("%s=%s" % (item.text(0).ascii(), item.text(1).ascii()))
            else:
                dn = iso2utf("%s=%s,%s" % (item.text(0).ascii(), item.text(1).ascii(), dnParent))
        if attrs.get(item.text(0).ascii()):
            attrs[item.text(0).ascii()].extend([iso2utf(item.text(1).ascii())])
        else:
            attrs[item.text(0).ascii()] = [iso2utf(item.text(1).ascii())]
        item = item.nextSibling()
    try:
        self.ldap_add(dn, attrs)
    except UnboundLocalError, e:
        self.console("<b>Atenção:</b> selecione o DN entre os atributos.")

}

void dKorreio::ldap_insert_ou() {

attrs = {}
if self.cbLdapFormUnit.currentText().ascii() == 'organizationalUnit':
    attrs['objectClass'] = ['organizationalUnit']
    attrs['ou'] = [iso2utf(self.iLdapFormUnit.text().ascii())]
    dn = iso2utf("ou=%s,%s" % (self.iLdapFormUnit.text().ascii(), self.ldap_current_dn()))
else:
    attrs['objectClass'] = ['organization']
    attrs['o'] = [iso2utf(self.iLdapFormUnit.text().ascii())]
    dn = iso2utf("o=%s,%s" % (self.iLdapFormUnit.text().ascii(), self.ldap_current_dn()))
if self.iLdapFormUnitStreet.text().ascii():
    attrs['street'] = [iso2utf(self.iLdapFormUnitStreet.text().ascii())]
if self.iLdapFormUnitL.text().ascii():
    attrs['l'] = [iso2utf(self.iLdapFormUnitL.text().ascii())]
if self.iLdapFormUnitPostalCode.text().ascii():
    attrs['postalCode'] = [iso2utf(self.iLdapFormUnitPostalCode.text().ascii())]
if self.iLdapFormUnitTelephoneNumber.text().ascii():
    attrs['telephoneNumber'] = [iso2utf(self.iLdapFormUnitTelephoneNumber.text().ascii())]

if self.ldap_add(dn,attrs):
    self.korreio_module_clear("ldap.form.unit")

}

void dKorreio::ldap_del_entry( a0 ) {

dn = a0
l = self.ldap_connect()
try:
    l.delete_s(dn)
    del self.ldap_cache_attr[dn.lower()]
    return True
except ldap.STRONG_AUTH_REQUIRED, e:
    self.parse_exception("LDAPError", e)
    return False
except KeyError, e:
    return True

}

void dKorreio::ldap_remove( a0 ) {

dn = a0

def __ldap_remove(dn):
    item = self.ldap_cache_items.get(dn.lower())
    subitem = item.firstChild()
    while subitem is not None:
        __ldap_remove("%s,%s" % (subitem.text(0).ascii(), dn))
        subitem = subitem.nextSibling()

    if self.ldap_del_entry(iso2utf(dn)):
        self.console("<b>Ok:</b> registro %s removido." % iso2utf(dn))
        return True
    else:
        self.console("Erro: não foi possível excluir o registro %s" % iso2utf(dn))
        return False

if __ldap_remove(dn):
    item = self.ldap_cache_items.get(dn.lower())
    if item.parent() is None:
        self.lvLdap.clear()
        self.lvLdapAttr.clear()
    else:
        item.parent().takeItem(item)
        self.lvLdap.currentItem().setSelected(True)

}

void dKorreio::ldap_remove_entry() {

dn =  iso2utf(self.ldap_current_dn())
if dn is not None:
    ok = QMessageBox.information( None, "Confirme!", utf2iso("Confirme a remoção do registro:\n\n    - %s\n\n" % dn), "&Sim", utf2iso("&Não") )
    if ok == 0:
        self.ldap_remove(utf2iso(dn))
        item = self.lvLdap.currentItem()
        self.ldap_dn_clicked()
    else:
        self.console("<b>Atenção:</b> a remoção do registro %s foi cancelada." % dn)

}

void dKorreio::ldap_copy( a0, a1, a2 ) {
dnFrom = a0
dnTo = a1
rdnTo = a2

attrs = self.ldap_cache_attr[dnFrom.lower()]
if rdnTo is None:
    rdnTo = "%s,%s" % (dnFrom.split(",")[0], dnTo)
else:
    rdnToList = rdnTo.split("=")
    rdnTo = "%s,%s" % (rdnTo, dnTo)
    attrs[rdnToList[0]] = [rdnToList[1]]

if self.ldap_add(iso2utf(rdnTo), attrs):
    item = self.ldap_cache_items[dnFrom.lower()].firstChild()
    while item is not None:
        self.ldap_copy("%s,%s" % (item.text(0).ascii(), dnFrom), rdnTo, None)
        self.ldap_cache_items[rdnTo.lower()].setOpen(False)
        item=item.nextSibling()
    return True
else:
    return False

}

void dKorreio::ldap_remove_attr() {

itemAttr = self.lvLdapAttr.currentItem()

if self.cConfLdapSchemaDelAttr.isChecked() and itemAttr.text(0).ascii().lower() == 'objectclass':
    depends = []

    item=self.lvConfLdapSchema.firstChild().firstChild()
    while item is not None:
        if item.text(0).ascii().lower() == itemAttr.text(1).ascii().lower():
            subitem=item.firstChild()
            while subitem is not None:
                if subitem.text(0).ascii().lower() != 'objectclass':
                    depends.append(subitem.text(0).ascii())
                subitem=subitem.nextSibling()
            break
        item=item.nextSibling()

    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if item.text(0).ascii() in depends:
            tmp=item
            item=item.nextSibling()
            self.lvLdapAttr.takeItem(tmp)
        else:
            item=item.nextSibling()

self.lvLdapAttr.takeItem(itemAttr)

try:
    self.lvLdapAttr.currentItem().setSelected(True)
except AttributeError, e:
    pass

}

void dKorreio::ldap_rename_attr_value() {

if not self.lvLdap.currentItem().text(0).ascii() == "=".join([self.lvLdapAttr.currentItem().text(0).ascii(),self.lvLdapAttr.currentItem().text(1).ascii()]):
    self.lvLdapAttr.currentItem().setRenameEnabled(1,True)
    self.lvLdapAttr.currentItem().startRename(1)

}

void dKorreio::ldap_add_attr() {

attr=self.cbLdapAttr.currentText().ascii()
value=self.cbLdapValue.currentText().ascii()
if not attr:
    return True

attrs = [(attr,value)]

if self.cConfLdapSchemaAddAttr.isChecked() and attr.lower() == 'objectclass':
    if not value:
        return True
    item=self.lvConfLdapSchema.firstChild()
    item=item.firstChild()
    while item is not None:
        subitem=item.firstChild()
        if item.text(0).ascii().lower() == value.lower():
            while subitem is not None:
                if subitem.text(1).ascii() is None: newvalue=""
                else: newvalue=subitem.text(1).ascii()
                attrs.extend([(subitem.text(0).ascii(),newvalue)])
                subitem=subitem.nextSibling()
        item=item.nextSibling()

for attr,value in attrs:
    item=self.lvLdapAttr.firstChild()
    jump=False
    while item is not None:
        if item.text(0).ascii() == attr and (item.text(1).ascii() == value or value == ''):
            jump=True
            break
        item=item.nextSibling()
    if jump:
        continue
    item = QListViewItem(self.lvLdapAttr)
    item.setText(0,attr)
    item.setText(1,value)
if self.cbLdapStack.currentItem() == 1:
    self.console("<b>Atenção:</b> ao criar o registro, pré-selecione um atributo como Distinguish Name.")

}

void dKorreio::ldap_edit_rdn() {

if self.lvLdap.currentItem().parent() is not None:
    self.rdnold = self.ldap_current_dn()
    self.lvLdap.currentItem().setRenameEnabled(0,True)
    self.lvLdap.currentItem().startRename(0)

}

void dKorreio::ldap_rename_rdn() {

item = self.lvLdap.currentItem()
rdnnew = item.text(0).ascii()

if self.rdnold.split(",")[0].lower() == rdnnew.lower():
    item.setText(0, self.rdnold.split(",")[0])
    return True

if item.childCount() > 0:
    item.setText(0, self.rdnold.split(",")[0])
    if self.ldap_copy(self.rdnold, ",".join(self.rdnold.split(",")[1:]), rdnnew):
        self.ldap_remove(self.rdnold)
else:
    dnexist = 1
    item = self.lvLdapAttr.firstChild()
    while item is not None:
        if "%s=%s".lower() % (item.text(0).ascii(), item.text(1).ascii()) == rdnnew.lower():
            dnexist = 0
            break
        item = item.nextSibling()
    if self.ldap_modify_rdn(self.rdnold, rdnnew, None, dnexist):
        self.console("<b>Ok:</b> registro %s alterado." % iso2utf(self.rdnold))
    else:
        self.lvLdap.currentItem().setText(0, self.rdnold.split(",")[0])
        return False

self.ldap_dn_clicked()
return True

}

void dKorreio::ldap_modify_rdn( a0, a1, a2, a3 ) {
#a0 = dnOld, a1 = dnNew, a2=newParent or None, a3 = newDNexist

dnOld = a0
dnNew = a1
newParent = a2
newDNexist = a3

try:
    l = self.ldap_connect()
    l.rename_s(iso2utf(dnOld), iso2utf(dnNew), newParent, newDNexist)
    dn = "%s,%s" % (dnNew, ",".join(dnOld.split(",")[1:]))
    self.ldap_cache_items[dn.lower()] = self.ldap_cache_items[dnOld.lower()]
    del self.ldap_cache_items[dnOld.lower()]
    self.ldap_cache_attr[dn.lower()] = self.ldap_cache_attr[dnOld.lower()]
    del self.ldap_cache_attr[dnOld.lower()]
    if newDNexist == 1:
        dnOldList = dnOld.split(",")[0].split("=")
        del self.ldap_cache_attr[dn.lower()][dnOldList[0]]
        dnNewList = dnNew.split("=")
        if self.ldap_cache_attr[dn.lower()].get(dnNewList[0]):
             self.ldap_cache_attr[dn.lower()][dnNewList[0]].append(dnNewList[1])
        else:
             self.ldap_cache_attr[dn.lower()][dnNewList[0]] = [dnNewList[1]]
    return True
except ldap.LDAPError, e:
    self.parse_exception("LDAPError", e)
    return False

}

void dKorreio::ldap_current_dn() {

item = self.lvLdap.currentItem()
if item is None:
    return None

dn = item.text(0).ascii()
while item.parent() is not None:
    dn = dn+","+item.parent().text(0).ascii()
    item = item.parent()

return dn

}

void dKorreio::ldap_change_widgetstack() {

selected_stack = self.cbLdapStack.currentItem()

if selected_stack == 1:
    self.lvLdapAttr.clear()
    self.wsLdap.raiseWidget(0)
    self.cbLdapAttr.setFocus()
    if self.lvLdap.currentItem() is None:
        self.console("<b>Atenção:</b> o registro raiz será inserido na base %s." % iso2utf(self.cbLdapBaseDN.currentText().ascii()))
    else:
        self.console("<b>Atenção:</b> o registro será inserido na base %s." % iso2utf(self.ldap_current_dn()))
else:
    if self.lvLdap.currentItem() is None:
        self.cbLdapStack.setCurrentItem(0)
        self.console("<b>Atenção:</b> selecione o registro para executar esta ação.")
        return True

    self.wsLdap.raiseWidget(selected_stack)
    if selected_stack == 0:
        self.ldap_dn_clicked()
        self.lvLdap.setFocus()
    elif selected_stack == 2:
        self.console("<b>Atenção:</b> o registro será inserido na base %s." % iso2utf(self.ldap_current_dn()))
        self.korreio_module_clear("ldap.form")
    elif selected_stack == 3:
        self.console("<b>Atenção:</b> o registro será inserido na base %s." % iso2utf(self.ldap_current_dn()))
        self.korreio_module_clear("ldap.form.unit")
    elif selected_stack == 4:
        self.console("<b>Atenção:</b> o registro selecionado é %s." % iso2utf(self.ldap_current_dn()))
        self.korreio_module_clear("ldap.form.password")
    elif selected_stack == 5:
        self.console("<b>Atenção:</b> o registro selecionado é %s." % iso2utf(self.ldap_current_dn()))
        self.korreio_module_clear("ldap.smb.populate")
}

void dKorreio::ldap_passwd() {

if not self.cbLdapUserPassword.isChecked() and not self.cbLdapSambaPassword.isChecked() and not self.cbLdapAstPassword.isChecked():
    self.console("<b>Atenção:</b> selecione ao menos uma opção.")
    return False

if self.iLdapPasswd.text().ascii() != self.iLdapPasswd2.text().ascii():
    self.console("<b>Atenção:</b> as senhas não conferem, digite novamente..")
    self.iLdapPasswd.clear()
    self.iLdapPasswd2.clear()
    return False

attrOld={}
attrNew={}

if self.cbLdapUserPassword.isChecked():

    salt = ''
    for i in range(16):
        salt += choice(letters+digits)

    attrOld["userPassword"] = 'None'
    hash = self.cbUserPassword.currentText().ascii()
    if hash == "{SSHA}":
        attrNew["userPassword"] = ["{SSHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]]
    elif hash == "{SHA}":
        attrNew["userPassword"] = ["{SHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii()).digest())[:-1]]
    elif hash == "{SMD5}":
        attrNew["userPassword"] = ["{SMD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]]
    elif hash == "{MD5}":
        attrNew["userPassword"] = ["{MD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii()).digest())[:-1]]
    elif hash == "{CRYPT}":
        salt = ''
        for i in [0,1]:
            salt += choice(letters+digits)
        attrNew["userPassword"] = ["{CRYPT}" + crypt.crypt(str(self.iLdapPasswd.text().ascii()),salt)]
    elif hash == "{PLAINTEXT}":
        attrNew["userPassword"] = [self.iLdapPasswd.text().ascii()]
    else:
        self.console("<b>Erro:</b> algoritmo não implementando.")
        return False

if self.cbLdapSambaPassword.isChecked():
    attrOld["sambaNTPassword"] = 'None'
    attrNew["sambaNTPassword"] = [smbpasswd.nthash(self.iLdapPasswd.text().ascii())]
    attrOld["sambaLMPassword"] = 'None'
    attrNew["sambaLMPassword"] = [smbpasswd.lmhash(self.iLdapPasswd.text().ascii())]
    if self.cConfLdapsambaPwdMustChange.isChecked():
        attrOld["sambaPwdMustChange"] = 'None'
        attrNew["sambaPwdMustChange"] = ["1"]

if self.cbLdapAstPassword.isChecked():
    attrOld["astSecret"] = 'None'
    attrNew["astSecret"] = [self.iLdapPasswd.text().ascii()]


if self.ldap_modify(self.ldap_current_dn(), attrOld, attrNew):
    self.iLdapPasswd.clear()
    self.iLdapPasswd2.clear()
    self.iLdapPasswd.setFocus()

self.ldap_dn_clicked()

}


void dKorreio::ldap_samba_populate() {

dnPopulate = self.ldap_current_dn()

domain = self.iLdapSMBdomain.text().ascii()
if not domain:
    self.console("<b>Atenção:</b> informe o domínio netbios.")
    self.iLdapSMBdomain.setFocus()
    return False

SID = self.iLdapSMBSID.text().ascii()
if not SID:
    self.console("<b>Atenção:</b> informe o SID do domínio netbios.")
    self.iLdapSMBSID.setFocus()
    return False

passwd = self.iLdapSMBpassword.text().ascii()
if not passwd:
    self.console("<b>Atenção:</b> informe uma senha para o administrador.")
    self.iLdapSMBpassword.setFocus()
    return False


#
# Units
#

units = []
units.append("Users")
units.append("Groups")
units.append("Computers")
units.append("Idmap")

for unit in units:
    dn = iso2utf("ou=%s,%s" % (unit, dnPopulate))
    attrs = {}
    attrs['objectClass'] = ['organizationalUnit']
    attrs['ou'] = [unit]
    if not self.ldap_add(dn,attrs):
        self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)

#
# Groups
#

groups = []
groups.append(["2", "512", "Domain Admins", "Netbios Domain Administrators"])
groups.append(["2", "513", "Domain Users", "Netbios Domain Users"])
groups.append(["2", "514", "Domain Guests", "Netbios Domain Guests Users"])
groups.append(["2", "515", "Domain Computers", "Netbios Domain Computers accounts"])
groups.append(["5", "544", "Administrators", "Netbios Domain Members can fully administer the computer/sambaDomainName"])
groups.append(["5", "548", "Account Operators", "Netbios Domain Users to manipulate users accounts"])
groups.append(["5", "550", "Print Operators", "Netbios Domain Print Operators"])
groups.append(["5", "551", "Backup Operators", "Netbios Domain Members can bypass file security to back up files"])
groups.append(["5", "552", "Replicators", "Netbios Domain Supports file replication in a sambaDomainName"])

for group in groups:
    dn = iso2utf("cn=%s,ou=Groups,%s" % (group[2], dnPopulate))
    attrs = {}
    attrs['objectClass'] = ['posixGroup', 'sambaGroupMapping']
    attrs['gidNumber'] = [group[1]]
    attrs['cn'] = [group[2]]
    attrs['displayName'] = [group[2]]
    if group[1] == '512':
        attrs['memberUid'] = ['root']
    attrs['description'] = [group[3]]
    attrs['sambaGroupType'] = [group[0]]
    if group[0] == "2":
        attrs['sambaSID'] = ["%s-%s" % (SID, group[1])]
    elif group[0] == "5":
        attrs['sambaSID'] = ["S-1-5-32-%s" % group[1]]
    if not self.ldap_add(dn,attrs):
        self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)

#
# Users: Root
#

dn = iso2utf("uid=root,ou=Users,%s" % dnPopulate)
attrs = {}
attrs['objectClass'] = ['inetOrgPerson', 'sambaSamAccount','posixAccount','shadowAccount']
attrs['cn'] = ["Administrador"]
attrs['sn'] = ["root"]
attrs['uidNumber'] = ["0"]
attrs['gidNumber'] = ["0"]
attrs['uid'] = ["root"]
attrs['homeDirectory'] = ["/root"]
attrs['loginShell'] = ["/bin/false"]
attrs['gecos'] = ["Netbios Domain Administrator"]
attrs['sambaLogonTime'] = ["0"]
attrs['sambaLogoffTime'] = ["2147483647"]
attrs['sambaKickoffTime'] = ["2147483647"]
attrs['sambaPwdMustChange'] = ["2147483647"]
attrs['sambaPwdCanChange'] = ["0"]
attrs['sambaHomeDrive'] = ["H:"]
attrs['sambaHomePath'] = ["\\\\server\\root"]
attrs['sambaProfilePath'] = ["\\\\server\\profiles\\root"]
attrs['sambaSID'] = ["%s-500" % SID]
attrs['sambaPrimaryGroupSID'] = ["%s-512" % SID]
attrs['sambaNTPassword'] = [smbpasswd.nthash(passwd)]
attrs['sambaLMPassword'] = [smbpasswd.lmhash(passwd)]
attrs['sambaAcctFlags'] = ["[U          ]"]
attrs['sambaPwdLastSet'] = ["1"]
salt = ''
for i in range(16):
    salt += choice(letters+digits)
attrs['userPassword'] = ["{SSHA}%s"  % b2a_base64(sha.new(self.iLdapFormUserP.text().ascii() + salt).digest() + salt)[:-1]]
if not self.ldap_add(dn,attrs):
    self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)

#
# Users: Nobody
#

dn = iso2utf("uid=nobody,ou=Users,%s" % dnPopulate)
attrs = {}
attrs['objectClass'] = ['inetOrgPerson', 'sambaSamAccount','posixAccount','shadowAccount']
attrs['cn'] = ["nobody"]
attrs['sn'] = ["nobody"]
attrs['uidNumber'] = ["999"]
attrs['gidNumber'] = ["514"]
attrs['uid'] = ["nobody"]
attrs['homeDirectory'] = ["/dev/null"]
attrs['loginShell'] = ["/bin/false"]
attrs['sambaLogonTime'] = ["0"]
attrs['sambaLogoffTime'] = ["2147483647"]
attrs['sambaKickoffTime'] = ["2147483647"]
attrs['sambaPwdMustChange'] = ["2147483647"]
attrs['sambaPwdCanChange'] = ["0"]
attrs['sambaHomeDrive'] = ["H:"]
attrs['sambaHomePath'] = ["\\\\server\\nonexistent"]
attrs['sambaProfilePath'] = ["\\\\server\\profiles\\nonexistent"]
attrs['sambaSID'] = ["%s-2998" % SID]
attrs['sambaPrimaryGroupSID'] = ["%s-514" % SID]
attrs['sambaNTPassword'] = ["NO PASSWORDXXXXXXXXXXXXXXXXXXXXX"]
attrs['sambaLMPassword'] = ["NO PASSWORDXXXXXXXXXXXXXXXXXXXXX"]
attrs['sambaAcctFlags'] = ["[NUD        ]"]
attrs['sambaPwdLastSet'] = ["0"]
if not self.ldap_add(dn,attrs):
    self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)

#
# sambaDomain
#

# from: 0=m, 1=h, 2=d
def time2seconds(value, type):
    valueInt=int(value)
    if type == 0:
        return "%i" % (valueInt * 60)
    elif type == 1:
        return "%i" % (valueInt * 60 * 60)
    elif type == 2:
        return "%i" % (valueInt * 24 * 60 * 60)
    else:
        raise "Erro: parametro de tempo invalido."

def time2minutes(value, type):
    valueInt=int(value)
    if type == 0:
        return "%i" % (valueInt)
    elif type == 1:
        return "%i" % (valueInt * 60)
    elif type == 2:
        return "%i" % (valueInt * 24 * 60)
    else:
        raise "Erro: parametro de tempo invalido."

dn = iso2utf("sambaDomainName=%s,%s" % (domain.upper(), dnPopulate))
attrs = {}
attrs['objectClass'] = ['sambaDomain', 'sambaUnixIdPool']
attrs['sambaDomainName'] = [domain.upper()]
attrs['sambaSID'] = [SID]
attrs['uidNumber'] = [self.iLdapSMBuidNumber.text().ascii()]
attrs['gidNumber'] = [self.iLdapSMBgidNumber.text().ascii()]
attrs['sambaAlgorithmicRidBase'] = ["1000"]
attrs['sambaNextUserRid'] = ["1000"]
attrs['sambaNextRid'] = ["1000"]
attrs['sambaMinPwdLength'] = [self.iLdapSMBminPwdLength.text().ascii()]
attrs['sambaPwdHistoryLength'] = [self.iLdapSMBpwdHistLenght.text().ascii()]
attrs['sambaMaxPwdAge'] = [time2seconds(self.iLdapSMBmaxPwdAge.text().ascii(), self.cbLdapSMBmaxPwdAge.currentItem())]
attrs['sambaMinPwdAge'] = [time2seconds(self.iLdapSMBminPwdAge.text().ascii(), self.cbLdapSMBminPwdAge.currentItem())]
attrs['sambaLockoutThreshold'] = [self.iLdapSMBlockout.text().ascii()]
attrs['sambaLockoutDuration'] = [time2minutes(self.iLdapSMBlockoutDuration.text().ascii(), self.cbLdapSMBlockoutDuration.currentItem())]
attrs['sambaLockoutObservationWindow'] = [time2minutes(self.iLdapSMBlockoutWindow.text().ascii(), self.cbLdapSMBlockoutWindow.currentItem())]
attrs['sambaLogonToChgPwd'] = ["0"]
attrs['sambaForceLogoff'] = ["-1"]
attrs['sambaRefuseMachinePwdChange'] = ["0"]
if not self.ldap_add(dn,attrs):
    self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)

self.lvLdap.currentItem().setOpen(True)

}

void dKorreio::ldap_menu() {

self.korreio_update_servers_menu()

if a0 is None:
    self.lvLdapMenu.setItemEnabled(0, False)
    self.lvLdapMenu.setItemEnabled(1, False)
    self.lvLdapMenu.setItemEnabled(2, False)
    self.lvLdapMenu.setItemEnabled(3, False)
    self.lvLdapMenu.setItemEnabled(4, False)
    self.lvLdapMenu.setItemEnabled(5, False)
    self.lvLdapMenu.setItemEnabled(6, False)
    self.lvLdapMenu.setItemEnabled(7, False)
    self.lvLdapMenu.setItemEnabled(8, False)
    self.lvLdapMenu.setItemEnabled(9, False)
else:
    self.lvLdapMenu.setItemEnabled(0, True)
    self.lvLdapMenu.setItemEnabled(1, True)
    self.lvLdapMenu.setItemEnabled(2, True)
    self.lvLdapMenu.setItemEnabled(3, True)
    self.lvLdapMenu.setItemEnabled(5, True)
    self.lvLdapMenu.setItemEnabled(6, True)
    self.lvLdapMenu.setItemEnabled(7, True)
    self.lvLdapMenu.setItemEnabled(8, True)
    self.lvLdapMenu.setItemEnabled(9, True)
    if self.lvLdapMenu.clipBoard == "None" or not self.ldap_cache_attr.get(self.lvLdapMenu.clipBoard.lower()):
        self.lvLdapMenu.setItemEnabled(4, False)
    else:
        self.lvLdapMenu.setItemEnabled(4, True)

self.lvLdapMenu.popup(a1)

}

void dKorreio::ldap_menu_clicked( a0 ) {

if a0 == 1:
    self.ldap_edit_rdn()
elif a0 == 2 or a0 == 3:
    self.lvLdapMenu.clipBoardMode = a0
    self.lvLdapMenu.clipBoard = self.ldap_current_dn()
elif a0 == 4:
    if re.search(self.lvLdapMenu.clipBoard, self.ldap_current_dn()):
        self.console("<b>Atenção:</b> solicitação inválida.")
    else:
        if self.ldap_copy(self.lvLdapMenu.clipBoard, self.ldap_current_dn(), None):
            if self.lvLdapMenu.clipBoardMode == 3:
                self.ldap_remove(self.lvLdapMenu.clipBoard)
                self.lvLdapMenu.clipBoard = "None"
elif a0 == 5:
    self.ldap_remove_entry()    
elif a0 == 6:
    self.cbLdapStack.setCurrentItem(4)
    self.ldap_change_widgetstack()
elif a0 == 7:
    self.cbLdapStack.setCurrentItem(5)
    self.ldap_change_widgetstack()
elif a0 == 8:
    dn = self.ldap_current_dn()
    self.cbLdapBaseDN.setCurrentText(dn)
    self.ldap_search()
elif a0 == 9:
    conn = self.iLdapConnection.text().ascii()
    i=0
    while self.confDict.get("ldap%s.name" % i):
        if self.confDict.get("ldap%s.name" % i) == conn:
            self.cbLdapBaseDN.setCurrentText(self.confDict.get("ldap%s.basedn" % i))
            self.ldap_search()
            break
        i+=1

}

void dKorreio::ldap_submenu1_clicked( a0 ) {

if a0 == 0:
    self.cbLdapStack.setCurrentItem(1)
elif a0 == 1:
    self.cbLdapStack.setCurrentItem(2)
elif a0 == 2:
    self.cbLdapStack.setCurrentItem(3)

self.ldap_change_widgetstack()

}

void dKorreio::ssh_connect() {

try:
    if self.ssh:
        if active_conn.get("ssh.host") == self.iSshHost.text().ascii() and active_conn.get("ssh.port") == self.iSshPort.text().ascii() and active_conn.get("ssh.user") == self.iSshUser.text().ascii() and active_conn.get("ssh.pass") == self.iSshPass.text().ascii():
            return self.ssh
except:
    pass

active_conn["ssh.host"] = self.iSshHost.text().ascii()
active_conn["ssh.port"] = self.iSshPort.text().ascii()
active_conn["ssh.user"] = self.iSshUser.text().ascii()
active_conn["ssh.pass"] = self.iSshPass.text().ascii()

self.ssh = pxssh.pxssh()

try:
    server = "ssh://%s@%s:%s" % (active_conn["ssh.user"], active_conn["ssh.host"], active_conn["ssh.port"])
    if self.ssh.login("-p%s %s" % (active_conn["ssh.port"], active_conn["ssh.host"]), active_conn["ssh.user"], active_conn["ssh.pass"]):
        self.console("<b>Ok:</b> servidor %s conectado." % server)
        return self.ssh
    else:
        del self.ssh
        self.console("<b>Erro:</b> servidor %s desconectado." % server)
        raise "Authentication error."
except pexpect.EOF, t:
    del self.ssh
    self.parse_exception("pexpect.EOF", t)
    raise "Connection hangup."

}

void dKorreio::ssh_open( a0 ) {

if self.cbSSHsudo.currentItem() == 0:
    cmd = a0
else:
    cmd = "sudo %s" % a0

result = []
s = self.ssh_connect()
self.console("<b>Info:</b> executando comando remoto: %s." % cmd)
try:
    s.sendline (cmd)
    s.prompt()
    for line in s.before.split("\n")[1:-1]:
        line = re.sub("\r","",line)
        result.append(line)
    return result
except pexpect.EOF, t:
    self.parse_exception("pexpect.EOF", t)
except pexpect.TIMEOUT, t:
    self.parse_exception("pexpect.TIMEOUT", t)

}

void dKorreio::ssh_exec( a0 ) {

if self.cbSSHsudo.currentItem() == 0:
    cmd = a0
else:
    cmd = "sudo %s" % a0

s = self.ssh_connect()
s.sendline ("%s > /dev/null 2>&1 && echo OK" % cmd)
s.prompt()
if re.search("\nOK", s.before):
    self.console("<b>Ok:</b> executando comando remoto: %s." % cmd)
    return True
else:
    self.console("<b>Erro:</b> executando comando remoto: %s." % cmd)
    return False

}

void dKorreio::scp_exec( a0 ) {

try:
    self.console("<b>Info:</b> salvando arquivo remoto: %s" % a0)
    child = pexpect.spawn('scp -P%s /tmp/korreio.tmp %s@%s:"%s"' % (self.iSshPort.text().ascii(), self.iSshUser.text().ascii(), self.iSshHost.text().ascii(), a0))
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        child.sendline('yes')
        child.expect('assword', timeout=2)
        child.sendline(self.iSshPass.text().ascii())
    print_cmd=[]
    for line in child:
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    self.console("<b>Erro:</b> conexão com %s terminada." % self.iSshHost.text().ascii())
except pexpect.TIMEOUT, t:
    self.console("<b>Erro:</b> conexão com %s sofreu timeout." % self.iSshHost.text().ascii())

}

void dKorreio::postfix_postconf() {

if self.rbPostconfN.isChecked():
    cmd = "postconf -n"
elif self.rbPostconfAll.isChecked():
    cmd = "postconf"
if self.rbPostconfD.isChecked():
    cmd = "postconf -d"
cmd = self.ssh_open(cmd)
self.postconf = {}
lastOpt = self.cbPostconf.currentText().ascii()
self.cbPostconf.clear()
i = 0
for config in cmd:
    if re.search("=",config):
        configlist = config.strip().split("=")
        configlist[0]=configlist[0].strip(" ")
        self.postconf[configlist[0]] = configlist[1]
        self.cbPostconf.insertItem(configlist[0])
        if configlist[0] == lastOpt:
            lastItem = i
        i += 1
try:
    self.cbPostconf.setCurrentItem(lastItem)
except UnboundLocalError, e:
    pass
self.postfix_postconf_changed()

}

void dKorreio::postfix_postconf_changed() {

value = self.postconf.get(self.cbPostconf.currentText().ascii())
value = re.sub("( )+"," ",value)
value = re.sub(", ",",",value)
value = re.sub(",",",\n",value)
value = re.sub("^ ","",value)
self.tePostconf.setText(value)

}

void dKorreio::postfix_postconf_save() {

value = re.sub(",", ", ", self.tePostconf.text().ascii())
value = re.sub(" +", " ",value)
value = re.sub("\n","",value)
value = re.sub("\r","",value)
option = self.cbPostconf.currentText().ascii()

if self.ssh_exec("postconf -e %s=%s" % (option, re.sub(" ", "\ ", value))):
    self.console("<b>Ok:</b> opção %s configurada." % option )
    self.postconf[option] = value
else:
    self.console("<b>Erro:</b> não foi possível configurar %s." % option )

}

void dKorreio::services_open_file() {

if not self.cbPostFileOpen.currentText().ascii():
    self.console("<b>Atenção:</b> informe o nome do arquivo.")
    self.cbPostFileOpen.setFocus()
    return True

contentList = self.ssh_open("cat %s" % self.cbPostFileOpen.currentText().ascii())
content = "\n".join(contentList)

if re.search("^cat: ", content):
    self.console("<b>Erro:</b> arquivo %s nao encontrado." % self.cbPostFileOpen.currentText().ascii())
    return True

self.tePostFileOpen.setText(content)

}

void dKorreio::services_save_file() {

if self.tePostFileOpen.length () == 0:
    self.ssh_exec("rm -f %s" % self.cbPostFileOpen.currentText().ascii())
    return True

# pexpext dont handle tab correctly.
self.ssh_open("cat <<< \"%s\" | sed -e \'s/#TAB#/\\t/g\' > %s" % (re.sub("\t", "#TAB#", self.tePostFileOpen.text().ascii()), self.cbPostFileOpen.currentText().ascii()))

}

void dKorreio::services_postmap() {

file = self.cbPostFileOpen.currentText().ascii()
if self.ssh_exec("postmap %s" % file):
    self.console("<b>Ok:</b> database %s.db gerada." % file )
else:
    self.console("<b>Erro:</b> não foi possível gerar database %s.db." % file )

}

void dKorreio::services_status() {

service = self.cbServiceService.currentText().ascii()
status = self.cbServiceStatus.currentText().ascii()
log = self.ssh_open("/etc/init.d/%s %s" % (service, status))
self.teServiceStatus.setText("\n".join(log))

}

void dKorreio::services_change_widgetstack() {

item = self.lvServices.currentItem()

if  item.text(1).ascii() == "1":
    self.wsServices.raiseWidget(0)
elif item.text(1).ascii() == "2":
   self.wsServices.raiseWidget(2)
elif item.text(1).ascii() == "3.1":
    self.wsServices.raiseWidget(1)

}

void dKorreio::services_menu() {
# a0: item, a1: pos-xy

self.lvServicesMenu.popup(a1)

}

void dKorreio::sieve_search() {

self.lvSieve.clear()
imap = self.imap_connect()
for user in imap.lm("user%s%s%%" % (imap.SEP, self.iSieveSearch.text().ascii())):
    user=user.split(imap.SEP)[1]
    item = QListViewItem(self.lvSieve)
    item.setText(0, user)
    if self.cSieveScript.isChecked():
        s = self.sieve_connect(user)
        scripts = s.listscripts()
        s.logout()
        if scripts[0] == 'OK':
            for script,active in scripts[1]:
                if active:
                    item.setText(1, script)
                    break

}

void dKorreio::sieve_connect( a0 ) {

admin = self.iCyrusUser.text().ascii().split("@")
if admin[0] != self.iCyrusUser.text().ascii():
    user = "%s@%s" % (a0, admin[1])
else:
    user = a0

msg = "sieve://%s:%s/%s" % (self.iCyrusHost.text().ascii(), self.iCyrusSievePort.text().ascii(), user)

s = sievelib.MANAGESIEVE(self.iCyrusHost.text().ascii(),int(self.iCyrusSievePort.text().ascii()))
if s.alive:
    if s.login('PLAIN',user,self.iCyrusPass.text().ascii(),self.iCyrusUser.text().ascii()):
        self.console("<b>Ok:</b> servidor %s conectado." % msg)
        return s
    else:
        self.console("<b>Erro de conexão:</b> %s (Usuário ou senha incorretos)." % msg)
else:
    self.console("<b>Erro de conexão:</b> %s (Conexão recusada)." % msg)

return False

}

void dKorreio::sieve_user_clicked() {

self.teSieveScript.clear()
self.cbSieveScript.clear()

item = self.lvSieve.currentItem()
if item is None:
    return True

s = self.sieve_connect(item.text(0).ascii())
scripts = s.listscripts()
s.logout()

if scripts[0] == 'OK':
    for script,active in scripts[1]:
        self.cbSieveScript.insertItem(script)
        if self.lvSieve.currentItem().text(1).ascii() == script:
            self.cbSieveScript.setCurrentText(script)

if self.cbSieveScript.count() > 0:
    self.sieve_get_script()

}

void dKorreio::sieve_get_script() {

s = self.sieve_connect(self.lvSieve.currentItem().text(0).ascii())
script = s.getscript(self.cbSieveScript.currentText().ascii())
s.logout()

self.teSieveScript.clear()
if script[0] == 'OK':
    self.teSieveScript.setText(script[1])

}

void dKorreio::sieve_set_script() {

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        if self.cbSieveScript.currentText().ascii():
            status = s.putscript(self.cbSieveScript.currentText().ascii(),self.teSieveScript.text().ascii().replace("#USER#",item.text(0).ascii()))
            if status == 'OK':
                item.setText(1,self.cbSieveScript.currentText().ascii())
                s.setactive(self.cbSieveScript.currentText().ascii())
        else:
            item.setText(1,"")
            s.setactive()
        s.logout()
    item=item.nextSibling()

self.sieve_get_script()

}

void dKorreio::sieve_unset_script() {

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        s.setactive()
        s.logout()
        item.setText(1,"")
    item=item.nextSibling()

}

void dKorreio::sieve_del_script() {

if not self.cbSieveScript.currentText().ascii():
    self.console("<b>Atenção:</b> digite o nome do script.")
    return True

item = self.lvSieve.firstChild()
while item is not None:
    if item.isSelected():
        s = self.sieve_connect(item.text(0).ascii())
        if s.deletescript(self.cbSieveScript.currentText().ascii()) == 'OK':
            if self.cbSieveScript.currentText().ascii() == item.text(1).ascii():
                item.setText(1,"")
        s.logout()
    item=item.nextSibling()

self.sieve_get_script()

}

void dKorreio::sieve_select_all() {

self.lvSieve.selectAll(True)

}


void dKorreio::sieve_use_template() {

try:
    sep = self.m.SEP
except AttributeError, e:
    sep = "/"

self.cbSieveScript.setCurrentText("script.siv")
template = self.lbSieveScripts.currentItem()
if template == 0:
    self.teSieveScript.setText("redirect \"destinatario@exemplo.com.br\";\n")

elif template == 1:
    self.teSieveScript.setText("""redirect "destinatario@exemplo.com.br";
keep;
""".replace("        ",""))

elif template == 2:
    self.teSieveScript.setText("""require "fileinto";
if address :contains "from" "remetente1@exemplo.com.br" {
   fileinto "INBOX%(sep)sPasta1";
}
""".replace("        ","") % {'sep':sep})

elif template == 3:
    self.teSieveScript.setText("""require "fileinto";
if address :contains "from" ["from1@dom1.com","from2@dom2.com"] {
    fileinto "INBOX%(sep)sPasta1";
}
elsif address :contains "from" ["from3@dom3.com","from4@dom4.com"] {
    fileinto "INBOX%(sep)sPasta2";
}
""".replace("        ","") % {'sep':sep})

elif template == 4:
    self.teSieveScript.setText("""if header :contains "X-Spam-Flag" "YES" {
    discard;
}
""".replace("        ",""))

elif template == 5:
    self.teSieveScript.setText("""require "fileinto";
if header :contains "X-Spam-Flag" "YES" {
    fileinto "INBOX%(sep)sSpam";
}
""".replace("        ","") % {'sep':sep})

elif template == 6:
    self.console("<b>Atenção:</b> a macro #USER# será substituida pelo respectivo usuário.")
    if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
        domain="dominio.com.br"
    else:
        domain=self.iCyrusUser.text().ascii().split("@")[1]
    self.teSieveScript.setText("""require ["vacation","fileinto"];

if header :contains "X-Spam-Flag" "YES" {
    fileinto "INBOX%(sep)sSpam";
    stop;
}

vacation :days 5
:subject "Estou ausente"
:addresses ["#USER#@%(domain)s"]
 "Estarei ausente entre os dias ....

 Obrigado,

 --
 xxxxxxxxxxxx";
""".replace("        ","") % {'sep':sep,'domain':domain})

elif template == 7:
    if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
        domain="exemplo.com.br"
    else:
        domain=self.iCyrusUser.text().ascii().split("@")[1]
    self.console("<b>Atenção:</b> a macro #USER# será substituida pelo respectivo usuário.")
    self.teSieveScript.setText("""require "vacation";
vacation :days 5
:subject "Estou ausente."
:addresses ["#USER#@%s"]
 "Estarei ausente entre os dias ....

 Obrigado,

 --
 xxxxxxxxxxxx";
""".replace("        ","") % domain)
}

void dKorreio::sieve_menu() {
# a0: item, a1: pos-xy

self.korreio_update_servers_menu()
self.lvSieveMenu.popup(a1)

}

void dKorreio::sieve_menu_clicked( a0 ) {

if a0 == 0:
    self.sieve_select_all()

}

void dKorreio::queue_load() {

re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)\s+(\d+)\s([A-Z][a-z][a-z])\s([A-Z][a-z][a-z])\s+(\d+)\s(\d\d:\d\d:\d\d)\s+(.*)')
re_rcpt  = re.compile(r'\s+(.*@.*)\b')
re_log  = re.compile(r'(\s+)?\(.*\)')

oldItem = self.lvQueue.currentItem()
if oldItem:
    while oldItem.parent() is not None:
        oldItem = oldItem.parent()
    oldFrom = oldItem.text(0).ascii()
else:
    oldFrom = ""

self.iQueueMessage.clear()
self.lvQueue.clear()

itemFrom = {}
itemQueueID = {}
self.itemLog = {}

queueList = self.ssh_open("postqueue -p")
if re.search("command not found", queueList[0]):
    self.console("<b>Erro:</b> comando não encontrado: postqueue.")
    return False

for line in queueList:
    match = re_queueid.match(line)
    if match is not None:
        tmp = ""
        self.itemLog[match.group(1)] = "%s %s %s %s" % (match.group(3), match.group(4), match.group(5), match.group(6))
        #print "regexp: %s %s %s %s %s %s %s" % (match.group(1), match.group(2), match.group(3), match.group(4), match.group(5), match.group(6), match.group(7))
        mailFrom = match.group(7)
        if not itemFrom.get(mailFrom):
            itemFrom[mailFrom] = QListViewItem(self.lvQueue)
            itemFrom[mailFrom].setText(0,match.group(7))
            if match.group(7) == oldFrom:
                self.lvQueue.setCurrentItem(itemFrom[mailFrom])
                itemFrom[mailFrom].setOpen(True)
        queueid = match.group(1)
        itemQueueID[queueid] = QListViewItem(itemFrom[mailFrom])
        itemQueueID[queueid].setText(0,"%s - %s Kb" % (queueid, int(match.group(2)) / 1024) )
        itemQueueID[queueid].setOpen(True)
        continue
    match = re_log.match(line)
    if match is not None:
        tmp = line
        continue
    match = re_rcpt.match(line)
    if match is not None:
        try:
            self.itemLog["%s:%s" % ( queueid, match.group(1) )] = tmp
        except:
            pass
        tmp = ""
        itemRcpt = QListViewItem(itemQueueID[queueid])
        itemRcpt.setText(0,match.group(1))

if not oldFrom:
    self.lvQueue.setCurrentItem(self.lvQueue.firstChild())

item = self.lvQueue.firstChild()
total = [0, 0]
while item is not None:
    count = item.childCount()
    subcount = 0
    if count > 0:
        subitem = item.firstChild()
        while subitem is not None:
            subcount = subcount + subitem.childCount()
            subitem.setText(1,"%s" % subitem.childCount())
            subitem = subitem.nextSibling()
    item.setText(1,"%s/%s" % (count, subcount))
    item = item.nextSibling()
    total[0] += count
    total[1] += subcount

self.tlQueueMsgs.setText("%s/%s" % (total[0], total[1]))
self.lvQueue.setColumnWidth(0, self.lvQueue.width() - 130)
self.lvQueue.setColumnWidth(1, 126)
self.lvQueue.ensureItemVisible(self.lvQueue.currentItem())
self.queue_get_message()

}

void dKorreio::queue_get_message() {

item = self.lvQueue.currentItem()

if item is None:
    return True

if item.parent() is None:
    size = 0
    subitem = item.firstChild()
    while subitem is not None:
        queueid = subitem.text(0).ascii()
        re_queueid  = re.compile(r'\b[A-Z0-9]+\*?\!? - (\d+) Kb')
        match = re_queueid.match(queueid)
        if match is not None:
            size += int(match.group(1))
        subitem.text(0).ascii()
        subitem = subitem.nextSibling()
    self.iQueueMessage.setText("*** TOTAL SIZE ***\n%s Kbytes" % size)
    return True

if item.childCount() == 0:
    re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)')
    match = re_queueid.match(item.parent().text(0).ascii())
    if match is not None:
        self.iQueueMessage.setText("*** DELAY REASON ***\n%s" % re.sub(" *\(", "(", self.itemLog.get("%s:%s" % (match.group(1), item.text(0).ascii()) ) ))
        return True

queueid = item.text(0).ascii()
re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)')
match = re_queueid.match(queueid)
if match is not None:
    self.iQueueMessage.setText("*** ARRIVAL TIME ***\n%s" % self.itemLog.get(match.group(1)))

}

void dKorreio::queue_set_message( a0, a1 ) {
# a0=cmd, a1=remove item

self.iQueueMessage.clear()

item = self.lvQueue.currentItem()
re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')

if item.parent() is None:
    subitem = item.firstChild()
    success = False
    queuelist = []
    while subitem is not None:
        queuelist.append(re_queueid.match(subitem.text(0).ascii()).group(1))
        if len(queuelist) == 50 or subitem.nextSibling() is None:
            if self.ssh_exec("%s - <<< \"%s\"" % (a0, "\n".join(queuelist))):
                success = True
            queuelist = []
        subitem = subitem.nextSibling()
    if success:
        self.console("<b>Ok:</b> %s mensagen(s) processadas(s)." % item.childCount())
    if a1 == True:
        self.lvQueue.takeItem(item)
else:
    match = re_queueid.match(item.text(0).ascii())
    if match is not None:
        self.ssh_exec("%s %s" % (a0, match.group(1)))
        if a1 == True:
            count = item.parent().text(1).ascii().split("/")
            if int(count[0]) == 1:
                self.lvQueue.takeItem(item.parent())
            else:
                item.parent().setText(1 ,"%s/%s" % (str(int(count[0]) - 1), str(int(count[1]) - int(item.childCount()))))
                item.parent().takeItem(item)

}

void dKorreio::queue_menu() {

self.korreio_update_servers_menu()

item = a0

if item is None or item.childCount() == 0:
    self.lvQueueMenu.setItemEnabled(1, False)
    self.lvQueueMenu.setItemEnabled(2, False)
    self.lvQueueMenu.setItemEnabled(3, False)
    self.lvQueueMenu.setItemEnabled(4, False)
    self.lvQueueMenu.setItemEnabled(5, False)
elif item.parent() is None:
    self.lvQueueMenu.setItemEnabled(1, False)
    self.lvQueueMenu.setItemEnabled(2, True)
    self.lvQueueMenu.setItemEnabled(3, True)
    self.lvQueueMenu.setItemEnabled(4, True)
    self.lvQueueMenu.setItemEnabled(5, True)
else:
    self.lvQueueMenu.setItemEnabled(1, True)
    self.lvQueueMenu.setItemEnabled(2, True)
    self.lvQueueMenu.setItemEnabled(3, True)
    self.lvQueueMenu.setItemEnabled(4, True)
    self.lvQueueMenu.setItemEnabled(5, True)

self.lvQueueMenu.popup(a1)

}


void dKorreio::queue_menu_clicked( a0 ) {

if a0 == 0:
    self.queue_load()
elif a0 == 1:
    queueid = self.lvQueue.currentItem().text(0).ascii()
    re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
    match = re_queueid.match(queueid)
    if match is not None:
        self.iQueueMessage.setText("\n".join(self.ssh_open("postcat -q %s" % match.group(1))))
elif a0 == 2:
    self.queue_set_message("postsuper -h", False)
elif a0 == 3:
    self.queue_set_message("postsuper -H", False)
elif a0 == 4:
    self.queue_set_message("postsuper -r", False)
elif a0 == 5:
    item = self.lvQueue.currentItem()
    if item.parent() is None:
        msg = "Deseja remover todas as mensagens do remetente %s?" % item.text(0).ascii()
    else:
        re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
        match = re_queueid.match(item.text(0).ascii())
        msg = "Deseja remover a mensagem %s do remetente %s?" % (match.group(1), item.parent().text(0).ascii())
    if QMessageBox.information( None, "Confirme!",
           utf2iso(msg), "&Sim", utf2iso("&Não") ) != 0:
        self.console("<b>Atenção:</b> a ação DELETE foi cancelada.")
        return True
    self.queue_set_message("postsuper -d", True)

}

void dKorreio::queue_submenu1_clicked( a0 ) {

if a0 == 0:
    QMessageBox.information( None, "Aviso!",
           utf2iso("    Atenção: a ação de FLUSH interfere negativamente no algoritmo de\n"+
                       "escalonamento de envio de mensagens do QMGR com filas grandes.\n"+
                       "Use somente quando necessário."), "&Ok")
    cmd = "postqueue -f"
elif a0 == 1:
    if QMessageBox.information( None, "Confirme!",
           "Deseja colocar todas as mensagens em HOLD?", "&Sim", utf2iso("&Não") ) != 0:
        self.console("<b>Atenção:</b> a ação HOLD foi cancelada.")
        return True
    cmd = "postsuper -h ALL"
elif a0 == 2:
    if QMessageBox.information( None, "Confirme!",
           "Deseja retirar todas a mensagens de HOLD?", "&Sim", utf2iso("&Não") ) != 0:
        self.console("<b>Atenção:</b> a ação HOLD foi cancelada.")
        return True
    cmd = "postsuper -H ALL"
elif a0 == 3:
    if QMessageBox.information( None, "Confirme!",
           "Deseja reconsultar o transport (requeue) para todas as mensagens?", "&Sim", utf2iso("&Não") ) != 0:
        self.console("<b>Atenção:</b> a ação REQUEUE foi cancelada.")
        return True
    cmd = "postsuper -r ALL"
elif a0 == 4:
    if QMessageBox.information( None, "Confirme!",
           "Deseja remover todas as mensagens?", "&Sim", utf2iso("&Não") ) != 0:
        self.console("<b>Atenção:</b> a ação DELETE foi cancelada.")
        return True
    cmd = "postsuper -d ALL"

if self.ssh_exec(cmd) and a0 == 4:
    self.lvQueue.clear()

}

