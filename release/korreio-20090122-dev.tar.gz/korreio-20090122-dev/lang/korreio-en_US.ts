<!DOCTYPE TS><TS>
<context>
    <name>dKorreio</name>
    <message>
        <source>Distinguished Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IMAP Mailbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IMAP Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ACL anyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korreio - Mail Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>objectClass=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ou=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cn=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uid=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mail=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>objectClass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>structuralObjectClass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gecos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>homeDirectory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>loginShell</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uidNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gidNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>userPassword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowLastChange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowMin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowMax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowWarning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowInactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowExpire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowFlag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>carLicense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>displayName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>homePhone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>street</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>postalCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLMPassword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaNTPassword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPwdLastSet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLogonTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLogoffTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaKickoffTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPwdCanChange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPwdMustChange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaAcctFlags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaHomePath</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaHomeDrive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLogonScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaProfilePath</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaUserWorkstations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPrimaryGroupSID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaDomainName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaMungedDial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaBadPasswordCount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaBadPasswordTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPasswordHistory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLogonHours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailAlternateAddress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ipHostNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>owner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>serialNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>member</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>inetOrgPerson</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>posixAccount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaSamAccount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowAccount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>simpleSecurityObject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>organizationalUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>organizationalRole</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>groupOfNames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ipHost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ipNetwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>referral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>extensibleObject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;New User&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;inetOrgPerson&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;cn&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Full name&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mail:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;mail&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;user@example.com&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;l&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;street&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Av. Example, N 123&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;District, City, State&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Postal code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;postalCode&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;000000&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;homePhone&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;+1 (55) 5555-5555&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;userPassword&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password (again):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;posixAccount&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uid number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;uidNumber&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gid number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;gidNumber&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;homeDirectory&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shell:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;loginShell&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User id:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;uid&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/bin/bash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaSamAccount&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaDomain&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaPrimaryGroupSID&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaPwdMustChange&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drive Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaHomePath&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profile type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaProfilePath&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logon script:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLogonScript&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drive:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaHomeDrive&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain Users (513)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain Guests (514)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain Admins (512)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;astSipPeer&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;astUsername&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>astSecret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ramal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;astName&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5070</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;radiusProfile&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dialup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;New Organization&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;ou&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Example Av. N 123&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{SSHA}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{SMD5}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{CRYPT}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{SHA}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{MD5}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{TEXT}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Samba Populate&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;opulate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extend lock after new logon errors:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLockoutObservationWindow&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unlock account after:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLockoutDuration&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimun password lenght:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaMinPwdLength&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First uidNumber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logon errors to lock account:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLockoutThreshold&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deny password reuse:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaPwdHistoryLength&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First gidNumber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wait before change password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaMinPwdAge&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force change password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaMaxPwdAge&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Root password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;userPassword&lt;br&gt;sambaLMPassword&lt;br&gt;sambaNTPassword&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMB Domain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaDomainName&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;net getlocalsid DOMAIN&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;0: disabled&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;-1: disabled&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;LDAP Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mailbox:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Permissions&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;User&lt;/b&gt;. Use comma as user separator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;L&lt;/b&gt;: List
&lt;br&gt;&lt;b&gt;R&lt;/b&gt;: Read&lt;br&gt;&lt;b&gt;S&lt;/b&gt;: Read status
&lt;br&gt;&lt;b&gt;W&lt;/b&gt;: Write status
&lt;br&gt;&lt;b&gt;I&lt;/b&gt;: Write message &lt;br&gt;&lt;b&gt;C&lt;/b&gt;: Create/Delete folders
&lt;br&gt;&lt;b&gt;D&lt;/b&gt;: Delete message
&lt;br&gt;&lt;b&gt;P&lt;/b&gt;: Post
&lt;br&gt;&lt;b&gt;A&lt;/b&gt;: Add/Delete Acls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Add&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Delete&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Annotation&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Annotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/expire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/lastupdate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/lastpop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/squat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Reconstruct&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Quota&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Used:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kbytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Imap Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Partition:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0 ~ 0 Mbytes ~ 0%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Used/Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imap &amp;Partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Script:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Activate&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Disable&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep and Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select folder by sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select folder by senders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard Spam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select folder if Spam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vacation if not Spam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vacation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sie&amp;ve Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Postfix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Files&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/cyrus.conf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/imapd.conf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/saslauthd.conf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/default/saslauthd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/postfix/main.cf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/postfix/master.cf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;ostmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Postfix&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sa&amp;ve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defaults values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configured options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Services&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>postfix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>slapd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cyrus2.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;ervices Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Total:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0/0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Queue Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LDAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Annotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2.2.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IMAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2.3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Servers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.1.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.1.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP Server&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Server:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Admin user:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BaseDN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ldap://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ldaps://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>389</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expand referrals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t verify SSL certificate (must restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Get</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;IMAP Server&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sieve port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>imap://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>imaps://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>143</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;SSH Server&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sudo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>22</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disabled (root login)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Servers&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cn=admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cn=manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uid=root,ou=users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Filters&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Password&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;IMAP Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Default IMAP folders&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>60</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Default Quota&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mbytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP SMB Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>netlogon.bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#UID#.bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uid counter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SID Dn:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaSID&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP SMB Populate Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaUnixIdPool&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>86400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP Schema Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Add objectClasses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Delete objectClasses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Auxiliary schema&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ou</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>domain1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ref</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaSID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S-0-0-00-0000000000-0000000000-0000000000-0000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[U          ]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2147483647</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\PDC\profiles\#UID#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S-0-0-00-0000000000-0000000000-0000000000-514</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XXX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>logon.bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\PDC-SRV\#UID#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/home/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Log&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;IMAP Server Annotation&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/motd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&amp;ut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Re&amp;construct</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This libraries can not be found:
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set &amp;Quota...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Flush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Unhold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Requeue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Show message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>For &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\server\profiles\#UID#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\server\#UID#\.profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\server\#UID#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Base: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imap delimiter: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check mailbox for deletion:

    - %1

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set quota limit (Kbytes):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm entry deletion:

    - %1

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm all messages deletion request from user &apos;%1&apos;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm message &apos;%1&apos; deletion request from user &apos;%2&apos;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    Warning: the FLUSH operation cause negative interference in QMGR 
sent messages scheduler algorithm, especially in large queues.
Use only when necessary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confim set all messages on hold?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm set all messages to delivery (unhold)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm transport requeue for all messages?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirme all messages deletion request?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t load libraries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>search results many entries, server limit anwser. Set a filter properly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>invalid syntax for search filter. Set a filter properly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>search don&apos;t have results.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>entry already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>objectClass &apos;%1&apos; require attribute &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>attribute &apos;%1&apos; is not supported by these objectClass&apos;s.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>incompatible objectClasses &apos;%1&apos; e &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>object class violation (%1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>connection refused to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>attribute &apos;%1&apos; undefined at schema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no write permission by user &apos;%1&apos; or wrong ldap authentication.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>connection dropped to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>connection timeout to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t make directory ~/.korreio (%1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t read configuration file ~/.korreio/korreio.conf (%1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration saved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set objectClass/attribute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 connected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>parent mailbox &apos;%1&apos; don&apos;t exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set mailbox.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select mailbox for deletion.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; deletion aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no write permission to parent entry &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; deletion failed. (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select mailbox to set quota.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; seted quota to &apos;%2 Kbytes&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t set quota to mailbox &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select mailbox for reconstruct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has been reconstructed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t reconstruct mailbox &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; already exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t detect IMAP-partition to &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>rename aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; renamed to &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select annotation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has annotation &apos;%2&apos; set to &apos;%3&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t set annotation &apos;%1&apos; for mailbox &apos;%2&apos; (%3).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select mailbox to set annotation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select a mailbox.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select mailbox for ACL deletion.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has ACL to &apos;%2&apos; deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t delete ACL to &apos;%1&apos; for mailbox &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select mailbox to set ACL.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has added ACL &apos;%2&apos; to user &apos;%3&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t set ACL &apos;%1&apos; to user &apos;%2&apos; for mailbox &apos;%3&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select IMAP-Partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; moved to IMAP-Partition &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t move mailbox &apos;%1&apos; to IMAP-Partition &apos;%2&apos;. (%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; has set quota to &apos;%2 Kbytes&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set quota aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set netbios domains.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set user name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>password don&apos;t match, type again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set uid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set uidNumber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set gidNumber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>domain &apos;%1&apos; is not configured.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SIDdn for domain &apos;%1&apos; is not configured.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uidNumber counter for domain &apos;%1&apos; is not configured.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set user for asterisk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set ramal for asterisk user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set port for asterisk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set user radius group.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>entry &apos;%1&apos; added.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>entry &apos;%1&apos; modified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select a entry.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select a attribute to be DN.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>entry &apos;%1&apos; deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t delete entry &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>entry &apos;%1&apos; deletion been aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>selected attribute will be Distinguish Name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>entry Distinguish Name &apos;%1&apos; changed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>the entry will be added to &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>selected entry to password change is &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>selected entry to populate is &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>passwords don&apos;t match, type again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unsupported hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set netbios domain name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set netbios domain SID.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set uid=root password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t add entry &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>invalid request. Operation can&apos;t be done.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>running remote request: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>saving file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set file name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>file &apos;%1&apos; not found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hash &apos;%1.db&apos; created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t create hash &apos;%1.db&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 disconnected. (wrong user or password)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 disconnected. (connection refused)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set sieve script name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;#USER#&apos; macro will be replaced properly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>command not found: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;%1&apos; processed message(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>deletion request was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>flush request was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hold on request was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unhold request was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>transport requeue request was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Templates:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable without password (NOPASSWD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imap delimiter: disconnected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>type a valid mailbox name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>wrong user or password to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>user is not cyrus administrator to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korreio (c) Copyleft 2008 - Reinaldo de Carvalho &lt;reinaldoc@gmail.com&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set &amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;DHCP Populate&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default lease time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;server1.example.com&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max lease time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Netbios servers:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DNS servers:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network interface:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Broadcast address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Range IP:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Netmask:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eth0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eth1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eth2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eth3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>31</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>29</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>28</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>27</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>26</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>25</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>24</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>23</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>21</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>20</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>19</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>18</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>17</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>option &apos;%1&apos; is set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t set option &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>28800</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>192.168.0.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpOption: netbios-name-servers&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>192.168.0.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpOption: domain-name-servers&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>example.com</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>192.168.0.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpNetMask&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpOption: broadcast-address&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>192.168.0.255</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gateway:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpOption: routers&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>192.168.0.10 192.168.0.100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>192.168.0.254</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpStatements: default-lease-time&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;cn of dhcpServer&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;cn of dhcpSharedNetwork&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;cn of dhcpSubnet&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpRange&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;/24&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt; 192.168.0.254&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt; 192.168.0.0&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt; 192.168.0.255&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt; 192.168.0.10 192.168.0.100&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt; 192.168.0.2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt; 192.168.0.1&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;example.com&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Samba Populate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;DHCP Populate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;New DHCP entry&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dhcpHost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dhcpSharedNetwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dhcpSubnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MAC address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;DHCP entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;host name&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;192.168.0.101&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;00:11:22:33:44:55&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Description&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpOption: domain-name&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DHCP Populate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMB Populate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.1.3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP DHCP Populate Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpService&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.1.4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpSubnet&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set server name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set shared network name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set network address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#GID#.bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change password required in logon time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set email or uid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Set password&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Attributes&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Samba&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>samba{LM-NT}Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-complete user:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distinguist Name of new user entry:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expire (days)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;New user and set Password options&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>invalid fingerprint to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*** TOTAL SIZE ***
%1 Kbytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*** DELAY REASON ***
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*** ARRIVAL TIME ***
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unsupported salt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select at least one option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcp objectClass&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;cn of dhcpHost&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpStatements: fixed-address&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpHWAddress: ethernet&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;dhcpComments&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please verify if user is not logged by POP/IMAP before you proceed.
         # grep -r johndoe /var/lib/cyrus/proc/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>can&apos;t rename &apos;%1&apos;. Set option: &quot;allowusermoves: yes&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Mailbox&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dhcpGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>invalid syntax for attribute &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailbox &apos;%1&apos; creation failed (%2).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set objectClass name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>referral dn &apos;%1&apos; don&apos;t present in this entry.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ldap://127.0.0.1/ou=example,o=Example%20Corporation??sub</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sub-folder &apos;%1&apos; listed before folder &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View: &amp;set as LDAP Base</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View: &amp;back to LDAP Base</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expand</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
