#!/usr/bin/python

from qt import *
from korreio import *

import sys
if __name__ == "__main__":
    app = QApplication(sys.argv)
    f = dKorreio()
    f.show()
    app.setMainWidget(f)
    app.exec_loop()
