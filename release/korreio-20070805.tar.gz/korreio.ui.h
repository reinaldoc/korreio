
void dKorreio::cyrus_search() {
m = self.cyrus_connect()
mailboxes = m.lm("user",self.iCyrUser.text().ascii()+"*")
m.logout()
self.lvCyrus.clear()
mailbox = []
if self.iCyrMailbox.text().ascii():
    mailbox = self.iCyrMailbox.text().ascii().split("/")
lastlen=99
tree = {}
i=True
for group in mailboxes:
    for id in mailboxes[group]:
      print group+"::"+id
      idlist = id.split("/")
      if idlist[0] == "INBOX":
        idlist[0] = self.iCyrusUser.text().ascii()
      elif idlist[0] == "user":
        idlist = idlist[1:]
      newlen = len(idlist)
      if newlen == 1:
        tree[1] = QListViewItem(self.lvCyrus)
        tree[1].setText(0,idlist[-1])
      elif newlen == 2:
        tree[2] = QListViewItem(tree[1])
        tree[2].setText(0,idlist[-1])
      else:
        tree[newlen] = QListViewItem(tree[newlen-1])
        tree[newlen].setText(0,idlist[-1])
      if len(mailbox) > newlen:
        if tree[newlen].text(0).ascii() == mailbox[newlen-1]:
          tree[newlen].setOpen(True)
}


void dKorreio::save_config() {
import os.path

try:
    os.mkdir(os.path.expanduser("~/.korreio"),0755)
except OSError, e:
    pass
try:
    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')
    f.write('cyrus.mode='+self.cbCyrusMode.currentText().ascii()+'\n')
    f.write('cyrus.host='+self.iCyrusHost.text().ascii()+'\n')
    f.write('cyrus.port='+self.iCyrusPort.text().ascii()+'\n')
    f.write('cyrus.user='+self.iCyrusUser.text().ascii()+'\n')
    f.write('cyrus.pass='+self.iCyrusPass.text().ascii()+'\n')
    f.write('ldap.mode='+self.cbLdapMode.currentText().ascii()+'\n')
    f.write('ldap.host='+self.iLdapHost.text().ascii()+'\n')
    f.write('ldap.port='+self.iLdapPort.text().ascii()+'\n')
    f.write('ldap.basedn='+self.iLdapBaseDN.text().ascii()+'\n')
    f.write('ldap.user='+self.iLdapUser.text().ascii()+'\n')
    f.write('ldap.pass='+self.iLdapPass.text().ascii()+'\n')
    f.write('ssh.host='+self.iSshHost.text().ascii()+'\n')
    f.write('ssh.port='+self.iSshPort.text().ascii()+'\n')
    f.write('ssh.user='+self.iSshUser.text().ascii()+'\n')
    f.write('ssh.pass='+self.iSshPass.text().ascii()+'\n')
    f.close()
except OSError, e:
    print "Debug::conf() Info: "+e.filename+" "+e.strerror

print "Debug::save_config() Configuration saved."


}


void dKorreio::load_config() {
import os.path
try:
    f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
    conf=f.read()
    f.close()
except IOError, e:
    print "Debug::conf() Info: "+e.filename+" "+e.strerror
    return True

confList = conf.split("\n")
confList.pop()
confDict = {}

for line in confList:
   key=line.split("=")
   confDict[key[0]] = "=".join(key[1:])

self.cbCyrusMode.setCurrentText(confDict.get("cyrus.mode"))
self.iCyrusHost.setText(confDict.get("cyrus.host"))
self.iCyrusPort.setText(confDict.get("cyrus.port"))
self.iCyrusUser.setText(confDict.get("cyrus.user"))
self.iCyrusPass.setText(confDict.get("cyrus.pass"))
self.cbLdapMode.setCurrentText(confDict.get("ldap.mode"))
self.iLdapHost.setText(confDict.get("ldap.host"))
self.iLdapPort.setText(confDict.get("ldap.port"))
self.iLdapBaseDN.setText(confDict.get("ldap.basedn"))
self.iLdapUser.setText(confDict.get("ldap.user"))
self.iLdapPass.setText(confDict.get("ldap.pass"))
self.iSshHost.setText(confDict.get("ssh.host"))
self.iSshPort.setText(confDict.get("ssh.port"))
self.iSshUser.setText(confDict.get("ssh.user"))
self.iSshPass.setText(confDict.get("ssh.pass"))

print "Debug::load_config() Configuration loaded."

}


void dKorreio::tab_changed() {
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
menu=str(self.wKorreio.tabLabel(self.wKorreio.currentPage()))
print "Debug::menu_click() Menu: "+menu
if menu == "LDAP Manager":
    self.load_config()
elif menu == "Postfix Manager":
    self.postfix_postconf()
}


void dKorreio::mailbox_clicked() {

item=self.lvCyrus.currentItem()
if item.childCount() == 0:
    self.pCyrDelete.setEnabled(True)
else:
    self.pCyrDelete.setEnabled(False)
mailbox=item.text(0).ascii()
while item.parent() is not None:
    mailbox=item.parent().text(0).ascii()+"/"+mailbox
    item=item.parent()
self.iCyrMailbox.setText(mailbox)

if len(mailbox.split("/")) == 1:
    self.gbQuota.setEnabled(True)
    self.iQuotaUsed.setEnabled(False)
else:
    self.gbQuota.setEnabled(False)

m = self.cyrus_connect()
quota = m.lq("user",self.iCyrMailbox.text().ascii())
self.iQuotaUsed.setText(str(quota[0]))
self.iQuota.setText(str(quota[1]))
self.permissions = m.lam("user",mailbox);
self.cbUserACL.clear();
for user in self.permissions:
    self.cbUserACL.insertItem(user)
self.check_permissions();
}

void dKorreio::create_mailbox() {
m = self.cyrus_connect()
m.cm("user", self.iCyrMailbox.text().ascii())
m.sam("user", self.iCyrMailbox.text().ascii(), self.iCyrusUser.text().ascii(), " ")
m.logout()
self.cyrus_search()
}


void dKorreio::delete_mailbox() {
m = self.cyrus_connect()
m.sam("user", self.iCyrMailbox.text().ascii(), self.iCyrusUser.text().ascii(), "c")
m.dm("user", self.iCyrMailbox.text().ascii())
m.logout()
self.cyrus_search()
}


void dKorreio::set_quota() {
m = self.cyrus_connect()
m.sq("user",self.iCyrMailbox.text().ascii(),self.iQuota.text().ascii())
m.logout()
}

void dKorreio::check_permissions() {
mailbox_perm = self.permissions[self.cbUserACL.currentText().ascii()]
import re
if re.search("l",mailbox_perm): self.cCyrPermL.setChecked(True)
else: self.cCyrPermL.setChecked(False)
if re.search("r",mailbox_perm): self.cCyrPermR.setChecked(True)
else: self.cCyrPermR.setChecked(False)
if re.search("s",mailbox_perm): self.cCyrPermS.setChecked(True)
else: self.cCyrPermS.setChecked(False)
if re.search("w",mailbox_perm): self.cCyrPermW.setChecked(True)
else: self.cCyrPermW.setChecked(False)
if re.search("i",mailbox_perm): self.cCyrPermI.setChecked(True)
else: self.cCyrPermI.setChecked(False)
if re.search("p",mailbox_perm): self.cCyrPermP.setChecked(True)
else: self.cCyrPermP.setChecked(False)
if re.search("c",mailbox_perm): self.cCyrPermC.setChecked(True)
else: self.cCyrPermC.setChecked(False)
if re.search("d",mailbox_perm): self.cCyrPermD.setChecked(True)
else: self.cCyrPermD.setChecked(False)
if re.search("a",mailbox_perm): self.cCyrPermA.setChecked(True)
else: self.cCyrPermA.setChecked(False)
}


void dKorreio::set_cyracl() {
perm=""
if self.cCyrPermL.isChecked():
    perm="l"
if self.cCyrPermR.isChecked():
    perm=perm+"r"
if self.cCyrPermS.isChecked():
    perm=perm+"s"
if self.cCyrPermW.isChecked():
    perm=perm+"w"
if self.cCyrPermI.isChecked():
    perm=perm+"i"
if self.cCyrPermP.isChecked():
    perm=perm+"p"
if self.cCyrPermC.isChecked():
    perm=perm+"c"
if self.cCyrPermD.isChecked():
    perm=perm+"d"
if self.cCyrPermA.isChecked():
    perm=perm+"a"

import cyruslib
if self.cbCyrusMode.currentText().ascii() == "imaps://":
    cyrmode = 1
else:
    cyrmode = 0
m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),cyrmode)
m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
m.sam("user",self.iCyrMailbox.text().ascii(),self.cbUserACL.currentText().ascii(),perm)
}


void dKorreio::reconstruct_mailbox() {
import cyruslib
if self.cbCyrusMode.currentText().ascii() == "imaps://":
    cyrmode = 1
else:
    cyrmode = 0
m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),cyrmode)
m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
m.reconstruct("user",self.iCyrMailbox.text().ascii())

}


void dKorreio::get_ldap_basedn() {
import ldap
try:
    l = ldap.open(self.iLdapHost.text().ascii(),int(self.iLdapPort.text().ascii()))
    l.protocol_version = ldap.VERSION3
    if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
        l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
    else:
        l.simple_bind()
    searchScope = ldap.SCOPE_BASE
    searchFilter = "objectclass=*"
    retrieveAttributes = None
    ldap_result_id = l.search("", searchScope, searchFilter, retrieveAttributes)
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        print result_type
        print result_data
        if (result_data == []):
            break
        else:
            if result_type == ldap.RES_SEARCH_ENTRY:
                for j in result_data:
                     pass
                     #self.iLdapBaseDN.setText(j[1]["dn"][0])
                     #print j[1]["dn"][0]
                     #break
except ldap.LDAPError, e:
    print e

}


void dKorreio::set_imap_port() {
if self.cbCyrusMode.currentText().ascii() == "imap://":
    self.iCyrusPort.setText("143")
else:
    self.iCyrusPort.setText("993")
}


void dKorreio::cyrus_connect() {
import cyruslib
if self.cbCyrusMode.currentText().ascii() == "imaps://":
    cyrmode = 1
else:
    cyrmode = 0
m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),cyrmode)
m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
return m
}


void dKorreio::ldap_search() {
    import re
    self.lvLdap.clear()
    self.cbLdapOu.clear()
    self.cbLdapOu.insertItem("----")
    basedn = QListViewItem(self.lvLdap)
    basedn.setText(0,self.iLdapBaseDN.text().ascii())
    basedn.setOpen(True)
    self.ldap_attr = self.ldap_result("(|(objectClass=inetOrgPerson)(objectClass=organizationalUnit))")
    itemdict = {}
    for dn in self.ldap_attr:
        if re.search("^ou=",dn):
            dn = re.sub(","+self.iLdapBaseDN.text().ascii(),"",dn)
            self.cbLdapOu.insertItem(dn)
            dnlist = dn.split(",")
            if len(dnlist) == 1:
                item = QListViewItem(basedn)
                itemdict[dn] = item
            else:
                item = QListViewItem(itemdict[dnlist[-1]])
                itemdict[",".join(dnlist[1:])] = item
            item.setText(0,dn)

    for dn in self.ldap_attr:
        if re.search("^cn=",dn):
            dn = re.sub(","+self.iLdapBaseDN.text().ascii(),"",dn)
            dnlist = dn.split(",")
            if len(dnlist) == 1:
               item = QListViewItem(basedn)
            else:
               item = QListViewItem(itemdict.get(",".join(dnlist[1:])))
               dn=dnlist[0]
            item.setText(0,dn)
}

void dKorreio::ldap_connect() {
try:
    import ldap
    l = ldap.open(self.iLdapHost.text().ascii(),int(self.iLdapPort.text().ascii()))
    l.protocol_version = ldap.VERSION3
    l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
    return l
except ldap.LDAPError, e:
    print e
}

void dKorreio::ldap_result(a0) {
import ldap
try:
    l = self.ldap_connect()
    searchScope = ldap.SCOPE_SUBTREE
    searchFilter = a0
    retrieveAttributes = None
    ldap_result_id = l.search(self.iLdapBaseDN.text().ascii(), searchScope, searchFilter, retrieveAttributes)
    ldap_result = {}
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if (result_data == []):
            break
        elif result_type == ldap.RES_SEARCH_ENTRY:
            ldap_result[result_data[0][0]] = result_data[0][1]
    return ldap_result
except ldap.LDAPError, e:
    print e
}


void dKorreio::ldap_dn_clicked() {
self.lvLdapAttr.clear()
item = self.lvLdap.currentItem()
if item.parent() is not None:
    dn = item.text(0).ascii()
    while item.parent() is not None:
        dn = dn+","+item.parent().text(0).ascii()
        item = item.parent()
    for attribute,values in self.ldap_attr.get(dn).items():
        for value in values:
           item = QListViewItem(self.lvLdapAttr)
           item.setText(0,attribute)
           item.setText(1,value)
}


void dKorreio::ldap_insert_user() {
import md5
import base64
if self.cbLdapOu.currentText().ascii() != "----":
    dn="cn="+self.iLdapCn.text().ascii()+","+self.cbLdapOu.currentText().ascii()+","+self.iLdapBaseDN.text().ascii()
else:
    dn="cn="+self.iLdapCn.text().ascii()+","+self.iLdapBaseDN.text().ascii()
attrs = {}
attrs['objectclass'] = ['inetOrgPerson']
attrs['cn'] = self.iLdapCn.text().ascii()
attrs['sn'] = self.iLdapCn.text().ascii().split(" ")[-1]
attrs['mail'] = self.iLdapMail.text().ascii()
m = md5.new(self.iLdapUserP.text().ascii())
attrs['userPassword'] = '{md5}'+base64.encodestring(m.digest())
self.ldap_add(dn,attrs)
self.ldap_search()
}


void dKorreio::ldap_add(a0,a1) {
#a0 = DN, a1 = attrs
import ldap
import ldap.modlist as modlist
try:
    ldif = modlist.addModlist(a1)
    l = self.ldap_connect()
    l.add_s(a0,ldif)
    l.unbind_s()
except ldap.LDAPError, e:
    print e
}


void dKorreio::ldap_insert_ou() {
dn="ou="+self.iLdapOu.text().ascii()+","+self.iLdapBaseDN.text().ascii()
attrs = {}
attrs['objectclass'] = ['organizationalUnit']
attrs['ou'] = self.iLdapOu.text().ascii()
self.ldap_add(dn,attrs)
self.ldap_search()
}


void dKorreio::ldap_remove() {
item = self.lvLdap.currentItem()
if item.parent() is not None:
    dn = item.text(0).ascii()
    while item.parent() is not None:
        dn = dn+","+item.parent().text(0).ascii()
        item = item.parent()
    self.ldap_del(dn)
    self.ldap_search()
    self.lvLdapAttr.clear()
}


void dKorreio::ldap_del(a0) {
l = self.ldap_connect()
l.delete_s(a0)
}


void dKorreio::postfix_postconf() {
import re
cmd = self.ssh_cmd("postconf")
self.postconf = {}
self.cbPostconf.clear()
for config in cmd:
    if re.search("=",config):
        configlist = config.strip().split("=")
        configlist[0]=configlist[0].strip(" ")
        self.postconf[configlist[0]] = configlist[1]
        self.cbPostconf.insertItem(configlist[0])
}


void dKorreio::ssh_cmd(a0) {
import pexpect
import re
try:
    child = pexpect.spawn('ssh -p'+self.iSshPort.text().ascii()+' '+self.iSshUser.text().ascii()+"@"+self.iSshHost.text().ascii()+' '+a0)
    i = child.expect(['assword','want to continue connecting'], timeout=5)
    if i==0:
        print "Sending password"
        child.sendline(self.iSshPass.text().ascii())
    elif i==1:
        print "Accepting fingerprint"
        child.sendline('yes')
        child.expect('assword', timeout=2)
        print "Sending password"
        child.sendline(self.iSshPass.text().ascii())
    print_cmd=[]
    for line in child:
        print_cmd.append(line)
    child.kill(0)
except pexpect.EOF, t:
    print "Cant connect to: "+self.iSshHost.text().ascii()
except pexpect.TIMEOUT, t:
    print "Timeout connection to: "+self.iSshHost.text().ascii()
return print_cmd
}


void dKorreio::postconf_changed() {
self.tePostconf.setText(self.postconf.get(self.cbPostconf.currentText().ascii()))
}
