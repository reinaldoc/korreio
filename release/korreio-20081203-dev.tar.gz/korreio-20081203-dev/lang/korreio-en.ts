<!DOCTYPE TS><TS>
<context>
    <name>dKorreio</name>
    <message>
        <source>Distinguished Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IMAP Mailbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IMAP Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-expire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ACL anyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korreio - Mail Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korreio (c) Copyleft 2008 - Reinaldo de Carvalho &lt;reinaldoc@gmail.com&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>objectClass=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ou=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cn=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uid=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mail=*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ldap Browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Define Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Samba Populate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>objectClass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>structuralObjectClass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gecos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>homeDirectory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>loginShell</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uidNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gidNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>userPassword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowLastChange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowMin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowMax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowWarning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowInactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowExpire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowFlag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>carLicense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>displayName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>homePhone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>street</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>postalCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLMPassword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaNTPassword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPwdLastSet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLogonTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLogoffTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaKickoffTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPwdCanChange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPwdMustChange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaAcctFlags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaHomePath</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaHomeDrive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLogonScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaProfilePath</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaUserWorkstations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPrimaryGroupSID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaDomainName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaMungedDial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaBadPasswordCount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaBadPasswordTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaPasswordHistory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLogonHours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mailAlternateAddress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ipHostNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>owner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>serialNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>member</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>inetOrgPerson</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>posixAccount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaSamAccount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadowAccount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>simpleSecurityObject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>organizationalUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>organizationalRole</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>groupOfNames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ipHost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ipNetwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>referral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>extensibleObject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;New User&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;inetOrgPerson&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;cn&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Full name&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mail:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;mail&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;user@example.com&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;l&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;street&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Av. Example, N 123&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;District, City, State&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Postal code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;postalCode&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;000000&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;homePhone&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;+1 (55) 5555-5555&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;userPassword&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password (again):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;posixAccount&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uid number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;uidNumber&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gid number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;gidNumber&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;homeDirectory&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shell:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;loginShell&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User id:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;uid&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/bin/bash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaSamAccount&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaDomain&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaPrimaryGroupSID&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force user change password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaPwdMustChange&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drive Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaHomePath&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profile type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaProfilePath&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logon script:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLogonScript&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drive:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaHomeDrive&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain Users (513)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain Guests (514)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain Admins (512)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;astSipPeer&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;astUsername&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>astSecret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ramal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;astName&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5070</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;radiusProfile&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dialup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;New Organization&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;ou&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Example Av. N 123&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Define password&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attribute:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaLMPassword/sambaNTPassword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{SSHA}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{SMD5}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{CRYPT}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{SHA}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{MD5}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>{TEXT}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Samba Populate&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;opulate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extend lock after new logon errors:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLockoutObservationWindow&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unlock account after:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLockoutDuration&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimun password lenght:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaMinPwdLength&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First uidNumber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logon errors to lock account:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaLockoutThreshold&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deny password reuse:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaPwdHistoryLength&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First gidNumber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wait before change password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaMinPwdAge&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force change password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaMaxPwdAge&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Root password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;userPassword&lt;br&gt;sambaLMPassword&lt;br&gt;sambaNTPassword&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMB Domain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaDomainName&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;net getlocalsid DOMAIN&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;0: disabled&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;-1: disabled&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;LDAP Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mailbox:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Permissions&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;User&lt;/b&gt;. Use comma as user separator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;L&lt;/b&gt;: List
&lt;br&gt;&lt;b&gt;R&lt;/b&gt;: Read&lt;br&gt;&lt;b&gt;S&lt;/b&gt;: Read status
&lt;br&gt;&lt;b&gt;W&lt;/b&gt;: Write status
&lt;br&gt;&lt;b&gt;I&lt;/b&gt;: Write message &lt;br&gt;&lt;b&gt;C&lt;/b&gt;: Create/Delete folders
&lt;br&gt;&lt;b&gt;D&lt;/b&gt;: Delete message
&lt;br&gt;&lt;b&gt;P&lt;/b&gt;: Post
&lt;br&gt;&lt;b&gt;A&lt;/b&gt;: Add/Delete Acls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Add&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Delete&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Annotation&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Annotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/expire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/lastupdate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/lastpop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/squat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Reconstruct&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Quota&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Used:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kbytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Imap Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Partition:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0 ~ 0 Mbytes ~ 0%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Used/Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imap &amp;Partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Script:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Activate&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Disable&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep and Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select folder by sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select folder by senders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard Spam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select folder if Spam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vacation if not Spam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vacation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Modelos:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sie&amp;ve Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Postfix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Files&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/cyrus.conf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/imapd.conf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/saslauthd.conf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/default/saslauthd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/postfix/main.cf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/etc/postfix/master.cf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;ostmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Postfix&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sa&amp;ve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defaults values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configured options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Services&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>postfix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>slapd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cyrus2.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;ervices Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Total:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0/0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Queue Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LDAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Annotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2.2.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IMAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2.3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Servers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Populate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.1.1.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.1.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.1.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP Server&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Server:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Admin user:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BaseDN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ldap://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ldaps://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>389</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expand referrals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t verify SSL certificate (must restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Get</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;IMAP Server&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sieve port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>imap://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>imaps://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>143</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;SSH Server&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sudo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>22</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disabled (root login)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable withoutpassword (NOPASSWD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Servers&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Base:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imap delimiter: desconectado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-complete admin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cn=admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cn=manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uid=root,ou=users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Filters&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Password&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force change password at next logon (samba{LM-NT}Password)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;IMAP Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Default IMAP folders&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>60</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expire:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acl post:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Default Quota&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mbytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP SMB Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Domain:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\servername\profiles\#UID#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\servername\#UID#\.profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Perfil:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain Admins(512)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\servername\#UID#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>netlogon.bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#UID#.bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uid counter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SID Dn:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaSID&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP SMB Populate Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extend lock after new logons errors:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;sambaUnixIdPool&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>86400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;LDAP Schema Preferences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Add objectClasses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Delete objectClasses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Auxiliary schema&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ou</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>domain1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ref</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ldap://127.0.0.1/ou=example,o=Example%20Corporation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sambaSID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S-0-0-00-0000000000-0000000000-0000000000-0000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[U          ]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2147483647</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\PDC\profiles\#UID#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S-0-0-00-0000000000-0000000000-0000000000-514</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XXX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>logon.bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>\\PDC-SRV\#UID#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/home/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Log&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;IMAP Server Annotation&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/motd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/vendor/cmu/cyrus-imapd/shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&amp;ut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Set Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;amba populate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set as &amp;Base</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Back to Base</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Re&amp;construct</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Ok:&lt;/b&gt; server %1/%2 conected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Ok:&lt;/b&gt; Configuration saved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Ok:&lt;/b&gt; entry %1 added.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can not load libraries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This libraries can not be found:
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set &amp;Quota...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Flush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Unhold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Requeue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Show message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>For &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; entry already exists.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
