
class QTextEditSieveScript(QTextEdit):
    def __init__(self, parent, name):
        apply(QTextEdit.__init__, (self, parent, name))

    def createPopupMenu(self, *args):
        self.lvSieveScriptMenu = QPopupMenu(self)
        self.lvSieveScriptMenu.setCaption("Sieve Helper")
        self.lvSieveScriptMenu.insertItem(self.__tr('&Require...'), 20)
        self.lvSieveScriptMenu.insertItem(self.__tr('&Clausule...'), 21)
        self.lvSieveScriptMenu.insertItem(self.__tr('&Action...'), 22)
        self.connect(self.lvSieveScriptMenu, SIGNAL('activated(int)'), self.sieve_menu_clicked)
        return self.lvSieveScriptMenu

    def sieve_menu_clicked(self, menuItem):
        self.insert("xxxx", True, True)
        print menuItem
        return True

    def setConfig(self, config):
        self.config = config

    def __tr(self,s,c = None):
        return qApp.translate("dKorreio",s,c)
