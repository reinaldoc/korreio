# -*- coding: utf-8 -*-
# Korreio v0.1-20080517
# Copyright (c) 2007-2008 -  Reinaldo de Carvalho <reinaldoc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.


from qt import *


class dKorreio(QMainWindow):
    def __init__(self,parent = None,name = None,fl = 0):
        QMainWindow.__init__(self,parent,name,fl)
        self.statusBar()

        if not name:
            self.setName("dKorreio")


        self.setCentralWidget(QWidget(self,"qt_central_widget"))
        dKorreioLayout = QGridLayout(self.centralWidget(),1,1,8,6,"dKorreioLayout")

        self.tlConsole = QLabel(self.centralWidget(),"tlConsole")
        self.tlConsole.setMinimumSize(QSize(0,24))
        self.tlConsole.setMaximumSize(QSize(32767,24))
        self.tlConsole.setFrameShape(QLabel.StyledPanel)
        self.tlConsole.setFrameShadow(QLabel.Sunken)

        dKorreioLayout.addWidget(self.tlConsole,1,0)

        self.wKorreio = QTabWidget(self.centralWidget(),"wKorreio")

        self.tabLdap = QWidget(self.wKorreio,"tabLdap")
        tabLdapLayout = QGridLayout(self.tabLdap,1,1,8,6,"tabLdapLayout")

        self.splitter6 = QSplitter(self.tabLdap,"splitter6")
        self.splitter6.setOrientation(QSplitter.Horizontal)

        LayoutWidget = QWidget(self.splitter6,"layout7")
        layout7 = QVBoxLayout(LayoutWidget,0,6,"layout7")

        self.cbLdapFilter = QComboBox(0,LayoutWidget,"cbLdapFilter")
        self.cbLdapFilter.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed,0,0,self.cbLdapFilter.sizePolicy().hasHeightForWidth()))
        self.cbLdapFilter.setMinimumSize(QSize(280,0))
        self.cbLdapFilter.setAcceptDrops(1)
        self.cbLdapFilter.setEditable(1)
        self.cbLdapFilter.setAutoCompletion(1)
        self.cbLdapFilter.setDuplicatesEnabled(0)
        layout7.addWidget(self.cbLdapFilter)

        self.lvLdap = QListView(LayoutWidget,"lvLdap")
        self.lvLdap.addColumn(self.__tr("Distinguished Name"))
        self.lvLdap.setRootIsDecorated(1)
        self.lvLdap.setResizeMode(QListView.AllColumns)
        layout7.addWidget(self.lvLdap)

        self.pLdapDelete = QPushButton(LayoutWidget,"pLdapDelete")
        self.pLdapDelete.setEnabled(0)
        self.pLdapDelete.setMinimumSize(QSize(120,0))
        self.pLdapDelete.setMaximumSize(QSize(120,26))
        layout7.addWidget(self.pLdapDelete)

        LayoutWidget_2 = QWidget(self.splitter6,"layout521")
        layout521 = QVBoxLayout(LayoutWidget_2,0,6,"layout521")

        layout9 = QHBoxLayout(None,0,6,"layout9")

        self.pLdapSearch = QPushButton(LayoutWidget_2,"pLdapSearch")
        self.pLdapSearch.setMaximumSize(QSize(32767,26))
        layout9.addWidget(self.pLdapSearch)
        spacer26_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout9.addItem(spacer26_2)

        self.cbLdapStack = QComboBox(0,LayoutWidget_2,"cbLdapStack")
        layout9.addWidget(self.cbLdapStack)
        layout521.addLayout(layout9)

        self.wsLdap = QWidgetStack(LayoutWidget_2,"wsLdap")
        self.wsLdap.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Minimum,0,0,self.wsLdap.sizePolicy().hasHeightForWidth()))
        self.wsLdap.setMargin(-8)

        self.WStackPage = QWidget(self.wsLdap,"WStackPage")
        WStackPageLayout = QGridLayout(self.WStackPage,1,1,8,6,"WStackPageLayout")

        self.lvLdapAttr = QListView(self.WStackPage,"lvLdapAttr")
        self.lvLdapAttr.addColumn(self.__tr("Atributo"))
        self.lvLdapAttr.addColumn(self.__tr("Valor"))
        self.lvLdapAttr.setLineWidth(2)
        self.lvLdapAttr.setAllColumnsShowFocus(1)
        self.lvLdapAttr.setShowSortIndicator(1)
        self.lvLdapAttr.setResizeMode(QListView.LastColumn)
        self.lvLdapAttr.setDefaultRenameAction(QListView.Accept)

        WStackPageLayout.addMultiCellWidget(self.lvLdapAttr,0,0,0,5)
        spacer2 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout.addItem(spacer2,1,4)

        self.cbLdapAttr = QComboBox(0,self.WStackPage,"cbLdapAttr")
        self.cbLdapAttr.setEditable(1)
        self.cbLdapAttr.setAutoCompletion(1)

        WStackPageLayout.addWidget(self.cbLdapAttr,1,0)

        self.cbLdapValue = QComboBox(0,self.WStackPage,"cbLdapValue")
        self.cbLdapValue.setEditable(1)
        self.cbLdapValue.setAutoCompletion(1)

        WStackPageLayout.addWidget(self.cbLdapValue,1,1)

        self.pLdapAddAttr = QPushButton(self.WStackPage,"pLdapAddAttr")
        self.pLdapAddAttr.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pLdapAddAttr.sizePolicy().hasHeightForWidth()))
        self.pLdapAddAttr.setMaximumSize(QSize(30,32767))

        WStackPageLayout.addWidget(self.pLdapAddAttr,1,2)

        self.pLdapDeleteAttr = QPushButton(self.WStackPage,"pLdapDeleteAttr")
        self.pLdapDeleteAttr.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pLdapDeleteAttr.sizePolicy().hasHeightForWidth()))
        self.pLdapDeleteAttr.setMaximumSize(QSize(30,32767))

        WStackPageLayout.addWidget(self.pLdapDeleteAttr,1,3)

        self.pLdapModify = QPushButton(self.WStackPage,"pLdapModify")

        WStackPageLayout.addWidget(self.pLdapModify,1,5)
        self.wsLdap.addWidget(self.WStackPage,0)

        self.WStackPage_2 = QWidget(self.wsLdap,"WStackPage_2")
        self.wsLdap.addWidget(self.WStackPage_2,1)

        self.WStackPage_3 = QWidget(self.wsLdap,"WStackPage_3")
        WStackPageLayout_2 = QGridLayout(self.WStackPage_3,1,1,8,6,"WStackPageLayout_2")

        layout51 = QGridLayout(None,1,1,0,0,"layout51")

        self.line22 = QFrame(self.WStackPage_3,"line22")
        self.line22.setFrameShape(QFrame.HLine)
        self.line22.setFrameShadow(QFrame.Sunken)
        self.line22.setFrameShape(QFrame.HLine)

        layout51.addMultiCellWidget(self.line22,1,1,0,1)

        self.textLabel1_2 = QLabel(self.WStackPage_3,"textLabel1_2")
        self.textLabel1_2.setMinimumSize(QSize(250,0))
        self.textLabel1_2.setMaximumSize(QSize(32767,26))

        layout51.addWidget(self.textLabel1_2,0,0)
        spacer148 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51.addItem(spacer148,0,1)

        WStackPageLayout_2.addMultiCellLayout(layout51,0,0,0,1)
        spacer348 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_2.addItem(spacer348,2,0)

        self.line24 = QFrame(self.WStackPage_3,"line24")
        self.line24.setFrameShape(QFrame.HLine)
        self.line24.setFrameShadow(QFrame.Sunken)
        self.line24.setFrameShape(QFrame.HLine)

        WStackPageLayout_2.addMultiCellWidget(self.line24,3,3,0,1)
        spacer75 = QSpacerItem(250,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_2.addItem(spacer75,1,1)

        layout173 = QHBoxLayout(None,0,6,"layout173")

        self.pLdapFormBack = QPushButton(self.WStackPage_3,"pLdapFormBack")
        self.pLdapFormBack.setMinimumSize(QSize(100,0))
        self.pLdapFormBack.setMaximumSize(QSize(110,26))
        layout173.addWidget(self.pLdapFormBack)

        self.pLdapFormNext = QPushButton(self.WStackPage_3,"pLdapFormNext")
        self.pLdapFormNext.setMinimumSize(QSize(100,0))
        self.pLdapFormNext.setMaximumSize(QSize(110,26))
        layout173.addWidget(self.pLdapFormNext)
        spacer76 = QSpacerItem(190,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout173.addItem(spacer76)

        self.pLdapAddUser = QPushButton(self.WStackPage_3,"pLdapAddUser")
        self.pLdapAddUser.setMaximumSize(QSize(110,26))
        layout173.addWidget(self.pLdapAddUser)

        WStackPageLayout_2.addMultiCellLayout(layout173,4,4,0,1)

        self.wsLdapForm = QWidgetStack(self.WStackPage_3,"wsLdapForm")

        self.WStackPage_4 = QWidget(self.wsLdapForm,"WStackPage_4")
        WStackPageLayout_3 = QGridLayout(self.WStackPage_4,1,1,8,6,"WStackPageLayout_3")

        layout46_2 = QVBoxLayout(None,0,0,"layout46_2")

        self.textLabel1_2_3 = QLabel(self.WStackPage_4,"textLabel1_2_3")
        layout46_2.addWidget(self.textLabel1_2_3)

        self.line22_2 = QFrame(self.WStackPage_4,"line22_2")
        self.line22_2.setFrameShape(QFrame.HLine)
        self.line22_2.setFrameShadow(QFrame.Sunken)
        self.line22_2.setFrameShape(QFrame.HLine)
        layout46_2.addWidget(self.line22_2)

        WStackPageLayout_3.addLayout(layout46_2,0,0)
        spacer146 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_3.addItem(spacer146,2,0)

        self.frame23 = QFrame(self.WStackPage_4,"frame23")
        self.frame23.setFrameShape(QFrame.NoFrame)
        self.frame23.setFrameShadow(QFrame.Raised)
        frame23Layout = QGridLayout(self.frame23,1,1,8,6,"frame23Layout")

        self.textLabel3_2 = QLabel(self.frame23,"textLabel3_2")
        self.textLabel3_2.setMinimumSize(QSize(120,0))

        frame23Layout.addWidget(self.textLabel3_2,0,0)

        self.iLdapFormCn = QLineEdit(self.frame23,"iLdapFormCn")
        self.iLdapFormCn.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormCn,0,1)

        self.textLabel5 = QLabel(self.frame23,"textLabel5")

        frame23Layout.addWidget(self.textLabel5,1,0)

        self.iLdapFormMail = QLineEdit(self.frame23,"iLdapFormMail")
        self.iLdapFormMail.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormMail,1,1)

        self.textLabel5_3 = QLabel(self.frame23,"textLabel5_3")

        frame23Layout.addWidget(self.textLabel5_3,3,0)

        self.textLabel3_2_3 = QLabel(self.frame23,"textLabel3_2_3")

        frame23Layout.addWidget(self.textLabel3_2_3,2,0)

        self.iLdapFormStreet = QLineEdit(self.frame23,"iLdapFormStreet")
        self.iLdapFormStreet.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormStreet,2,1)

        self.iLdapFormL = QLineEdit(self.frame23,"iLdapFormL")
        self.iLdapFormL.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormL,3,1)

        self.textLabel3_2_4 = QLabel(self.frame23,"textLabel3_2_4")

        frame23Layout.addWidget(self.textLabel3_2_4,4,0)

        self.iLdapFormPostalCode = QLineEdit(self.frame23,"iLdapFormPostalCode")
        self.iLdapFormPostalCode.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormPostalCode,4,1)

        self.textLabel5_4 = QLabel(self.frame23,"textLabel5_4")

        frame23Layout.addWidget(self.textLabel5_4,5,0)

        self.iLdapFormHomePhone = QLineEdit(self.frame23,"iLdapFormHomePhone")
        self.iLdapFormHomePhone.setMinimumSize(QSize(270,0))

        frame23Layout.addWidget(self.iLdapFormHomePhone,5,1)
        spacer28 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame23Layout.addItem(spacer28,0,2)

        self.iLdapFormUserP = QLineEdit(self.frame23,"iLdapFormUserP")
        self.iLdapFormUserP.setMinimumSize(QSize(270,0))
        self.iLdapFormUserP.setEchoMode(QLineEdit.Password)

        frame23Layout.addWidget(self.iLdapFormUserP,6,1)

        self.iLdapFormUserP2 = QLineEdit(self.frame23,"iLdapFormUserP2")
        self.iLdapFormUserP2.setMinimumSize(QSize(270,0))
        self.iLdapFormUserP2.setEchoMode(QLineEdit.Password)

        frame23Layout.addWidget(self.iLdapFormUserP2,7,1)

        self.textLabel1_3 = QLabel(self.frame23,"textLabel1_3")

        frame23Layout.addWidget(self.textLabel1_3,6,0)

        self.textLabel1_3_4 = QLabel(self.frame23,"textLabel1_3_4")

        frame23Layout.addWidget(self.textLabel1_3_4,7,0)

        WStackPageLayout_3.addWidget(self.frame23,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_4,0)

        self.WStackPage_5 = QWidget(self.wsLdapForm,"WStackPage_5")
        WStackPageLayout_4 = QGridLayout(self.WStackPage_5,1,1,8,6,"WStackPageLayout_4")

        layout53 = QGridLayout(None,1,1,0,0,"layout53")

        self.textLabel1_2_3_2 = QLabel(self.WStackPage_5,"textLabel1_2_3_2")

        layout53.addWidget(self.textLabel1_2_3_2,0,0)
        spacer156 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout53.addItem(spacer156,0,2)

        self.line22_2_2 = QFrame(self.WStackPage_5,"line22_2_2")
        self.line22_2_2.setFrameShape(QFrame.HLine)
        self.line22_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_2_2.setFrameShape(QFrame.HLine)

        layout53.addMultiCellWidget(self.line22_2_2,1,1,0,2)

        self.cLdapFormPosix = QCheckBox(self.WStackPage_5,"cLdapFormPosix")

        layout53.addWidget(self.cLdapFormPosix,0,1)

        WStackPageLayout_4.addLayout(layout53,0,0)

        self.fLdapFormPosix = QFrame(self.WStackPage_5,"fLdapFormPosix")
        self.fLdapFormPosix.setEnabled(0)
        self.fLdapFormPosix.setFrameShape(QFrame.NoFrame)
        self.fLdapFormPosix.setFrameShadow(QFrame.Raised)
        fLdapFormPosixLayout = QGridLayout(self.fLdapFormPosix,1,1,8,6,"fLdapFormPosixLayout")

        self.textLabel5_2_2 = QLabel(self.fLdapFormPosix,"textLabel5_2_2")

        fLdapFormPosixLayout.addWidget(self.textLabel5_2_2,1,0)

        self.textLabel1_3_3_2 = QLabel(self.fLdapFormPosix,"textLabel1_3_3_2")

        fLdapFormPosixLayout.addWidget(self.textLabel1_3_3_2,2,0)

        self.textLabel1_3_3 = QLabel(self.fLdapFormPosix,"textLabel1_3_3")
        self.textLabel1_3_3.setMinimumSize(QSize(0,0))

        fLdapFormPosixLayout.addWidget(self.textLabel1_3_3,4,0)

        self.textLabel5_2 = QLabel(self.fLdapFormPosix,"textLabel5_2")

        fLdapFormPosixLayout.addWidget(self.textLabel5_2,3,0)

        self.iLdapFormGidNumber = QLineEdit(self.fLdapFormPosix,"iLdapFormGidNumber")
        self.iLdapFormGidNumber.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormGidNumber,2,1)

        self.textLabel3_2_2 = QLabel(self.fLdapFormPosix,"textLabel3_2_2")
        self.textLabel3_2_2.setMinimumSize(QSize(120,0))

        fLdapFormPosixLayout.addWidget(self.textLabel3_2_2,0,0)

        self.iLdapFormLoginShell = QLineEdit(self.fLdapFormPosix,"iLdapFormLoginShell")
        self.iLdapFormLoginShell.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormLoginShell,3,1)

        self.iLdapFormHomeDirectory = QLineEdit(self.fLdapFormPosix,"iLdapFormHomeDirectory")
        self.iLdapFormHomeDirectory.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormHomeDirectory,4,1)
        spacer28_3 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormPosixLayout.addMultiCell(spacer28_3,4,4,2,3)

        self.iLdapFormUid = QLineEdit(self.fLdapFormPosix,"iLdapFormUid")
        self.iLdapFormUid.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormUid,0,1)

        self.iLdapFormUidNumber = QLineEdit(self.fLdapFormPosix,"iLdapFormUidNumber")
        self.iLdapFormUidNumber.setMinimumSize(QSize(270,0))

        fLdapFormPosixLayout.addWidget(self.iLdapFormUidNumber,1,1)

        self.pLdapGetUidNumber = QPushButton(self.fLdapFormPosix,"pLdapGetUidNumber")
        self.pLdapGetUidNumber.setMaximumSize(QSize(32767,25))

        fLdapFormPosixLayout.addWidget(self.pLdapGetUidNumber,1,2)
        spacer90 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormPosixLayout.addItem(spacer90,1,3)

        WStackPageLayout_4.addWidget(self.fLdapFormPosix,1,0)
        spacer146_2 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_4.addItem(spacer146_2,2,0)
        self.wsLdapForm.addWidget(self.WStackPage_5,1)

        self.WStackPage_6 = QWidget(self.wsLdapForm,"WStackPage_6")
        WStackPageLayout_5 = QGridLayout(self.WStackPage_6,1,1,8,6,"WStackPageLayout_5")

        layout53_2 = QGridLayout(None,1,1,0,0,"layout53_2")

        self.textLabel1_2_3_2_2 = QLabel(self.WStackPage_6,"textLabel1_2_3_2_2")

        layout53_2.addWidget(self.textLabel1_2_3_2_2,0,0)
        spacer156_2 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout53_2.addItem(spacer156_2,0,2)

        self.line22_2_2_2 = QFrame(self.WStackPage_6,"line22_2_2_2")
        self.line22_2_2_2.setFrameShape(QFrame.HLine)
        self.line22_2_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_2_2_2.setFrameShape(QFrame.HLine)

        layout53_2.addMultiCellWidget(self.line22_2_2_2,1,1,0,2)

        self.cLdapFormSamba = QCheckBox(self.WStackPage_6,"cLdapFormSamba")

        layout53_2.addWidget(self.cLdapFormSamba,0,1)

        WStackPageLayout_5.addLayout(layout53_2,0,0)
        spacer152 = QSpacerItem(20,16,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_5.addItem(spacer152,2,0)

        self.fLdapFormSamba = QFrame(self.WStackPage_6,"fLdapFormSamba")
        self.fLdapFormSamba.setEnabled(0)
        self.fLdapFormSamba.setFrameShape(QFrame.NoFrame)
        self.fLdapFormSamba.setFrameShadow(QFrame.Raised)
        fLdapFormSambaLayout = QGridLayout(self.fLdapFormSamba,1,1,8,6,"fLdapFormSambaLayout")

        self.textLabel3_2_2_2 = QLabel(self.fLdapFormSamba,"textLabel3_2_2_2")
        self.textLabel3_2_2_2.setMinimumSize(QSize(120,0))

        fLdapFormSambaLayout.addWidget(self.textLabel3_2_2_2,0,0)

        self.textLabel1_3_3_2_2 = QLabel(self.fLdapFormSamba,"textLabel1_3_3_2_2")

        fLdapFormSambaLayout.addWidget(self.textLabel1_3_3_2_2,1,0)
        spacer28_3_2 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormSambaLayout.addItem(spacer28_3_2,0,2)

        self.iLdapFormSambaPwdMustChange = QCheckBox(self.fLdapFormSamba,"iLdapFormSambaPwdMustChange")
        self.iLdapFormSambaPwdMustChange.setChecked(1)

        fLdapFormSambaLayout.addWidget(self.iLdapFormSambaPwdMustChange,2,1)

        self.line124 = QFrame(self.fLdapFormSamba,"line124")
        self.line124.setFrameShape(QFrame.HLine)
        self.line124.setFrameShadow(QFrame.Sunken)
        self.line124.setFrameShape(QFrame.HLine)

        fLdapFormSambaLayout.addMultiCellWidget(self.line124,3,3,0,1)

        self.wsLdapFormSmb = QWidgetStack(self.fLdapFormSamba,"wsLdapFormSmb")
        self.wsLdapFormSmb.setMargin(-8)

        self.WStackPage_7 = QWidget(self.wsLdapFormSmb,"WStackPage_7")
        self.wsLdapFormSmb.addWidget(self.WStackPage_7,0)

        self.WStackPage_8 = QWidget(self.wsLdapFormSmb,"WStackPage_8")
        WStackPageLayout_6 = QGridLayout(self.WStackPage_8,1,1,8,6,"WStackPageLayout_6")

        self.iLdapFormLogonScript = QLineEdit(self.WStackPage_8,"iLdapFormLogonScript")
        self.iLdapFormLogonScript.setMinimumSize(QSize(270,0))
        self.iLdapFormLogonScript.setReadOnly(1)

        WStackPageLayout_6.addWidget(self.iLdapFormLogonScript,4,1)

        self.textLabel1_3_3_3 = QLabel(self.WStackPage_8,"textLabel1_3_3_3")

        WStackPageLayout_6.addWidget(self.textLabel1_3_3_3,3,0)

        self.textLabel5_2_2_2 = QLabel(self.WStackPage_8,"textLabel5_2_2_2")
        self.textLabel5_2_2_2.setMinimumSize(QSize(120,0))

        WStackPageLayout_6.addWidget(self.textLabel5_2_2_2,0,0)

        self.textLabel1_3_3_3_2 = QLabel(self.WStackPage_8,"textLabel1_3_3_3_2")

        WStackPageLayout_6.addWidget(self.textLabel1_3_3_3_2,4,0)

        self.iLdapFormProfilePath = QLineEdit(self.WStackPage_8,"iLdapFormProfilePath")
        self.iLdapFormProfilePath.setMinimumSize(QSize(270,0))
        self.iLdapFormProfilePath.setReadOnly(1)

        WStackPageLayout_6.addWidget(self.iLdapFormProfilePath,1,1)

        self.textLabel5_2_3 = QLabel(self.WStackPage_8,"textLabel5_2_3")

        WStackPageLayout_6.addWidget(self.textLabel5_2_3,2,0)

        self.iLdapFormDrivePath = QLineEdit(self.WStackPage_8,"iLdapFormDrivePath")
        self.iLdapFormDrivePath.setMinimumSize(QSize(270,0))
        self.iLdapFormDrivePath.setReadOnly(1)

        WStackPageLayout_6.addWidget(self.iLdapFormDrivePath,3,1)

        self.iLdapFormHomeDrive = QLineEdit(self.WStackPage_8,"iLdapFormHomeDrive")
        self.iLdapFormHomeDrive.setMinimumSize(QSize(270,0))
        self.iLdapFormHomeDrive.setReadOnly(1)

        WStackPageLayout_6.addWidget(self.iLdapFormHomeDrive,2,1)

        self.cbLdapFormProfileType = QComboBox(0,self.WStackPage_8,"cbLdapFormProfileType")

        WStackPageLayout_6.addWidget(self.cbLdapFormProfileType,0,1)
        self.wsLdapFormSmb.addWidget(self.WStackPage_8,1)

        fLdapFormSambaLayout.addMultiCellWidget(self.wsLdapFormSmb,4,4,0,1)

        self.pLdapFormSmbShow = QPushButton(self.fLdapFormSamba,"pLdapFormSmbShow")
        self.pLdapFormSmbShow.setMaximumSize(QSize(40,26))

        fLdapFormSambaLayout.addWidget(self.pLdapFormSmbShow,2,0)

        self.cbLdapFormSambaDomain = QComboBox(0,self.fLdapFormSamba,"cbLdapFormSambaDomain")

        fLdapFormSambaLayout.addWidget(self.cbLdapFormSambaDomain,0,1)

        self.cbLdapFormPrimaryGroup = QComboBox(0,self.fLdapFormSamba,"cbLdapFormPrimaryGroup")

        fLdapFormSambaLayout.addWidget(self.cbLdapFormPrimaryGroup,1,1)

        WStackPageLayout_5.addWidget(self.fLdapFormSamba,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_6,2)

        self.WStackPage_9 = QWidget(self.wsLdapForm,"WStackPage_9")
        WStackPageLayout_7 = QGridLayout(self.WStackPage_9,1,1,8,6,"WStackPageLayout_7")

        layout53_3 = QGridLayout(None,1,1,0,0,"layout53_3")

        self.textLabel1_2_3_2_3 = QLabel(self.WStackPage_9,"textLabel1_2_3_2_3")

        layout53_3.addWidget(self.textLabel1_2_3_2_3,0,0)
        spacer156_3 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout53_3.addItem(spacer156_3,0,2)

        self.line22_2_2_3 = QFrame(self.WStackPage_9,"line22_2_2_3")
        self.line22_2_2_3.setFrameShape(QFrame.HLine)
        self.line22_2_2_3.setFrameShadow(QFrame.Sunken)
        self.line22_2_2_3.setFrameShape(QFrame.HLine)

        layout53_3.addMultiCellWidget(self.line22_2_2_3,1,1,0,2)

        self.cLdapFormAst = QCheckBox(self.WStackPage_9,"cLdapFormAst")

        layout53_3.addWidget(self.cLdapFormAst,0,1)

        WStackPageLayout_7.addLayout(layout53_3,0,0)
        spacer146_2_3 = QSpacerItem(20,80,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_7.addItem(spacer146_2_3,2,0)

        self.fLdapFormAst = QFrame(self.WStackPage_9,"fLdapFormAst")
        self.fLdapFormAst.setEnabled(0)
        self.fLdapFormAst.setFrameShape(QFrame.NoFrame)
        self.fLdapFormAst.setFrameShadow(QFrame.Raised)
        fLdapFormAstLayout = QGridLayout(self.fLdapFormAst,1,1,8,6,"fLdapFormAstLayout")

        self.textLabel3_2_2_3 = QLabel(self.fLdapFormAst,"textLabel3_2_2_3")
        self.textLabel3_2_2_3.setMinimumSize(QSize(120,0))

        fLdapFormAstLayout.addWidget(self.textLabel3_2_2_3,0,0)

        self.cLdapFormAstSecret = QCheckBox(self.fLdapFormAst,"cLdapFormAstSecret")
        self.cLdapFormAstSecret.setChecked(1)

        fLdapFormAstLayout.addWidget(self.cLdapFormAstSecret,3,1)

        self.textLabel5_2_2_3 = QLabel(self.fLdapFormAst,"textLabel5_2_2_3")

        fLdapFormAstLayout.addWidget(self.textLabel5_2_2_3,1,0)

        self.iLdapFormAstName = QLineEdit(self.fLdapFormAst,"iLdapFormAstName")
        self.iLdapFormAstName.setMinimumSize(QSize(270,0))

        fLdapFormAstLayout.addWidget(self.iLdapFormAstName,1,1)
        spacer28_3_3 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormAstLayout.addItem(spacer28_3_3,0,2)

        self.textLabel5_2_2_3_2 = QLabel(self.fLdapFormAst,"textLabel5_2_2_3_2")

        fLdapFormAstLayout.addWidget(self.textLabel5_2_2_3_2,2,0)

        self.iLdapFormAstPort = QLineEdit(self.fLdapFormAst,"iLdapFormAstPort")
        self.iLdapFormAstPort.setMinimumSize(QSize(270,0))

        fLdapFormAstLayout.addWidget(self.iLdapFormAstPort,2,1)

        self.iLdapFormAstUsername = QLineEdit(self.fLdapFormAst,"iLdapFormAstUsername")
        self.iLdapFormAstUsername.setMinimumSize(QSize(270,0))

        fLdapFormAstLayout.addWidget(self.iLdapFormAstUsername,0,1)

        WStackPageLayout_7.addWidget(self.fLdapFormAst,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_9,3)

        self.WStackPage_10 = QWidget(self.wsLdapForm,"WStackPage_10")
        WStackPageLayout_8 = QGridLayout(self.WStackPage_10,1,1,8,6,"WStackPageLayout_8")

        layout53_4 = QGridLayout(None,1,1,0,0,"layout53_4")

        self.textLabel1_2_3_2_4 = QLabel(self.WStackPage_10,"textLabel1_2_3_2_4")

        layout53_4.addWidget(self.textLabel1_2_3_2_4,0,0)
        spacer156_4 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout53_4.addItem(spacer156_4,0,2)

        self.line22_2_2_4 = QFrame(self.WStackPage_10,"line22_2_2_4")
        self.line22_2_2_4.setFrameShape(QFrame.HLine)
        self.line22_2_2_4.setFrameShadow(QFrame.Sunken)
        self.line22_2_2_4.setFrameShape(QFrame.HLine)

        layout53_4.addMultiCellWidget(self.line22_2_2_4,1,1,0,2)

        self.cLdapFormRadius = QCheckBox(self.WStackPage_10,"cLdapFormRadius")

        layout53_4.addWidget(self.cLdapFormRadius,0,1)

        WStackPageLayout_8.addLayout(layout53_4,0,0)
        spacer146_2_4 = QSpacerItem(20,112,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_8.addItem(spacer146_2_4,2,0)

        self.fLdapFormRadius = QFrame(self.WStackPage_10,"fLdapFormRadius")
        self.fLdapFormRadius.setEnabled(0)
        self.fLdapFormRadius.setFrameShape(QFrame.NoFrame)
        self.fLdapFormRadius.setFrameShadow(QFrame.Raised)
        fLdapFormRadiusLayout = QGridLayout(self.fLdapFormRadius,1,1,8,6,"fLdapFormRadiusLayout")

        self.iLdapFormRadiusGroup = QLineEdit(self.fLdapFormRadius,"iLdapFormRadiusGroup")
        self.iLdapFormRadiusGroup.setMinimumSize(QSize(270,0))

        fLdapFormRadiusLayout.addWidget(self.iLdapFormRadiusGroup,0,1)

        self.textLabel3_2_2_4 = QLabel(self.fLdapFormRadius,"textLabel3_2_2_4")
        self.textLabel3_2_2_4.setMinimumSize(QSize(120,0))

        fLdapFormRadiusLayout.addWidget(self.textLabel3_2_2_4,0,0)
        spacer28_3_4 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fLdapFormRadiusLayout.addItem(spacer28_3_4,0,2)

        WStackPageLayout_8.addWidget(self.fLdapFormRadius,1,0)
        self.wsLdapForm.addWidget(self.WStackPage_10,4)

        WStackPageLayout_2.addWidget(self.wsLdapForm,1,0)
        self.wsLdap.addWidget(self.WStackPage_3,2)

        self.WStackPage_11 = QWidget(self.wsLdap,"WStackPage_11")
        WStackPageLayout_9 = QGridLayout(self.WStackPage_11,1,1,8,6,"WStackPageLayout_9")

        layout51_2 = QGridLayout(None,1,1,0,0,"layout51_2")

        self.line22_3 = QFrame(self.WStackPage_11,"line22_3")
        self.line22_3.setFrameShape(QFrame.HLine)
        self.line22_3.setFrameShadow(QFrame.Sunken)
        self.line22_3.setFrameShape(QFrame.HLine)

        layout51_2.addMultiCellWidget(self.line22_3,1,1,0,1)

        self.textLabel1_2_4 = QLabel(self.WStackPage_11,"textLabel1_2_4")
        self.textLabel1_2_4.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4.setMaximumSize(QSize(32767,26))

        layout51_2.addWidget(self.textLabel1_2_4,0,0)
        spacer148_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2.addItem(spacer148_2,0,1)

        WStackPageLayout_9.addMultiCellLayout(layout51_2,0,0,0,1)

        self.pLdapAddOu = QPushButton(self.WStackPage_11,"pLdapAddOu")
        self.pLdapAddOu.setMaximumSize(QSize(110,26))

        WStackPageLayout_9.addWidget(self.pLdapAddOu,4,1)

        self.line27 = QFrame(self.WStackPage_11,"line27")
        self.line27.setFrameShape(QFrame.HLine)
        self.line27.setFrameShadow(QFrame.Sunken)
        self.line27.setFrameShape(QFrame.HLine)

        WStackPageLayout_9.addMultiCellWidget(self.line27,3,3,0,1)
        spacer159 = QSpacerItem(20,200,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_9.addItem(spacer159,2,0)

        self.frame24 = QFrame(self.WStackPage_11,"frame24")
        self.frame24.setFrameShape(QFrame.NoFrame)
        self.frame24.setFrameShadow(QFrame.Raised)
        frame24Layout = QGridLayout(self.frame24,1,1,8,6,"frame24Layout")

        self.textLabel2_3 = QLabel(self.frame24,"textLabel2_3")

        frame24Layout.addWidget(self.textLabel2_3,0,0)

        self.iLdapOu = QLineEdit(self.frame24,"iLdapOu")
        self.iLdapOu.setMinimumSize(QSize(270,0))

        frame24Layout.addWidget(self.iLdapOu,0,1)
        spacer31 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame24Layout.addItem(spacer31,0,2)

        WStackPageLayout_9.addMultiCellWidget(self.frame24,1,1,0,1)
        self.wsLdap.addWidget(self.WStackPage_11,3)

        self.WStackPage_12 = QWidget(self.wsLdap,"WStackPage_12")
        WStackPageLayout_10 = QGridLayout(self.WStackPage_12,1,1,8,6,"WStackPageLayout_10")

        layout51_2_2 = QGridLayout(None,1,1,0,0,"layout51_2_2")

        self.line22_3_2 = QFrame(self.WStackPage_12,"line22_3_2")
        self.line22_3_2.setFrameShape(QFrame.HLine)
        self.line22_3_2.setFrameShadow(QFrame.Sunken)
        self.line22_3_2.setFrameShape(QFrame.HLine)

        layout51_2_2.addMultiCellWidget(self.line22_3_2,1,1,0,1)

        self.textLabel1_2_4_2 = QLabel(self.WStackPage_12,"textLabel1_2_4_2")
        self.textLabel1_2_4_2.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4_2.setMaximumSize(QSize(32767,26))

        layout51_2_2.addWidget(self.textLabel1_2_4_2,0,0)
        spacer148_2_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2_2.addItem(spacer148_2_2,0,1)

        WStackPageLayout_10.addMultiCellLayout(layout51_2_2,0,0,0,1)
        spacer30_2_2 = QSpacerItem(100,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_10.addItem(spacer30_2_2,1,1)

        self.frame25 = QFrame(self.WStackPage_12,"frame25")
        self.frame25.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.frame25.sizePolicy().hasHeightForWidth()))
        self.frame25.setFrameShape(QFrame.NoFrame)
        self.frame25.setFrameShadow(QFrame.Raised)
        frame25Layout = QGridLayout(self.frame25,1,1,8,6,"frame25Layout")

        self.textLabel1_3_2_2 = QLabel(self.frame25,"textLabel1_3_2_2")
        self.textLabel1_3_2_2.setMinimumSize(QSize(100,0))

        frame25Layout.addMultiCellWidget(self.textLabel1_3_2_2,0,2,0,0)

        self.textLabel1_3_2_4 = QLabel(self.frame25,"textLabel1_3_2_4")

        frame25Layout.addWidget(self.textLabel1_3_2_4,5,0)

        self.iLdapPasswd = QLineEdit(self.frame25,"iLdapPasswd")
        self.iLdapPasswd.setMinimumSize(QSize(270,0))
        self.iLdapPasswd.setMaximumSize(QSize(270,32767))
        self.iLdapPasswd.setEchoMode(QLineEdit.Password)

        frame25Layout.addMultiCellWidget(self.iLdapPasswd,4,4,1,3)

        self.textLabel1_3_2 = QLabel(self.frame25,"textLabel1_3_2")

        frame25Layout.addWidget(self.textLabel1_3_2,4,0)

        self.iLdapPasswd2 = QLineEdit(self.frame25,"iLdapPasswd2")
        self.iLdapPasswd2.setMinimumSize(QSize(270,0))
        self.iLdapPasswd2.setMaximumSize(QSize(270,32767))
        self.iLdapPasswd2.setEchoMode(QLineEdit.Password)

        frame25Layout.addMultiCellWidget(self.iLdapPasswd2,5,5,1,3)

        self.cbLdapSambaPassword = QCheckBox(self.frame25,"cbLdapSambaPassword")

        frame25Layout.addMultiCellWidget(self.cbLdapSambaPassword,1,1,1,3)

        self.cbLdapAstPassword = QCheckBox(self.frame25,"cbLdapAstPassword")

        frame25Layout.addMultiCellWidget(self.cbLdapAstPassword,2,2,1,2)

        self.line44 = QFrame(self.frame25,"line44")
        self.line44.setFrameShape(QFrame.HLine)
        self.line44.setFrameShadow(QFrame.Sunken)
        self.line44.setFrameShape(QFrame.HLine)

        frame25Layout.addMultiCellWidget(self.line44,3,3,0,3)

        self.cbLdapUserPassword = QCheckBox(self.frame25,"cbLdapUserPassword")
        self.cbLdapUserPassword.setChecked(1)

        frame25Layout.addWidget(self.cbLdapUserPassword,0,1)

        self.cbUserPassword = QComboBox(0,self.frame25,"cbUserPassword")
        self.cbUserPassword.setEnabled(1)
        self.cbUserPassword.setMinimumSize(QSize(0,23))
        self.cbUserPassword.setMaximumSize(QSize(100,32767))

        frame25Layout.addWidget(self.cbUserPassword,0,2)
        spacer91 = QSpacerItem(51,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        frame25Layout.addItem(spacer91,0,3)

        WStackPageLayout_10.addWidget(self.frame25,1,0)
        spacer161 = QSpacerItem(21,210,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_10.addItem(spacer161,2,0)

        self.line29 = QFrame(self.WStackPage_12,"line29")
        self.line29.setFrameShape(QFrame.HLine)
        self.line29.setFrameShadow(QFrame.Sunken)
        self.line29.setFrameShape(QFrame.HLine)

        WStackPageLayout_10.addMultiCellWidget(self.line29,3,3,0,1)

        layout48 = QHBoxLayout(None,0,6,"layout48")
        spacer92 = QSpacerItem(551,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout48.addItem(spacer92)

        self.pLdapPasswd = QPushButton(self.WStackPage_12,"pLdapPasswd")
        self.pLdapPasswd.setMinimumSize(QSize(110,0))
        self.pLdapPasswd.setMaximumSize(QSize(110,26))
        layout48.addWidget(self.pLdapPasswd)

        WStackPageLayout_10.addMultiCellLayout(layout48,4,4,0,1)
        self.wsLdap.addWidget(self.WStackPage_12,4)

        self.WStackPage_13 = QWidget(self.wsLdap,"WStackPage_13")
        WStackPageLayout_11 = QGridLayout(self.WStackPage_13,1,1,8,6,"WStackPageLayout_11")

        layout51_2_2_2 = QGridLayout(None,1,1,0,0,"layout51_2_2_2")

        self.line22_3_2_2 = QFrame(self.WStackPage_13,"line22_3_2_2")
        self.line22_3_2_2.setFrameShape(QFrame.HLine)
        self.line22_3_2_2.setFrameShadow(QFrame.Sunken)
        self.line22_3_2_2.setFrameShape(QFrame.HLine)

        layout51_2_2_2.addMultiCellWidget(self.line22_3_2_2,1,1,0,1)

        self.textLabel1_2_4_2_2 = QLabel(self.WStackPage_13,"textLabel1_2_4_2_2")
        self.textLabel1_2_4_2_2.setMinimumSize(QSize(250,0))
        self.textLabel1_2_4_2_2.setMaximumSize(QSize(32767,26))

        layout51_2_2_2.addWidget(self.textLabel1_2_4_2_2,0,0)
        spacer148_2_2_2 = QSpacerItem(282,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout51_2_2_2.addItem(spacer148_2_2_2,0,1)

        WStackPageLayout_11.addMultiCellLayout(layout51_2_2_2,0,0,0,1)

        layout130 = QHBoxLayout(None,0,6,"layout130")
        spacer266 = QSpacerItem(760,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout130.addItem(spacer266)

        self.pLdapSambaPopulate = QPushButton(self.WStackPage_13,"pLdapSambaPopulate")
        self.pLdapSambaPopulate.setMinimumSize(QSize(110,0))
        self.pLdapSambaPopulate.setMaximumSize(QSize(110,26))
        layout130.addWidget(self.pLdapSambaPopulate)

        WStackPageLayout_11.addMultiCellLayout(layout130,4,4,0,1)

        self.line29_2 = QFrame(self.WStackPage_13,"line29_2")
        self.line29_2.setFrameShape(QFrame.HLine)
        self.line29_2.setFrameShadow(QFrame.Sunken)
        self.line29_2.setFrameShape(QFrame.HLine)

        WStackPageLayout_11.addMultiCellWidget(self.line29_2,3,3,0,1)
        spacer161_2 = QSpacerItem(21,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_11.addItem(spacer161_2,2,0)
        spacer86 = QSpacerItem(40,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_11.addItem(spacer86,1,1)

        self.frame25_2 = QFrame(self.WStackPage_13,"frame25_2")
        self.frame25_2.setMinimumSize(QSize(0,200))
        self.frame25_2.setFrameShape(QFrame.NoFrame)
        self.frame25_2.setFrameShadow(QFrame.Raised)
        frame25_2Layout = QGridLayout(self.frame25_2,1,1,8,6,"frame25_2Layout")

        self.textLabel1_3_2_3_2_2_3_3_2 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_3_3_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_3_3_2,11,0)

        self.textLabel1_3_2_3_2_2_3_3 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_3_3")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_3_3,10,0)

        self.textLabel1_3_2_3_2_2_2 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_2,5,0)

        self.textLabel1_3_2_3_2 = QLabel(self.frame25_2,"textLabel1_3_2_3_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2,3,0)

        self.textLabel1_3_2_3_2_2_2_3 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_2_3")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_2_3,9,0)

        self.textLabel1_3_2_3_2_2_3 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_3")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_3,6,0)

        self.textLabel1_3_2_3_2_2 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2,4,0)

        self.textLabel1_3_2_3_2_2_5 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_5")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_5,8,0)

        self.textLabel1_3_2_3_2_2_4 = QLabel(self.frame25_2,"textLabel1_3_2_3_2_2_4")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3_2_2_4,7,0)

        self.textLabel1_3_2_3 = QLabel(self.frame25_2,"textLabel1_3_2_3")

        frame25_2Layout.addWidget(self.textLabel1_3_2_3,2,0)

        self.textLabel1_3_2_2_2 = QLabel(self.frame25_2,"textLabel1_3_2_2_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_2_2,0,0)

        self.textLabel1_3_2_2_2_2 = QLabel(self.frame25_2,"textLabel1_3_2_2_2_2")

        frame25_2Layout.addWidget(self.textLabel1_3_2_2_2_2,1,0)

        self.iLdapSMBdomain = QLineEdit(self.frame25_2,"iLdapSMBdomain")
        self.iLdapSMBdomain.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBdomain.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBdomain,0,1)

        self.iLdapSMBSID = QLineEdit(self.frame25_2,"iLdapSMBSID")
        self.iLdapSMBSID.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBSID.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBSID,1,1)

        self.iLdapSMBpassword = QLineEdit(self.frame25_2,"iLdapSMBpassword")
        self.iLdapSMBpassword.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBpassword.sizePolicy().hasHeightForWidth()))
        self.iLdapSMBpassword.setEchoMode(QLineEdit.Password)

        frame25_2Layout.addWidget(self.iLdapSMBpassword,2,1)

        self.iLdapSMBuidNumber = QLineEdit(self.frame25_2,"iLdapSMBuidNumber")
        self.iLdapSMBuidNumber.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBuidNumber.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBuidNumber,3,1)

        self.iLdapSMBgidNumber = QLineEdit(self.frame25_2,"iLdapSMBgidNumber")
        self.iLdapSMBgidNumber.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBgidNumber.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBgidNumber,4,1)

        self.iLdapSMBminPwdLength = QLineEdit(self.frame25_2,"iLdapSMBminPwdLength")
        self.iLdapSMBminPwdLength.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBminPwdLength.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBminPwdLength,5,1)

        self.iLdapSMBpwdHistLenght = QLineEdit(self.frame25_2,"iLdapSMBpwdHistLenght")
        self.iLdapSMBpwdHistLenght.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBpwdHistLenght.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBpwdHistLenght,6,1)

        self.iLdapSMBmaxPwdAge = QLineEdit(self.frame25_2,"iLdapSMBmaxPwdAge")
        self.iLdapSMBmaxPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBmaxPwdAge.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBmaxPwdAge,7,1)

        self.cbLdapSMBmaxPwdAge = QComboBox(0,self.frame25_2,"cbLdapSMBmaxPwdAge")
        self.cbLdapSMBmaxPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapSMBmaxPwdAge.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.cbLdapSMBmaxPwdAge,7,2)

        self.iLdapSMBminPwdAge = QLineEdit(self.frame25_2,"iLdapSMBminPwdAge")
        self.iLdapSMBminPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBminPwdAge.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBminPwdAge,8,1)

        self.cbLdapSMBminPwdAge = QComboBox(0,self.frame25_2,"cbLdapSMBminPwdAge")
        self.cbLdapSMBminPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapSMBminPwdAge.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.cbLdapSMBminPwdAge,8,2)

        self.iLdapSMBlockout = QLineEdit(self.frame25_2,"iLdapSMBlockout")
        self.iLdapSMBlockout.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBlockout.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBlockout,9,1)

        self.iLdapSMBlockoutDuration = QLineEdit(self.frame25_2,"iLdapSMBlockoutDuration")
        self.iLdapSMBlockoutDuration.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBlockoutDuration.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBlockoutDuration,10,1)

        self.cbLdapSMBlockoutDuration = QComboBox(0,self.frame25_2,"cbLdapSMBlockoutDuration")
        self.cbLdapSMBlockoutDuration.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapSMBlockoutDuration.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.cbLdapSMBlockoutDuration,10,2)

        self.iLdapSMBlockoutWindow = QLineEdit(self.frame25_2,"iLdapSMBlockoutWindow")
        self.iLdapSMBlockoutWindow.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iLdapSMBlockoutWindow.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.iLdapSMBlockoutWindow,11,1)

        self.cbLdapSMBlockoutWindow = QComboBox(0,self.frame25_2,"cbLdapSMBlockoutWindow")
        self.cbLdapSMBlockoutWindow.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbLdapSMBlockoutWindow.sizePolicy().hasHeightForWidth()))

        frame25_2Layout.addWidget(self.cbLdapSMBlockoutWindow,11,2)

        WStackPageLayout_11.addWidget(self.frame25_2,1,0)
        self.wsLdap.addWidget(self.WStackPage_13,5)
        layout521.addWidget(self.wsLdap)

        tabLdapLayout.addWidget(self.splitter6,0,0)
        self.wKorreio.insertTab(self.tabLdap,QString.fromLatin1(""))

        self.tabCyrus = QWidget(self.wKorreio,"tabCyrus")
        tabCyrusLayout = QGridLayout(self.tabCyrus,1,1,8,6,"tabCyrusLayout")

        self.tCyrUser = QLabel(self.tabCyrus,"tCyrUser")
        self.tCyrUser.setMinimumSize(QSize(65,0))

        tabCyrusLayout.addMultiCellWidget(self.tCyrUser,0,0,0,1)

        self.iImapSearch = QLineEdit(self.tabCyrus,"iImapSearch")
        self.iImapSearch.setMinimumSize(QSize(220,0))
        self.iImapSearch.setMaximumSize(QSize(220,32767))

        tabCyrusLayout.addWidget(self.iImapSearch,0,2)

        self.pImapSearch = QPushButton(self.tabCyrus,"pImapSearch")

        tabCyrusLayout.addWidget(self.pImapSearch,0,3)
        spacer1 = QSpacerItem(470,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabCyrusLayout.addMultiCell(spacer1,0,0,4,9)

        self.lvCyrus = QListView(self.tabCyrus,"lvCyrus")
        self.lvCyrus.addColumn(self.__tr("IMAP Mailboxes"))
        self.lvCyrus.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,0,1,self.lvCyrus.sizePolicy().hasHeightForWidth()))
        self.lvCyrus.setShowSortIndicator(1)
        self.lvCyrus.setRootIsDecorated(1)
        self.lvCyrus.setResizeMode(QListView.AllColumns)

        tabCyrusLayout.addMultiCellWidget(self.lvCyrus,1,1,0,6)

        self.lvCyrusGlobal = QListView(self.tabCyrus,"lvCyrusGlobal")
        self.lvCyrusGlobal.addColumn(self.__tr("Global IMAP Mailboxes"))
        self.lvCyrusGlobal.setShowSortIndicator(1)
        self.lvCyrusGlobal.setRootIsDecorated(1)
        self.lvCyrusGlobal.setResizeMode(QListView.AllColumns)

        tabCyrusLayout.addWidget(self.lvCyrusGlobal,1,9)

        self.line21 = QFrame(self.tabCyrus,"line21")
        self.line21.setFrameShape(QFrame.VLine)
        self.line21.setFrameShadow(QFrame.Sunken)
        self.line21.setFrameShape(QFrame.VLine)

        tabCyrusLayout.addMultiCellWidget(self.line21,1,5,7,8)

        self.lvImapAcl = QListView(self.tabCyrus,"lvImapAcl")
        self.lvImapAcl.addColumn(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f"))
        self.lvImapAcl.addColumn(self.__trUtf8("\x50\x65\x72\x6d\x69\x73\x73\xc3\xb5\x65\x73"))
        self.lvImapAcl.setSelectionMode(QListView.Extended)
        self.lvImapAcl.setAllColumnsShowFocus(1)
        self.lvImapAcl.setResizeMode(QListView.LastColumn)

        tabCyrusLayout.addMultiCellWidget(self.lvImapAcl,4,4,0,6)
        spacer33_2_2_2_2 = QSpacerItem(340,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabCyrusLayout.addMultiCell(spacer33_2_2_2_2,3,3,8,9)

        layout39 = QHBoxLayout(None,0,6,"layout39")

        self.cbImapMailbox = QComboBox(0,self.tabCyrus,"cbImapMailbox")
        self.cbImapMailbox.setMinimumSize(QSize(85,0))
        self.cbImapMailbox.setMaximumSize(QSize(90,32767))
        layout39.addWidget(self.cbImapMailbox)

        self.iImapMailbox = QLineEdit(self.tabCyrus,"iImapMailbox")
        self.iImapMailbox.setEnabled(1)
        layout39.addWidget(self.iImapMailbox)

        self.pCyrAdd = QPushButton(self.tabCyrus,"pCyrAdd")
        self.pCyrAdd.setMinimumSize(QSize(30,0))
        self.pCyrAdd.setMaximumSize(QSize(30,32767))
        layout39.addWidget(self.pCyrAdd)

        self.pCyrDelete = QPushButton(self.tabCyrus,"pCyrDelete")
        self.pCyrDelete.setEnabled(1)
        self.pCyrDelete.setMinimumSize(QSize(30,0))
        self.pCyrDelete.setMaximumSize(QSize(30,32767))
        layout39.addWidget(self.pCyrDelete)

        self.pCyrReconstruct = QPushButton(self.tabCyrus,"pCyrReconstruct")
        self.pCyrReconstruct.setMinimumSize(QSize(30,0))
        self.pCyrReconstruct.setMaximumSize(QSize(30,32767))
        layout39.addWidget(self.pCyrReconstruct)

        tabCyrusLayout.addMultiCellLayout(layout39,2,3,0,6)

        self.frame20 = QFrame(self.tabCyrus,"frame20")
        self.frame20.setFrameShape(QFrame.NoFrame)
        self.frame20.setFrameShadow(QFrame.Raised)
        frame20Layout = QGridLayout(self.frame20,1,1,0,6,"frame20Layout")
        spacer36 = QSpacerItem(30,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame20Layout.addItem(spacer36,4,4)

        self.iQuotaUsed = QLineEdit(self.frame20,"iQuotaUsed")
        self.iQuotaUsed.setMinimumSize(QSize(90,25))
        self.iQuotaUsed.setMaximumSize(QSize(90,25))
        self.iQuotaUsed.setAlignment(QLineEdit.AlignRight)
        self.iQuotaUsed.setReadOnly(1)

        frame20Layout.addWidget(self.iQuotaUsed,1,1)

        self.pSetQuota = QPushButton(self.frame20,"pSetQuota")
        self.pSetQuota.setMaximumSize(QSize(40,32767))

        frame20Layout.addWidget(self.pSetQuota,2,3)

        self.pSetExpire = QPushButton(self.frame20,"pSetExpire")
        self.pSetExpire.setMaximumSize(QSize(40,32767))

        frame20Layout.addWidget(self.pSetExpire,4,3)
        spacer33_2 = QSpacerItem(50,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame20Layout.addItem(spacer33_2,1,4)
        spacer34 = QSpacerItem(60,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame20Layout.addItem(spacer34,2,4)

        self.textLabel2_5 = QLabel(self.frame20,"textLabel2_5")

        frame20Layout.addWidget(self.textLabel2_5,4,0)

        layout41 = QGridLayout(None,1,1,0,0,"layout41")

        self.textLabel4_2_2 = QLabel(self.frame20,"textLabel4_2_2")

        layout41.addWidget(self.textLabel4_2_2,0,0)
        spacer138 = QSpacerItem(210,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout41.addItem(spacer138,0,1)

        self.line3_2_2 = QFrame(self.frame20,"line3_2_2")
        self.line3_2_2.setFrameShape(QFrame.HLine)
        self.line3_2_2.setFrameShadow(QFrame.Sunken)
        self.line3_2_2.setFrameShape(QFrame.HLine)

        layout41.addMultiCellWidget(self.line3_2_2,1,1,0,1)

        frame20Layout.addMultiCellLayout(layout41,3,3,0,4)
        spacer33_2_2 = QSpacerItem(30,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame20Layout.addItem(spacer33_2_2,1,3)

        layout42 = QGridLayout(None,1,1,0,0,"layout42")

        self.line3_2 = QFrame(self.frame20,"line3_2")
        self.line3_2.setFrameShape(QFrame.HLine)
        self.line3_2.setFrameShadow(QFrame.Sunken)
        self.line3_2.setFrameShape(QFrame.HLine)

        layout42.addMultiCellWidget(self.line3_2,1,1,0,1)
        spacer33_2_2_2 = QSpacerItem(250,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout42.addItem(spacer33_2_2_2,0,1)

        self.textLabel4_2 = QLabel(self.frame20,"textLabel4_2")

        layout42.addWidget(self.textLabel4_2,0,0)

        frame20Layout.addMultiCellLayout(layout42,0,0,0,4)

        self.textLabel1_6 = QLabel(self.frame20,"textLabel1_6")

        frame20Layout.addWidget(self.textLabel1_6,4,2)

        self.iAnnotationExpire = QLineEdit(self.frame20,"iAnnotationExpire")
        self.iAnnotationExpire.setMaximumSize(QSize(90,32767))
        self.iAnnotationExpire.setAlignment(QLineEdit.AlignRight)

        frame20Layout.addWidget(self.iAnnotationExpire,4,1)

        self.textLabel1 = QLabel(self.frame20,"textLabel1")

        frame20Layout.addWidget(self.textLabel1,1,0)

        self.iQuota = QLineEdit(self.frame20,"iQuota")
        self.iQuota.setMinimumSize(QSize(90,0))
        self.iQuota.setMaximumSize(QSize(90,32767))
        self.iQuota.setAlignment(QLineEdit.AlignRight)

        frame20Layout.addWidget(self.iQuota,2,1)

        self.textLabel2_2 = QLabel(self.frame20,"textLabel2_2")

        frame20Layout.addWidget(self.textLabel2_2,2,0)

        self.textLabel2 = QLabel(self.frame20,"textLabel2")

        frame20Layout.addWidget(self.textLabel2,2,2)

        self.textLabel2_4 = QLabel(self.frame20,"textLabel2_4")

        frame20Layout.addWidget(self.textLabel2_4,1,2)
        spacer144 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        frame20Layout.addItem(spacer144,5,1)

        tabCyrusLayout.addMultiCellWidget(self.frame20,4,5,8,9)

        self.textLabel2_6 = QLabel(self.tabCyrus,"textLabel2_6")

        tabCyrusLayout.addWidget(self.textLabel2_6,5,0)

        self.iImapAclUser = QLineEdit(self.tabCyrus,"iImapAclUser")
        self.iImapAclUser.setMinimumSize(QSize(240,0))

        tabCyrusLayout.addMultiCellWidget(self.iImapAclUser,5,5,1,2)

        self.cbACL = QComboBox(0,self.tabCyrus,"cbACL")
        self.cbACL.setMinimumSize(QSize(145,0))
        self.cbACL.setMaximumSize(QSize(145,32767))
        self.cbACL.setEditable(1)

        tabCyrusLayout.addMultiCellWidget(self.cbACL,5,5,3,4)

        self.pImapAclAdd = QPushButton(self.tabCyrus,"pImapAclAdd")
        self.pImapAclAdd.setMinimumSize(QSize(30,0))
        self.pImapAclAdd.setMaximumSize(QSize(30,32767))

        tabCyrusLayout.addWidget(self.pImapAclAdd,5,5)

        self.pImapAclDel = QPushButton(self.tabCyrus,"pImapAclDel")
        self.pImapAclDel.setMinimumSize(QSize(30,0))
        self.pImapAclDel.setMaximumSize(QSize(30,32767))

        tabCyrusLayout.addWidget(self.pImapAclDel,5,6)
        self.wKorreio.insertTab(self.tabCyrus,QString.fromLatin1(""))

        self.TabPage = QWidget(self.wKorreio,"TabPage")
        TabPageLayout = QGridLayout(self.TabPage,1,1,8,6,"TabPageLayout")

        self.splitter2 = QSplitter(self.TabPage,"splitter2")
        self.splitter2.setOrientation(QSplitter.Horizontal)

        self.lvImapPartition = QListView(self.splitter2,"lvImapPartition")
        self.lvImapPartition.addColumn(self.__tr("IMAP Mailboxes"))
        self.lvImapPartition.addColumn(self.__tr("Partition"))
        self.lvImapPartition.addColumn(self.__tr("Tamanho"))
        self.lvImapPartition.setSelectionMode(QListView.Extended)
        self.lvImapPartition.setAllColumnsShowFocus(1)
        self.lvImapPartition.setShowSortIndicator(1)
        self.lvImapPartition.setRootIsDecorated(1)
        self.lvImapPartition.setResizeMode(QListView.AllColumns)

        self.lvImapPartitionGlobal = QListView(self.splitter2,"lvImapPartitionGlobal")
        self.lvImapPartitionGlobal.addColumn(self.__tr("Global IMAP Mailboxes"))
        self.lvImapPartitionGlobal.addColumn(self.__tr("Partition"))
        self.lvImapPartitionGlobal.addColumn(self.__tr("Tamanho"))
        self.lvImapPartitionGlobal.setSelectionMode(QListView.Extended)
        self.lvImapPartitionGlobal.setAllColumnsShowFocus(1)
        self.lvImapPartitionGlobal.setShowSortIndicator(1)
        self.lvImapPartitionGlobal.setRootIsDecorated(1)
        self.lvImapPartitionGlobal.setResizeMode(QListView.AllColumns)

        TabPageLayout.addWidget(self.splitter2,1,0)

        layout30 = QHBoxLayout(None,0,6,"layout30")

        self.tCyrUser_2 = QLabel(self.TabPage,"tCyrUser_2")
        self.tCyrUser_2.setMinimumSize(QSize(65,0))
        layout30.addWidget(self.tCyrUser_2)

        self.iImapPartitionSearch = QLineEdit(self.TabPage,"iImapPartitionSearch")
        self.iImapPartitionSearch.setMinimumSize(QSize(220,0))
        self.iImapPartitionSearch.setMaximumSize(QSize(220,32767))
        layout30.addWidget(self.iImapPartitionSearch)

        self.pImapPartitionSearch = QPushButton(self.TabPage,"pImapPartitionSearch")
        layout30.addWidget(self.pImapPartitionSearch)

        self.cImapSize = QCheckBox(self.TabPage,"cImapSize")
        self.cImapSize.setChecked(1)
        layout30.addWidget(self.cImapSize)
        spacer1_2 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout30.addItem(spacer1_2)

        self.pImapSelectAll = QPushButton(self.TabPage,"pImapSelectAll")
        layout30.addWidget(self.pImapSelectAll)

        TabPageLayout.addLayout(layout30,0,0)

        layout31 = QHBoxLayout(None,0,6,"layout31")

        self.textLabel1_2_2 = QLabel(self.TabPage,"textLabel1_2_2")
        self.textLabel1_2_2.setMinimumSize(QSize(65,0))
        layout31.addWidget(self.textLabel1_2_2)

        self.cbImapPartition = QComboBox(0,self.TabPage,"cbImapPartition")
        self.cbImapPartition.setMinimumSize(QSize(220,0))
        self.cbImapPartition.setMaximumSize(QSize(220,32767))
        self.cbImapPartition.setEditable(1)
        self.cbImapPartition.setAutoCompletion(1)
        self.cbImapPartition.setDuplicatesEnabled(0)
        layout31.addWidget(self.cbImapPartition)

        self.pImapPartitionMove = QPushButton(self.TabPage,"pImapPartitionMove")
        self.pImapPartitionMove.setMinimumSize(QSize(100,0))
        self.pImapPartitionMove.setMaximumSize(QSize(100,32767))
        layout31.addWidget(self.pImapPartitionMove)
        spacer38_2 = QSpacerItem(390,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout31.addItem(spacer38_2)

        layout6 = QHBoxLayout(None,0,6,"layout6")

        self.tlImapSize = QLabel(self.TabPage,"tlImapSize")
        self.tlImapSize.setMinimumSize(QSize(200,0))
        self.tlImapSize.setAlignment(QLabel.AlignVCenter | QLabel.AlignRight)
        layout6.addWidget(self.tlImapSize)

        self.cImapSizeUpdate = QCheckBox(self.TabPage,"cImapSizeUpdate")
        self.cImapSizeUpdate.setMinimumSize(QSize(20,0))
        self.cImapSizeUpdate.setMaximumSize(QSize(20,32767))
        self.cImapSizeUpdate.setChecked(1)
        layout6.addWidget(self.cImapSizeUpdate)
        layout31.addLayout(layout6)

        TabPageLayout.addLayout(layout31,2,0)
        self.wKorreio.insertTab(self.TabPage,QString.fromLatin1(""))

        self.TabPage_2 = QWidget(self.wKorreio,"TabPage_2")
        TabPageLayout_2 = QGridLayout(self.TabPage_2,1,1,8,6,"TabPageLayout_2")

        self.tCyrUser_2_2 = QLabel(self.TabPage_2,"tCyrUser_2_2")
        self.tCyrUser_2_2.setMinimumSize(QSize(65,0))
        self.tCyrUser_2_2.setMaximumSize(QSize(60,32767))

        TabPageLayout_2.addWidget(self.tCyrUser_2_2,0,0)

        self.iSieveSearch = QLineEdit(self.TabPage_2,"iSieveSearch")
        self.iSieveSearch.setMinimumSize(QSize(220,0))
        self.iSieveSearch.setMaximumSize(QSize(220,32767))

        TabPageLayout_2.addWidget(self.iSieveSearch,0,1)

        self.cSieveScript = QCheckBox(self.TabPage_2,"cSieveScript")
        self.cSieveScript.setChecked(1)

        TabPageLayout_2.addWidget(self.cSieveScript,0,3)

        self.pSieveSearch = QPushButton(self.TabPage_2,"pSieveSearch")

        TabPageLayout_2.addWidget(self.pSieveSearch,0,2)

        self.pSieveSelectAll = QPushButton(self.TabPage_2,"pSieveSelectAll")

        TabPageLayout_2.addWidget(self.pSieveSelectAll,0,5)
        spacer61 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout_2.addItem(spacer61,0,4)

        self.splitter5 = QSplitter(self.TabPage_2,"splitter5")
        self.splitter5.setOrientation(QSplitter.Vertical)

        self.lvSieve = QListView(self.splitter5,"lvSieve")
        self.lvSieve.addColumn(self.__tr("IMAP Users"))
        self.lvSieve.addColumn(self.__tr("Script ativo"))
        self.lvSieve.setSelectionMode(QListView.Extended)
        self.lvSieve.setAllColumnsShowFocus(1)
        self.lvSieve.setShowSortIndicator(1)
        self.lvSieve.setRootIsDecorated(1)
        self.lvSieve.setResizeMode(QListView.LastColumn)

        LayoutWidget_3 = QWidget(self.splitter5,"layout13")
        layout13 = QVBoxLayout(LayoutWidget_3,0,6,"layout13")

        layout12 = QHBoxLayout(None,0,6,"layout12")

        self.textLabel1_2_2_2 = QLabel(LayoutWidget_3,"textLabel1_2_2_2")
        self.textLabel1_2_2_2.setMinimumSize(QSize(65,0))
        layout12.addWidget(self.textLabel1_2_2_2)

        self.cbSieveScript = QComboBox(0,LayoutWidget_3,"cbSieveScript")
        self.cbSieveScript.setMinimumSize(QSize(220,0))
        self.cbSieveScript.setEditable(1)
        self.cbSieveScript.setAutoCompletion(1)
        self.cbSieveScript.setDuplicatesEnabled(0)
        layout12.addWidget(self.cbSieveScript)

        self.pSieveScriptActive = QPushButton(LayoutWidget_3,"pSieveScriptActive")
        self.pSieveScriptActive.setMaximumSize(QSize(30,32767))
        layout12.addWidget(self.pSieveScriptActive)

        self.pSieveScriptDisable = QPushButton(LayoutWidget_3,"pSieveScriptDisable")
        self.pSieveScriptDisable.setMaximumSize(QSize(30,32767))
        layout12.addWidget(self.pSieveScriptDisable)

        self.pSieveScriptRemove = QPushButton(LayoutWidget_3,"pSieveScriptRemove")
        self.pSieveScriptRemove.setMaximumSize(QSize(30,32767))
        layout12.addWidget(self.pSieveScriptRemove)
        spacer61_2_2 = QSpacerItem(100,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout12.addItem(spacer61_2_2)
        layout13.addLayout(layout12)

        self.splitter4 = QSplitter(LayoutWidget_3,"splitter4")
        self.splitter4.setOrientation(QSplitter.Horizontal)

        self.teSieveScript = QTextEdit(self.splitter4,"teSieveScript")
        self.teSieveScript.setMinimumSize(QSize(600,200))

        LayoutWidget_4 = QWidget(self.splitter4,"layout11")
        layout11 = QGridLayout(LayoutWidget_4,1,1,0,6,"layout11")
        spacer129 = QSpacerItem(121,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout11.addItem(spacer129,0,1)

        self.lbSieveScripts = QListBox(LayoutWidget_4,"lbSieveScripts")

        layout11.addMultiCellWidget(self.lbSieveScripts,1,1,0,1)

        self.textLabel1_8 = QLabel(LayoutWidget_4,"textLabel1_8")

        layout11.addWidget(self.textLabel1_8,0,0)
        layout13.addWidget(self.splitter4)

        TabPageLayout_2.addMultiCellWidget(self.splitter5,1,1,0,5)
        self.wKorreio.insertTab(self.TabPage_2,QString.fromLatin1(""))

        self.TabPage_3 = QWidget(self.wKorreio,"TabPage_3")
        TabPageLayout_3 = QGridLayout(self.TabPage_3,1,1,8,6,"TabPageLayout_3")

        layout7_2 = QHBoxLayout(None,0,6,"layout7_2")

        self.pPostStart = QPushButton(self.TabPage_3,"pPostStart")
        layout7_2.addWidget(self.pPostStart)

        self.pPostStop = QPushButton(self.TabPage_3,"pPostStop")
        layout7_2.addWidget(self.pPostStop)

        self.pPostRestart = QPushButton(self.TabPage_3,"pPostRestart")
        layout7_2.addWidget(self.pPostRestart)
        spacer27 = QSpacerItem(311,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout7_2.addItem(spacer27)

        TabPageLayout_3.addLayout(layout7_2,2,0)

        self.buttonGroup2 = QButtonGroup(self.TabPage_3,"buttonGroup2")
        self.buttonGroup2.setColumnLayout(0,Qt.Vertical)
        self.buttonGroup2.layout().setSpacing(6)
        self.buttonGroup2.layout().setMargin(8)
        buttonGroup2Layout = QGridLayout(self.buttonGroup2.layout())
        buttonGroup2Layout.setAlignment(Qt.AlignTop)

        self.pPostMainSave = QPushButton(self.buttonGroup2,"pPostMainSave")

        buttonGroup2Layout.addWidget(self.pPostMainSave,1,6)
        spacer18 = QSpacerItem(81,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2Layout.addMultiCell(spacer18,2,2,0,1)

        self.textLabel6 = QLabel(self.buttonGroup2,"textLabel6")

        buttonGroup2Layout.addWidget(self.textLabel6,1,0)
        spacer31_2 = QSpacerItem(192,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer31_2,0,7)

        self.rbPostconfD = QRadioButton(self.buttonGroup2,"rbPostconfD")

        buttonGroup2Layout.addMultiCellWidget(self.rbPostconfD,0,0,4,6)
        spacer19 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer19,1,1)
        spacer20 = QSpacerItem(20,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer20,1,5)

        self.cbPostconf = QComboBox(0,self.buttonGroup2,"cbPostconf")
        self.cbPostconf.setMinimumSize(QSize(340,0))

        buttonGroup2Layout.addMultiCellWidget(self.cbPostconf,1,1,2,4)

        self.tePostconf = QTextEdit(self.buttonGroup2,"tePostconf")

        buttonGroup2Layout.addMultiCellWidget(self.tePostconf,2,2,2,7)

        self.rbPostconfAll = QRadioButton(self.buttonGroup2,"rbPostconfAll")

        buttonGroup2Layout.addWidget(self.rbPostconfAll,0,3)

        self.textLabel1_4 = QLabel(self.buttonGroup2,"textLabel1_4")

        buttonGroup2Layout.addWidget(self.textLabel1_4,0,0)
        spacer19_2 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer19_2,0,1)
        spacer21 = QSpacerItem(192,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2Layout.addItem(spacer21,1,7)

        self.rbPostconfN = QRadioButton(self.buttonGroup2,"rbPostconfN")
        self.rbPostconfN.setAutoMask(1)

        buttonGroup2Layout.addWidget(self.rbPostconfN,0,2)

        TabPageLayout_3.addWidget(self.buttonGroup2,0,0)

        self.groupBox10 = QGroupBox(self.TabPage_3,"groupBox10")
        self.groupBox10.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,0,0,self.groupBox10.sizePolicy().hasHeightForWidth()))
        self.groupBox10.setColumnLayout(0,Qt.Vertical)
        self.groupBox10.layout().setSpacing(6)
        self.groupBox10.layout().setMargin(8)
        groupBox10Layout = QGridLayout(self.groupBox10.layout())
        groupBox10Layout.setAlignment(Qt.AlignTop)

        self.textLabel7 = QLabel(self.groupBox10,"textLabel7")

        groupBox10Layout.addWidget(self.textLabel7,0,0)
        spacer14 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer14,0,1)
        spacer15 = QSpacerItem(80,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addMultiCell(spacer15,1,1,0,1)

        self.pPostFileOpen = QPushButton(self.groupBox10,"pPostFileOpen")

        groupBox10Layout.addWidget(self.pPostFileOpen,0,4)
        spacer12 = QSpacerItem(20,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer12,0,3)

        self.tePostFileOpen = QTextEdit(self.groupBox10,"tePostFileOpen")

        groupBox10Layout.addMultiCellWidget(self.tePostFileOpen,1,1,2,9)

        self.iPostFileOpen = QLineEdit(self.groupBox10,"iPostFileOpen")
        self.iPostFileOpen.setMinimumSize(QSize(340,0))

        groupBox10Layout.addWidget(self.iPostFileOpen,0,2)
        spacer13 = QSpacerItem(20,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer13,0,5)
        spacer13_2 = QSpacerItem(20,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer13_2,0,7)

        self.pPostFileSave = QPushButton(self.groupBox10,"pPostFileSave")

        groupBox10Layout.addWidget(self.pPostFileSave,0,6)

        self.pPostFilePostmap = QPushButton(self.groupBox10,"pPostFilePostmap")

        groupBox10Layout.addWidget(self.pPostFilePostmap,0,8)
        spacer17 = QSpacerItem(110,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer17,0,9)

        TabPageLayout_3.addWidget(self.groupBox10,1,0)
        self.wKorreio.insertTab(self.TabPage_3,QString.fromLatin1(""))

        self.TabPage_4 = QWidget(self.wKorreio,"TabPage_4")
        TabPageLayout_4 = QGridLayout(self.TabPage_4,1,1,8,6,"TabPageLayout_4")

        self.pQueueLoad = QPushButton(self.TabPage_4,"pQueueLoad")
        self.pQueueLoad.setMinimumSize(QSize(87,0))
        self.pQueueLoad.setMaximumSize(QSize(87,32767))

        TabPageLayout_4.addWidget(self.pQueueLoad,1,0)

        self.pQueueDel = QPushButton(self.TabPage_4,"pQueueDel")

        TabPageLayout_4.addWidget(self.pQueueDel,1,5)

        self.splitter7 = QSplitter(self.TabPage_4,"splitter7")
        self.splitter7.setOrientation(QSplitter.Horizontal)

        self.lvQueue = QListView(self.splitter7,"lvQueue")
        self.lvQueue.addColumn(self.__tr("Remetente"))
        self.lvQueue.addColumn(self.__tr("Items"))
        self.lvQueue.setMinimumSize(QSize(400,0))
        self.lvQueue.setAllColumnsShowFocus(1)
        self.lvQueue.setShowSortIndicator(1)
        self.lvQueue.setRootIsDecorated(1)
        self.lvQueue.setResizeMode(QListView.LastColumn)

        self.iQueueMessage = QTextEdit(self.splitter7,"iQueueMessage")

        TabPageLayout_4.addMultiCellWidget(self.splitter7,0,0,0,5)
        spacer90_2 = QSpacerItem(341,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        TabPageLayout_4.addItem(spacer90_2,1,4)

        self.textLabel1_12 = QLabel(self.TabPage_4,"textLabel1_12")

        TabPageLayout_4.addWidget(self.textLabel1_12,1,2)

        self.tlQueueMsgs = QLabel(self.TabPage_4,"tlQueueMsgs")

        TabPageLayout_4.addWidget(self.tlQueueMsgs,1,3)
        spacer2_2 = QSpacerItem(144,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        TabPageLayout_4.addItem(spacer2_2,1,1)
        self.wKorreio.insertTab(self.TabPage_4,QString.fromLatin1(""))

        self.tabConfig = QWidget(self.wKorreio,"tabConfig")
        tabConfigLayout = QGridLayout(self.tabConfig,1,1,8,6,"tabConfigLayout")

        layout176 = QVBoxLayout(None,0,6,"layout176")

        self.lvConfig = QListView(self.tabConfig,"lvConfig")
        self.lvConfig.addColumn(self.__tr("Menu"))
        self.lvConfig.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Expanding,0,0,self.lvConfig.sizePolicy().hasHeightForWidth()))
        self.lvConfig.setMinimumSize(QSize(240,0))
        self.lvConfig.setMargin(0)
        self.lvConfig.setAllColumnsShowFocus(1)
        self.lvConfig.setShowSortIndicator(1)
        self.lvConfig.setRootIsDecorated(1)
        self.lvConfig.setResizeMode(QListView.LastColumn)
        layout176.addWidget(self.lvConfig)
        spacer6 = QSpacerItem(33,35,QSizePolicy.Minimum,QSizePolicy.Fixed)
        layout176.addItem(spacer6)

        tabConfigLayout.addMultiCellLayout(layout176,0,2,0,0)

        self.line512 = QFrame(self.tabConfig,"line512")
        self.line512.setFrameShape(QFrame.HLine)
        self.line512.setFrameShadow(QFrame.Sunken)
        self.line512.setFrameShape(QFrame.HLine)

        tabConfigLayout.addWidget(self.line512,1,1)

        layout528 = QHBoxLayout(None,0,6,"layout528")

        self.pSaveConfig = QPushButton(self.tabConfig,"pSaveConfig")
        self.pSaveConfig.setMinimumSize(QSize(135,0))
        self.pSaveConfig.setMaximumSize(QSize(135,26))
        layout528.addWidget(self.pSaveConfig)
        spacer7 = QSpacerItem(423,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout528.addItem(spacer7)

        tabConfigLayout.addLayout(layout528,2,1)

        self.wsConfig = QWidgetStack(self.tabConfig,"wsConfig")
        self.wsConfig.setFrameShape(QWidgetStack.NoFrame)
        self.wsConfig.setFrameShadow(QWidgetStack.Raised)
        self.wsConfig.setMargin(-8)

        self.sServLdap = QWidget(self.wsConfig,"sServLdap")
        sServLdapLayout = QGridLayout(self.sServLdap,1,1,8,6,"sServLdapLayout")

        layout26 = QVBoxLayout(None,0,0,"layout26")

        self.textLabel3_3_3 = QLabel(self.sServLdap,"textLabel3_3_3")
        self.textLabel3_3_3.setMaximumSize(QSize(32767,21))
        layout26.addWidget(self.textLabel3_3_3)

        self.line24_2 = QFrame(self.sServLdap,"line24_2")
        self.line24_2.setFrameShape(QFrame.HLine)
        self.line24_2.setFrameShadow(QFrame.Sunken)
        self.line24_2.setFrameShape(QFrame.HLine)
        layout26.addWidget(self.line24_2)

        sServLdapLayout.addMultiCellLayout(layout26,0,0,0,1)

        self.frame8 = QFrame(self.sServLdap,"frame8")
        self.frame8.setFrameShape(QFrame.NoFrame)
        self.frame8.setFrameShadow(QFrame.Raised)
        frame8Layout = QGridLayout(self.frame8,1,1,12,6,"frame8Layout")

        self.textLabel4 = QLabel(self.frame8,"textLabel4")
        self.textLabel4.setMinimumSize(QSize(100,0))
        self.textLabel4.setMaximumSize(QSize(100,32767))

        frame8Layout.addWidget(self.textLabel4,0,0)

        self.tLdapUser = QLabel(self.frame8,"tLdapUser")

        frame8Layout.addWidget(self.tLdapUser,5,0)

        self.tLdapPass = QLabel(self.frame8,"tLdapPass")

        frame8Layout.addWidget(self.tLdapPass,6,0)

        self.tLdapName = QLabel(self.frame8,"tLdapName")

        frame8Layout.addWidget(self.tLdapName,2,0)

        self.tLdapHost = QLabel(self.frame8,"tLdapHost")

        frame8Layout.addWidget(self.tLdapHost,3,0)

        self.tLdapPort = QLabel(self.frame8,"tLdapPort")

        frame8Layout.addWidget(self.tLdapPort,3,4)

        self.tLdapBaseDN = QLabel(self.frame8,"tLdapBaseDN")

        frame8Layout.addWidget(self.tLdapBaseDN,4,0)

        self.cbLdapConnection = QComboBox(0,self.frame8,"cbLdapConnection")
        self.cbLdapConnection.setMinimumSize(QSize(230,0))
        self.cbLdapConnection.setMaximumSize(QSize(230,32767))

        frame8Layout.addMultiCellWidget(self.cbLdapConnection,0,0,1,2)

        self.pConfDelLdapConnection = QPushButton(self.frame8,"pConfDelLdapConnection")
        self.pConfDelLdapConnection.setMinimumSize(QSize(40,0))
        self.pConfDelLdapConnection.setMaximumSize(QSize(40,25))

        frame8Layout.addWidget(self.pConfDelLdapConnection,0,3)

        self.iLdapConnection = QLineEdit(self.frame8,"iLdapConnection")

        frame8Layout.addMultiCellWidget(self.iLdapConnection,2,2,1,3)

        self.cbLdapMode = QComboBox(0,self.frame8,"cbLdapMode")
        self.cbLdapMode.setMaximumSize(QSize(80,32767))

        frame8Layout.addWidget(self.cbLdapMode,3,1)

        self.iLdapHost = QLineEdit(self.frame8,"iLdapHost")

        frame8Layout.addMultiCellWidget(self.iLdapHost,3,3,2,3)

        self.iLdapPort = QLineEdit(self.frame8,"iLdapPort")
        self.iLdapPort.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed,0,0,self.iLdapPort.sizePolicy().hasHeightForWidth()))
        self.iLdapPort.setMinimumSize(QSize(50,0))
        self.iLdapPort.setMaximumSize(QSize(50,32767))

        frame8Layout.addWidget(self.iLdapPort,3,5)

        self.cbLdapBaseDN = QComboBox(0,self.frame8,"cbLdapBaseDN")
        self.cbLdapBaseDN.setEditable(1)

        frame8Layout.addMultiCellWidget(self.cbLdapBaseDN,4,4,1,3)

        self.iLdapUser = QLineEdit(self.frame8,"iLdapUser")

        frame8Layout.addMultiCellWidget(self.iLdapUser,5,5,1,3)

        self.iLdapPass = QLineEdit(self.frame8,"iLdapPass")
        self.iLdapPass.setEchoMode(QLineEdit.Password)

        frame8Layout.addMultiCellWidget(self.iLdapPass,6,6,1,3)

        self.cLdapRef = QCheckBox(self.frame8,"cLdapRef")

        frame8Layout.addMultiCellWidget(self.cLdapRef,7,7,0,1)

        self.cLdapCert = QCheckBox(self.frame8,"cLdapCert")

        frame8Layout.addMultiCellWidget(self.cLdapCert,8,8,0,3)

        self.pGetBaseDN = QPushButton(self.frame8,"pGetBaseDN")
        self.pGetBaseDN.setSizePolicy(QSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed,0,0,self.pGetBaseDN.sizePolicy().hasHeightForWidth()))
        self.pGetBaseDN.setMaximumSize(QSize(32767,25))

        frame8Layout.addMultiCellWidget(self.pGetBaseDN,4,4,4,5)

        self.line5 = QFrame(self.frame8,"line5")
        self.line5.setFrameShape(QFrame.HLine)
        self.line5.setFrameShadow(QFrame.Sunken)
        self.line5.setFrameShape(QFrame.HLine)

        frame8Layout.addMultiCellWidget(self.line5,1,1,0,5)

        sServLdapLayout.addWidget(self.frame8,1,0)
        spacer42 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        sServLdapLayout.addItem(spacer42,1,1)
        spacer41 = QSpacerItem(20,100,QSizePolicy.Minimum,QSizePolicy.Expanding)
        sServLdapLayout.addItem(spacer41,2,0)
        self.wsConfig.addWidget(self.sServLdap,0)

        self.WStackPage_14 = QWidget(self.wsConfig,"WStackPage_14")
        WStackPageLayout_12 = QGridLayout(self.WStackPage_14,1,1,8,6,"WStackPageLayout_12")

        layout27 = QVBoxLayout(None,0,0,"layout27")

        self.textLabel3_3_2 = QLabel(self.WStackPage_14,"textLabel3_3_2")
        self.textLabel3_3_2.setMaximumSize(QSize(32767,21))
        layout27.addWidget(self.textLabel3_3_2)

        self.line25 = QFrame(self.WStackPage_14,"line25")
        self.line25.setFrameShape(QFrame.HLine)
        self.line25.setFrameShadow(QFrame.Sunken)
        self.line25.setFrameShape(QFrame.HLine)
        layout27.addWidget(self.line25)

        WStackPageLayout_12.addMultiCellLayout(layout27,0,0,0,1)
        spacer48 = QSpacerItem(21,80,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_12.addItem(spacer48,2,0)
        spacer49 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_12.addItem(spacer49,1,1)

        self.frame7 = QFrame(self.WStackPage_14,"frame7")
        self.frame7.setFrameShape(QFrame.NoFrame)
        self.frame7.setFrameShadow(QFrame.Raised)
        frame7Layout = QGridLayout(self.frame7,1,1,12,6,"frame7Layout")

        self.textLabel6_2 = QLabel(self.frame7,"textLabel6_2")
        self.textLabel6_2.setMinimumSize(QSize(100,0))
        self.textLabel6_2.setMaximumSize(QSize(100,32767))

        frame7Layout.addWidget(self.textLabel6_2,0,0)

        self.tCyrusPartition_3 = QLabel(self.frame7,"tCyrusPartition_3")

        frame7Layout.addWidget(self.tCyrusPartition_3,7,0)

        self.tCyrusPartition = QLabel(self.frame7,"tCyrusPartition")

        frame7Layout.addWidget(self.tCyrusPartition,6,0)

        self.tCyrusUser = QLabel(self.frame7,"tCyrusUser")

        frame7Layout.addWidget(self.tCyrusUser,4,0)

        self.tCyrusPass = QLabel(self.frame7,"tCyrusPass")

        frame7Layout.addWidget(self.tCyrusPass,5,0)
        spacer69 = QSpacerItem(16,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        frame7Layout.addItem(spacer69,7,2)

        self.textLabel7_2 = QLabel(self.frame7,"textLabel7_2")

        frame7Layout.addWidget(self.textLabel7_2,2,0)
        spacer71 = QSpacerItem(180,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7Layout.addMultiCell(spacer71,7,7,3,4)

        self.tCyrusHost = QLabel(self.frame7,"tCyrusHost")

        frame7Layout.addWidget(self.tCyrusHost,3,0)

        self.tCyrusPort = QLabel(self.frame7,"tCyrusPort")

        frame7Layout.addWidget(self.tCyrusPort,3,5)

        self.cbCyrusConnection = QComboBox(0,self.frame7,"cbCyrusConnection")
        self.cbCyrusConnection.setMinimumSize(QSize(230,0))
        self.cbCyrusConnection.setMaximumSize(QSize(230,32767))

        frame7Layout.addMultiCellWidget(self.cbCyrusConnection,0,0,1,3)

        self.pConfDelImapConnection = QPushButton(self.frame7,"pConfDelImapConnection")
        self.pConfDelImapConnection.setMinimumSize(QSize(40,0))
        self.pConfDelImapConnection.setMaximumSize(QSize(40,25))

        frame7Layout.addWidget(self.pConfDelImapConnection,0,4)

        self.iCyrusConnection = QLineEdit(self.frame7,"iCyrusConnection")

        frame7Layout.addMultiCellWidget(self.iCyrusConnection,2,2,1,4)

        self.cbCyrusMode = QComboBox(0,self.frame7,"cbCyrusMode")
        self.cbCyrusMode.setMinimumSize(QSize(91,0))
        self.cbCyrusMode.setMaximumSize(QSize(91,32767))

        frame7Layout.addMultiCellWidget(self.cbCyrusMode,3,3,1,2)

        self.iCyrusHost = QLineEdit(self.frame7,"iCyrusHost")

        frame7Layout.addMultiCellWidget(self.iCyrusHost,3,3,3,4)

        self.iCyrusPort = QLineEdit(self.frame7,"iCyrusPort")
        self.iCyrusPort.setMinimumSize(QSize(50,0))
        self.iCyrusPort.setMaximumSize(QSize(50,32767))

        frame7Layout.addWidget(self.iCyrusPort,3,6)

        self.iCyrusUser = QLineEdit(self.frame7,"iCyrusUser")

        frame7Layout.addMultiCellWidget(self.iCyrusUser,4,4,1,4)

        self.iCyrusPass = QLineEdit(self.frame7,"iCyrusPass")
        self.iCyrusPass.setEchoMode(QLineEdit.Password)

        frame7Layout.addMultiCellWidget(self.iCyrusPass,5,5,1,4)

        self.iCyrusPart = QLineEdit(self.frame7,"iCyrusPart")

        frame7Layout.addMultiCellWidget(self.iCyrusPart,6,6,1,4)

        self.iCyrusSievePort = QLineEdit(self.frame7,"iCyrusSievePort")
        self.iCyrusSievePort.setMinimumSize(QSize(60,0))
        self.iCyrusSievePort.setMaximumSize(QSize(60,32767))

        frame7Layout.addWidget(self.iCyrusSievePort,7,1)

        self.line6 = QFrame(self.frame7,"line6")
        self.line6.setFrameShape(QFrame.HLine)
        self.line6.setFrameShadow(QFrame.Sunken)
        self.line6.setFrameShape(QFrame.HLine)

        frame7Layout.addMultiCellWidget(self.line6,1,1,0,6)

        WStackPageLayout_12.addWidget(self.frame7,1,0)
        self.wsConfig.addWidget(self.WStackPage_14,1)

        self.WStackPage_15 = QWidget(self.wsConfig,"WStackPage_15")
        WStackPageLayout_13 = QGridLayout(self.WStackPage_15,1,1,8,6,"WStackPageLayout_13")

        layout28 = QVBoxLayout(None,0,0,"layout28")

        self.textLabel3_3 = QLabel(self.WStackPage_15,"textLabel3_3")
        self.textLabel3_3.setMaximumSize(QSize(32767,21))
        layout28.addWidget(self.textLabel3_3)

        self.line26 = QFrame(self.WStackPage_15,"line26")
        self.line26.setFrameShape(QFrame.HLine)
        self.line26.setFrameShadow(QFrame.Sunken)
        self.line26.setFrameShape(QFrame.HLine)
        layout28.addWidget(self.line26)

        WStackPageLayout_13.addMultiCellLayout(layout28,0,0,0,1)

        self.frame4 = QFrame(self.WStackPage_15,"frame4")
        self.frame4.setFrameShape(QFrame.NoFrame)
        self.frame4.setFrameShadow(QFrame.Raised)
        frame4Layout = QGridLayout(self.frame4,1,1,12,6,"frame4Layout")

        self.line7 = QFrame(self.frame4,"line7")
        self.line7.setFrameShape(QFrame.HLine)
        self.line7.setFrameShadow(QFrame.Sunken)
        self.line7.setFrameShape(QFrame.HLine)

        frame4Layout.addMultiCellWidget(self.line7,1,1,0,4)

        self.textLabel8 = QLabel(self.frame4,"textLabel8")
        self.textLabel8.setMinimumSize(QSize(100,0))

        frame4Layout.addWidget(self.textLabel8,0,0)

        self.tCyrusPass_2 = QLabel(self.frame4,"tCyrusPass_2")

        frame4Layout.addWidget(self.tCyrusPass_2,5,0)

        self.textLabel9 = QLabel(self.frame4,"textLabel9")

        frame4Layout.addWidget(self.textLabel9,2,0)

        self.tCyrusHost_2 = QLabel(self.frame4,"tCyrusHost_2")

        frame4Layout.addWidget(self.tCyrusHost_2,3,0)

        self.tCyrusPort_2 = QLabel(self.frame4,"tCyrusPort_2")

        frame4Layout.addWidget(self.tCyrusPort_2,3,3)

        self.tCyrusUser_2 = QLabel(self.frame4,"tCyrusUser_2")

        frame4Layout.addWidget(self.tCyrusUser_2,4,0)

        self.cbSSHConnection = QComboBox(0,self.frame4,"cbSSHConnection")
        self.cbSSHConnection.setMinimumSize(QSize(230,0))

        frame4Layout.addWidget(self.cbSSHConnection,0,1)

        self.pConfDelSshConnection = QPushButton(self.frame4,"pConfDelSshConnection")
        self.pConfDelSshConnection.setMinimumSize(QSize(40,0))
        self.pConfDelSshConnection.setMaximumSize(QSize(40,25))

        frame4Layout.addWidget(self.pConfDelSshConnection,0,2)

        self.iSSHConnection = QLineEdit(self.frame4,"iSSHConnection")

        frame4Layout.addMultiCellWidget(self.iSSHConnection,2,2,1,2)

        self.iSshHost = QLineEdit(self.frame4,"iSshHost")

        frame4Layout.addMultiCellWidget(self.iSshHost,3,3,1,2)

        self.iSshPort = QLineEdit(self.frame4,"iSshPort")
        self.iSshPort.setMinimumSize(QSize(50,0))
        self.iSshPort.setMaximumSize(QSize(50,32767))

        frame4Layout.addWidget(self.iSshPort,3,4)

        self.iSshUser = QLineEdit(self.frame4,"iSshUser")

        frame4Layout.addMultiCellWidget(self.iSshUser,4,4,1,2)

        self.iSshPass = QLineEdit(self.frame4,"iSshPass")
        self.iSshPass.setEchoMode(QLineEdit.Password)

        frame4Layout.addMultiCellWidget(self.iSshPass,5,5,1,2)

        WStackPageLayout_13.addWidget(self.frame4,1,0)
        spacer52 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_13.addItem(spacer52,1,1)
        spacer51 = QSpacerItem(20,180,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_13.addItem(spacer51,2,0)
        self.wsConfig.addWidget(self.WStackPage_15,2)

        self.WStackPage_16 = QWidget(self.wsConfig,"WStackPage_16")
        WStackPageLayout_14 = QGridLayout(self.WStackPage_16,1,1,8,6,"WStackPageLayout_14")
        spacer102 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_14.addItem(spacer102,2,0)

        layout21_2 = QVBoxLayout(None,0,0,"layout21_2")

        self.textLabel10_4 = QLabel(self.WStackPage_16,"textLabel10_4")
        self.textLabel10_4.setMaximumSize(QSize(32767,20))
        layout21_2.addWidget(self.textLabel10_4)

        self.line19_2 = QFrame(self.WStackPage_16,"line19_2")
        self.line19_2.setFrameShape(QFrame.HLine)
        self.line19_2.setFrameShadow(QFrame.Sunken)
        self.line19_2.setFrameShape(QFrame.HLine)
        layout21_2.addWidget(self.line19_2)

        WStackPageLayout_14.addMultiCellLayout(layout21_2,0,0,0,1)

        self.frame308 = QFrame(self.WStackPage_16,"frame308")
        self.frame308.setMinimumSize(QSize(400,0))
        self.frame308.setFrameShape(QFrame.NoFrame)
        self.frame308.setFrameShadow(QFrame.Raised)
        frame308Layout = QGridLayout(self.frame308,1,1,8,6,"frame308Layout")

        self.frame11 = QFrame(self.frame308,"frame11")
        self.frame11.setFrameShape(QFrame.NoFrame)
        self.frame11.setFrameShadow(QFrame.Raised)
        frame11Layout = QGridLayout(self.frame11,1,1,15,6,"frame11Layout")

        self.tConfShowSshServer = QLabel(self.frame11,"tConfShowSshServer")

        frame11Layout.addWidget(self.tConfShowSshServer,0,0)

        self.tConfShowSshUser = QLabel(self.frame11,"tConfShowSshUser")

        frame11Layout.addWidget(self.tConfShowSshUser,1,0)

        frame308Layout.addWidget(self.frame11,5,0)

        layout23 = QVBoxLayout(None,0,0,"layout23")

        self.textLabel10_3 = QLabel(self.frame308,"textLabel10_3")
        self.textLabel10_3.setMaximumSize(QSize(32767,20))
        layout23.addWidget(self.textLabel10_3)

        self.line21_2 = QFrame(self.frame308,"line21_2")
        self.line21_2.setFrameShape(QFrame.HLine)
        self.line21_2.setFrameShadow(QFrame.Sunken)
        self.line21_2.setFrameShape(QFrame.HLine)
        layout23.addWidget(self.line21_2)

        frame308Layout.addLayout(layout23,4,0)

        self.frame10 = QFrame(self.frame308,"frame10")
        self.frame10.setFrameShape(QFrame.NoFrame)
        self.frame10.setFrameShadow(QFrame.Raised)
        frame10Layout = QGridLayout(self.frame10,1,1,15,6,"frame10Layout")

        self.tConfShowLdapServer = QLabel(self.frame10,"tConfShowLdapServer")

        frame10Layout.addWidget(self.tConfShowLdapServer,0,0)

        self.tConfShowLdapUser = QLabel(self.frame10,"tConfShowLdapUser")

        frame10Layout.addWidget(self.tConfShowLdapUser,1,0)

        self.tConfShowLdapBaseDN = QLabel(self.frame10,"tConfShowLdapBaseDN")

        frame10Layout.addWidget(self.tConfShowLdapBaseDN,2,0)

        frame308Layout.addWidget(self.frame10,3,0)

        layout22 = QVBoxLayout(None,0,0,"layout22")

        self.textLabel10_2 = QLabel(self.frame308,"textLabel10_2")
        self.textLabel10_2.setMaximumSize(QSize(32767,20))
        layout22.addWidget(self.textLabel10_2)

        self.line20 = QFrame(self.frame308,"line20")
        self.line20.setFrameShape(QFrame.HLine)
        self.line20.setFrameShadow(QFrame.Sunken)
        self.line20.setFrameShape(QFrame.HLine)
        layout22.addWidget(self.line20)

        frame308Layout.addLayout(layout22,2,0)

        self.frame9 = QFrame(self.frame308,"frame9")
        self.frame9.setFrameShape(QFrame.NoFrame)
        self.frame9.setFrameShadow(QFrame.Raised)
        frame9Layout = QGridLayout(self.frame9,1,1,15,6,"frame9Layout")

        self.tConfShowImapServer = QLabel(self.frame9,"tConfShowImapServer")

        frame9Layout.addWidget(self.tConfShowImapServer,0,0)

        self.tConfShowImapUser = QLabel(self.frame9,"tConfShowImapUser")

        frame9Layout.addWidget(self.tConfShowImapUser,1,0)

        self.tConfShowImapSep = QLabel(self.frame9,"tConfShowImapSep")

        frame9Layout.addWidget(self.tConfShowImapSep,2,0)

        frame308Layout.addWidget(self.frame9,1,0)

        layout21 = QVBoxLayout(None,0,0,"layout21")

        self.textLabel10 = QLabel(self.frame308,"textLabel10")
        self.textLabel10.setMaximumSize(QSize(32767,20))
        layout21.addWidget(self.textLabel10)

        self.line19 = QFrame(self.frame308,"line19")
        self.line19.setFrameShape(QFrame.HLine)
        self.line19.setFrameShadow(QFrame.Sunken)
        self.line19.setFrameShape(QFrame.HLine)
        layout21.addWidget(self.line19)

        frame308Layout.addLayout(layout21,0,0)

        WStackPageLayout_14.addWidget(self.frame308,1,0)
        spacer1315 = QSpacerItem(131,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_14.addItem(spacer1315,1,1)
        self.wsConfig.addWidget(self.WStackPage_16,3)

        self.WStackPage_17 = QWidget(self.wsConfig,"WStackPage_17")
        WStackPageLayout_15 = QGridLayout(self.WStackPage_17,1,1,8,6,"WStackPageLayout_15")

        layout25_2_2_2 = QVBoxLayout(None,0,0,"layout25_2_2_2")

        self.textLabel3_3_2_3_2_2_2 = QLabel(self.WStackPage_17,"textLabel3_3_2_3_2_2_2")
        self.textLabel3_3_2_3_2_2_2.setMaximumSize(QSize(32767,21))
        layout25_2_2_2.addWidget(self.textLabel3_3_2_3_2_2_2)

        self.line23_2_2_2 = QFrame(self.WStackPage_17,"line23_2_2_2")
        self.line23_2_2_2.setFrameShape(QFrame.HLine)
        self.line23_2_2_2.setFrameShadow(QFrame.Sunken)
        self.line23_2_2_2.setFrameShape(QFrame.HLine)
        layout25_2_2_2.addWidget(self.line23_2_2_2)

        WStackPageLayout_15.addMultiCellLayout(layout25_2_2_2,0,0,0,1)
        spacer1301 = QSpacerItem(21,190,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_15.addItem(spacer1301,2,0)
        spacer1300 = QSpacerItem(80,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_15.addItem(spacer1300,1,1)

        self.frame307_2 = QFrame(self.WStackPage_17,"frame307_2")
        self.frame307_2.setFrameShape(QFrame.NoFrame)
        self.frame307_2.setFrameShadow(QFrame.Raised)
        frame307_2Layout = QGridLayout(self.frame307_2,1,1,8,6,"frame307_2Layout")

        self.textLabel1_3_2_3_2_3_2 = QLabel(self.frame307_2,"textLabel1_3_2_3_2_3_2")

        frame307_2Layout.addWidget(self.textLabel1_3_2_3_2_3_2,1,0)

        layout522_3 = QVBoxLayout(None,0,0,"layout522_3")

        self.textLabel1_5_3 = QLabel(self.frame307_2,"textLabel1_5_3")
        layout522_3.addWidget(self.textLabel1_5_3)

        self.line506_3 = QFrame(self.frame307_2,"line506_3")
        self.line506_3.setFrameShape(QFrame.HLine)
        self.line506_3.setFrameShadow(QFrame.Sunken)
        self.line506_3.setFrameShape(QFrame.HLine)
        layout522_3.addWidget(self.line506_3)

        frame307_2Layout.addMultiCellLayout(layout522_3,0,0,0,2)
        spacer86_2 = QSpacerItem(90,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame307_2Layout.addItem(spacer86_2,1,2)
        spacer175 = QSpacerItem(380,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame307_2Layout.addMultiCell(spacer175,2,2,0,2)

        self.cbConfLdapCompleteUser = QComboBox(0,self.frame307_2,"cbConfLdapCompleteUser")
        self.cbConfLdapCompleteUser.setEditable(1)

        frame307_2Layout.addWidget(self.cbConfLdapCompleteUser,1,1)

        WStackPageLayout_15.addWidget(self.frame307_2,1,0)
        self.wsConfig.addWidget(self.WStackPage_17,4)

        self.WStackPage_18 = QWidget(self.wsConfig,"WStackPage_18")
        WStackPageLayout_16 = QGridLayout(self.WStackPage_18,1,1,8,6,"WStackPageLayout_16")

        layout25 = QVBoxLayout(None,0,0,"layout25")

        self.textLabel3_3_2_3 = QLabel(self.WStackPage_18,"textLabel3_3_2_3")
        self.textLabel3_3_2_3.setMaximumSize(QSize(32767,21))
        layout25.addWidget(self.textLabel3_3_2_3)

        self.line23 = QFrame(self.WStackPage_18,"line23")
        self.line23.setFrameShape(QFrame.HLine)
        self.line23.setFrameShadow(QFrame.Sunken)
        self.line23.setFrameShape(QFrame.HLine)
        layout25.addWidget(self.line23)

        WStackPageLayout_16.addMultiCellLayout(layout25,0,0,0,1)
        spacer1309_3 = QSpacerItem(21,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_16.addItem(spacer1309_3,2,0)
        spacer1304 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_16.addItem(spacer1304,1,1)

        self.frame7_3 = QFrame(self.WStackPage_18,"frame7_3")
        self.frame7_3.setMinimumSize(QSize(340,0))
        self.frame7_3.setFrameShape(QFrame.NoFrame)
        self.frame7_3.setFrameShadow(QFrame.Raised)
        frame7_3Layout = QGridLayout(self.frame7_3,1,1,8,6,"frame7_3Layout")

        layout530 = QVBoxLayout(None,0,0,"layout530")

        self.textLabel6_2_3 = QLabel(self.frame7_3,"textLabel6_2_3")
        self.textLabel6_2_3.setMinimumSize(QSize(100,0))
        layout530.addWidget(self.textLabel6_2_3)

        self.line9 = QFrame(self.frame7_3,"line9")
        self.line9.setFrameShape(QFrame.HLine)
        self.line9.setFrameShadow(QFrame.Sunken)
        self.line9.setFrameShape(QFrame.HLine)
        layout530.addWidget(self.line9)

        frame7_3Layout.addMultiCellLayout(layout530,0,0,0,3)

        layout531 = QVBoxLayout(None,0,0,"layout531")

        self.textLabel7_2_3 = QLabel(self.frame7_3,"textLabel7_2_3")
        layout531.addWidget(self.textLabel7_2_3)

        self.line6_3 = QFrame(self.frame7_3,"line6_3")
        self.line6_3.setFrameShape(QFrame.HLine)
        self.line6_3.setFrameShadow(QFrame.Sunken)
        self.line6_3.setFrameShape(QFrame.HLine)
        layout531.addWidget(self.line6_3)

        frame7_3Layout.addMultiCellLayout(layout531,3,3,0,3)

        self.lvConfImapFolders = QListView(self.frame7_3,"lvConfImapFolders")
        self.lvConfImapFolders.addColumn(self.__tr("Nome"))
        self.lvConfImapFolders.addColumn(self.__tr("Auto-expire"))
        self.lvConfImapFolders.addColumn(self.__tr("ACL anyone"))
        self.lvConfImapFolders.setMinimumSize(QSize(340,140))
        self.lvConfImapFolders.setMaximumSize(QSize(340,140))
        self.lvConfImapFolders.setAllColumnsShowFocus(1)
        self.lvConfImapFolders.setResizeMode(QListView.AllColumns)

        frame7_3Layout.addMultiCellWidget(self.lvConfImapFolders,1,1,0,3)

        self.frame94 = QFrame(self.frame7_3,"frame94")
        self.frame94.setMaximumSize(QSize(340,32767))
        self.frame94.setFrameShape(QFrame.NoFrame)
        self.frame94.setFrameShadow(QFrame.Raised)
        frame94Layout = QGridLayout(self.frame94,1,1,0,6,"frame94Layout")

        layout174 = QVBoxLayout(None,0,0,"layout174")

        self.textLabel1_11 = QLabel(self.frame94,"textLabel1_11")
        self.textLabel1_11.setSizePolicy(QSizePolicy(QSizePolicy.Minimum,QSizePolicy.Preferred,0,0,self.textLabel1_11.sizePolicy().hasHeightForWidth()))
        layout174.addWidget(self.textLabel1_11)

        self.textLabel1_11_2 = QLabel(self.frame94,"textLabel1_11_2")
        self.textLabel1_11_2.setSizePolicy(QSizePolicy(QSizePolicy.Minimum,QSizePolicy.Preferred,0,0,self.textLabel1_11_2.sizePolicy().hasHeightForWidth()))
        layout174.addWidget(self.textLabel1_11_2)

        self.textLabel2_7 = QLabel(self.frame94,"textLabel2_7")
        self.textLabel2_7.setSizePolicy(QSizePolicy(QSizePolicy.Minimum,QSizePolicy.Preferred,0,0,self.textLabel2_7.sizePolicy().hasHeightForWidth()))
        layout174.addWidget(self.textLabel2_7)

        frame94Layout.addMultiCellLayout(layout174,0,2,0,0)

        layout175 = QVBoxLayout(None,0,6,"layout175")

        self.iConfImapFolder = QLineEdit(self.frame94,"iConfImapFolder")
        self.iConfImapFolder.setMinimumSize(QSize(100,0))
        layout175.addWidget(self.iConfImapFolder)

        self.iConfImapExpire = QLineEdit(self.frame94,"iConfImapExpire")
        layout175.addWidget(self.iConfImapExpire)

        self.cbConfImapACLp = QComboBox(0,self.frame94,"cbConfImapACLp")
        layout175.addWidget(self.cbConfImapACLp)

        frame94Layout.addMultiCellLayout(layout175,0,2,1,1)

        self.pConfImapFoldersAdd = QPushButton(self.frame94,"pConfImapFoldersAdd")
        self.pConfImapFoldersAdd.setMinimumSize(QSize(30,0))
        self.pConfImapFoldersAdd.setMaximumSize(QSize(30,32767))

        frame94Layout.addWidget(self.pConfImapFoldersAdd,0,2)

        self.pConfImapFoldersDel = QPushButton(self.frame94,"pConfImapFoldersDel")
        self.pConfImapFoldersDel.setMinimumSize(QSize(30,0))
        self.pConfImapFoldersDel.setMaximumSize(QSize(30,32767))

        frame94Layout.addWidget(self.pConfImapFoldersDel,0,3)

        self.textLabel1_11_2_2 = QLabel(self.frame94,"textLabel1_11_2_2")

        frame94Layout.addWidget(self.textLabel1_11_2_2,1,2)
        spacer367 = QSpacerItem(51,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame94Layout.addMultiCell(spacer367,2,2,2,3)

        frame7_3Layout.addMultiCellWidget(self.frame94,2,2,0,3)

        self.textLabel1_10 = QLabel(self.frame7_3,"textLabel1_10")
        self.textLabel1_10.setMinimumSize(QSize(70,0))

        frame7_3Layout.addWidget(self.textLabel1_10,4,0)

        self.iConfImapQuotaMbytes = QLineEdit(self.frame7_3,"iConfImapQuotaMbytes")
        self.iConfImapQuotaMbytes.setMinimumSize(QSize(120,0))
        self.iConfImapQuotaMbytes.setMaximumSize(QSize(120,32767))
        self.iConfImapQuotaMbytes.setAlignment(QLineEdit.AlignRight)

        frame7_3Layout.addWidget(self.iConfImapQuotaMbytes,4,1)

        self.textLabel1_7 = QLabel(self.frame7_3,"textLabel1_7")

        frame7_3Layout.addWidget(self.textLabel1_7,4,2)
        spacer368 = QSpacerItem(151,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame7_3Layout.addItem(spacer368,4,3)

        WStackPageLayout_16.addWidget(self.frame7_3,1,0)
        self.wsConfig.addWidget(self.WStackPage_18,5)

        self.WStackPage_19 = QWidget(self.wsConfig,"WStackPage_19")
        WStackPageLayout_17 = QGridLayout(self.WStackPage_19,1,1,8,6,"WStackPageLayout_17")

        layout25_2 = QVBoxLayout(None,0,0,"layout25_2")

        self.textLabel3_3_2_3_2 = QLabel(self.WStackPage_19,"textLabel3_3_2_3_2")
        self.textLabel3_3_2_3_2.setMaximumSize(QSize(32767,21))
        layout25_2.addWidget(self.textLabel3_3_2_3_2)

        self.line23_2 = QFrame(self.WStackPage_19,"line23_2")
        self.line23_2.setFrameShape(QFrame.HLine)
        self.line23_2.setFrameShadow(QFrame.Sunken)
        self.line23_2.setFrameShape(QFrame.HLine)
        layout25_2.addWidget(self.line23_2)

        WStackPageLayout_17.addLayout(layout25_2,0,0)
        spacer51_2 = QSpacerItem(20,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_17.addItem(spacer51_2,2,0)

        self.frame4_2 = QFrame(self.WStackPage_19,"frame4_2")
        self.frame4_2.setFrameShape(QFrame.NoFrame)
        self.frame4_2.setFrameShadow(QFrame.Raised)
        frame4_2Layout = QGridLayout(self.frame4_2,1,1,12,6,"frame4_2Layout")

        self.cbConfLdapSmbDomain = QComboBox(0,self.frame4_2,"cbConfLdapSmbDomain")
        self.cbConfLdapSmbDomain.setMinimumSize(QSize(230,0))

        frame4_2Layout.addWidget(self.cbConfLdapSmbDomain,0,1)

        self.textLabel8_2 = QLabel(self.frame4_2,"textLabel8_2")
        self.textLabel8_2.setMinimumSize(QSize(100,0))

        frame4_2Layout.addWidget(self.textLabel8_2,0,0)

        self.pConfLdapSmbDomainDel = QPushButton(self.frame4_2,"pConfLdapSmbDomainDel")
        self.pConfLdapSmbDomainDel.setMinimumSize(QSize(40,0))
        self.pConfLdapSmbDomainDel.setMaximumSize(QSize(40,25))

        frame4_2Layout.addWidget(self.pConfLdapSmbDomainDel,0,2)

        self.iConfLdapSmbDomain = QLineEdit(self.frame4_2,"iConfLdapSmbDomain")
        self.iConfLdapSmbDomain.setReadOnly(1)

        frame4_2Layout.addMultiCellWidget(self.iConfLdapSmbDomain,2,2,1,2)

        self.textLabel9_2 = QLabel(self.frame4_2,"textLabel9_2")

        frame4_2Layout.addWidget(self.textLabel9_2,2,0)
        spacer346 = QSpacerItem(111,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        frame4_2Layout.addItem(spacer346,2,3)

        self.cbConfLdapSmbProfilePath = QComboBox(0,self.frame4_2,"cbConfLdapSmbProfilePath")
        self.cbConfLdapSmbProfilePath.setEnabled(0)
        self.cbConfLdapSmbProfilePath.setEditable(1)

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbProfilePath,9,9,1,2)

        self.tCyrusHost_2_2_4_2_2 = QLabel(self.frame4_2,"tCyrusHost_2_2_4_2_2")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_4_2_2,12,0)

        self.tCyrusHost_2_2_4_2 = QLabel(self.frame4_2,"tCyrusHost_2_2_4_2")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_4_2,11,0)

        self.iConfLdapSmbHomeDrive = QLineEdit(self.frame4_2,"iConfLdapSmbHomeDrive")

        frame4_2Layout.addMultiCellWidget(self.iConfLdapSmbHomeDrive,10,10,1,2)

        self.tCyrusHost_2_2_2 = QLabel(self.frame4_2,"tCyrusHost_2_2_2")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_2,8,0)

        self.cbConfLdapSmbPrimaryGroup = QComboBox(0,self.frame4_2,"cbConfLdapSmbPrimaryGroup")

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbPrimaryGroup,5,5,1,2)

        self.iConfLdapSmbDrivePath = QLineEdit(self.frame4_2,"iConfLdapSmbDrivePath")

        frame4_2Layout.addMultiCellWidget(self.iConfLdapSmbDrivePath,11,11,1,2)

        self.cbConfLdapSmbLogonScript = QComboBox(0,self.frame4_2,"cbConfLdapSmbLogonScript")
        self.cbConfLdapSmbLogonScript.setEnabled(1)
        self.cbConfLdapSmbLogonScript.setEditable(1)

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbLogonScript,12,12,1,2)

        self.tCyrusHost_2_2_3 = QLabel(self.frame4_2,"tCyrusHost_2_2_3")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_3,5,0)

        self.cbConfLdapSmbProfileType = QComboBox(0,self.frame4_2,"cbConfLdapSmbProfileType")

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbProfileType,8,8,1,2)

        self.tCyrusHost_2_2_4 = QLabel(self.frame4_2,"tCyrusHost_2_2_4")

        frame4_2Layout.addWidget(self.tCyrusHost_2_2_4,10,0)

        self.tCyrusUser_2_2 = QLabel(self.frame4_2,"tCyrusUser_2_2")
        self.tCyrusUser_2_2.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.tCyrusUser_2_2.sizePolicy().hasHeightForWidth()))

        frame4_2Layout.addWidget(self.tCyrusUser_2_2,4,0)

        self.tCyrusUser_2_2_2 = QLabel(self.frame4_2,"tCyrusUser_2_2_2")
        self.tCyrusUser_2_2_2.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Preferred,0,0,self.tCyrusUser_2_2_2.sizePolicy().hasHeightForWidth()))

        frame4_2Layout.addWidget(self.tCyrusUser_2_2_2,3,0)

        self.cConfLdapSmbPwdMustChange = QCheckBox(self.frame4_2,"cConfLdapSmbPwdMustChange")
        self.cConfLdapSmbPwdMustChange.setChecked(1)

        frame4_2Layout.addMultiCellWidget(self.cConfLdapSmbPwdMustChange,6,6,1,2)

        self.pConfLdapSmbGetsambaDomain = QPushButton(self.frame4_2,"pConfLdapSmbGetsambaDomain")
        self.pConfLdapSmbGetsambaDomain.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pConfLdapSmbGetsambaDomain.sizePolicy().hasHeightForWidth()))
        self.pConfLdapSmbGetsambaDomain.setMaximumSize(QSize(32767,25))

        frame4_2Layout.addWidget(self.pConfLdapSmbGetsambaDomain,3,4)

        self.pConfLdapSmbGetsambaUnixPoolId = QPushButton(self.frame4_2,"pConfLdapSmbGetsambaUnixPoolId")
        self.pConfLdapSmbGetsambaUnixPoolId.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.pConfLdapSmbGetsambaUnixPoolId.sizePolicy().hasHeightForWidth()))
        self.pConfLdapSmbGetsambaUnixPoolId.setMaximumSize(QSize(32767,25))

        frame4_2Layout.addWidget(self.pConfLdapSmbGetsambaUnixPoolId,4,4)

        self.line7_2 = QFrame(self.frame4_2,"line7_2")
        self.line7_2.setFrameShape(QFrame.HLine)
        self.line7_2.setFrameShadow(QFrame.Sunken)
        self.line7_2.setFrameShape(QFrame.HLine)

        frame4_2Layout.addMultiCellWidget(self.line7_2,1,1,0,4)

        self.line167 = QFrame(self.frame4_2,"line167")
        self.line167.setFrameShape(QFrame.HLine)
        self.line167.setFrameShadow(QFrame.Sunken)
        self.line167.setFrameShape(QFrame.HLine)

        frame4_2Layout.addMultiCellWidget(self.line167,7,7,0,4)

        self.cbConfLdapSmbSIDEntry = QComboBox(0,self.frame4_2,"cbConfLdapSmbSIDEntry")

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbSIDEntry,3,3,1,3)

        self.cbConfLdapSmbCounterEntry = QComboBox(0,self.frame4_2,"cbConfLdapSmbCounterEntry")

        frame4_2Layout.addMultiCellWidget(self.cbConfLdapSmbCounterEntry,4,4,1,3)

        WStackPageLayout_17.addWidget(self.frame4_2,1,0)
        self.wsConfig.addWidget(self.WStackPage_19,6)

        self.WStackPage_20 = QWidget(self.wsConfig,"WStackPage_20")
        WStackPageLayout_18 = QGridLayout(self.WStackPage_20,1,1,8,6,"WStackPageLayout_18")

        layout25_2_2 = QVBoxLayout(None,0,0,"layout25_2_2")

        self.textLabel3_3_2_3_2_2 = QLabel(self.WStackPage_20,"textLabel3_3_2_3_2_2")
        self.textLabel3_3_2_3_2_2.setMaximumSize(QSize(32767,21))
        layout25_2_2.addWidget(self.textLabel3_3_2_3_2_2)

        self.line23_2_2 = QFrame(self.WStackPage_20,"line23_2_2")
        self.line23_2_2.setFrameShape(QFrame.HLine)
        self.line23_2_2.setFrameShadow(QFrame.Sunken)
        self.line23_2_2.setFrameShape(QFrame.HLine)
        layout25_2_2.addWidget(self.line23_2_2)

        WStackPageLayout_18.addMultiCellLayout(layout25_2_2,0,0,0,1)
        spacer1299 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        WStackPageLayout_18.addItem(spacer1299,1,1)
        spacer698 = QSpacerItem(20,63,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_18.addItem(spacer698,2,0)

        self.frame307 = QFrame(self.WStackPage_20,"frame307")
        self.frame307.setFrameShape(QFrame.NoFrame)
        self.frame307.setFrameShadow(QFrame.Raised)
        frame307Layout = QGridLayout(self.frame307,1,1,8,6,"frame307Layout")

        self.textLabel1_3_2_3_2_3 = QLabel(self.frame307,"textLabel1_3_2_3_2_3")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_3,1,0)

        self.iConfLdapSMBuidNumber = QLineEdit(self.frame307,"iConfLdapSMBuidNumber")
        self.iConfLdapSMBuidNumber.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBuidNumber.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.iConfLdapSMBuidNumber,1,1)

        self.textLabel1_3_2_3_2_2_6 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_6")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_6,2,0)

        self.iConfLdapSMBgidNumber = QLineEdit(self.frame307,"iConfLdapSMBgidNumber")
        self.iConfLdapSMBgidNumber.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBgidNumber.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.iConfLdapSMBgidNumber,2,1)

        self.textLabel1_3_2_3_2_2_3_3_3 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_3_3_3")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_3_3_3,9,0)

        self.iConfLdapSMBpwdHistLenght = QLineEdit(self.frame307,"iConfLdapSMBpwdHistLenght")
        self.iConfLdapSMBpwdHistLenght.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBpwdHistLenght.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.iConfLdapSMBpwdHistLenght,5,1)

        self.textLabel1_3_2_3_2_2_3_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_3_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_3_2,5,0)

        self.iConfLdapSMBlockoutDuration = QLineEdit(self.frame307,"iConfLdapSMBlockoutDuration")
        self.iConfLdapSMBlockoutDuration.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBlockoutDuration.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.iConfLdapSMBlockoutDuration,9,1)

        self.iConfLdapSMBminPwdAge = QLineEdit(self.frame307,"iConfLdapSMBminPwdAge")
        self.iConfLdapSMBminPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBminPwdAge.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.iConfLdapSMBminPwdAge,7,1)

        self.cbConfLdapSMBlockoutDuration = QComboBox(0,self.frame307,"cbConfLdapSMBlockoutDuration")
        self.cbConfLdapSMBlockoutDuration.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapSMBlockoutDuration.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.cbConfLdapSMBlockoutDuration,9,2)

        self.textLabel1_3_2_3_2_2_2_3_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_2_3_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_2_3_2,8,0)

        self.textLabel1_3_2_3_2_2_3_3_2_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_3_3_2_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_3_3_2_2,10,0)

        self.iConfLdapSMBminPwdLength = QLineEdit(self.frame307,"iConfLdapSMBminPwdLength")
        self.iConfLdapSMBminPwdLength.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBminPwdLength.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.iConfLdapSMBminPwdLength,4,1)

        self.iConfLdapSMBlockout = QLineEdit(self.frame307,"iConfLdapSMBlockout")
        self.iConfLdapSMBlockout.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBlockout.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.iConfLdapSMBlockout,8,1)

        self.iConfLdapSMBlockoutWindow = QLineEdit(self.frame307,"iConfLdapSMBlockoutWindow")
        self.iConfLdapSMBlockoutWindow.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBlockoutWindow.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.iConfLdapSMBlockoutWindow,10,1)

        self.cbConfLdapSMBmaxPwdAge = QComboBox(0,self.frame307,"cbConfLdapSMBmaxPwdAge")
        self.cbConfLdapSMBmaxPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapSMBmaxPwdAge.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.cbConfLdapSMBmaxPwdAge,6,2)

        self.cbConfLdapSMBlockoutWindow = QComboBox(0,self.frame307,"cbConfLdapSMBlockoutWindow")
        self.cbConfLdapSMBlockoutWindow.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapSMBlockoutWindow.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.cbConfLdapSMBlockoutWindow,10,2)

        self.textLabel1_3_2_3_2_2_4_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_4_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_4_2,6,0)

        self.cbConfLdapSMBminPwdAge = QComboBox(0,self.frame307,"cbConfLdapSMBminPwdAge")
        self.cbConfLdapSMBminPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.cbConfLdapSMBminPwdAge.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.cbConfLdapSMBminPwdAge,7,2)

        self.textLabel1_3_2_3_2_2_2_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_2_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_2_2,4,0)

        self.textLabel1_3_2_3_2_2_5_2 = QLabel(self.frame307,"textLabel1_3_2_3_2_2_5_2")

        frame307Layout.addWidget(self.textLabel1_3_2_3_2_2_5_2,7,0)

        self.iConfLdapSMBmaxPwdAge = QLineEdit(self.frame307,"iConfLdapSMBmaxPwdAge")
        self.iConfLdapSMBmaxPwdAge.setSizePolicy(QSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed,0,0,self.iConfLdapSMBmaxPwdAge.sizePolicy().hasHeightForWidth()))

        frame307Layout.addWidget(self.iConfLdapSMBmaxPwdAge,6,1)

        layout522_2 = QVBoxLayout(None,0,0,"layout522_2")

        self.textLabel1_5_2 = QLabel(self.frame307,"textLabel1_5_2")
        layout522_2.addWidget(self.textLabel1_5_2)

        self.line506_2 = QFrame(self.frame307,"line506_2")
        self.line506_2.setFrameShape(QFrame.HLine)
        self.line506_2.setFrameShadow(QFrame.Sunken)
        self.line506_2.setFrameShape(QFrame.HLine)
        layout522_2.addWidget(self.line506_2)

        frame307Layout.addMultiCellLayout(layout522_2,3,3,0,2)

        layout522 = QVBoxLayout(None,0,0,"layout522")

        self.textLabel1_5 = QLabel(self.frame307,"textLabel1_5")
        layout522.addWidget(self.textLabel1_5)

        self.line506 = QFrame(self.frame307,"line506")
        self.line506.setFrameShape(QFrame.HLine)
        self.line506.setFrameShadow(QFrame.Sunken)
        self.line506.setFrameShape(QFrame.HLine)
        layout522.addWidget(self.line506)

        frame307Layout.addMultiCellLayout(layout522,0,0,0,2)

        WStackPageLayout_18.addWidget(self.frame307,1,0)
        self.wsConfig.addWidget(self.WStackPage_20,7)

        self.WStackPage_21 = QWidget(self.wsConfig,"WStackPage_21")
        WStackPageLayout_19 = QGridLayout(self.WStackPage_21,1,1,8,6,"WStackPageLayout_19")

        layout24 = QVBoxLayout(None,0,0,"layout24")

        self.textLabel3_3_2_2 = QLabel(self.WStackPage_21,"textLabel3_3_2_2")
        self.textLabel3_3_2_2.setMaximumSize(QSize(32767,21))
        layout24.addWidget(self.textLabel3_3_2_2)

        self.line22_4 = QFrame(self.WStackPage_21,"line22_4")
        self.line22_4.setFrameShape(QFrame.HLine)
        self.line22_4.setFrameShadow(QFrame.Sunken)
        self.line22_4.setFrameShape(QFrame.HLine)
        layout24.addWidget(self.line22_4)

        WStackPageLayout_19.addLayout(layout24,0,0)
        spacer48_2 = QSpacerItem(21,20,QSizePolicy.Minimum,QSizePolicy.Expanding)
        WStackPageLayout_19.addItem(spacer48_2,2,0)

        self.frame7_2 = QFrame(self.WStackPage_21,"frame7_2")
        self.frame7_2.setFrameShape(QFrame.NoFrame)
        self.frame7_2.setFrameShadow(QFrame.Raised)
        frame7_2Layout = QGridLayout(self.frame7_2,1,1,12,6,"frame7_2Layout")

        self.cConfLdapSchemaAddAttr = QCheckBox(self.frame7_2,"cConfLdapSchemaAddAttr")
        self.cConfLdapSchemaAddAttr.setChecked(1)

        frame7_2Layout.addWidget(self.cConfLdapSchemaAddAttr,1,0)

        self.cConfLdapSchemaDelAttr = QCheckBox(self.frame7_2,"cConfLdapSchemaDelAttr")
        self.cConfLdapSchemaDelAttr.setChecked(1)

        frame7_2Layout.addWidget(self.cConfLdapSchemaDelAttr,1,1)

        layout47 = QVBoxLayout(None,0,0,"layout47")

        self.textLabel1_9 = QLabel(self.frame7_2,"textLabel1_9")
        layout47.addWidget(self.textLabel1_9)

        self.line43 = QFrame(self.frame7_2,"line43")
        self.line43.setFrameShape(QFrame.HLine)
        self.line43.setFrameShadow(QFrame.Sunken)
        self.line43.setFrameShape(QFrame.HLine)
        layout47.addWidget(self.line43)

        frame7_2Layout.addMultiCellLayout(layout47,0,0,0,1)

        self.fConfLdapSchema = QFrame(self.frame7_2,"fConfLdapSchema")
        self.fConfLdapSchema.setFrameShape(QFrame.NoFrame)
        self.fConfLdapSchema.setFrameShadow(QFrame.Raised)
        fConfLdapSchemaLayout = QGridLayout(self.fConfLdapSchema,1,1,0,6,"fConfLdapSchemaLayout")

        self.pConfLdapDelItem = QPushButton(self.fConfLdapSchema,"pConfLdapDelItem")
        self.pConfLdapDelItem.setMinimumSize(QSize(30,0))
        self.pConfLdapDelItem.setMaximumSize(QSize(30,32767))

        fConfLdapSchemaLayout.addWidget(self.pConfLdapDelItem,1,3)

        self.pConfLdapAddItem = QPushButton(self.fConfLdapSchema,"pConfLdapAddItem")
        self.pConfLdapAddItem.setMinimumSize(QSize(30,0))
        self.pConfLdapAddItem.setMaximumSize(QSize(30,32767))

        fConfLdapSchemaLayout.addWidget(self.pConfLdapAddItem,1,2)

        self.iConfLdapAttr = QLineEdit(self.fConfLdapSchema,"iConfLdapAttr")

        fConfLdapSchemaLayout.addWidget(self.iConfLdapAttr,1,0)

        self.iConfLdapValue = QLineEdit(self.fConfLdapSchema,"iConfLdapValue")
        self.iConfLdapValue.setEnabled(0)

        fConfLdapSchemaLayout.addWidget(self.iConfLdapValue,1,1)
        spacer62 = QSpacerItem(82,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        fConfLdapSchemaLayout.addItem(spacer62,1,4)

        self.lvConfLdapSchema = QListView(self.fConfLdapSchema,"lvConfLdapSchema")
        self.lvConfLdapSchema.addColumn(self.__tr("Attributo"))
        self.lvConfLdapSchema.addColumn(self.__tr("Valor"))
        self.lvConfLdapSchema.setMinimumSize(QSize(0,200))
        self.lvConfLdapSchema.setAllColumnsShowFocus(1)
        self.lvConfLdapSchema.setRootIsDecorated(1)
        self.lvConfLdapSchema.setResizeMode(QListView.AllColumns)

        fConfLdapSchemaLayout.addMultiCellWidget(self.lvConfLdapSchema,0,0,0,4)

        frame7_2Layout.addMultiCellWidget(self.fConfLdapSchema,2,2,0,1)

        self.line42 = QFrame(self.frame7_2,"line42")
        self.line42.setFrameShape(QFrame.HLine)
        self.line42.setFrameShadow(QFrame.Sunken)
        self.line42.setFrameShape(QFrame.HLine)

        frame7_2Layout.addMultiCellWidget(self.line42,3,3,0,1)

        WStackPageLayout_19.addWidget(self.frame7_2,1,0)
        self.wsConfig.addWidget(self.WStackPage_21,8)

        self.WStackPage_22 = QWidget(self.wsConfig,"WStackPage_22")
        WStackPageLayout_20 = QGridLayout(self.WStackPage_22,1,1,8,6,"WStackPageLayout_20")

        layout24_2 = QVBoxLayout(None,0,0,"layout24_2")

        self.textLabel3_3_2_2_2 = QLabel(self.WStackPage_22,"textLabel3_3_2_2_2")
        self.textLabel3_3_2_2_2.setMaximumSize(QSize(32767,21))
        layout24_2.addWidget(self.textLabel3_3_2_2_2)

        self.line22_4_2 = QFrame(self.WStackPage_22,"line22_4_2")
        self.line22_4_2.setFrameShape(QFrame.HLine)
        self.line22_4_2.setFrameShadow(QFrame.Sunken)
        self.line22_4_2.setFrameShape(QFrame.HLine)
        layout24_2.addWidget(self.line22_4_2)

        WStackPageLayout_20.addLayout(layout24_2,0,0)

        self.lbLog = QListBox(self.WStackPage_22,"lbLog")

        WStackPageLayout_20.addWidget(self.lbLog,2,0)

        self.buttonGroup2_2 = QButtonGroup(self.WStackPage_22,"buttonGroup2_2")
        self.buttonGroup2_2.setFrameShape(QButtonGroup.NoFrame)
        self.buttonGroup2_2.setColumnLayout(0,Qt.Vertical)
        self.buttonGroup2_2.layout().setSpacing(6)
        self.buttonGroup2_2.layout().setMargin(3)
        buttonGroup2_2Layout = QGridLayout(self.buttonGroup2_2.layout())
        buttonGroup2_2Layout.setAlignment(Qt.AlignTop)

        self.rbConfLogModeRecent = QRadioButton(self.buttonGroup2_2,"rbConfLogModeRecent")
        self.rbConfLogModeRecent.setChecked(1)

        buttonGroup2_2Layout.addWidget(self.rbConfLogModeRecent,0,0)

        self.rbConfLogModeFull = QRadioButton(self.buttonGroup2_2,"rbConfLogModeFull")

        buttonGroup2_2Layout.addWidget(self.rbConfLogModeFull,0,1)
        spacer89 = QSpacerItem(241,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        buttonGroup2_2Layout.addItem(spacer89,0,2)

        WStackPageLayout_20.addWidget(self.buttonGroup2_2,1,0)
        self.wsConfig.addWidget(self.WStackPage_22,9)

        tabConfigLayout.addWidget(self.wsConfig,0,1)
        self.wKorreio.insertTab(self.tabConfig,QString.fromLatin1(""))

        dKorreioLayout.addWidget(self.wKorreio,0,0)



        self.languageChange()

        self.resize(QSize(916,659).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)

        self.connect(self.cbCyrusConnection,SIGNAL("activated(const QString&)"),self.config_imap_set_connection)
        self.connect(self.cbCyrusMode,SIGNAL("activated(const QString&)"),self.config_imap_set_port)
        self.connect(self.cbLdapConnection,SIGNAL("activated(const QString&)"),self.config_ldap_set_connection)
        self.connect(self.cbLdapMode,SIGNAL("activated(const QString&)"),self.config_ldap_set_port)
        self.connect(self.cbLdapStack,SIGNAL("activated(const QString&)"),self.ldap_change_widgetstack)
        self.connect(self.cbPostconf,SIGNAL("activated(const QString&)"),self.postfix_postconf_changed)
        self.connect(self.cbSieveScript,SIGNAL("activated(int)"),self.sieve_get_script)
        self.connect(self.cbSSHConnection,SIGNAL("activated(const QString&)"),self.config_ssh_set_connection)
        self.connect(self.lbSieveScripts,SIGNAL("selectionChanged()"),self.sieve_use_template)
        self.connect(self.lbSieveScripts,SIGNAL("clicked(QListBoxItem*)"),self.sieve_use_template)
        self.connect(self.lvConfig,SIGNAL("selectionChanged()"),self.config_change_widgetstack)
        self.connect(self.lvCyrus,SIGNAL("currentChanged(QListViewItem*)"),self.imap_mailbox_clicked)
        self.connect(self.lvCyrus,SIGNAL("doubleClicked(QListViewItem*)"),self.imap_mailbox_doubleclicked)
        self.connect(self.lvCyrus,SIGNAL("itemRenamed(QListViewItem*,int)"),self.imap_rename_mailbox)
        self.connect(self.lvCyrusGlobal,SIGNAL("doubleClicked(QListViewItem*)"),self.imap_gmailbox_doubleclicked)
        self.connect(self.lvCyrusGlobal,SIGNAL("currentChanged(QListViewItem*)"),self.imap_gmailbox_clicked)
        self.connect(self.lvCyrusGlobal,SIGNAL("itemRenamed(QListViewItem*,int)"),self.imap_gmailbox_rename)
        self.connect(self.lvLdap,SIGNAL("selectionChanged()"),self.ldap_dn_clicked)
        self.connect(self.lvLdap,SIGNAL("doubleClicked(QListViewItem*)"),self.ldap_dn_doubleclicked)
        self.connect(self.lvLdap,SIGNAL("itemRenamed(QListViewItem*,int)"),self.ldap_rename_rdn)
        self.connect(self.lvLdapAttr,SIGNAL("doubleClicked(QListViewItem*)"),self.ldap_rename_attr_value)
        self.connect(self.lvQueue,SIGNAL("currentChanged(QListViewItem*)"),self.queue_get_message)
        self.connect(self.lvSieve,SIGNAL("clicked(QListViewItem*)"),self.sieve_user_clicked)
        self.connect(self.pConfDelImapConnection,SIGNAL("clicked()"),self.config_imap_del_connection)
        self.connect(self.pConfDelLdapConnection,SIGNAL("clicked()"),self.config_ldap_del_connection)
        self.connect(self.pConfDelSshConnection,SIGNAL("clicked()"),self.config_ssh_del_connection)
        self.connect(self.pConfImapFoldersAdd,SIGNAL("clicked()"),self.config_imap_add_default_folder)
        self.connect(self.pConfImapFoldersDel,SIGNAL("clicked()"),self.config_imap_del_default_folder)
        self.connect(self.pCyrAdd,SIGNAL("clicked()"),self.imap_create_mailbox)
        self.connect(self.pCyrDelete,SIGNAL("clicked()"),self.imap_delete_mailbox)
        self.connect(self.pCyrReconstruct,SIGNAL("clicked()"),self.imap_reconstruct)
        self.connect(self.pGetBaseDN,SIGNAL("clicked()"),self.config_ldap_get_basedn)
        self.connect(self.pImapPartitionMove,SIGNAL("clicked()"),self.imap_partition_move)
        self.connect(self.pImapPartitionSearch,SIGNAL("clicked()"),self.imap_partition_search)
        self.connect(self.pImapSearch,SIGNAL("clicked()"),self.imap_search)
        self.connect(self.pImapSelectAll,SIGNAL("clicked()"),self.imap_selectall)
        self.connect(self.pLdapAddAttr,SIGNAL("clicked()"),self.ldap_add_attr)
        self.connect(self.pLdapAddUser,SIGNAL("clicked()"),self.ldap_form_insert_user)
        self.connect(self.pLdapDelete,SIGNAL("clicked()"),self.ldap_remove_entry)
        self.connect(self.pLdapDeleteAttr,SIGNAL("clicked()"),self.ldap_remove_attr)
        self.connect(self.pLdapModify,SIGNAL("clicked()"),self.ldap_modify_clicked)
        self.connect(self.pLdapPasswd,SIGNAL("clicked()"),self.ldap_passwd)
        self.connect(self.pLdapSearch,SIGNAL("clicked()"),self.ldap_search)
        self.connect(self.pPostFileOpen,SIGNAL("clicked()"),self.postfix_open_conf)
        self.connect(self.pPostFilePostmap,SIGNAL("clicked()"),self.postfix_postmap)
        self.connect(self.pPostFileSave,SIGNAL("clicked()"),self.postfix_save_conf)
        self.connect(self.pPostMainSave,SIGNAL("clicked()"),self.postfix_postconf_save)
        self.connect(self.pPostRestart,SIGNAL("clicked()"),self.postfix_restart)
        self.connect(self.pPostStart,SIGNAL("clicked()"),self.postfix_start)
        self.connect(self.pPostStop,SIGNAL("clicked()"),self.postfix_stop)
        self.connect(self.pQueueDel,SIGNAL("clicked()"),self.queue_del_message)
        self.connect(self.pQueueLoad,SIGNAL("clicked()"),self.queue_load)
        self.connect(self.pSaveConfig,SIGNAL("clicked()"),self.config_save)
        self.connect(self.pSieveScriptActive,SIGNAL("clicked()"),self.sieve_set_script)
        self.connect(self.pSieveScriptDisable,SIGNAL("clicked()"),self.sieve_unset_script)
        self.connect(self.pSieveScriptRemove,SIGNAL("clicked()"),self.sieve_del_script)
        self.connect(self.pSieveSearch,SIGNAL("clicked()"),self.sieve_search)
        self.connect(self.pSieveSelectAll,SIGNAL("clicked()"),self.sieve_select_all)
        self.connect(self.rbPostconfAll,SIGNAL("clicked()"),self.postfix_postconf)
        self.connect(self.rbPostconfD,SIGNAL("clicked()"),self.postfix_postconf)
        self.connect(self.rbPostconfN,SIGNAL("clicked()"),self.postfix_postconf)
        self.connect(self.wKorreio,SIGNAL("currentChanged(QWidget*)"),self.korreio_module_changed)
        self.connect(self.cbACL,SIGNAL("activated(int)"),self.imap_acl_wizard)
        self.connect(self.lvImapAcl,SIGNAL("currentChanged(QListViewItem*)"),self.imap_acl_clicked)
        self.connect(self.pImapAclAdd,SIGNAL("clicked()"),self.imap_acl_add)
        self.connect(self.pImapAclDel,SIGNAL("clicked()"),self.imap_acl_del)
        self.connect(self.pLdapAddOu,SIGNAL("clicked()"),self.ldap_insert_ou)
        self.connect(self.lvImapPartition,SIGNAL("selectionChanged()"),self.imap_partition_size)
        self.connect(self.lvImapPartitionGlobal,SIGNAL("selectionChanged()"),self.imap_partition_size)
        self.connect(self.pSetExpire,SIGNAL("clicked()"),self.imap_set_annotation_expire)
        self.connect(self.pSetQuota,SIGNAL("clicked()"),self.imap_set_quota)
        self.connect(self.cbLdapBaseDN,SIGNAL("activated(int)"),self.config_ldap_set_admin)
        self.connect(self.pLdapFormBack,SIGNAL("clicked()"),self.ldap_form_back)
        self.connect(self.pLdapFormNext,SIGNAL("clicked()"),self.ldap_form_next)
        self.connect(self.cLdapFormPosix,SIGNAL("clicked()"),self.ldap_form_posixAccount_enable)
        self.connect(self.iLdapFormUid,SIGNAL("textChanged(const QString&)"),self.ldap_form_uid_changed)
        self.connect(self.pLdapSambaPopulate,SIGNAL("clicked()"),self.ldap_samba_populate)
        self.connect(self.cLdapFormSamba,SIGNAL("clicked()"),self.ldap_form_sambaSamAccount_enable)
        self.connect(self.iLdapFormMail,SIGNAL("textChanged(const QString&)"),self.ldap_form_inetOrgPerson_mail_changed)
        self.connect(self.lvConfLdapSchema,SIGNAL("currentChanged(QListViewItem*)"),self.config_ldap_schema)
        self.connect(self.cConfLdapSchemaAddAttr,SIGNAL("clicked()"),self.config_ldap_schema_checked)
        self.connect(self.cConfLdapSchemaDelAttr,SIGNAL("clicked()"),self.config_ldap_schema_checked)
        self.connect(self.pConfLdapAddItem,SIGNAL("clicked()"),self.config_ldap_add_attr)
        self.connect(self.pConfLdapDelItem,SIGNAL("clicked()"),self.config_ldap_del_attr)
        self.connect(self.cbConfLdapSmbDomain,SIGNAL("activated(int)"),self.config_smb_set_domain)
        self.connect(self.cbConfLdapSmbProfileType,SIGNAL("activated(int)"),self.config_ldap_smb_perfil_changed)
        self.connect(self.pConfLdapSmbDomainDel,SIGNAL("clicked()"),self.config_smb_del_domain)
        self.connect(self.cbLdapFormProfileType,SIGNAL("activated(const QString&)"),self.ldap_form_sambaSamAccount_perfil_clicked)
        self.connect(self.cbLdapFormSambaDomain,SIGNAL("activated(int)"),self.ldap_form_sambaSamAccount_domain_clicked)
        self.connect(self.cLdapFormAst,SIGNAL("clicked()"),self.ldap_form_astSipUser_enable)
        self.connect(self.cLdapFormRadius,SIGNAL("clicked()"),self.ldap_form_radiusProfile_enable)
        self.connect(self.pConfLdapSmbGetsambaUnixPoolId,SIGNAL("clicked()"),self.config_ldap_smb_get_sambaUnixIdPool)
        self.connect(self.pLdapFormSmbShow,SIGNAL("clicked()"),self.ldap_form_sambaSamAccount_show_frame)
        self.connect(self.pConfLdapSmbGetsambaDomain,SIGNAL("clicked()"),self.config_ldap_smb_get_sambaDomain)
        self.connect(self.cbConfLdapSmbSIDEntry,SIGNAL("activated(int)"),self.config_ldap_smb_sambaDomain_clicked)
        self.connect(self.pLdapGetUidNumber,SIGNAL("clicked()"),self.ldap_form_posixAccount_get_uidNumber)
        self.connect(self.rbConfLogModeFull,SIGNAL("clicked()"),self.config_log_mode)
        self.connect(self.rbConfLogModeRecent,SIGNAL("clicked()"),self.config_log_mode)
        self.connect(self.lvLdap,SIGNAL("contextMenuRequested(QListViewItem*,const QPoint&,int)"),self.ldap_menu)

        self.init()


    def languageChange(self):
        self.setCaption(self.__trUtf8("\x4b\x6f\x72\x72\x65\x69\x6f\x20\x2d\x20\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\xc3\xa7\xc3\xa3\x6f\x20\x64\x65\x20\x43\x6f\x72\x72\x65\x69\x6f\x20\x45\x6c\x65\x74\x72\xc3\xb4\x6e\x69\x63\x6f"))
        self.tlConsole.setText(self.__tr("Korreio (c) Copyleft 2008 - Reinaldo de Carvalho <reinaldoc@gmail.com>"))
        self.cbLdapFilter.clear()
        self.cbLdapFilter.insertItem(self.__tr("objectClass=*"))
        self.cbLdapFilter.insertItem(self.__tr("ou=*"))
        self.cbLdapFilter.insertItem(self.__tr("cn=*"))
        self.cbLdapFilter.insertItem(self.__tr("uid=*"))
        self.cbLdapFilter.insertItem(self.__tr("mail=*"))
        self.lvLdap.header().setLabel(0,self.__tr("Distinguished Name"))
        self.pLdapDelete.setText(self.__tr("Remover"))
        self.pLdapSearch.setText(self.__tr("Pesquisar"))
        self.cbLdapStack.clear()
        self.cbLdapStack.insertItem(self.__tr("Ldap Browser"))
        self.cbLdapStack.insertItem(self.__tr("Novo registro"))
        self.cbLdapStack.insertItem(self.__trUtf8("\x4e\x6f\x76\x6f\x20\x72\x65\x67\x69\x73\x74\x72\x6f\x20\x64\x65\x20\x55\x73\x75\xc3\xa1\x72\x69\x6f"))
        self.cbLdapStack.insertItem(self.__tr("Novo registro de Unidade"))
        self.cbLdapStack.insertItem(self.__tr("Trocar Senha"))
        self.cbLdapStack.insertItem(self.__tr("Samba Populate"))
        self.lvLdapAttr.header().setLabel(0,self.__tr("Atributo"))
        self.lvLdapAttr.header().setLabel(1,self.__tr("Valor"))
        self.cbLdapAttr.clear()
        self.cbLdapAttr.insertItem(QString.null)
        self.cbLdapAttr.insertItem(self.__tr("objectClass"))
        self.cbLdapAttr.insertItem(self.__tr("structuralObjectClass"))
        self.cbLdapAttr.insertItem(self.__tr("uid"))
        self.cbLdapAttr.insertItem(self.__tr("cn"))
        self.cbLdapAttr.insertItem(self.__tr("sn"))
        self.cbLdapAttr.insertItem(self.__tr("mail"))
        self.cbLdapAttr.insertItem(self.__tr("gecos"))
        self.cbLdapAttr.insertItem(self.__tr("description"))
        self.cbLdapAttr.insertItem(self.__tr("homeDirectory"))
        self.cbLdapAttr.insertItem(self.__tr("loginShell"))
        self.cbLdapAttr.insertItem(self.__tr("uidNumber"))
        self.cbLdapAttr.insertItem(self.__tr("gidNumber"))
        self.cbLdapAttr.insertItem(self.__tr("userPassword"))
        self.cbLdapAttr.insertItem(self.__tr("shadowLastChange"))
        self.cbLdapAttr.insertItem(self.__tr("shadowMin"))
        self.cbLdapAttr.insertItem(self.__tr("shadowMax"))
        self.cbLdapAttr.insertItem(self.__tr("shadowWarning"))
        self.cbLdapAttr.insertItem(self.__tr("shadowInactive"))
        self.cbLdapAttr.insertItem(self.__tr("shadowExpire"))
        self.cbLdapAttr.insertItem(self.__tr("shadowFlag"))
        self.cbLdapAttr.insertItem(self.__tr("carLicense"))
        self.cbLdapAttr.insertItem(self.__tr("displayName"))
        self.cbLdapAttr.insertItem(self.__tr("homePhone"))
        self.cbLdapAttr.insertItem(self.__tr("l"))
        self.cbLdapAttr.insertItem(self.__tr("street"))
        self.cbLdapAttr.insertItem(self.__tr("postalCode"))
        self.cbLdapAttr.insertItem(self.__tr("o"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLMPassword"))
        self.cbLdapAttr.insertItem(self.__tr("sambaNTPassword"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdLastSet"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogoffTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaKickoffTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdCanChange"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPwdMustChange"))
        self.cbLdapAttr.insertItem(self.__tr("sambaAcctFlags"))
        self.cbLdapAttr.insertItem(self.__tr("sambaHomePath"))
        self.cbLdapAttr.insertItem(self.__tr("sambaHomeDrive"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonScript"))
        self.cbLdapAttr.insertItem(self.__tr("sambaProfilePath"))
        self.cbLdapAttr.insertItem(self.__tr("sambaUserWorkstations"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPrimaryGroupSID"))
        self.cbLdapAttr.insertItem(self.__tr("sambaDomainName"))
        self.cbLdapAttr.insertItem(self.__tr("sambaMungedDial"))
        self.cbLdapAttr.insertItem(self.__tr("sambaBadPasswordCount"))
        self.cbLdapAttr.insertItem(self.__tr("sambaBadPasswordTime"))
        self.cbLdapAttr.insertItem(self.__tr("sambaPasswordHistory"))
        self.cbLdapAttr.insertItem(self.__tr("sambaLogonHours"))
        self.cbLdapAttr.insertItem(self.__tr("mailAlternateAddress"))
        self.cbLdapAttr.insertItem(self.__tr("ipHostNumber"))
        self.cbLdapAttr.insertItem(self.__tr("owner"))
        self.cbLdapAttr.insertItem(self.__tr("manager"))
        self.cbLdapAttr.insertItem(self.__tr("serialNumber"))
        self.cbLdapAttr.insertItem(self.__tr("member"))
        self.cbLdapValue.clear()
        self.cbLdapValue.insertItem(QString.null)
        self.cbLdapValue.insertItem(self.__tr("inetOrgPerson"))
        self.cbLdapValue.insertItem(self.__tr("posixAccount"))
        self.cbLdapValue.insertItem(self.__tr("sambaSamAccount"))
        self.cbLdapValue.insertItem(self.__tr("shadowAccount"))
        self.cbLdapValue.insertItem(self.__tr("top"))
        self.cbLdapValue.insertItem(self.__tr("simpleSecurityObject"))
        self.cbLdapValue.insertItem(self.__tr("organization"))
        self.cbLdapValue.insertItem(self.__tr("organizationalUnit"))
        self.cbLdapValue.insertItem(self.__tr("organizationalRole"))
        self.cbLdapValue.insertItem(self.__tr("groupOfNames"))
        self.cbLdapValue.insertItem(self.__tr("device"))
        self.cbLdapValue.insertItem(self.__tr("ipHost"))
        self.cbLdapValue.insertItem(self.__tr("ipNetwork"))
        self.cbLdapValue.insertItem(self.__tr("referral"))
        self.cbLdapValue.insertItem(self.__tr("extensibleObject"))
        self.pLdapAddAttr.setText(self.__tr("+"))
        self.pLdapDeleteAttr.setText(self.__tr("-"))
        self.pLdapModify.setText(self.__tr("Aplicar"))
        self.textLabel1_2.setText(self.__trUtf8("\x3c\x62\x3e\x4e\x6f\x76\x6f\x20\x72\x65\x67\x69\x73\x74\x72\x6f\x20\x64\x65\x20\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3c\x2f\x62\x3e"))
        self.pLdapFormBack.setText(self.__tr("Voltar"))
        self.pLdapFormNext.setText(self.__trUtf8("\x50\x72\xc3\xb3\x78\x69\x6d\x6f"))
        self.pLdapAddUser.setText(self.__tr("Cadastrar"))
        self.textLabel1_2_3.setText(self.__tr("<b>inetOrgPerson</b>"))
        self.textLabel3_2.setText(self.__tr("Nome:"))
        QToolTip.add(self.textLabel3_2,self.__tr("<b>cn</b>"))
        QToolTip.add(self.iLdapFormCn,self.__tr("<b>Nome Completo</b>"))
        self.textLabel5.setText(self.__tr("E-mail:"))
        QToolTip.add(self.textLabel5,self.__tr("<b>mail</b>"))
        QToolTip.add(self.iLdapFormMail,self.__tr("<b>usuario@exemplo.com.br</b>"))
        self.textLabel5_3.setText(self.__tr("Localidade:"))
        QToolTip.add(self.textLabel5_3,self.__tr("<b>l</b>"))
        self.textLabel3_2_3.setText(self.__trUtf8("\x45\x6e\x64\x65\x72\x65\xc3\xa7\x6f\x3a"))
        QToolTip.add(self.textLabel3_2_3,self.__tr("<b>street</b>"))
        QToolTip.add(self.iLdapFormStreet,self.__tr("<b>Av. Fulano, N 123</b>"))
        QToolTip.add(self.iLdapFormL,self.__tr("<b>Bairro, Cidade, Estado</b>"))
        self.textLabel3_2_4.setText(self.__tr("CEP:"))
        QToolTip.add(self.textLabel3_2_4,self.__tr("<b>postalCode</b>"))
        QToolTip.add(self.iLdapFormPostalCode,self.__tr("<b>66000-000</b>"))
        self.textLabel5_4.setText(self.__tr("Telefone:"))
        QToolTip.add(self.textLabel5_4,self.__tr("<b>homePhone</b>"))
        QToolTip.add(self.iLdapFormHomePhone,self.__tr("<b>+55 (99) 3222-2222</b>"))
        self.textLabel1_3.setText(self.__tr("Senha:"))
        QToolTip.add(self.textLabel1_3,self.__tr("<b>userPassword</b>"))
        self.textLabel1_3_4.setText(self.__tr("Senha (repetir):"))
        QToolTip.add(self.textLabel1_3_4,self.__tr("<b>userPassword</b>"))
        self.textLabel1_2_3_2.setText(self.__tr("<b>posixAccount</b>"))
        self.cLdapFormPosix.setText(QString.null)
        self.textLabel5_2_2.setText(self.__tr("uidNumber:"))
        QToolTip.add(self.textLabel5_2_2,self.__tr("<b>uidNumber</b>"))
        self.textLabel1_3_3_2.setText(self.__tr("Grupo:"))
        QToolTip.add(self.textLabel1_3_3_2,self.__tr("<b>gidNumber</b>"))
        self.textLabel1_3_3.setText(self.__tr("Home:"))
        QToolTip.add(self.textLabel1_3_3,self.__tr("<b>homeDirectory</b>"))
        self.textLabel5_2.setText(self.__tr("Shell:"))
        QToolTip.add(self.textLabel5_2,self.__tr("<b>loginShell</b>"))
        self.iLdapFormGidNumber.setText(self.__tr("100"))
        self.textLabel3_2_2.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        QToolTip.add(self.textLabel3_2_2,self.__tr("<b>uid</b>"))
        self.iLdapFormLoginShell.setText(self.__tr("/bin/bash"))
        self.iLdapFormHomeDirectory.setText(self.__tr("/home"))
        self.iLdapFormUidNumber.setText(self.__tr("1000"))
        self.pLdapGetUidNumber.setText(self.__tr("Get"))
        self.textLabel1_2_3_2_2.setText(self.__tr("<b>sambaSamAccount</b>"))
        self.cLdapFormSamba.setText(QString.null)
        self.textLabel3_2_2_2.setText(self.__trUtf8("\x44\x6f\x6d\xc3\xad\x6e\x69\x6f\x3a"))
        QToolTip.add(self.textLabel3_2_2_2,self.__tr("<b>sambaDomain</b>"))
        self.textLabel1_3_3_2_2.setText(self.__tr("Grupo:"))
        QToolTip.add(self.textLabel1_3_3_2_2,self.__tr("<b>sambaPrimaryGroupSID</b>"))
        self.iLdapFormSambaPwdMustChange.setText(self.__trUtf8("\x54\x72\x6f\x63\x61\x72\x20\x73\x65\x6e\x68\x61\x20\x6e\x6f\x20\x70\x72\xc3\xb3\x78\x69\x6d\x6f\x20\x6c\x6f\x67\x69\x6e"))
        QToolTip.add(self.iLdapFormSambaPwdMustChange,self.__tr("<b>sambaPwdMustChange</b>"))
        self.iLdapFormLogonScript.setText(QString.null)
        self.textLabel1_3_3_3.setText(self.__tr("Drive Path:"))
        QToolTip.add(self.textLabel1_3_3_3,self.__tr("<b>sambaHomePath</b>"))
        self.textLabel5_2_2_2.setText(self.__tr("Perfil:"))
        QToolTip.add(self.textLabel5_2_2_2,self.__tr("<b>sambaProfilePath</b>"))
        self.textLabel1_3_3_3_2.setText(self.__tr("Logon script:"))
        QToolTip.add(self.textLabel1_3_3_3_2,self.__tr("<b>sambaLogonScript</b>"))
        self.iLdapFormProfilePath.setText(QString.null)
        self.textLabel5_2_3.setText(self.__tr("Drive:"))
        QToolTip.add(self.textLabel5_2_3,self.__tr("<b>sambaHomeDrive</b>"))
        self.iLdapFormDrivePath.setText(QString.null)
        self.iLdapFormHomeDrive.setText(QString.null)
        self.cbLdapFormProfileType.clear()
        self.cbLdapFormProfileType.insertItem(self.__tr("Local"))
        self.cbLdapFormProfileType.insertItem(self.__tr("Remoto"))
        self.pLdapFormSmbShow.setText(self.__tr(">>"))
        self.cbLdapFormPrimaryGroup.clear()
        self.cbLdapFormPrimaryGroup.insertItem(self.__tr("Domain Users (513)"))
        self.cbLdapFormPrimaryGroup.insertItem(self.__tr("Domain Guests (514)"))
        self.cbLdapFormPrimaryGroup.insertItem(self.__tr("Domain Admins (512)"))
        self.textLabel1_2_3_2_3.setText(self.__tr("<b>astSipPeer</b>"))
        self.cLdapFormAst.setText(QString.null)
        self.textLabel3_2_2_3.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        QToolTip.add(self.textLabel3_2_2_3,self.__tr("<b>astUsername</b>"))
        self.cLdapFormAstSecret.setText(self.__tr("astSecret"))
        self.textLabel5_2_2_3.setText(self.__tr("Ramal:"))
        QToolTip.add(self.textLabel5_2_2_3,self.__tr("<b>astName</b>"))
        self.iLdapFormAstName.setText(self.__tr("1000"))
        self.textLabel5_2_2_3_2.setText(self.__tr("Porta:"))
        QToolTip.add(self.textLabel5_2_2_3_2,self.__tr("<b>astName</b>"))
        self.iLdapFormAstPort.setText(self.__tr("5070"))
        self.textLabel1_2_3_2_4.setText(self.__tr("<b>radiusProfile</b>"))
        self.cLdapFormRadius.setText(QString.null)
        self.iLdapFormRadiusGroup.setText(self.__tr("dialup"))
        self.textLabel3_2_2_4.setText(self.__tr("Grupo:"))
        QToolTip.add(self.textLabel3_2_2_4,self.__tr("<b>uid</b>"))
        self.textLabel1_2_4.setText(self.__tr("<b>Novo registro de Unidade</b>"))
        self.pLdapAddOu.setText(self.__tr("Cadastrar"))
        self.textLabel2_3.setText(self.__tr("Unidade (ou):"))
        self.textLabel1_2_4_2.setText(self.__tr("<b>Trocar senha</b>"))
        self.textLabel1_3_2_2.setText(self.__tr("Atributo:"))
        self.textLabel1_3_2_4.setText(self.__tr("Senha (repetir):"))
        self.textLabel1_3_2.setText(self.__tr("Senha:"))
        self.cbLdapSambaPassword.setText(self.__tr("sambaLMPassword/sambaNTPassword"))
        self.cbLdapAstPassword.setText(self.__tr("astSecret"))
        self.cbLdapUserPassword.setText(self.__tr("userPassword"))
        self.cbUserPassword.clear()
        self.cbUserPassword.insertItem(self.__tr("{SSHA}"))
        self.cbUserPassword.insertItem(self.__tr("{SMD5}"))
        self.cbUserPassword.insertItem(self.__tr("{CRYPT}"))
        self.cbUserPassword.insertItem(self.__tr("{SHA}"))
        self.cbUserPassword.insertItem(self.__tr("{MD5}"))
        self.cbUserPassword.insertItem(self.__tr("{TEXT}"))
        self.pLdapPasswd.setText(self.__tr("Trocar"))
        self.textLabel1_2_4_2_2.setText(self.__tr("<b>Samba Populate</b>"))
        self.pLdapSambaPopulate.setText(self.__tr("Populate"))
        self.textLabel1_3_2_3_2_2_3_3_2.setText(self.__tr("Extender bloqueio em:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_3_2,self.__tr("<b>sambaLockoutObservationWindow</b>"))
        self.textLabel1_3_2_3_2_2_3_3.setText(self.__trUtf8("\x44\x65\x73\x62\x6c\x6f\x71\x75\x65\x61\x72\x20\x61\x70\xc3\xb3\x73\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_3,self.__tr("<b>sambaLockoutDuration</b>"))
        self.textLabel1_3_2_3_2_2_2.setText(self.__trUtf8("\x54\x61\x6d\x61\x6e\x68\x6f\x20\x6d\xc3\xad\x6e\x69\x6d\x6f\x20\x64\x61\x20\x73\x65\x6e\x68\x61\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_2,self.__tr("<b>sambaMinPwdLength</b>"))
        self.textLabel1_3_2_3_2.setText(self.__tr("uidNumber Inicial:"))
        QToolTip.add(self.textLabel1_3_2_3_2,self.__tr("<b>uidNumber</b>"))
        self.textLabel1_3_2_3_2_2_2_3.setText(self.__trUtf8("\x42\x6c\x6f\x71\x75\x65\x61\x72\x20\x61\x70\xc3\xb3\x73\x20\x65\x72\x72\x6f\x73\x20\x64\x65\x20\x6c\x6f\x67\x6f\x6e\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_2_3,self.__tr("<b>sambaLockoutThreshold</b>"))
        self.textLabel1_3_2_3_2_2_3.setText(self.__trUtf8("\x49\x6d\x70\x65\x64\x69\x72\x20\x72\x65\x75\x74\x69\x6c\x69\x7a\x61\xc3\xa7\xc3\xa3\x6f\x20\x64\x65\x20\x73\x65\x6e\x68\x61\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3,self.__tr("<b>sambaPwdHistoryLength</b>"))
        self.textLabel1_3_2_3_2_2.setText(self.__tr("gidNumber Inicial:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2,self.__tr("<b>gidNumber</b>"))
        self.textLabel1_3_2_3_2_2_5.setText(self.__tr("Intervalo para trocar senha:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_5,self.__tr("<b>sambaMinPwdAge</b>"))
        self.textLabel1_3_2_3_2_2_4.setText(self.__trUtf8("\x45\x78\x69\x67\x69\x72\x20\x74\x72\x6f\x63\x61\x20\x64\x65\x20\x73\x65\x6e\x68\x61\x20\x61\x70\xc3\xb3\x73\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_4,self.__tr("<b>sambaMaxPwdAge</b>"))
        self.textLabel1_3_2_3.setText(self.__tr("Senha (root):"))
        QToolTip.add(self.textLabel1_3_2_3,self.__tr("<b>userPassword<br>sambaLMPassword<br>sambaNTPassword</b>"))
        self.textLabel1_3_2_2_2.setText(self.__trUtf8("\x44\x6f\x6d\xc3\xad\x6e\x69\x6f\x20\x53\x4d\x42\x3a"))
        QToolTip.add(self.textLabel1_3_2_2_2,self.__tr("<b>sambaDomainName</b>"))
        self.textLabel1_3_2_2_2_2.setText(self.__tr("SID:"))
        QToolTip.add(self.textLabel1_3_2_2_2_2,self.__tr("<b>sambaDomainName</b>"))
        self.iLdapSMBdomain.setText(QString.null)
        self.iLdapSMBSID.setText(QString.null)
        self.iLdapSMBuidNumber.setText(QString.null)
        self.iLdapSMBgidNumber.setText(QString.null)
        self.iLdapSMBminPwdLength.setText(QString.null)
        self.iLdapSMBpwdHistLenght.setText(QString.null)
        QToolTip.add(self.iLdapSMBpwdHistLenght,self.__tr("<b>Desativar: 0</b>"))
        self.iLdapSMBmaxPwdAge.setText(QString.null)
        QToolTip.add(self.iLdapSMBmaxPwdAge,self.__tr("<b>Desativar: -1</b>"))
        self.cbLdapSMBmaxPwdAge.clear()
        self.cbLdapSMBmaxPwdAge.insertItem(self.__tr("minutos"))
        self.cbLdapSMBmaxPwdAge.insertItem(self.__tr("horas"))
        self.cbLdapSMBmaxPwdAge.insertItem(self.__tr("dias"))
        self.iLdapSMBminPwdAge.setText(QString.null)
        QToolTip.add(self.iLdapSMBminPwdAge,self.__tr("<b>Desativar: 0</b>"))
        self.cbLdapSMBminPwdAge.clear()
        self.cbLdapSMBminPwdAge.insertItem(self.__tr("minutos"))
        self.cbLdapSMBminPwdAge.insertItem(self.__tr("horas"))
        self.cbLdapSMBminPwdAge.insertItem(self.__tr("dias"))
        self.iLdapSMBlockout.setText(QString.null)
        QToolTip.add(self.iLdapSMBlockout,self.__tr("<b>Desativar: 0</b>"))
        self.iLdapSMBlockoutDuration.setText(QString.null)
        self.cbLdapSMBlockoutDuration.clear()
        self.cbLdapSMBlockoutDuration.insertItem(self.__tr("minutos"))
        self.cbLdapSMBlockoutDuration.insertItem(self.__tr("horas"))
        self.cbLdapSMBlockoutDuration.insertItem(self.__tr("dias"))
        self.iLdapSMBlockoutWindow.setText(QString.null)
        self.cbLdapSMBlockoutWindow.clear()
        self.cbLdapSMBlockoutWindow.insertItem(self.__tr("minutos"))
        self.cbLdapSMBlockoutWindow.insertItem(self.__tr("horas"))
        self.cbLdapSMBlockoutWindow.insertItem(self.__tr("dias"))
        self.wKorreio.changeTab(self.tabLdap,self.__tr("LDAP Manager"))
        self.tCyrUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.pImapSearch.setText(self.__tr("Pesquisar"))
        self.lvCyrus.header().setLabel(0,self.__tr("IMAP Mailboxes"))
        self.lvCyrusGlobal.header().setLabel(0,self.__tr("Global IMAP Mailboxes"))
        self.lvImapAcl.header().setLabel(0,self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f"))
        self.lvImapAcl.header().setLabel(1,self.__trUtf8("\x50\x65\x72\x6d\x69\x73\x73\xc3\xb5\x65\x73"))
        self.cbImapMailbox.clear()
        self.cbImapMailbox.insertItem(self.__tr("user"))
        self.cbImapMailbox.insertItem(self.__tr("global"))
        self.pCyrAdd.setText(self.__tr("+"))
        QToolTip.add(self.pCyrAdd,self.__tr("<b>Criar</b>"))
        self.pCyrDelete.setText(self.__tr("-"))
        QToolTip.add(self.pCyrDelete,self.__tr("<b>Remover</b>"))
        self.pCyrReconstruct.setText(self.__tr("R"))
        QToolTip.add(self.pCyrReconstruct,self.__tr("<b>Reconstruir</b>"))
        self.pSetQuota.setText(self.__tr("OK"))
        self.pSetExpire.setText(self.__tr("OK"))
        self.textLabel2_5.setText(self.__tr("Expirar:"))
        self.textLabel4_2_2.setText(self.__tr("<b>Annotation</b>"))
        self.textLabel4_2.setText(self.__tr("<b>Quota</b>"))
        self.textLabel1_6.setText(self.__tr("dias"))
        self.textLabel1.setText(self.__tr("Utilizado:"))
        self.textLabel2_2.setText(self.__tr("Limite:"))
        self.textLabel2.setText(self.__tr("Kbytes"))
        self.textLabel2_4.setText(self.__tr("Kbytes"))
        self.textLabel2_6.setText(self.__tr("ACL:"))
        QToolTip.add(self.iImapAclUser,self.__trUtf8("\x3c\x62\x3e\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3c\x2f\x62\x3e\x2e\x20\x55\x73\x65\x20\x61\x20\x76\xc3\xad\x72\x67\x75\x6c\x61\x20\x63\x6f\x6d\x6f\x20\x73\x65\x70\x61\x72\x61\x64\x6f\x72\x20\x70\x61\x72\x61\x20\x6d\x75\x6c\x74\x69\x70\x6c\x61\x73\x20\x41\x43\x4c\x73\x2e\x20\x4e\xc3\xa3\x6f\x20\x75\x73\x65\x20\x65\x73\x70\x61\xc3\xa7\x6f\x73\x2e"))
        self.cbACL.clear()
        self.cbACL.insertItem(QString.null)
        self.cbACL.insertItem(self.__tr("Ler"))
        self.cbACL.insertItem(self.__tr("Adicionar"))
        self.cbACL.insertItem(self.__tr("Escrever"))
        self.cbACL.insertItem(self.__tr("Entrega"))
        self.cbACL.insertItem(self.__tr("Total"))
        QToolTip.add(self.cbACL,self.__trUtf8("\x3c\x62\x3e\x4c\x3c\x2f\x62\x3e\x3a\x20\x4c\x69\x73\x74\xc3\xa1\x76\x65\x6c\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x52\x3c\x2f\x62\x3e\x3a\x20\x4c\x65\x72\x20\x6d\x65\x6e\x73\x61\x67\x65\x6e\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x53\x3c\x2f\x62\x3e\x3a\x20\x4c\x65\x72\x20\x73\x74\x61\x74\x75\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x57\x3c\x2f\x62\x3e\x3a\x20\x45\x73\x63\x72\x65\x76\x65\x72\x20\x73\x74\x61\x74\x75\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x49\x3c\x2f\x62\x3e\x3a\x20\x49\x6e\x73\x65\x72\x69\x72\x20\x6d\x65\x6e\x73\x61\x67\x65\x6d\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x43\x3c\x2f\x62\x3e\x3a\x20\x43\x72\x69\x61\x72\x20\x65\x20\x72\x65\x6d\x6f\x76\x65\x72\x20\x73\x75\x62\x2d\x70\x61\x73\x74\x61\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x44\x3c\x2f\x62\x3e\x3a\x20\x52\x65\x6d\x6f\x76\x65\x72\x20\x6d\x65\x6e\x73\x61\x67\x65\x6e\x73\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x50\x3c\x2f\x62\x3e\x3a\x20\x53\x75\x62\x6d\x69\x73\x73\xc3\xa3\x6f\x0a\x3c\x62\x72\x3e\x3c\x62\x3e\x41\x3c\x2f\x62\x3e\x3a\x20\x41\x6c\x74\x65\x72\x61\x72\x20\x70\x65\x72\x6d\x69\x73\x73\xc3\xb5\x65\x73"))
        QWhatsThis.add(self.cbACL,QString.null)
        self.pImapAclAdd.setText(self.__tr("+"))
        QToolTip.add(self.pImapAclAdd,self.__tr("<b>Adicionar</b>"))
        self.pImapAclDel.setText(self.__tr("-"))
        QToolTip.add(self.pImapAclDel,self.__tr("<b>Remover</b>"))
        self.wKorreio.changeTab(self.tabCyrus,self.__tr("Imap Manager"))
        self.lvImapPartition.header().setLabel(0,self.__tr("IMAP Mailboxes"))
        self.lvImapPartition.header().setLabel(1,self.__tr("Partition"))
        self.lvImapPartition.header().setLabel(2,self.__tr("Tamanho"))
        self.lvImapPartitionGlobal.header().setLabel(0,self.__tr("Global IMAP Mailboxes"))
        self.lvImapPartitionGlobal.header().setLabel(1,self.__tr("Partition"))
        self.lvImapPartitionGlobal.header().setLabel(2,self.__tr("Tamanho"))
        self.tCyrUser_2.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.pImapPartitionSearch.setText(self.__tr("Pesquisar"))
        self.cImapSize.setText(self.__tr("Tamanho"))
        self.pImapSelectAll.setText(self.__tr("Selecionar todos"))
        self.textLabel1_2_2.setText(self.__tr("Partition:"))
        self.pImapPartitionMove.setText(self.__tr("Mover"))
        self.tlImapSize.setText(self.__tr("0 Mbytes"))
        self.cImapSizeUpdate.setText(QString.null)
        self.wKorreio.changeTab(self.TabPage,self.__tr("Imap Partitions"))
        self.tCyrUser_2_2.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.cSieveScript.setText(self.__tr("Script ativo"))
        self.pSieveSearch.setText(self.__tr("Pesquisar"))
        self.pSieveSelectAll.setText(self.__tr("Selecionar todos"))
        self.lvSieve.header().setLabel(0,self.__tr("IMAP Users"))
        self.lvSieve.header().setLabel(1,self.__tr("Script ativo"))
        self.textLabel1_2_2_2.setText(self.__tr("Script:"))
        self.pSieveScriptActive.setText(self.__tr("+"))
        QToolTip.add(self.pSieveScriptActive,self.__tr("<b>Ativar</b>"))
        self.pSieveScriptDisable.setText(self.__tr("-"))
        QToolTip.add(self.pSieveScriptDisable,self.__tr("<b>Desativar</b>"))
        self.pSieveScriptRemove.setText(self.__tr("x"))
        QToolTip.add(self.pSieveScriptRemove,self.__tr("<b>Remover</b>"))
        self.lbSieveScripts.clear()
        self.lbSieveScripts.insertItem(self.__tr("Encaminhar"))
        self.lbSieveScripts.insertItem(self.__tr("Encaminhar e salvar"))
        self.lbSieveScripts.insertItem(self.__tr("Mover por remetente"))
        self.lbSieveScripts.insertItem(self.__tr("Mover por remetentes"))
        self.lbSieveScripts.insertItem(self.__tr("Descartar Spam"))
        self.lbSieveScripts.insertItem(self.__tr("Mover Spam"))
        self.lbSieveScripts.insertItem(self.__trUtf8("\x46\xc3\xa9\x72\x69\x61\x73\x2c\x20\x73\x65\x20\x6e\xc3\xa3\x6f\x2d\x53\x70\x61\x6d"))
        self.lbSieveScripts.insertItem(self.__trUtf8("\x46\xc3\xa9\x72\x69\x61\x73"))
        self.textLabel1_8.setText(self.__tr("<b>Modelos:</b>"))
        self.wKorreio.changeTab(self.TabPage_2,self.__tr("Sieve Manager"))
        self.pPostStart.setText(self.__tr("Start Postfix"))
        self.pPostStop.setText(self.__tr("Stop Postfix"))
        self.pPostRestart.setText(self.__tr("Restart Postfix"))
        self.buttonGroup2.setTitle(self.__tr("main.cf"))
        self.pPostMainSave.setText(self.__tr("Salvar"))
        self.textLabel6.setText(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xa3\x6f\x3a"))
        self.rbPostconfD.setText(self.__trUtf8("\x56\x61\x6c\x6f\x72\x65\x73\x20\x70\x61\x64\x72\xc3\xb5\x65\x73"))
        self.rbPostconfAll.setText(self.__trUtf8("\x54\x6f\x64\x61\x73\x20\x6f\x70\xc3\xa7\xc3\xb5\x65\x73"))
        self.textLabel1_4.setText(self.__tr("Modo:"))
        self.rbPostconfN.setText(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xb5\x65\x73\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x64\x61\x73"))
        self.groupBox10.setTitle(self.__tr("Editor de arquivos"))
        self.textLabel7.setText(self.__tr("Arquivo:"))
        self.pPostFileOpen.setText(self.__tr("Abrir"))
        self.iPostFileOpen.setText(self.__tr("/etc/postfix/"))
        self.pPostFileSave.setText(self.__tr("Salvar"))
        self.pPostFilePostmap.setText(self.__tr("Postmap"))
        self.wKorreio.changeTab(self.TabPage_3,self.__tr("Postfix Manager"))
        self.pQueueLoad.setText(self.__tr("Atualizar"))
        self.pQueueDel.setText(self.__tr("Remover"))
        self.lvQueue.header().setLabel(0,self.__tr("Remetente"))
        self.lvQueue.header().setLabel(1,self.__tr("Items"))
        self.textLabel1_12.setText(self.__tr("<b>Total:</b>"))
        self.tlQueueMsgs.setText(self.__tr("0/0"))
        self.wKorreio.changeTab(self.TabPage_4,self.__tr("Queue Manager"))
        self.lvConfig.header().setLabel(0,self.__tr("Menu"))
        self.lvConfig.clear()
        item = QListViewItem(self.lvConfig,None)
        item.setText(0,self.__tr("Log"))

        item_2 = QListViewItem(self.lvConfig,item)
        item_2.setOpen(1)
        item = QListViewItem(item_2,item)
        item.setText(0,self.__tr("LDAP"))
        item_2.setOpen(1)
        item = QListViewItem(item_2,item)
        item.setText(0,self.__tr("IMAP"))
        item_2.setOpen(1)
        item = QListViewItem(item_2,item)
        item.setText(0,self.__tr("SSH"))
        item_2.setText(0,self.__tr("Servidores"))

        item_3 = QListViewItem(self.lvConfig,item_2)
        item_3.setOpen(1)
        item_4 = QListViewItem(item_3,item_2)
        item_4.setOpen(1)
        item_5 = QListViewItem(item_4,item_2)
        item_5.setOpen(1)
        item = QListViewItem(item_5,item_2)
        item.setText(0,self.__tr("Populate"))
        item_5.setText(0,self.__tr("SMB"))
        item_4.setOpen(1)
        item = QListViewItem(item_4,item_5)
        item.setText(0,self.__tr("Schema"))
        item_4.setText(0,self.__tr("LDAP"))
        item_3.setOpen(1)
        item = QListViewItem(item_3,item_4)
        item.setText(0,self.__tr("IMAP"))
        item_3.setText(0,self.__trUtf8("\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73"))

        self.pSaveConfig.setText(self.__tr("Salvar"))
        self.textLabel3_3_3.setText(self.__tr("<b>Servidor LDAP</b>"))
        self.textLabel4.setText(self.__trUtf8("\x3c\x62\x3e\x43\x6f\x6e\x65\x78\xc3\xa3\x6f\x3a\x3c\x2f\x62\x3e"))
        self.tLdapUser.setText(self.__tr("User Admin:"))
        self.tLdapPass.setText(self.__tr("Senha:"))
        self.tLdapName.setText(self.__tr("Nome:"))
        self.tLdapHost.setText(self.__tr("Host:"))
        self.tLdapPort.setText(self.__tr("Port:"))
        self.tLdapBaseDN.setText(self.__tr("BaseDN:"))
        self.pConfDelLdapConnection.setText(self.__tr("Del"))
        self.cbLdapMode.clear()
        self.cbLdapMode.insertItem(self.__tr("ldap://"))
        self.cbLdapMode.insertItem(self.__tr("ldaps://"))
        self.iLdapPort.setText(self.__tr("389"))
        self.cLdapRef.setText(self.__tr("Consultar referrals"))
        self.cLdapCert.setText(self.__trUtf8("\x4e\xc3\xa3\x6f\x20\x76\x65\x72\x69\x66\x69\x63\x61\x72\x20\x63\x65\x72\x74\x69\x66\x69\x63\x61\x64\x6f\x20\x53\x53\x4c\x20\x28\x72\x65\x69\x6e\x69\x63\x69\x65\x20\x6f\x20\x6b\x6f\x72\x72\x65\x69\x6f\x29"))
        self.pGetBaseDN.setText(self.__tr("Get"))
        self.textLabel3_3_2.setText(self.__tr("<b>Servidor IMAP</b>"))
        self.textLabel6_2.setText(self.__trUtf8("\x3c\x62\x3e\x43\x6f\x6e\x65\x78\xc3\xa3\x6f\x3a\x3c\x2f\x62\x3e"))
        self.tCyrusPartition_3.setText(self.__tr("Sieve port:"))
        self.tCyrusPartition.setText(self.__tr("Partition:"))
        self.tCyrusUser.setText(self.__tr("User Admin:"))
        self.tCyrusPass.setText(self.__tr("Senha:"))
        self.textLabel7_2.setText(self.__tr("Nome:"))
        self.tCyrusHost.setText(self.__tr("Host:"))
        self.tCyrusPort.setText(self.__tr("Port:"))
        self.pConfDelImapConnection.setText(self.__tr("Del"))
        self.cbCyrusMode.clear()
        self.cbCyrusMode.insertItem(self.__tr("imap://"))
        self.cbCyrusMode.insertItem(self.__tr("imaps://"))
        self.iCyrusPort.setText(self.__tr("143"))
        self.iCyrusPart.setText(QString.null)
        self.iCyrusSievePort.setText(self.__tr("2000"))
        self.textLabel3_3.setText(self.__tr("<b>Servidor SSH</b>"))
        self.textLabel8.setText(self.__trUtf8("\x3c\x62\x3e\x43\x6f\x6e\x65\x78\xc3\xa3\x6f\x3a\x3c\x2f\x62\x3e"))
        self.tCyrusPass_2.setText(self.__tr("Senha:"))
        self.textLabel9.setText(self.__tr("Nome:"))
        self.tCyrusHost_2.setText(self.__tr("Host:"))
        self.tCyrusPort_2.setText(self.__tr("Port:"))
        self.tCyrusUser_2.setText(self.__tr("User:"))
        self.pConfDelSshConnection.setText(self.__tr("Del"))
        self.iSshPort.setText(self.__tr("22"))
        self.textLabel10_4.setText(self.__trUtf8("\x3c\x62\x3e\x43\x6f\x6e\x65\x78\xc3\xb5\x65\x73\x3c\x2f\x62\x3e"))
        self.tConfShowSshServer.setText(self.__tr("Host:"))
        self.tConfShowSshUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.textLabel10_3.setText(self.__tr("<b>Servidor SSH</b>"))
        self.tConfShowLdapServer.setText(self.__tr("Host:"))
        self.tConfShowLdapUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.tConfShowLdapBaseDN.setText(self.__tr("Base:"))
        self.textLabel10_2.setText(self.__tr("<b>Servidor LDAP</b>"))
        self.tConfShowImapServer.setText(self.__tr("Host:"))
        self.tConfShowImapUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.tConfShowImapSep.setText(self.__tr("Imap delimiter: desconectado"))
        self.textLabel10.setText(self.__tr("<b>Servidor IMAP</b>"))
        self.textLabel3_3_2_3_2_2_2.setText(self.__trUtf8("\x3c\x62\x3e\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73\x20\x4c\x44\x41\x50\x3c\x2f\x62\x3e"))
        self.textLabel1_3_2_3_2_3_2.setText(self.__tr("Auto-completar admin:"))
        QToolTip.add(self.textLabel1_3_2_3_2_3_2,self.__tr("<b>uidNumber</b>"))
        self.textLabel1_5_3.setText(self.__tr("<b>Servidores</b>"))
        self.cbConfLdapCompleteUser.clear()
        self.cbConfLdapCompleteUser.insertItem(self.__tr("cn=admin"))
        self.cbConfLdapCompleteUser.insertItem(self.__tr("cn=manager"))
        self.cbConfLdapCompleteUser.insertItem(self.__tr("uid=root,ou=users"))
        self.textLabel3_3_2_3.setText(self.__trUtf8("\x3c\x62\x3e\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73\x20\x49\x4d\x41\x50\x3c\x2f\x62\x3e"))
        self.textLabel6_2_3.setText(self.__trUtf8("\x3c\x62\x3e\x50\x61\x73\x74\x61\x73\x20\x70\x61\x64\x72\xc3\xb5\x65\x73\x3c\x2f\x62\x3e"))
        self.textLabel7_2_3.setText(self.__trUtf8("\x3c\x62\x3e\x51\x75\x6f\x74\x61\x20\x70\x61\x64\x72\xc3\xa3\x6f\x3c\x2f\x62\x3e"))
        self.lvConfImapFolders.header().setLabel(0,self.__tr("Nome"))
        self.lvConfImapFolders.header().setLabel(1,self.__tr("Auto-expire"))
        self.lvConfImapFolders.header().setLabel(2,self.__tr("ACL anyone"))
        self.lvConfImapFolders.clear()
        item = QListViewItem(self.lvConfImapFolders,None)
        item.setText(0,self.__tr("Trash"))
        item.setText(1,self.__tr("60"))

        item = QListViewItem(self.lvConfImapFolders,item)
        item.setText(0,self.__tr("Sent"))

        item = QListViewItem(self.lvConfImapFolders,item)
        item.setText(0,self.__tr("Drafts"))

        item = QListViewItem(self.lvConfImapFolders,item)
        item.setText(0,self.__tr("Spam"))
        item.setText(1,self.__tr("30"))
        item.setText(2,self.__tr("p"))

        self.textLabel1_11.setText(self.__tr("Nome:"))
        self.textLabel1_11_2.setText(self.__tr("Expirar:"))
        self.textLabel2_7.setText(self.__tr("Acl post:"))
        self.iConfImapExpire.setText(QString.null)
        self.cbConfImapACLp.clear()
        self.cbConfImapACLp.insertItem(self.__trUtf8("\x4e\xc3\xa3\x6f"))
        self.cbConfImapACLp.insertItem(self.__tr("Sim"))
        self.pConfImapFoldersAdd.setText(self.__tr("+"))
        self.pConfImapFoldersDel.setText(self.__tr("-"))
        self.textLabel1_11_2_2.setText(self.__tr("dias"))
        self.textLabel1_10.setText(self.__tr("Limite:"))
        self.textLabel1_7.setText(self.__tr("Mbytes"))
        self.textLabel3_3_2_3_2.setText(self.__trUtf8("\x3c\x62\x3e\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73\x20\x4c\x44\x41\x50\x20\x53\x4d\x42\x3c\x2f\x62\x3e"))
        self.textLabel8_2.setText(self.__trUtf8("\x3c\x62\x3e\x44\x6f\x6d\xc3\xad\x6e\x69\x6f\x3a\x3c\x2f\x62\x3e"))
        self.pConfLdapSmbDomainDel.setText(self.__tr("Del"))
        self.textLabel9_2.setText(self.__trUtf8("\x44\x6f\x6d\xc3\xad\x6e\x69\x6f\x3a"))
        QToolTip.add(self.textLabel9_2,self.__tr("<b>sambaDomain</b>"))
        self.cbConfLdapSmbProfilePath.clear()
        self.cbConfLdapSmbProfilePath.insertItem(self.__tr("\\\\servidor\\profiles\\#UID#"))
        self.cbConfLdapSmbProfilePath.insertItem(self.__tr("\\\\servidor\\#UID#\\.profile"))
        self.tCyrusHost_2_2_4_2_2.setText(self.__tr("Logon script:"))
        QToolTip.add(self.tCyrusHost_2_2_4_2_2,self.__tr("<b>sambaLogonScript</b>"))
        self.tCyrusHost_2_2_4_2.setText(self.__tr("Drive Path:"))
        QToolTip.add(self.tCyrusHost_2_2_4_2,self.__tr("<b>sambaHomePath</b>"))
        self.iConfLdapSmbHomeDrive.setText(self.__tr("S:"))
        self.tCyrusHost_2_2_2.setText(self.__tr("Perfil:"))
        QToolTip.add(self.tCyrusHost_2_2_2,self.__tr("<b>sambaProfilePath</b>"))
        self.cbConfLdapSmbPrimaryGroup.clear()
        self.cbConfLdapSmbPrimaryGroup.insertItem(self.__tr("Domain Users (513)"))
        self.cbConfLdapSmbPrimaryGroup.insertItem(self.__tr("Domain Guests (514)"))
        self.cbConfLdapSmbPrimaryGroup.insertItem(self.__tr("Domain Admins(512)"))
        self.iConfLdapSmbDrivePath.setText(self.__tr("\\\\servidor\\#UID#"))
        self.cbConfLdapSmbLogonScript.clear()
        self.cbConfLdapSmbLogonScript.insertItem(self.__tr("netlogon.bat"))
        self.cbConfLdapSmbLogonScript.insertItem(self.__tr("#UID#.bat"))
        self.tCyrusHost_2_2_3.setText(self.__tr("Grupo:"))
        QToolTip.add(self.tCyrusHost_2_2_3,self.__tr("<b>sambaPrimaryGroupSID</b>"))
        self.cbConfLdapSmbProfileType.clear()
        self.cbConfLdapSmbProfileType.insertItem(self.__tr("Local"))
        self.cbConfLdapSmbProfileType.insertItem(self.__tr("Remoto"))
        self.tCyrusHost_2_2_4.setText(self.__tr("Drive:"))
        QToolTip.add(self.tCyrusHost_2_2_4,self.__tr("<b>sambaHomeDrive</b>"))
        self.tCyrusUser_2_2.setText(self.__tr("Contador:"))
        QToolTip.add(self.tCyrusUser_2_2,self.__tr("<b>uidNumber</b>"))
        self.tCyrusUser_2_2_2.setText(self.__tr("SID Dn:"))
        QToolTip.add(self.tCyrusUser_2_2_2,self.__tr("<b>sambaSID</b>"))
        self.cConfLdapSmbPwdMustChange.setText(self.__trUtf8("\x54\x72\x6f\x63\x61\x72\x20\x73\x65\x6e\x68\x61\x20\x6e\x6f\x20\x70\x72\xc3\xb3\x78\x69\x6d\x6f\x20\x6c\x6f\x67\x69\x6e"))
        QToolTip.add(self.cConfLdapSmbPwdMustChange,self.__tr("<b>sambaPwdMustChange</b>"))
        self.pConfLdapSmbGetsambaDomain.setText(self.__tr("Get"))
        QToolTip.add(self.pConfLdapSmbGetsambaDomain,self.__trUtf8("\x3c\x62\x3e\x6e\x65\x74\x6c\x6f\x63\x61\x6c\x73\x69\x64\x20\x61\x74\x72\x61\x76\xc3\xa9\x73\x20\x64\x65\x20\x63\x6f\x6e\x65\x78\xc3\xa3\x6f\x20\x53\x53\x48\x3c\x2f\x62\x3e"))
        self.pConfLdapSmbGetsambaUnixPoolId.setText(self.__tr("Get"))
        QToolTip.add(self.pConfLdapSmbGetsambaUnixPoolId,self.__trUtf8("\x3c\x62\x3e\x6e\x65\x74\x6c\x6f\x63\x61\x6c\x73\x69\x64\x20\x61\x74\x72\x61\x76\xc3\xa9\x73\x20\x64\x65\x20\x63\x6f\x6e\x65\x78\xc3\xa3\x6f\x20\x53\x53\x48\x3c\x2f\x62\x3e"))
        self.textLabel3_3_2_3_2_2.setText(self.__trUtf8("\x3c\x62\x3e\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73\x20\x4c\x44\x41\x50\x20\x53\x4d\x42\x20\x50\x6f\x70\x75\x6c\x61\x74\x65\x3c\x2f\x62\x3e"))
        self.textLabel1_3_2_3_2_3.setText(self.__tr("uidNumber Inicial:"))
        QToolTip.add(self.textLabel1_3_2_3_2_3,self.__tr("<b>uidNumber</b>"))
        self.iConfLdapSMBuidNumber.setText(self.__tr("1000"))
        self.textLabel1_3_2_3_2_2_6.setText(self.__tr("gidNumber Inicial:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_6,self.__tr("<b>gidNumber</b>"))
        self.iConfLdapSMBgidNumber.setText(self.__tr("1000"))
        self.textLabel1_3_2_3_2_2_3_3_3.setText(self.__trUtf8("\x44\x65\x73\x62\x6c\x6f\x71\x75\x65\x61\x72\x20\x61\x70\xc3\xb3\x73\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_3_3,self.__tr("<b>sambaLockoutDuration</b>"))
        self.iConfLdapSMBpwdHistLenght.setText(self.__tr("5"))
        self.textLabel1_3_2_3_2_2_3_2.setText(self.__trUtf8("\x49\x6d\x70\x65\x64\x69\x72\x20\x72\x65\x75\x74\x69\x6c\x69\x7a\x61\xc3\xa7\xc3\xa3\x6f\x20\x64\x65\x20\x73\x65\x6e\x68\x61\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_2,self.__tr("<b>sambaPwdHistoryLength</b>"))
        self.iConfLdapSMBlockoutDuration.setText(self.__tr("30"))
        self.iConfLdapSMBminPwdAge.setText(self.__tr("60"))
        self.cbConfLdapSMBlockoutDuration.clear()
        self.cbConfLdapSMBlockoutDuration.insertItem(self.__tr("minutos"))
        self.cbConfLdapSMBlockoutDuration.insertItem(self.__tr("horas"))
        self.cbConfLdapSMBlockoutDuration.insertItem(self.__tr("dias"))
        self.textLabel1_3_2_3_2_2_2_3_2.setText(self.__trUtf8("\x42\x6c\x6f\x71\x75\x65\x61\x72\x20\x61\x70\xc3\xb3\x73\x20\x65\x72\x72\x6f\x73\x20\x64\x65\x20\x6c\x6f\x67\x6f\x6e\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_2_3_2,self.__tr("<b>sambaLockoutThreshold</b>"))
        self.textLabel1_3_2_3_2_2_3_3_2_2.setText(self.__tr("Extender bloqueio em:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_3_3_2_2,self.__tr("<b>sambaLockoutObservationWindow</b>"))
        self.iConfLdapSMBminPwdLength.setText(self.__tr("5"))
        self.iConfLdapSMBlockout.setText(self.__tr("3"))
        self.iConfLdapSMBlockoutWindow.setText(self.__tr("30"))
        self.cbConfLdapSMBmaxPwdAge.clear()
        self.cbConfLdapSMBmaxPwdAge.insertItem(self.__tr("minutos"))
        self.cbConfLdapSMBmaxPwdAge.insertItem(self.__tr("horas"))
        self.cbConfLdapSMBmaxPwdAge.insertItem(self.__tr("dias"))
        self.cbConfLdapSMBlockoutWindow.clear()
        self.cbConfLdapSMBlockoutWindow.insertItem(self.__tr("minutos"))
        self.cbConfLdapSMBlockoutWindow.insertItem(self.__tr("horas"))
        self.cbConfLdapSMBlockoutWindow.insertItem(self.__tr("dias"))
        self.textLabel1_3_2_3_2_2_4_2.setText(self.__trUtf8("\x45\x78\x69\x67\x69\x72\x20\x74\x72\x6f\x63\x61\x20\x64\x65\x20\x73\x65\x6e\x68\x61\x20\x61\x70\xc3\xb3\x73\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_4_2,self.__tr("<b>sambaMaxPwdAge</b>"))
        self.cbConfLdapSMBminPwdAge.clear()
        self.cbConfLdapSMBminPwdAge.insertItem(self.__tr("minutos"))
        self.cbConfLdapSMBminPwdAge.insertItem(self.__tr("horas"))
        self.cbConfLdapSMBminPwdAge.insertItem(self.__tr("dias"))
        self.textLabel1_3_2_3_2_2_2_2.setText(self.__trUtf8("\x54\x61\x6d\x61\x6e\x68\x6f\x20\x6d\xc3\xad\x6e\x69\x6d\x6f\x20\x64\x61\x20\x73\x65\x6e\x68\x61\x3a"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_2_2,self.__tr("<b>sambaMinPwdLength</b>"))
        self.textLabel1_3_2_3_2_2_5_2.setText(self.__tr("Intervalo para trocar senha:"))
        QToolTip.add(self.textLabel1_3_2_3_2_2_5_2,self.__tr("<b>sambaMinPwdAge</b>"))
        self.iConfLdapSMBmaxPwdAge.setText(self.__tr("86400"))
        self.textLabel1_5_2.setText(self.__tr("<b>sambaDomain</b>"))
        self.textLabel1_5.setText(self.__tr("<b>sambaUnixIdPool</b>"))
        self.textLabel3_3_2_2.setText(self.__trUtf8("\x3c\x62\x3e\x50\x72\x65\x66\x65\x72\xc3\xaa\x6e\x63\x69\x61\x73\x20\x4c\x44\x41\x50\x20\x53\x63\x68\x65\x6d\x61\x3c\x2f\x62\x3e"))
        self.cConfLdapSchemaAddAttr.setText(self.__tr("Ao adicionar objectClasses"))
        self.cConfLdapSchemaDelAttr.setText(self.__tr("Ao excluir objectClasses"))
        self.textLabel1_9.setText(self.__tr("<b>Schema auxiliar</b>"))
        self.pConfLdapDelItem.setText(self.__tr("-"))
        self.pConfLdapAddItem.setText(self.__tr("+"))
        self.lvConfLdapSchema.header().setLabel(0,self.__tr("Attributo"))
        self.lvConfLdapSchema.header().setLabel(1,self.__tr("Valor"))
        self.lvConfLdapSchema.clear()
        item_6 = QListViewItem(self.lvConfLdapSchema,None)
        item_6.setOpen(1)
        item_7 = QListViewItem(item_6,None)
        item_7.setOpen(1)
        item = QListViewItem(item_7,None)
        item.setText(0,self.__tr("ou"))
        item.setText(1,self.__tr("domain1"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("ref"))
        item.setText(1,self.__tr("ldap://127.0.0.1/ou=domain1,o=Nome%20Empresa"))
        item_7.setOpen(1)
        item = QListViewItem(item_7,item)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("extensibleObject"))
        item_7.setText(0,self.__tr("referral"))
        item_6.setOpen(1)
        item_8 = QListViewItem(item_6,item_7)
        item_8.setOpen(1)
        item = QListViewItem(item_8,item_7)
        item.setText(0,self.__tr("displayName"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaSID"))
        item.setText(1,self.__tr("S-0-0-00-0000000000-0000000000-0000000000-0000"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaAcctFlags"))
        item.setText(1,self.__tr("[U          ]"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaPwdMustChange"))
        item.setText(1,self.__tr("2147483647"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaPwdLastSet"))
        item.setText(1,self.__tr("1"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaPwdCanChange"))
        item.setText(1,self.__tr("0"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaProfilePath"))
        item.setText(1,self.__tr("\\\\PDC\\profiles\\#UID#"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaPrimaryGroupSID"))
        item.setText(1,self.__tr("S-0-0-00-0000000000-0000000000-0000000000-514"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaNTPassword"))
        item.setText(1,self.__tr("XXX"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaLogonTime"))
        item.setText(1,self.__tr("0"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaLogonScript"))
        item.setText(1,self.__tr("logon.bat"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaLogoffTime"))
        item.setText(1,self.__tr("2147483647"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaLMPassword"))
        item.setText(1,self.__tr("XXX"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaKickoffTime"))
        item.setText(1,self.__tr("2147483647"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaHomePath"))
        item.setText(1,self.__tr("\\\\PDC-SRV\\#UID#"))
        item_8.setOpen(1)
        item = QListViewItem(item_8,item)
        item.setText(0,self.__tr("sambaHomeDrive"))
        item.setText(1,self.__tr("H:"))
        item_8.setText(0,self.__tr("sambaSamAccount"))
        item_6.setOpen(1)
        item_9 = QListViewItem(item_6,item_8)
        item_9.setOpen(1)
        item = QListViewItem(item_9,item_8)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("shadowAccount"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("sn"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("cn"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("objectClass"))
        item.setText(1,self.__tr("inetOrgPerson"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("loginShell"))
        item.setText(1,self.__tr("/bin/bash"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("homeDirectory"))
        item.setText(1,self.__tr("/home/"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("gidNumber"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("uidNumber"))
        item_9.setOpen(1)
        item = QListViewItem(item_9,item)
        item.setText(0,self.__tr("uid"))
        item_9.setText(0,self.__tr("posixAccount"))
        item_6.setOpen(1)
        item_10 = QListViewItem(item_6,item_9)
        item_10.setOpen(1)
        item = QListViewItem(item_10,item_9)
        item.setText(0,self.__tr("cn"))
        item_10.setOpen(1)
        item = QListViewItem(item_10,item)
        item.setText(0,self.__tr("sn"))
        item_10.setText(0,self.__tr("inetOrgPerson"))
        item_6.setText(0,self.__tr("objectClass"))

        self.textLabel3_3_2_2_2.setText(self.__tr("<b>Log</b>"))
        self.buttonGroup2_2.setTitle(QString.null)
        self.rbConfLogModeRecent.setText(self.__tr("Recente"))
        self.rbConfLogModeFull.setText(self.__tr("Completo"))
        self.wKorreio.changeTab(self.tabConfig,self.__trUtf8("\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\xc3\xa7\xc3\xb5\x65\x73"))


    def init(self):
        
        global iso2utf, utf2iso
        
        def iso2utf(string):
            return str(self.__tr(string))
        
        def utf2iso(string):
            return string.encode('iso8859-1')
        
        try:
            global sys, re, datetime, os
            import sys, re, datetime, os.path
        
            reload(sys)
            sys.setdefaultencoding("utf-8")
        
            global  sha, md5, b2a_base64, choice, letters, digits
            import sha, md5
            from binascii import b2a_base64
            from random import choice
            from string import letters, digits
        except:
            print "Error importing core modules."
            sys.exit()
        
        modfailed = []
        
        try:
            global ldap, modlist
            import ldap, ldap.modlist as modlist
        except:
            self.wKorreio.page(0).setEnabled(False)
            self.pGetBaseDN.setEnabled(False)
            modfailed.append("ldap")
        
        try:
            global  smbpasswd
            import smbpasswd
        except:
            self.cbLdapSambaPassword.setEnabled(False)
            self.pLdapSambaPopulate.setEnabled(False)
            self.cLdapFormSamba.setEnabled(False)
            modfailed.append("smbpasswd")
        
        try:
            global cyruslib
            import cyruslib
        except:
            self.wKorreio.page(1).setEnabled(False)
            self.wKorreio.page(2).setEnabled(False)
            modfailed.append("cyrus")
        
        try:
            global sievelib
            import sievelib
        except:
            self.wKorreio.page(3).setEnabled(False)
            modfailed.append("sieve")
        
        try:
            global pexpect, pxssh
            import pexpect, pxssh
        except:
            self.wKorreio.page(4).setEnabled(False)
            self.wKorreio.page(5).setEnabled(False)
            modfailed.append("pexpect")
        
        if modfailed:
            msg = ""
            for mod in modfailed:
                msg = "%s%s\n" % (msg, "    - python-%s" % mod)
            QMessageBox.warning(None, "Modulos falharam", utf2iso("Os seguintes módulos não foram carregados:\n%s" % msg))
        
        global active_conn
        active_conn = {}
        
        self.lvLdapMenu = QPopupMenu(self)
        self.lvLdapMenu.clipBoard = "None"
        self.lvLdapMenu.insertItem('Copiar',0)
        self.lvLdapMenu.insertItem('Recortar',1)
        self.lvLdapMenu.insertItem('Colar',2)
        self.lvLdapMenu.insertSeparator()
        self.lvLdapMenu.insertItem('Remover',3)
        self.connect(self.lvLdapMenu, SIGNAL('activated(int)'), self.ldap_menu_clicked)
        
        

    def customEvent(self,a0):
        event = a0
        if event.type() == "set_console_text":
            self.console(event.data())
        

    def statusBar(self):
        pass
        

    def console(self,a0):
        
        msg = datetime.datetime.now().strftime("%d %b %Y %H:%M:%S :/# ")+a0
        self.tlConsole.setText(utf2iso(msg))
        
        msg = re.sub("(</?b>)","",msg)
        self.lbLog.insertItem(utf2iso(msg))
        self.lbLog.setCurrentItem(self.lbLog.count() - 1)
        self.lbLog.ensureCurrentVisible()
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.log"), 'a')
            f.write("%s\n" % msg)
            f.close()
        except OSError, e:
            print e
        
        

    def parse_exception(self,a0,a1):
        
        if a0 == "LDAPError":
            if a1[0]["desc"] == "Size limit exceeded":
                self.console("<b>Atenção:</b> quantidade de registros excedido. Utilize um filtro mais restritivo.")
            elif a1[0]["desc"] == "Bad search filter":
                self.console("<b>Erro:</b> sintaxe inválida para filtro de pesquisa.")
            elif a1[0]["desc"] == "Already exists":
                self.console("<b>Erro:</b> o registro já existe.")
            elif a1[0]['desc'] == "Object class violation":
                errList = a1[0]['info'].split("'")
                self.console("<b>Erro:</b> o objectClass '%s' exige o attributo '%s'." % (errList[1], errList[3]))
            elif a1[0]['desc'] == "Naming violation":
                self.console(a1[0]['info'])
            elif a1[0]['desc'] == "Can't contact LDAP server":
                self.console("<b>Erro:</b> conexão ao host %s recusada." % self.iLdapHost.text().ascii())
            elif a1[0]['desc'] == "Undefined attribute type":
                self.console("<b>Erro:</b> registro '%s' não esta definido no schema." % a1[0]['info'].split(":")[0])
            elif a1[0]['info'] == "no write access to parent":
                self.console("<b>Erro:</b> sem permissão de escrita no referral, autentique-se na raiz %s." % iso2utf(self.ldap_get_dn()))
            elif a1[0]['info'] == "modifications require authentication":
                user = self.iLdapUser.text().ascii()
                if not user: user = "anonymous"
                self.console("<b>Erro:</b> usuário '%s' sem permissão de escrita ou senha incorreta." % user)
            elif a1[0]['desc'] == "No such attribute":
                self.console(a1[0]['info'])
            else:
                self.console(str(a1))
        else:
            self.console(str(a1))
        
        

    def korreio_module_clear(self,a0):
        
        if a0 == "ldap":
            self.lvLdap.clear()
            self.lvLdapAttr.clear()
        elif a0 == "imap":
            self.lvCyrus.clear()
            self.lvCyrusGlobal.clear()
            self.iImapMailbox.clear()
            self.lvImapAcl.clear()
            self.iImapAclUser.clear()
            self.cbACL.setCurrentText("")
            self.iQuota.clear()
            self.iQuotaUsed.clear()
            self.iAnnotationExpire.clear()
        elif a0 == "imap-partition":
            self.lvImapPartition.clear()
            self.lvImapPartitionGlobal.clear()
            self.cbImapPartition.clear()
        elif a0 == "sieve":
            self.lvSieve.clear()
            self.cbSieveScript.clear()
            self.teSieveScript.clear()
        elif a0 == "ssh":
            self.cbPostconf.clear()
            self.tePostconf.clear()
            self.tePostFileOpen.clear()
            self.lvQueue.clear()
            self.iQueueMessage.clear()
        elif a0 == "ldap.form":
            self.iLdapFormCn.clear()
            self.iLdapFormMail.clear()
            self.iLdapFormStreet.clear()
            self.iLdapFormL.clear()
            self.iLdapFormPostalCode.clear()
            self.iLdapFormHomePhone.clear()
            self.iLdapFormUserP.clear()
            self.iLdapFormUserP2.clear()
            self.cLdapFormPosix.setChecked(False)
            self.fLdapFormPosix.setEnabled(False)
            self.iLdapFormUid.clear()
            self.iLdapFormUidNumber.setText("1000")
            self.iLdapFormGidNumber.setText("100")
            self.iLdapFormLoginShell.setText("/bin/bash")
            self.iLdapFormHomeDirectory.setText("/home")
            self.cLdapFormSamba.setChecked(False)
            self.fLdapFormSamba.setEnabled(False)
            self.cbLdapFormSambaDomain.clear()
            self.cbLdapFormPrimaryGroup.setCurrentItem(0)
            self.iLdapFormSambaPwdMustChange.setChecked(True)
            self.pLdapFormSmbShow.setText(">>")
            self.wsLdapFormSmb.raiseWidget(0)
            self.cbLdapFormProfileType.setCurrentItem(0)
            self.iLdapFormProfilePath.clear()
            self.iLdapFormProfilePath.setEnabled(False)
            self.iLdapFormHomeDrive.clear()
            self.iLdapFormDrivePath.clear()
            self.iLdapFormLogonScript.clear()
            self.cLdapFormAst.setChecked(False)
            self.fLdapFormAst.setEnabled(False)
            self.iLdapFormAstUsername.clear()
            self.iLdapFormAstName.setText("1000")
            self.cLdapFormRadius.setChecked(False)
            self.fLdapFormRadius.setEnabled(False)
            self.iLdapFormRadiusGroup.clear()
            self.wsLdapForm.raiseWidget(0)
        elif a0 == "ldap.form.ou":
            self.iLdapOu.clear()
        elif a0 == "ldap.form.password":
            self.cbLdapUserPassword.setChecked(True)
            self.cbUserPassword.setCurrentItem(0)
            self.iLdapPasswd.clear()
            self.iLdapPasswd2.clear()
        elif a0 == "ldap.smb.populate":
            self.iLdapSMBdomain.clear()
            self.iLdapSMBSID.clear()
            self.iLdapSMBpassword.clear()
            self.iLdapSMBuidNumber.setText(self.iConfLdapSMBuidNumber.text().ascii())
            self.iLdapSMBgidNumber.setText(self.iConfLdapSMBgidNumber.text().ascii())
            self.iLdapSMBminPwdLength.setText(self.iConfLdapSMBminPwdLength.text().ascii())
            self.iLdapSMBpwdHistLenght.setText(self.iConfLdapSMBpwdHistLenght.text().ascii())
            self.iLdapSMBmaxPwdAge.setText(self.iConfLdapSMBmaxPwdAge.text().ascii())
            self.cbLdapSMBmaxPwdAge.setCurrentItem(self.cbConfLdapSMBmaxPwdAge.currentItem())
            self.iLdapSMBminPwdAge.setText(self.iConfLdapSMBminPwdAge.text().ascii())
            self.cbLdapSMBminPwdAge.setCurrentItem(self.cbConfLdapSMBminPwdAge.currentItem())
            self.iLdapSMBlockout.setText(self.iConfLdapSMBlockout.text().ascii())
            self.iLdapSMBlockoutDuration.setText(self.iConfLdapSMBlockoutDuration.text().ascii())
            self.cbLdapSMBlockoutDuration.setCurrentItem(self.cbConfLdapSMBlockoutDuration.currentItem())
            self.iLdapSMBlockoutWindow.setText(self.iConfLdapSMBlockoutWindow.text().ascii())
            self.cbLdapSMBlockoutWindow.setCurrentItem(self.cbConfLdapSMBlockoutWindow.currentItem())
        
        

    def korreio_module_changed(self):
        
        page = self.wKorreio.currentPageIndex()
        if page == 0:
            try:
                self.loadconfig
            except:
                self.loadconfig = 1
                self.config_load()
                self.wsConfig.raiseWidget(3)
        elif page == 6:
            self.config_change_widgetstack()
        
        

    def config_load(self):
        
        try:
            os.mkdir(os.path.expanduser("~/.korreio"),0700)
        except OSError, e:
            if e[0] != 17:
                self.console("<b>Erro:</b> não foi possível criar ~/.korreio. %s" % e)
                print "Error creating ~/.korreio "+e
                return False
        
        try:
            if not os.path.isfile(os.path.expanduser("~/.korreio/korreio.conf")):
                self.config_save()
        except OSError, e:
            pass
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
            conf=f.read()
            f.close()
        except IOError, e:
            return True
        
        confList = conf.split("\n")
        confList.pop()
        confDict = {}
        
        for line in confList:
           key=line.split("=")
           confDict[key[0]] = "=".join(key[1:])
        
        self.confDict = confDict
        
        #
        # LDAP Connection
        #
        
        i=0
        self.cbLdapConnection.clear()
        while confDict.get("ldap%s.name" % i):
            self.cbLdapConnection.insertItem(confDict.get("ldap%s.name" % i))
            i=i+1
        
        lastConn=confDict.get("ldap.last")
        if lastConn:
            self.cbLdapConnection.setCurrentText(confDict.get("%s.name" % lastConn))
            self.iLdapConnection.setText(confDict.get("%s.name" % lastConn))
            self.cbLdapMode.setCurrentText(confDict.get("%s.mode" % lastConn))
            self.iLdapHost.setText(confDict.get("%s.host" % lastConn))
            self.iLdapPort.setText(confDict.get("%s.port" % lastConn))
            self.cbLdapBaseDN.clear()
            self.cbLdapBaseDN.insertItem(confDict.get("%s.basedn" % lastConn))
            self.iLdapUser.setText(confDict.get("%s.user" % lastConn))
            self.iLdapPass.setText(confDict.get("%s.pass" % lastConn))
            if confDict.get("%s.ref" % lastConn) == "True":
                self.cLdapRef.setChecked(True)
            if confDict.get("%s.cert" % lastConn) == "True":
                self.cLdapCert.setChecked(True)
        
        #
        # IMAP Connection
        #
        
        i=0
        self.cbCyrusConnection.clear()
        while confDict.get("imap%s.name" % i):
            self.cbCyrusConnection.insertItem(confDict.get("imap%s.name" % i))
            i=i+1
        
        lastConn=confDict.get("imap.last")
        if lastConn:
            self.cbCyrusConnection.setCurrentText(confDict.get("%s.name" % lastConn))
            self.iCyrusConnection.setText(confDict.get("%s.name" % lastConn))
            self.cbCyrusMode.setCurrentText(confDict.get("%s.mode" % lastConn))
            self.iCyrusHost.setText(confDict.get("%s.host" % lastConn))
            self.iCyrusPort.setText(confDict.get("%s.port" % lastConn))
            self.iCyrusSievePort.setText(confDict.get("%s.sieport" % lastConn))
            self.iCyrusUser.setText(confDict.get("%s.user" % lastConn))
            self.iCyrusPass.setText(confDict.get("%s.pass" % lastConn))
            self.iCyrusPart.setText(confDict.get("%s.part" % lastConn))
        
        #
        # SSH Connection
        #
        
        i=0
        self.cbSSHConnection.clear()
        while confDict.get("ssh%s.name" % i):
            self.cbSSHConnection.insertItem(confDict.get("ssh%s.name" % i))
            i=i+1
        
        lastConn=confDict.get("ssh.last")
        if lastConn:
            self.cbSSHConnection.setCurrentText(confDict.get("%s.name" % lastConn))
            self.iSSHConnection.setText(confDict.get("%s.name" % lastConn))
            self.iSshHost.setText(confDict.get("%s.host" % lastConn))
            self.iSshPort.setText(confDict.get("%s.port" % lastConn))
            self.iSshUser.setText(confDict.get("%s.user" % lastConn))
            self.iSshPass.setText(confDict.get("%s.pass" % lastConn))
        
        #
        # IMAP Prefs
        #
        
        
        self.lvConfImapFolders.clear()
        i=0
        while confDict.get("imap.defaultfolder%s" % i):
            folderList = confDict.get("imap.defaultfolder%s" % i).split(":")
            item = QListViewItem(self.lvConfImapFolders)
            item.setText(0, folderList[0])
            if folderList[1] != "None" and folderList[1] != "0":
                item.setText(1, folderList[1])
            if folderList[2] != "None":
                item.setText(2, folderList[2])
            i+=1
        
        if confDict.get("imap.defaultquota"):
            self.iConfImapQuotaMbytes.setText(confDict.get("imap.defaultquota"))
        
        #
        # LDAP Prefs
        #
        
        if confDict.get("ldap.admin.autocomplete"):
            self.cbConfLdapCompleteUser.setCurrentText(confDict.get("ldap.admin.autocomplete"))
        
        self.lvConfLdapSchema.clear()
        item = QListViewItem(self.lvConfLdapSchema)
        item.setText(0,'objectClass')
        item.setOpen(True)
        objnodes = {}
        i=0
        while confDict.get("ldap.objectclass%s" % i):
            objclass = confDict.get("ldap.objectclass%s" % i).split(".")
            if not objnodes.get(objclass[0]):
                objnodes[objclass[0]] = QListViewItem(item)
                objnodes[objclass[0]].setText(0,objclass[0])
            subitem=QListViewItem(objnodes[objclass[0]])
            subitem.setText(0,objclass[1])
            subitem.setText(1,".".join(objclass[2:]))
            i=i+1
        
        
        if confDict.get("ldap.schema.addattrs") == "True" or not confDict.get("ldap.schema.addattrs"):
            self.cConfLdapSchemaAddAttr.setChecked(True)
        else:
            self.cConfLdapSchemaAddAttr.setChecked(False)
        
        if confDict.get("ldap.schema.delattrs") == "True" or not confDict.get("ldap.schema.delattrs"):
            self.cConfLdapSchemaDelAttr.setChecked(True)
        else:
            self.cConfLdapSchemaDelAttr.setChecked(False)
        
        #
        # LDAP SMB Prefs
        #
        
        i=0
        self.cbConfLdapSmbDomain.clear()
        while confDict.get("ldap.smb%s.domain" % i):
            self.cbConfLdapSmbDomain.insertItem(confDict.get("ldap.smb%s.domain" % i))
            i=i+1
        
        lastConn=confDict.get("ldap.smb.last")
        if lastConn:
            self.cbConfLdapSmbDomain.setCurrentText(confDict.get("%s.domain" % lastConn))
            self.iConfLdapSmbDomain.setText(confDict.get("%s.domain" % lastConn))
            if confDict.get("%s.SIDEntry" % lastConn):
                self.cbConfLdapSmbSIDEntry.clear()
                self.cbConfLdapSmbSIDEntry.insertItem(confDict.get("%s.SIDEntry" % lastConn))
            self.cbConfLdapSmbSIDEntry.insertItem("")
            self.cbConfLdapSmbCounterEntry.clear()
            if confDict.get("%s.counterEntry" % lastConn):
                self.cbConfLdapSmbCounterEntry.clear()
                self.cbConfLdapSmbCounterEntry.insertItem(confDict.get("%s.counterEntry" % lastConn))
            self.cbConfLdapSmbCounterEntry.insertItem("")
            self.cbConfLdapSmbProfileType.setCurrentItem(int(confDict.get("%s.profileType" % lastConn)))
            if int(confDict.get("%s.profileType" % lastConn)) == 0:
                self.cbConfLdapSmbProfilePath.setEnabled(False)
            else:
                self.cbConfLdapSmbProfilePath.setEnabled(True)
            self.cbConfLdapSmbProfilePath.setCurrentText(confDict.get("%s.profilePath" % lastConn))
            self.iConfLdapSmbHomeDrive.setText(confDict.get("%s.homeDrive" % lastConn))
            self.iConfLdapSmbDrivePath.setText(confDict.get("%s.drivePath" % lastConn))
            self.cbConfLdapSmbLogonScript.setCurrentText(confDict.get("%s.logonScript" % lastConn))
            if confDict.get("%s.pwdMustChange" % lastConn) == "True":
                self.cConfLdapSmbPwdMustChange.setChecked(True)
            else:
                self.cConfLdapSmbPwdMustChange.setChecked(False)
            self.cbConfLdapSmbPrimaryGroup.setCurrentItem(int(confDict.get("%s.primaryGroup" % lastConn)))
        
        #
        # LDAP SMB Populate Prefs
        #
        
        if confDict.get("ldap.smb.populate.1stUidNumber"):
            self.iConfLdapSMBuidNumber.setText(confDict.get("ldap.smb.populate.1stUidNumber"))
        
        if confDict.get("ldap.smb.populate.1stGidNumber"):
            self.iConfLdapSMBgidNumber.setText(confDict.get("ldap.smb.populate.1stGidNumber"))
        
        if confDict.get("ldap.smb.populate.sambaMinPwdLenght"):
            self.iConfLdapSMBminPwdLength.setText(confDict.get("ldap.smb.populate.sambaMinPwdLenght"))
        
        if confDict.get("ldap.smb.populate.sambaPwdHistoryLenght"):
            self.iConfLdapSMBpwdHistLenght.setText(confDict.get("ldap.smb.populate.sambaPwdHistoryLenght"))
        
        if confDict.get("ldap.smb.populate.sambaMaxPwdAge"):
            self.iConfLdapSMBmaxPwdAge.setText(confDict.get("ldap.smb.populate.sambaMaxPwdAge"))
        
        if confDict.get("ldap.smb.populate.sambaMaxPwdAgeTime"):
            self.cbConfLdapSMBmaxPwdAge.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaMaxPwdAgeTime")))
        
        if confDict.get("ldap.smb.populate.sambaMinPwdAge"):
            self.iConfLdapSMBminPwdAge.setText(confDict.get("ldap.smb.populate.sambaMinPwdAge"))
        
        if confDict.get("ldap.smb.populate.sambaMinPwdAgeTime"):
            self.cbConfLdapSMBminPwdAge.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaMinPwdAgeTime")))
        
        if confDict.get("ldap.smb.populate.sambaLockoutThreshold"):
            self.iConfLdapSMBlockout.setText(confDict.get("ldap.smb.populate.sambaLockoutThreshold"))
        
        if confDict.get("ldap.smb.populate.sambaLockoutDuration"):
            self.iConfLdapSMBlockoutDuration.setText(confDict.get("ldap.smb.populate.sambaLockoutDuration"))
        
        if confDict.get("ldap.smb.populate.sambaLockoutDurationTime"):
            self.cbConfLdapSMBlockoutDuration.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaLockoutDurationTime")))
        
        if confDict.get("ldap.smb.populate.sambaLockoutObservationWindow"):
            self.iConfLdapSMBlockoutWindow.setText(confDict.get("ldap.smb.populate.sambaLockoutObservationWindow"))
        
        if confDict.get("ldap.smb.populate.sambaLockoutObservationWindowTime"):
            self.cbConfLdapSMBlockoutWindow.setCurrentItem(int(confDict.get("ldap.smb.populate.sambaLockoutObservationWindowTime")))
        
        

    def config_save(self):
        
        try:
            self.confDict
        except AttributeError, e:
            self.confDict = {}
        
        confList = []
        
        #
        # LDAP Connection
        #
        
        i=0
        while self.confDict.get("ldap%s.name" % i):
            if self.confDict.get("ldap%s.name" % i) == self.iLdapConnection.text().ascii():
                break
            i=i+1
        
        if self.iLdapConnection.text().ascii():
            confList.append("ldap.last=ldap%s" % i)
            self.confDict["ldap%s.name" % i]=self.iLdapConnection.text().ascii()
            self.confDict["ldap%s.mode" % i]=self.cbLdapMode.currentText().ascii()
            self.confDict["ldap%s.host" % i]=self.iLdapHost.text().ascii()
            self.confDict["ldap%s.port" % i]=self.iLdapPort.text().ascii()
            self.confDict["ldap%s.basedn" % i]=self.cbLdapBaseDN.currentText().ascii()
            self.confDict["ldap%s.user" % i]=self.iLdapUser.text().ascii()
            self.confDict["ldap%s.pass" % i]=self.iLdapPass.text().ascii()
            self.confDict["ldap%s.ref" % i]=str(self.cLdapRef.isChecked())
            self.confDict["ldap%s.cert" % i]=str(self.cLdapCert.isChecked())
        
        k=0
        self.cbLdapConnection.clear()
        while self.confDict.get("ldap%s.name" % k):
            self.cbLdapConnection.insertItem(self.confDict.get("ldap%s.name" % k))
            for j in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                opt = "ldap%s.%s" % (k, j)
                confList.append("%s=%s" % (opt, self.confDict.get(opt)))
            k=k+1
        
        self.cbLdapConnection.setCurrentItem(i)
        
        #
        # IMAP Connection
        #
        
        i=0
        while self.confDict.get("imap%s.name" % i):
            if self.confDict.get("imap%s.name" % i) == self.iCyrusConnection.text().ascii():
                break
            i=i+1
        
        if self.iCyrusConnection.text().ascii():
            confList.append("imap.last=imap%s" % i)
            self.confDict["imap%s.name" % i]=self.iCyrusConnection.text().ascii()
            self.confDict["imap%s.mode" % i]=self.cbCyrusMode.currentText().ascii()
            self.confDict["imap%s.host" % i]=self.iCyrusHost.text().ascii()
            self.confDict["imap%s.port" % i]=self.iCyrusPort.text().ascii()
            self.confDict["imap%s.sieport" % i]=self.iCyrusSievePort.text().ascii()
            self.confDict["imap%s.user" % i]=self.iCyrusUser.text().ascii()
            self.confDict["imap%s.pass" % i]=self.iCyrusPass.text().ascii()
            self.confDict["imap%s.part" % i]=self.iCyrusPart.text().ascii()
        
        k=0
        self.cbCyrusConnection.clear()
        while self.confDict.get("imap%s.name" % k):
            self.cbCyrusConnection.insertItem(self.confDict.get("imap%s.name" % k))
            for j in ['name','mode','host','port','sieport','user','pass','part']:
                opt = "imap%s.%s" % (k, j)
                confList.append("%s=%s" % (opt, self.confDict.get(opt)))
            k=k+1
        
        self.cbCyrusConnection.setCurrentItem(i)
        
        #
        # SSH Connection
        #
        
        i=0
        while self.confDict.get("ssh%s.name" % i):
            if self.confDict.get("ssh%s.name" % i) == self.iSSHConnection.text().ascii():
                break
            i=i+1
        
        if self.iSSHConnection.text().ascii():
            confList.append("ssh.last=ssh%s" % i)
            self.confDict["ssh%s.name" % i]=self.iSSHConnection.text().ascii()
            self.confDict["ssh%s.host" % i]=self.iSshHost.text().ascii()
            self.confDict["ssh%s.port" % i]=self.iSshPort.text().ascii()
            self.confDict["ssh%s.user" % i]=self.iSshUser.text().ascii()
            self.confDict["ssh%s.pass" % i]=self.iSshPass.text().ascii()
        
        k=0
        self.cbSSHConnection.clear()
        while self.confDict.get("ssh%s.name" % k):
            self.cbSSHConnection.insertItem(self.confDict.get("ssh%s.name" % k))
            for j in ['name','host','port','user','pass']:
                opt="ssh%s.%s" % (k, j)
                confList.append("%s=%s" % (opt, self.confDict.get(opt)))
            k+=1
        
        self.cbSSHConnection.setCurrentItem(i)
        
        #
        # IMAP Prefs
        #
        
        i=0
        item = self.lvConfImapFolders.firstChild()
        while item is not None:
            confList.append("imap.defaultfolder%s=%s:%s:%s" % (i, item.text(0).ascii(), item.text(1).ascii(), item.text(2).ascii()))
            item = item.nextSibling()
            i+=1
        confList.append("imap.defaultquota=%s" % self.iConfImapQuotaMbytes.text().ascii())
        
        #
        # LDAP Prefs
        #
        
        confList.append("ldap.admin.autocomplete=%s" % self.cbConfLdapCompleteUser.currentText().ascii())
        confList.append("ldap.schema.addattrs=%s" % self.cConfLdapSchemaAddAttr.isChecked())
        confList.append("ldap.schema.delattrs=%s" % self.cConfLdapSchemaDelAttr.isChecked())
        
        item=self.lvConfLdapSchema.firstChild()
        item=item.firstChild()
        i=0
        while item is not None:
            subitem=item.firstChild()
            while subitem is not None:
                if subitem.text(1).ascii() is None: value=""
                else: value=subitem.text(1).ascii()
                confList.append("ldap.objectclass%s=%s.%s.%s" % (i, item.text(0).ascii(), subitem.text(0).ascii(), value))
                subitem=subitem.nextSibling()
                i=i+1
            item=item.nextSibling()
        
        #
        # LDAP SMB Prefs
        #
        
        i=0
        while self.confDict.get("ldap.smb%s.domain" % i):
            if self.confDict.get("ldap.smb%s.domain" % i) == self.iConfLdapSmbDomain.text().ascii():
                break
            i=i+1
        
        if self.iConfLdapSmbDomain.text().ascii():
            confList.append("ldap.smb.last=ldap.smb%s" % i)
            self.confDict["ldap.smb%s.domain" % i]=self.iConfLdapSmbDomain.text().ascii()
            self.confDict["ldap.smb%s.SIDEntry" % i]=self.cbConfLdapSmbSIDEntry.currentText().ascii()
            self.confDict["ldap.smb%s.counterEntry" % i]=self.cbConfLdapSmbCounterEntry.currentText().ascii()
            self.confDict["ldap.smb%s.profileType" % i]="%s" % self.cbConfLdapSmbProfileType.currentItem()
            self.confDict["ldap.smb%s.profilePath" % i]=self.cbConfLdapSmbProfilePath.currentText().ascii()
            self.confDict["ldap.smb%s.homeDrive" % i]=self.iConfLdapSmbHomeDrive.text().ascii()
            self.confDict["ldap.smb%s.drivePath" % i]=self.iConfLdapSmbDrivePath.text().ascii()
            self.confDict["ldap.smb%s.logonScript" % i]=self.cbConfLdapSmbLogonScript.currentText().ascii()
            self.confDict["ldap.smb%s.pwdMustChange" % i]=self.cConfLdapSmbPwdMustChange.isChecked()
            self.confDict["ldap.smb%s.primaryGroup" % i]=self.cbConfLdapSmbPrimaryGroup.currentItem()
        
        k=0
        self.cbConfLdapSmbDomain.clear()
        while self.confDict.get("ldap.smb%s.domain" % k):
            self.cbConfLdapSmbDomain.insertItem(self.confDict.get("ldap.smb%s.domain" % k))
            for j in ['domain', 'SIDEntry', 'counterEntry', 'profileType', 'profilePath', 'homeDrive', 'drivePath', 'logonScript', 'pwdMustChange', 'primaryGroup']:
                opt = "ldap.smb%s.%s" % (k, j)
                confList.append("%s=%s" % (opt, self.confDict.get(opt)))
            k=k+1
        
        self.cbConfLdapSmbDomain.setCurrentItem(i)
        
        #
        # LDAP SMB Populate Prefs
        #
        
        confList.append("ldap.smb.populate.1stUidNumber=%s" % self.iConfLdapSMBuidNumber.text().ascii())
        confList.append("ldap.smb.populate.1stGidNumber=%s" % self.iConfLdapSMBgidNumber.text().ascii())
        confList.append("ldap.smb.populate.sambaMinPwdLenght=%s" % self.iConfLdapSMBminPwdLength.text().ascii())
        confList.append("ldap.smb.populate.sambaPwdHistoryLenght=%s" % self.iConfLdapSMBpwdHistLenght.text().ascii())
        confList.append("ldap.smb.populate.sambaMaxPwdAge=%s" % self.iConfLdapSMBmaxPwdAge.text().ascii())
        confList.append("ldap.smb.populate.sambaMaxPwdAgeTime=%s" % self.cbConfLdapSMBmaxPwdAge.currentItem())
        confList.append("ldap.smb.populate.sambaMinPwdAge=%s" % self.iConfLdapSMBminPwdAge.text().ascii())
        confList.append("ldap.smb.populate.sambaMinPwdAgeTime=%s" % self.cbConfLdapSMBminPwdAge.currentItem())
        confList.append("ldap.smb.populate.sambaLockoutThreshold=%s" % self.iConfLdapSMBlockout.text().ascii())
        confList.append("ldap.smb.populate.sambaLockoutDuration=%s" % self.iConfLdapSMBlockoutDuration.text().ascii())
        confList.append("ldap.smb.populate.sambaLockoutDurationTime=%s" % self.cbConfLdapSMBlockoutDuration.currentItem())
        confList.append("ldap.smb.populate.sambaLockoutObservationWindow=%s" % self.iConfLdapSMBlockoutWindow.text().ascii())
        confList.append("ldap.smb.populate.sambaLockoutObservationWindowTime=%s" % self.cbConfLdapSMBlockoutWindow.currentItem())
        
        #
        # End
        #
        
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')
            f.write("\n".join(confList))
            f.write("\n")
            f.close()
            os.chmod(os.path.expanduser("~/.korreio/korreio.conf"), 0600)
            self.console("<b>Ok:</b> configuração salva.")
        except OSError, e:
            self.parse_exception("OSError", e)
        
        

    def config_log_mode(self):
        
        self.lbLog.clear()
        try:
            if os.path.isfile(os.path.expanduser("~/.korreio/korreio.log")):
                f = open(os.path.expanduser("~/.korreio/korreio.log"), 'r')
                if self.rbConfLogModeRecent.isChecked():
                    f.seek(-1000, 2)
                for line in f.xreadlines():
                    line=line.strip('\n')
                    try:
                        self.lbLog.insertItem(utf2iso(line))
                    except:
                        pass
                f.close()
                if self.rbConfLogModeRecent.isChecked():
                    self.lbLog.removeItem(0)
                self.lbLog.setCurrentItem(self.lbLog.count() - 1)
                self.lbLog.ensureCurrentVisible()
        except:
            pass
        
        

    def config_change_widgetstack(self):
        
        try:
            self.config1st
        except:
            item = self.lvConfig.firstChild()
            while item is not None:
                if item.text(0).ascii() == "Servidores":
                    self.lvConfig.setCurrentItem(item)
                item = item.nextSibling()
            self.config1st = 1
        
        item=self.lvConfig.currentItem()
        if item.parent() is None:
            if  item.text(0).ascii() == "Servidores":
                self.wsConfig.raiseWidget(3)
                self.tConfShowLdapServer.setText("Host: %s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii()))
                self.tConfShowLdapUser.setText("User: %s" % self.iLdapUser.text().ascii())
                self.tConfShowLdapBaseDN.setText("Base: %s" % self.cbLdapBaseDN.currentText().ascii())
                self.tConfShowImapServer.setText("Host: %s%s:%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii()))
                self.tConfShowImapUser.setText("User: %s" % self.iCyrusUser.text().ascii())
                self.tConfShowSshServer.setText("Host: ssh://%s:%s" % (self.iSshHost.text().ascii(), self.iSshPort.text().ascii()))
                self.tConfShowSshUser.setText("User: %s" % self.iSshUser.text().ascii())
            elif item.text(0).ascii() == "Log":
                self.wsConfig.raiseWidget(9)
        elif "%s.%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) == "Servidores.LDAP":
            self.wsConfig.raiseWidget(0)
        elif "%s.%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) == "Servidores.IMAP":
            self.wsConfig.raiseWidget(1)
        elif "%s.%s" % (item.parent().text(0).ascii(), item.text(0).ascii()) == "Servidores.SSH":
            self.wsConfig.raiseWidget(2)
        elif "%s.%s" % (iso2utf(item.parent().text(0).ascii()), item.text(0).ascii()) == "Preferências.LDAP":
            self.wsConfig.raiseWidget(4)
        elif "%s.%s" % (iso2utf(item.parent().text(0).ascii()), item.text(0).ascii()) == "Preferências.IMAP":
            self.wsConfig.raiseWidget(5)
        elif "%s.%s" % (iso2utf(item.parent().text(0).ascii()), item.text(0).ascii()) == "LDAP.SMB":
            self.wsConfig.raiseWidget(6)
        elif "%s.%s" % (iso2utf(item.parent().text(0).ascii()), item.text(0).ascii()) == "SMB.Populate":
            self.wsConfig.raiseWidget(7)
        elif "%s.%s" % (iso2utf(item.parent().text(0).ascii()), item.text(0).ascii()) == "LDAP.Schema":
            self.wsConfig.raiseWidget(8)
        
        

    def config_imap_set_port(self):
        
        if self.cbCyrusMode.currentText().ascii() == "imap://":
            self.iCyrusPort.setText("143")
        else:
            self.iCyrusPort.setText("993")
        
        

    def config_ldap_set_port(self):
        if self.cbLdapMode.currentText().ascii() == "ldap://":
            self.iLdapPort.setText("389")
        else:
            self.iLdapPort.setText("636")
        

    def config_ldap_get_basedn(self):
        
        try:
            l = self.ldap_connect()
            ldap_result_id = l.search("", ldap.SCOPE_BASE, "objectclass=*", ["namingContexts"])
            self.cbLdapBaseDN.clear()
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                if (result_data == []):
                    break
                else:
                    if result_type == ldap.RES_SEARCH_ENTRY:
                        for j in result_data:
                             for root in j[1]["namingContexts"]:
                                 self.cbLdapBaseDN.insertItem(root)
        
            bases = self.cbLdapBaseDN.count()
            if bases > 1:
                    self.cbLdapBaseDN.popup()
            elif bases != 0:
                    self.iLdapUser.setText("%s,%s" % (self.cbConfLdapCompleteUser.currentText().ascii(), root))
        
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
        
        

    def config_ldap_schema(self):
        
        item = self.lvConfLdapSchema.currentItem()
        if item.parent() is None:
            self.iConfLdapValue.setEnabled(False)
            self.iConfLdapAttr.clear()
            self.iConfLdapValue.clear()
        else:
            self.iConfLdapValue.setEnabled(True)
            if item.text(0).ascii() is not None:
                self.iConfLdapAttr.setText(item.text(0).ascii())
            if item.text(1).ascii() is not None:
                self.iConfLdapValue.setText(item.text(1).ascii())
        
        

    def config_ldap_schema_checked(self):
        
        if not self.cConfLdapSchemaAddAttr.isChecked() and not self.cConfLdapSchemaDelAttr.isChecked():
            self.fConfLdapSchema.setEnabled(False)
        else:
            self.fConfLdapSchema.setEnabled(True)
        
        

    def config_ldap_smb_perfil_changed(self):
        
        if self.cbConfLdapSmbProfileType.currentItem() == 0:
            self.cbConfLdapSmbProfilePath.setEnabled(False)
        else:
            self.cbConfLdapSmbProfilePath.setEnabled(True)
        
        

    def config_ldap_smb_get_sambaUnixIdPool(self):
        
        self.cbConfLdapSmbCounterEntry.clear()
        self.cbConfLdapSmbCounterEntry.insertItem("")
        ldap_result = self.ldap_query("objectClass=sambaUnixIdPool", None)
        if ldap_result is not None:
            for dn in ldap_result:
                self.cbConfLdapSmbCounterEntry.insertItem(dn)
        
        if self.cbConfLdapSmbCounterEntry.count() > 1:
            self.cbConfLdapSmbCounterEntry.popup()
        
        

    def config_ldap_smb_get_sambaDomain(self):
        
        self.cbConfLdapSmbSIDEntry.clear()
        self.cbConfLdapSmbSIDEntry.insertItem("")
        ldap_result = self.ldap_query("objectClass=sambaDomain", None)
        if ldap_result is not None:
            for dn in ldap_result:
                self.cbConfLdapSmbSIDEntry.insertItem(dn)
        
        if self.cbConfLdapSmbSIDEntry.count() > 1:
            self.cbConfLdapSmbSIDEntry.popup()
        
        

    def config_ldap_smb_sambaDomain_clicked(self):
        
        domain = self.cbConfLdapSmbSIDEntry.currentText().ascii()
        if domain:
            self.iConfLdapSmbDomain.setText(domain.split(",")[0].split("=")[1].lower())
        else:
            self.iConfLdapSmbDomain.clear()
        
        

    def config_ldap_set_admin(self):
        
            self.iLdapUser.setText("%s,%s" % (self.cbConfLdapCompleteUser.currentText().ascii(), self.cbLdapBaseDN.currentText().ascii()))
        
        

    def config_imap_add_default_folder(self):
        
        if not self.iConfImapFolder.text().ascii():
            return False
        
        item = self.lvConfImapFolders.firstChild()
        while item is not None:
            if item.text(0).ascii() == self.iConfImapFolder.text().ascii():
                tmp = item.nextSibling()
                self.lvConfImapFolders.takeItem(item)
                item = tmp
            else:
                item = item.nextSibling()
        
        item = QListViewItem(self.lvConfImapFolders)
        item.setText(0, self.iConfImapFolder.text().ascii())
        item.setText(1, self.iConfImapExpire.text().ascii())
        if self.cbConfImapACLp.currentItem() == 1:
            item.setText(2, "p")
        
        

    def config_imap_del_default_folder(self):
        
        self.lvConfImapFolders.takeItem(self.lvConfImapFolders.currentItem())
        
        

    def config_ldap_add_attr(self):
        
        itemroot=self.lvConfLdapSchema.firstChild()
        if itemroot.isSelected():
            newitem=QListViewItem(itemroot)
            newitem.setText(0,self.iConfLdapAttr.text().ascii())
            newitem.setText(1,self.iConfLdapValue.text().ascii())
            return True
        item=itemroot.firstChild()
        while item is not None:
            if item.isSelected():
                item.setOpen(True)
                newitem=QListViewItem(item)
                newitem.setText(0,self.iConfLdapAttr.text().ascii())
                newitem.setText(1,self.iConfLdapValue.text().ascii())
                return True
            subitem=item.firstChild()
            while subitem is not None:
                if subitem.isSelected():
                    subitem.setOpen(True)
                    newitem=QListViewItem(item)
                    newitem.setText(0,self.iConfLdapAttr.text().ascii())
                    newitem.setText(1,self.iConfLdapValue.text().ascii())
                    return True
                subitem=subitem.nextSibling()
            item=item.nextSibling()
        
        

    def config_ldap_del_attr(self):
        
        itemroot=self.lvConfLdapSchema.firstChild()
        item=itemroot.firstChild()
        while item is not None:
            if item.isSelected():
                itemroot.takeItem(item)
                self.lvConfLdapSchema.currentItem().setSelected(True)
                return True
            subitem=item.firstChild()
            while subitem is not None:
                if subitem.isSelected():
                    item.takeItem(subitem)
                    self.lvConfLdapSchema.currentItem().setSelected(True)
                    return True
                subitem=subitem.nextSibling()
            item=item.nextSibling()
        
        

    def config_ldap_set_connection(self):
        
        i=0
        while self.confDict.get("ldap%s.name" % i):
            if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
                lastConn="ldap%s" % i
            i=i+1
        
        self.iLdapConnection.setText(self.confDict.get("%s.name" % lastConn))
        self.cbLdapMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
        self.iLdapHost.setText(self.confDict.get("%s.host" % lastConn))
        self.iLdapPort.setText(self.confDict.get("%s.port" % lastConn))
        self.cbLdapBaseDN.clear()
        self.cbLdapBaseDN.insertItem(self.confDict.get("%s.basedn" % lastConn))
        self.iLdapUser.setText(self.confDict.get("%s.user" % lastConn))
        self.iLdapPass.setText(self.confDict.get("%s.pass" % lastConn))
        if self.confDict.get("%s.ref" % lastConn) == "True":
            self.cLdapRef.setChecked(True)
        else:
            self.cLdapRef.setChecked(False)
        if self.confDict.get("%s.cert" % lastConn) == "True":
            self.cLdapCert.setChecked(True)
        else:
            self.cLdapCert.setChecked(False)
        
        self.korreio_module_clear("ldap")
        
        

    def config_imap_set_connection(self):
        
        i=0
        while self.confDict.get("imap%s.name" % i):
            if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
                lastConn="imap%s" % i
            i=i+1
        
        self.iCyrusConnection.setText(self.confDict.get("%s.name" % lastConn))
        self.cbCyrusMode.setCurrentText(self.confDict.get("%s.mode" % lastConn))
        self.iCyrusHost.setText(self.confDict.get("%s.host" % lastConn))
        self.iCyrusPort.setText(self.confDict.get("%s.port" % lastConn))
        self.iCyrusSievePort.setText(self.confDict.get("%s.sieport" % lastConn))
        self.iCyrusUser.setText(self.confDict.get("%s.user" % lastConn))
        self.iCyrusPass.setText(self.confDict.get("%s.pass" % lastConn))
        self.iCyrusPart.setText(self.confDict.get("%s.part" % lastConn))
        
        self.korreio_module_clear("imap")
        self.korreio_module_clear("imap-partition")
        self.korreio_module_clear("sieve")
        
        

    def config_ssh_set_connection(self):
        
        i=0
        while self.confDict.get("ssh%s.name" % i):
            if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
                lastConn="ssh%s" % i
            i=i+1
        self.iSSHConnection.setText(self.confDict.get("%s.name" % lastConn))
        self.iSshHost.setText(self.confDict.get("%s.host" % lastConn))
        self.iSshPort.setText(self.confDict.get("%s.port" % lastConn))
        self.iSshUser.setText(self.confDict.get("%s.user" % lastConn))
        self.iSshPass.setText(self.confDict.get("%s.pass" % lastConn))
        
        self.korreio_module_clear("ssh")
        
        

    def config_smb_set_domain(self):
        
        i=0
        while self.confDict.get("ldap.smb%s.domain" % i):
            if self.confDict.get("ldap.smb%s.domain" % i) == self.cbConfLdapSmbDomain.currentText().ascii():
                lastConn="ldap.smb%s" % i
            i=i+1
        
        self.iConfLdapSmbDomain.setText(self.confDict.get("%s.domain" % lastConn))
        
        self.cbConfLdapSmbSIDEntry.clear()
        self.cbConfLdapSmbSIDEntry.insertItem(self.confDict.get("%s.SIDEntry" % lastConn))
        self.cbConfLdapSmbSIDEntry.insertItem("")
        
        self.cbConfLdapSmbCounterEntry.clear()
        if self.confDict.get("%s.counterEntry" % lastConn) != "None":
            self.cbConfLdapSmbCounterEntry.insertItem(self.confDict.get("%s.counterEntry" % lastConn))
        self.cbConfLdapSmbProfileType.setCurrentItem(int(self.confDict.get("%s.profileType" % lastConn)))
        if int(self.confDict.get("%s.profileType" % lastConn)) == 0:
            self.cbConfLdapSmbProfilePath.setEnabled(False)
        else:
            self.cbConfLdapSmbProfilePath.setEnabled(True)
        self.cbConfLdapSmbProfilePath.setCurrentText(self.confDict.get("%s.profilePath" % lastConn))
        self.iConfLdapSmbHomeDrive.setText(self.confDict.get("%s.homeDrive" % lastConn))
        self.iConfLdapSmbDrivePath.setText(self.confDict.get("%s.drivePath" % lastConn))
        self.cbConfLdapSmbLogonScript.setCurrentText(self.confDict.get("%s.logonScript" % lastConn))
        if self.confDict.get("%s.pwdMustChange" % lastConn) == "True":
            self.cConfLdapSmbPwdMustChange.setChecked(True)
        else:
            self.cConfLdapSmbPwdMustChange.setChecked(False)
        self.cbConfLdapSmbPrimaryGroup.setCurrentItem(int(self.confDict.get("%s.primaryGroup" % lastConn)))
        
        

    def config_ldap_del_connection(self):
        
        if not self.cbLdapConnection.currentText().ascii():
            return True
        
        i=0
        while self.confDict.get("ldap%s.name" % i):
            if self.confDict.get("ldap%s.name" % i) == self.cbLdapConnection.currentText().ascii():
                j=i+1
                while self.confDict.get("ldap%s.name" % j):
                    for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
                        self.confDict["ldap%s.%s" % ((j-1), opt)]=self.confDict.get("ldap%s.%s" % (j, opt))
                    j=j+1
            i=i+1
        
        for opt in ['name','mode','host','port','basedn','user','pass','ref','cert']:
            del self.confDict["ldap%s.%s" % ((i-1), opt)]
        
        i=self.cbLdapConnection.currentItem()
        self.cbLdapConnection.removeItem(i)
        if i > 0:
            self.cbLdapConnection.setCurrentItem(i-1)
            self.config_ldap_set_connection()
        elif self.cbLdapConnection.count() > 0:
            self.cbLdapConnection.setCurrentItem(0)
            self.config_ldap_set_connection()
        else:
            self.iLdapConnection.clear()
            self.cbLdapMode.setCurrentText("ldap://")
            self.iLdapHost.clear()
            self.iLdapPort.setText("389")
            self.cbLdapBaseDN.clear()
            self.iLdapUser.clear()
            self.iLdapPass.clear()
            self.cLdapRef.setChecked(False)
            self.cLdapCert.setChecked(False)
        
        

    def config_imap_del_connection(self):
        
        if not self.cbCyrusConnection.currentText().ascii():
            return True
        
        i=0
        while self.confDict.get("imap%s.name" % i):
            if self.confDict.get("imap%s.name" % i) == self.cbCyrusConnection.currentText().ascii():
                j=i+1
                while self.confDict.get("imap%s.name" % j):
                    for opt in ['name','mode','host','port','sieport','user','pass','part']:
                        self.confDict["imap%s.%s" % ((j-1), opt)]=self.confDict.get("imap%s.%s" % (j, opt))
                    j=j+1
            i=i+1
        
        for opt in ['name','mode','host','port','sieport','user','pass','part']:
            del self.confDict["imap%s.%s" % ((i-1), opt)]
        
        i=self.cbCyrusConnection.currentItem()
        self.cbCyrusConnection.removeItem(i)
        if i > 0:
            self.cbCyrusConnection.setCurrentItem(i-1)
            self.config_imap_set_connection()
        elif self.cbCyrusConnection.count() > 0:
            self.cbCyrusConnection.setCurrentItem(0)
            self.config_imap_set_connection()
        else:
            self.iCyrusConnection.clear()
            self.cbCyrusMode.setCurrentText("imap://")
            self.iCyrusHost.clear()
            self.iCyrusPort.setText("143")
            self.iCyrusSievePort.setText("2000")
            self.iCyrusUser.clear()
            self.iCyrusPass.clear()
            self.iCyrusPart.clear()
        
        

    def config_ssh_del_connection(self):
        
        if not self.cbSSHConnection.currentText().ascii():
            return True
        i=0
        while self.confDict.get("ssh%s.name" % i):
            if self.confDict.get("ssh%s.name" % i) == self.cbSSHConnection.currentText().ascii():
                j=i+1
                while self.confDict.get("ssh%s.name" % j):
                    for opt in ['name','host','port','user','pass']:
                        self.confDict["ssh%s.%s" % ((j-1), opt)]=self.confDict.get("ssh%s.%s" % (j, opt))
                    j=j+1
            i=i+1
        
        for opt in ['name','host','port','user','pass']:
            del self.confDict["ssh%s.%s" % ((i-1), opt)]
        
        i=self.cbSSHConnection.currentItem()
        self.cbSSHConnection.removeItem(i)
        if i > 0:
            self.cbSSHConnection.setCurrentItem(i-1)
            self.config_ssh_set_connection()
        elif self.cbSSHConnection.count() > 0:
            self.cbSSHConnection.setCurrentItem(0)
            self.config_ssh_set_connection()
        else:
            self.iSSHConnection.clear()
            self.iSshHost.clear()
            self.iSshPort.setText("22")
            self.iSshUser.clear()
            self.iSshPass.clear()
        
        

    def config_smb_del_domain(self):
        
        if not self.cbConfLdapSmbDomain.currentText().ascii():
            return True
        i=0
        while self.confDict.get("ldap.smb%s.domain" % i):
            if self.confDict.get("ldap.smb%s.domain" % i) == self.cbConfLdapSmbDomain.currentText().ascii():
                j=i+1
                while self.confDict.get("ldap.smb%s.domain" % j):
                    for opt in['domain', 'SIDEntry', 'counterEntry', 'profileType', 'profilePath', 'homeDrive', 'drivePath', 'logonScript', 'pwdMustChange', 'primaryGroup']:
                        self.confDict["ldap.smb%s.%s" % ((j-1), opt)]=self.confDict.get("ldap.smb%s.%s" % (j, opt))
                    j=j+1
            i=i+1
        
        for opt in ['domain', 'SIDEntry', 'counterEntry', 'profileType', 'profilePath', 'homeDrive', 'drivePath', 'logonScript', 'pwdMustChange', 'primaryGroup']:
            del self.confDict["ldap.smb%s.%s" % ((i-1), opt)]
        
        i=self.cbConfLdapSmbDomain.currentItem()
        self.cbConfLdapSmbDomain.removeItem(i)
        if i > 0:
            self.cbConfLdapSmbDomain.setCurrentItem(i-1)
            self.config_smb_set_domain()
        elif self.cbConfLdapSmbDomain.count() > 0:
            self.cbConfLdapSmbDomain.setCurrentItem(0)
            self.config_smb_set_domain()
        else:
            self.cbConfLdapSmbDomain.clear()
            self.iConfLdapSmbDomain.clear()
            self.cbConfLdapSmbSIDEntry.clear()
            self.cbConfLdapSmbCounterEntry.clear()
            self.cbConfLdapSmbProfileType.setCurrentItem(0)
            self.cbConfLdapSmbProfilePath.setEnabled(False)
            self.cbConfLdapSmbProfilePath.setCurrentText("\servidor\profiles\#UID#")
            self.iConfLdapSmbHomeDrive.setText("Z:")
            self.iConfLdapSmbDrivePath.setText("\servidor\#UID#")
            self.cbConfLdapSmbLogonScript.setCurrentText("netlogon.bat")
            self.cConfLdapSmbPwdMustChange.setChecked(True)
            self.cbConfLdapSmbPrimaryGroup.setCurrentItem(0)
        
        

    def imap_connect(self):
        
        def imap_connect_now():
            ssl = False
            if self.cbCyrusMode.currentText().ascii() == "imaps://":
                ssl = True
            self.m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()),ssl)
            msg = "%s%s:%s/%s" % (self.cbCyrusMode.currentText().ascii(), self.iCyrusHost.text().ascii(), self.iCyrusPort.text().ascii(), self.iCyrusUser.text().ascii())
            if self.m.ALIVE:
                if self.m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii()):
                    if self.m.ADMIN is not None:
                        self.console("<b>Ok:</b> servidor %s conectado." % msg)
                    else:
                        self.m.logout()
                        self.console("<b>Erro de conexão:</b> %s (Usuário não é administrador)." % msg)
                else:
                    self.console("<b>Erro de conexão:</b> %s (Usuário ou senha inválidos)." % msg)
            else:
                self.console("<b>Erro de conexão:</b> %s (Conexão recusada)." % msg)
        
        def server_changed():
            if active_conn["imap.mode"] != self.cbCyrusMode.currentText().ascii() or active_conn["imap.host"] != self.iCyrusHost.text().ascii() or active_conn["imap.port"] != self.iCyrusPort.text().ascii() or active_conn["imap.user"] != self.iCyrusUser.text().ascii() or active_conn["imap.pass"] != self.iCyrusPass.text().ascii():
                return True
            return False
        
        try:
            # Is connected?
            if self.m.m.isadmin():
                if server_changed():
                    imap_connect_now()
            else:
                imap_connect_now()
        except AttributeError, e:
            # First connection
            imap_connect_now()
        
        active_conn["imap.mode"] = self.cbCyrusMode.currentText().ascii()
        active_conn["imap.host"] = self.iCyrusHost.text().ascii()
        active_conn["imap.port"] = self.iCyrusPort.text().ascii()
        active_conn["imap.user"] = self.iCyrusUser.text().ascii()
        active_conn["imap.pass"] = self.iCyrusPass.text().ascii()
        
        self.tConfShowImapSep.setText("Imap delimiter: "+self.m.SEP)
        
        return self.m
        

    def imap_search(self):
        
        # Save current selection
        oldmailbox=['','']
        if self.lvCyrus.childCount() > 1:
            item=self.lvCyrus.currentItem()
            oldmailbox[0]=item.text(0).ascii()
            while item.parent() is not None:
                oldmailbox[0]=item.parent().text(0).ascii()
                item=item.parent()
        
        if self.lvCyrusGlobal.childCount() > 1:
            item=self.lvCyrusGlobal.currentItem()
            oldmailbox[1]=item.text(0).ascii()
            while item.parent() is not None:
                oldmailbox[1]=item.parent().text(0).ascii()
                item=item.parent()
        
        self.korreio_module_clear("imap")
        
        # Imap query
        imap = self.imap_connect()
        if self.iImapSearch.text().ascii():
            pattern = "user%s%s*" % (imap.SEP, self.iImapSearch.text().ascii())
        else:
            pattern = "*"
        mailboxes = imap.lm(pattern)
        
        def create_nodes(dn):
            dnlist = dn.split(imap.SEP)
            dnnode = imap.SEP.join(dnlist[:-1])
            if not self.tree.get(dnnode):
                create_nodes(dnnode)
            self.tree[dn] = QListViewItem(self.tree.get(dnnode))
            self.tree[dn].setText(0,dnlist[-1])
        
        try:
            self.tree = {}
            for id in mailboxes:
                idlist = id.split(imap.SEP)
                if re.search("^user",id):
                    id = imap.SEP.join(idlist[1:])
                    if len(idlist) == 2:
                        self.tree[id] = QListViewItem(self.lvCyrus)
                        self.tree[id].setText(0, id)
                        continue
                elif len(idlist) == 1:
                    self.tree[id] = QListViewItem(self.lvCyrusGlobal)
                    self.tree[id].setText(0, idlist[0])
                    continue
                idlist = id.split(imap.SEP)
                if not self.tree.get(id):
                    create_nodes(id)
                else:
                    print "Erro obtendo "+ idlist[-1]
        except KeyError, e:
            pass
        
        try:
            def selectItem(item):
                self.lvCyrus.setCurrentItem(item)
                item.setOpen(True)
                item.setSelected(True)
        
            item=self.lvCyrus.firstChild()
            if not oldmailbox[0]:
                selectItem(item)
            else:
                while item is not None:
                    if item.text(0).ascii() == oldmailbox[0]:
                        selectItem(item)
                        self.lvCyrus.scrollBy(0,item.itemPos())
                        break
                    item=item.nextSibling()
                if item is None:
                    selectItem(self.lvCyrus.firstChild())
        except AttributeError, e:
            pass
        
        try:
            def selectItem(item):
                self.lvCyrusGlobal.setCurrentItem(item)
                item.setOpen(True)
                item.setSelected(True)
        
            item=self.lvCyrusGlobal.firstChild()
            if not oldmailbox[1]:
                selectItem(item)
            else:
                item=self.lvCyrusGlobal.firstChild()
                while item is not None:
                    if item.text(0).ascii() == oldmailbox[1]:
                        selectItem(item)
                        self.lvCyrusGlobal.scrollBy(0,item.itemPos())
                        break
                    item=item.nextSibling()
                if item is None:
                    selectItem(self.lvCyrusGlobal.firstChild())
        
        except AttributeError, e:
            pass
        
        if self.lvCyrus.childCount() > 0:
            self.imap_mailbox_clicked()
        
        

    def imap_create_mailbox(self):
        
        def create_mailbox(mailbox, partition=None):
            if imap.cm(mailbox, partition):
                self.console("<b>Ok:</b>caixa postal %s criada." % mailbox)
            else:
                self.console("<b>Erro:</b> não foi possível criar caixa postal %s." % mailbox)
                raise "Error creating mailbox %s" % mailbox
            
        mailbox = self.iImapMailbox.text().ascii()
        
        if not mailbox:
            self.console("<b>Atenção:</b> informe a caixa postal para ser criada.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        if self.iCyrusPart.text().ascii():
            create_mailbox("%s%s" % (mbtype, mailbox), self.iCyrusPart.text().ascii())
        else:
            create_mailbox("%s%s" % (mbtype, mailbox))
        
        if self.iConfImapQuotaMbytes.text().ascii():
            imap.sq("%s%s" % (mbtype, mailbox), (int(self.iConfImapQuotaMbytes.text().ascii()) * 1024))
        
        if self.cbImapMailbox.currentItem() == 0:
            if len(mailbox.split(imap.SEP)) == 1:
                item = self.lvConfImapFolders.firstChild()
                while item is not None:
                    create_mailbox("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, item.text(0).ascii()))
                    if item.text(1).ascii() is not None and item.text(1).ascii() != "0":
                        imap.setannotation("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, item.text(0).ascii()), "/vendor/cmu/cyrus-imapd/expire", item.text(1).ascii())
                    if item.text(1).ascii() is not None:
                        imap.sam("user%s%s%s%s" % (imap.SEP, mailbox, imap.SEP, item.text(0).ascii()), "anyone", "p")
                    item = item.nextSibling()
        
        self.imap_search()
        
        if self.cbImapMailbox.currentItem() == 1:
            self.imap_gmailbox_clicked()
            self.lvCyrusGlobal.currentItem().setSelected(True)
        
        

    def imap_delete_mailbox(self):
        
        def delete_mailbox(mailbox):
            imap.sam(mailbox, self.iCyrusUser.text().ascii(), "c")
            if imap.dm(mailbox):
                self.console("<b>Ok:</b> caixa postal %s removida." % mailbox)
            else:
                self.console("<b>Erro:</b> não foi possível remover a caixa postal %s." % mailbox)
                raise "Error deleting mailbox %s" % mailbox
        
        mailbox = self.iImapMailbox.text().ascii()
        
        if not mailbox:
            self.console("<b>Atenção:</b> selecione a caixa postal para exclusão.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        if QMessageBox.information( None, "Confirme!",
                                                       utf2iso("Confirme a remoção da caixa postal:\n\n    - %s%s\n\n" % (mbtype, mailbox)),
                                                       "Sim",
                                                       utf2iso("Não") ) != 0:
            self.console("<b>Atenção:</b> a remoção da caixa postal %s%s foi cancelada." % (mbtype, mailbox) )
            return True
        
        # Cyrus is not recursive for subfolders
        if len(mailbox.split(imap.SEP)) > 1:
            for mbox in imap.lm(mbtype+mailbox+imap.SEP+"*"):
                delete_mailbox(mbox)
        delete_mailbox(mbtype+mailbox)
        
        if self.cbImapMailbox.currentItem() == 0:
            if self.lvCyrus.currentItem().parent() is None:
                self.lvCyrus.takeItem(self.lvCyrus.currentItem())
            else:
                self.lvCyrus.currentItem().parent().takeItem(self.lvCyrus.currentItem())
            self.lvCyrus.currentItem().setSelected(True)
            self.imap_mailbox_clicked()
        else:
            if self.lvCyrusGlobal.currentItem().parent() is None:
                self.lvCyrusGlobal.takeItem(self.lvCyrusGlobal.currentItem())
            else:
                self.lvCyrusGlobal.currentItem().parent().takeItem(self.lvCyrusGlobal.currentItem())
            self.lvCyrusGlobal.currentItem().setSelected(True)
            self.imap_gmailbox_clicked()
        
        

    def imap_set_quota(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("<b>Atenção:</b> selecione a caixa postal para aplicar a quota.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        if imap.sq(mbtype+self.iImapMailbox.text().ascii(),self.iQuota.text().ascii()):
            self.console("<b>Ok:</b> caixa postal %s limitada a %s Kbytes." % (self.iImapMailbox.text().ascii(), self.iQuota.text().ascii()))
        else:
            self.console("<b>Erro:</b> não foi possível limitar a caixa postal %s" % self.iImapMailbox.text().ascii())
        
        

    def imap_reconstruct(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("<b>Atenção:</b> selecione a caixa postal para reconstruir.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        if imap.reconstruct(mbtype+self.iImapMailbox.text().ascii()):
            self.console("<b>Ok:</b> caixa postal %s esta sendo reconstruida." % self.iImapMailbox.text().ascii())
        else:
            self.console("<b>Erro:</b> não foi possível reconstruir a caixa postal %s." % self.iImapMailbox.text().ascii())
        
        

    def imap_set_annotation_expire(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("<b>Atenção:</b> selecione a caixa postal para aplica o auto-expire.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        if imap.setannotation(mbtype+self.iImapMailbox.text().ascii(),"/vendor/cmu/cyrus-imapd/expire",self.iAnnotationExpire.text().ascii()):
            self.console("<b>Ok:</b> auto-expire de %s dias configurado para caixa postal %s." % (self.iAnnotationExpire.text().ascii(), self.iImapMailbox.text().ascii()))
        else:
            self.console("<b>Erro:</b> não foi possível configurar auto-expire para caixa postal %s." % self.iImapMailbox.text().ascii())
        
        

    def imap_partition_search(self):
        
        self.lvImapPartition.clear()
        self.lvImapPartitionGlobal.clear()
        self.cbImapPartition.clear()
        
        partitions = {}
        
        imap = self.imap_connect()
        
        mailboxes = imap.getannotation("user%s%s%%" % (imap.SEP, self.iImapPartitionSearch.text().ascii()), "/vendor/cmu/cyrus-imapd/partition")
        if mailboxes[0] == True:
            for mailbox in mailboxes[1]:
                idlist = mailbox.split(imap.SEP)
                item = QListViewItem(self.lvImapPartition)
                item.setText(0, imap.SEP.join(idlist[1:]))
                item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
                if self.cImapSize.isChecked():
                    item.setText(2, "%s" % imap.lq(mailbox)[0])
                else:
                    item.setText(2, "0")
                partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""
        
        mailboxes = imap.getannotation("%s%%" % self.iImapPartitionSearch.text().ascii(), "/vendor/cmu/cyrus-imapd/partition")
        if mailboxes[0] == True:
            for mailbox in mailboxes[1]:
                item = QListViewItem(self.lvImapPartitionGlobal)
                item.setText(0, mailbox)
                item.setText(1, mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"])
                if self.cImapSize.isChecked():
                    item.setText(2, "%s" % imap.lq(mailbox)[0])
                else:
                    item.setText(2, "0")
                partitions[mailboxes[1][mailbox]["/vendor/cmu/cyrus-imapd/partition"]] = ""
        
        for i in partitions:
            self.cbImapPartition.insertItem(i)
        
        

    def imap_partition_move(self):
        
        imap = self.imap_connect()
        item = self.lvImapPartition.firstChild()
        while item is not None:
            if item.isSelected():
                self.console("<b>Ok:</b> caixa postal %s movida para partição IMAP %s." % (item.text(0).ascii(), self.cbImapPartition.currentText().ascii()))
                mailbox="user%s%s" % (imap.SEP, item.text(0).ascii())
                imap.rename(mailbox, mailbox, self.cbImapPartition.currentText().ascii())
            item=item.nextSibling()
        
        item = self.lvImapPartitionGlobal.firstChild()
        while item is not None:
            if item.isSelected():
                self.console("<b>Ok:</b> caixa postal %s movida para partição IMAP %s." % (item.text(0).ascii(), self.cbImapPartition.currentText().ascii()))
                imap.rename(item.text(0).ascii(), item.text(0).ascii(), self.cbImapPartition.currentText().ascii())
            item=item.nextSibling()
        
        self.imap_partition_search()
        
        

    def imap_partition_size(self):
        
        if not self.cImapSizeUpdate.isChecked():
            self.tlImapSize.setText("0 Mbytes")
            return True
        
        size = 0
        item = self.lvImapPartition.firstChild()
        while item is not None:
            if item.isSelected():
                size += int(item.text(2).ascii())
            item=item.nextSibling()
        
        item = self.lvImapPartitionGlobal.firstChild()
        while item is not None:
            if item.isSelected():
                size += int(item.text(2).ascii())
            item=item.nextSibling()
        
        self.tlImapSize.setText("%s Mbytes" % (size / 1024))
        
        

    def imap_rename(self,a0,a1):
        
        currentItem = a0
        
        imap = self.imap_connect()
        item = a0
        new = item.text(0).ascii()
        while item.parent() is not None:
            item=item.parent()        
            new = item.text(0).ascii()+imap.SEP+new
        
        if self.mailboxold != new:
            if len(imap.lm(a1+new)) > 0:
                self.console("<b>Atenção:</b> caixa postal %s já existe." % new)
                currentItem.setText(0,self.mailboxold.split(m.SEP)[-1])
                return True
            if imap.rename(a1+self.mailboxold,a1+new):
                self.console("<b>Ok:</b> caixa postal %s renomeada para %s." % (self.mailboxold, new))
            else:
                self.console("<b>Erro:</b> não foi possível renomear %s para %s." % (self.mailboxold, new))
                currentItem.setText(0,self.mailboxold.split(imap.SEP)[-1])
        
        

    def imap_rename_mailbox(self):
        
            self.imap_rename(self.lvCyrus.currentItem(), "user%s" % self.m.SEP)
        
        

    def imap_gmailbox_rename(self):
        
            self.imap_rename(self.lvCyrusGlobal.currentItem(),"")
        
        

    def imap_acl_wizard(self):
        
        if self.cbACL.currentItem() == 1:
            self.cbACL.setCurrentText("lrsw")
        elif self.cbACL.currentItem() == 2:
            self.cbACL.setCurrentText("lrswi")
        elif self.cbACL.currentItem() == 3:
            self.cbACL.setCurrentText("lrswicd")
        elif self.cbACL.currentItem() == 4:
            self.cbACL.setCurrentText("p")
        elif self.cbACL.currentItem() == 5:
            self.cbACL.setCurrentText("lrswipcda")
        
        

    def imap_acl_del(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("<b>Atenção:</b> selecione a caixa postal para remover a ACL.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        def acl_del(user):
            if imap.sam(mbtype+self.iImapMailbox.text().ascii(), user, ""):
                self.console("<b>Ok:</b> caixa postal %s: ACL de %s removida." % (self.iImapMailbox.text().ascii(), user))
                return True
            else:
                self.console("<b>Erro:</b> não foi possível remover ACL de %s em %s." % (user, self.iImapMailbox.text().ascii()))
                return False
        
        itemDel = []
        item = self.lvImapAcl.firstChild()
        while item is not None:
            if item.isSelected():
                if acl_del(item.text(0).ascii()):
                    itemDel.append(item)
            item = item.nextSibling()
        
        for item in itemDel:
            self.lvImapAcl.takeItem(item)
        
        

    def imap_acl_add(self):
        
        if len(self.iImapMailbox.text().ascii()) == 0:
            self.console("<b>Atenção:</b> selecione a caixa postal para aplicar a ACL.")
            return True
        
        imap = self.imap_connect()
        if self.cbImapMailbox.currentItem() == 0:
            mbtype = "user%s" % imap.SEP
        else:
            mbtype = ""
        
        AclUser = self.iImapAclUser.text().ascii()
        Acl = self.cbACL.currentText().ascii()
        
        for user in AclUser.split(","):
            if imap.sam(mbtype+self.iImapMailbox.text().ascii(), user, Acl):
                item = self.lvImapAcl.firstChild()
                while item is not None:
                    if item.text(0).ascii() == user:
                        self.lvImapAcl.takeItem(item)
                        break
                    item = item.nextSibling()
                item = QListViewItem(self.lvImapAcl)
                item.setText(0,user)
                item.setText(1,Acl)
                self.lvImapAcl.setCurrentItem(item)
                self.console("<b>Ok:</b> caixa postal %s: ACL %s -> %s " % (self.iImapMailbox.text().ascii(), Acl, AclUser))
            else:
                self.console("<b>Erro:</b> não foi possível aplicar ACL %s -> %s em %s." % (Acl, AclUser, self.iImapMailbox.text().ascii()))
        
        

    def imap_acl_clicked(self):
        
        item = self.lvImapAcl.currentItem()
        self.iImapAclUser.setText(item.text(0).ascii())
        self.cbACL.setCurrentText(item.text(1).ascii())
        
        

    def imap_selectall(self):
        
        if self.lvImapPartition.hasFocus():
            self.lvImapPartition.selectAll(True)
            self.lvImapPartitionGlobal.selectAll(False)
        else:
            self.lvImapPartitionGlobal.selectAll(True)
            self.lvImapPartition.selectAll(False)
        
        

    def imap_mailbox_clicked(self):
        
        self.cbImapMailbox.setCurrentItem(0)
        self.imap_mailbox_get_info(self.lvCyrus.currentItem(),"user")
        
        

    def imap_gmailbox_clicked(self):
        
        self.cbImapMailbox.setCurrentItem(1)
        self.imap_mailbox_get_info(self.lvCyrusGlobal.currentItem(),"")
        
        

    def imap_mailbox_get_info(self,a0,a1):
        
        imap = self.imap_connect()
        item = a0
        if a1:
            mbtype = a1+imap.SEP
        else:
            mbtype = a1
        
        mailbox=item.text(0).ascii()
        while item.parent() is not None:
            mailbox=item.parent().text(0).ascii()+imap.SEP+mailbox
            item=item.parent()
        
        self.iImapMailbox.setText(mailbox)
        
        if len(mailbox.split(imap.SEP)) == 1:
            self.pSetQuota.setEnabled(True)
        else:
            self.pSetQuota.setEnabled(False)
        
        quota = imap.lq(mbtype+mailbox.split(imap.SEP)[0])
        self.iQuotaUsed.setText("%s" % quota[0])
        self.iQuota.setText("%s" % quota[1])
        
        self.lvImapAcl.clear()
        for user,acl in imap.lam(mbtype+mailbox).items():
            item = QListViewItem(self.lvImapAcl)
            item.setText(0, user)
            item.setText(1, acl)
        
        self.lvImapAcl.setCurrentItem(self.lvImapAcl.firstChild())
        self.lvImapAcl.currentItem().setSelected(False)
        self.imap_acl_clicked()
        
        expire = imap.getannotation(mbtype+mailbox, "/vendor/cmu/cyrus-imapd/expire")
        if expire[0]:
            self.iAnnotationExpire.setText(expire[1][mbtype+mailbox]["/vendor/cmu/cyrus-imapd/expire"])
        else:
            self.iAnnotationExpire.setText("")
        
        

    def imap_mailbox_doubleclicked(self):
        
        if self.lvCyrus.currentItem().parent() is not None:
            item = self.lvCyrus.currentItem()
            self.mailboxold = item.text(0).ascii()
            while item.parent() is not None:
                item=item.parent()        
                self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
            self.lvCyrus.currentItem().setRenameEnabled(0,True)
            self.lvCyrus.currentItem().startRename(0)
        
        

    def imap_gmailbox_doubleclicked(self):
        
        item = self.lvCyrusGlobal.currentItem()
        self.mailboxold = item.text(0).ascii()
        while item.parent() is not None:
            item=item.parent()        
            self.mailboxold = item.text(0).ascii()+self.m.SEP+self.mailboxold
        self.lvCyrusGlobal.currentItem().setRenameEnabled(0,True)
        self.lvCyrusGlobal.currentItem().startRename(0)
        
        

    def ldap_connect(self):
        
        try:
            if self.cLdapCert.isChecked():
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,0)
            else:
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT,2)
            if self.cLdapRef.isChecked():
                ldap.set_option(ldap.OPT_REFERRALS,1)
            else:
                ldap.set_option(ldap.OPT_REFERRALS,0)
            server = "%s%s:%s" % (self.cbLdapMode.currentText().ascii(), self.iLdapHost.text().ascii(), self.iLdapPort.text().ascii())
            l = ldap.initialize(server)
            l.protocol_version = ldap.VERSION3
            if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
                l.simple_bind(self.iLdapUser.text().ascii(), self.iLdapPass.text().ascii())
            else:
                l.simple_bind()
            self.console("<b>Ok:</b> servidor %s/%s conectado." % (server, self.iLdapUser.text().ascii()))
            return l
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
        
        

    def ldap_search(self):
        
        def create_nodes(dn):
            dnlist = dn.split(",")
            dnnode = ",".join(dnlist[1:])
            if not self.ldap_cache_items.get(dnnode):
                if not dnnode == dnnode.split(",")[0]:
                    create_nodes(dnnode)
                else:
                    print "Erro fatal: servidor ldap retonou basedn diferente da consulta."
                    print "            O servidor exige basedn case sensitive. Verifique."
            self.ldap_cache_items[dn] = QListViewItem(self.ldap_cache_items.get(dnnode))
            self.ldap_cache_items[dn].setText(0,dnlist[0])
        
        if self.cbLdapFilter.count() == 10:
            self.cbLdapFilter.removeItem(4)
        self.cbLdapFilter.insertItem(self.cbLdapFilter.currentText().ascii())
        
        basedn = self.cbLdapBaseDN.currentText().ascii()
        try:
            olddn = self.ldap_get_dn()
        except AttributeError, e:
            olddn = basedn
        
        self.lvLdap.clear()
        self.ldap_cache_items = {}
        self.ldap_cache_items[basedn] = QListViewItem(self.lvLdap)
        self.ldap_cache_items[basedn].setText(0,basedn)
        self.ldap_cache_items[basedn].setOpen(True)
        
        if not self.cbLdapFilter.currentText().ascii():
            filter = "(objectClass=*)"
        else:
            filter = "(%s)" % iso2utf(self.cbLdapFilter.currentText().ascii())
        self.ldap_cache_attr = self.ldap_query(filter, None)
        if self.ldap_cache_attr is None:
            return
        
        try:
            basednattrs = self.ldap_cache_attr.get(basedn)
            del self.ldap_cache_attr[basedn]
        except KeyError, e:
            pass
        
        for dn in self.ldap_cache_attr:
            if not self.ldap_cache_items.get(dn):
                create_nodes(dn)
        
        try:
            self.ldap_cache_attr[basedn] = basednattrs
        except KeyError, e:
            pass
        
        try:
            self.lvLdap.setCurrentItem(self.ldap_cache_items[olddn])
            self.lvLdap.currentItem().setSelected(True)
        except KeyError, e:
            pass
        
        while olddn != basedn:
            try:
                self.ldap_cache_items[olddn].setOpen(True)
            except KeyError, e:
                pass
            olddn = ",".join(olddn.split(",")[1:])
            if len(olddn) == 0:
                break
        
        self.lvLdap.scrollBy(0,self.lvLdap.currentItem().itemPos())
        self.ldap_dn_clicked()
        
        

    def ldap_query(self,a0,a1):
        # a0: ldap_filter, a1: retrive attributes (List or None)
        
        try:
            l = self.ldap_connect()
            if l is None:
                return
            ldap_result_id = l.search(self.cbLdapBaseDN.currentText().ascii(), ldap.SCOPE_SUBTREE, a0, a1)
            ldap_result = {}
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                if result_type == ldap.RES_SEARCH_RESULT:
                    break
                elif result_type == ldap.RES_SEARCH_ENTRY:
                    ldap_result[utf2iso(result_data[0][0])] = result_data[0][1]
                elif result_type == ldap.RES_SEARCH_REFERENCE:
                    ldap_result[result_data[0][1][0].split("/")[3].split("?")[0]] = {'ref': [result_data[0][1][0]]}
                else:
                    print "Result type not implemented. "+str(result_type)
        
            return ldap_result
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            if e[0]["desc"] == "Size limit exceeded":
                return ldap_result
        
        

    def ldap_dn_clicked(self):
        
        self.lvLdapAttr.clear()
        self.wsLdap.raiseWidget(0)
        self.cbLdapStack.setCurrentItem(0)
        dn = self.ldap_get_dn()
        try:
            for attribute,values in self.ldap_cache_attr.get(dn).items():
                for value in values:
                    item = QListViewItem(self.lvLdapAttr)
                    item.setText(0,attribute)
                    try:
                        item.setText(1,utf2iso(value))
                    except UnicodeDecodeError, e:
                        item.setText(1,value)
        except AttributeError, e:
            pass
        item = self.lvLdap.currentItem()
        if item.parent() is None:
            self.pLdapDelete.setEnabled(False)
        else:
            self.pLdapDelete.setEnabled(True)
        
        if self.lvLdapAttr.childCount() > 0:
            self.lvLdapAttr.setCurrentItem(self.lvLdapAttr.firstChild())
            self.lvLdapAttr.currentItem().setSelected(True)
        
        

    def ldap_dn_doubleclicked(self):
        
        if self.lvLdap.currentItem().childCount() == 0:
            self.rdnold = iso2utf(self.ldap_get_dn())
            self.lvLdap.currentItem().setRenameEnabled(0,True)
            self.lvLdap.currentItem().startRename(0)
        
        

    def ldap_form_next(self):
        
            self.wsLdapForm.raiseWidget(self.wsLdapForm.id(self.wsLdapForm.visibleWidget()) + 1)
        
        

    def ldap_form_back(self):
        
            self.wsLdapForm.raiseWidget(self.wsLdapForm.id(self.wsLdapForm.visibleWidget()) - 1)
        
        

    def ldap_form_posixAccount_enable(self):
        
            if self.cLdapFormPosix.isChecked():
                self.fLdapFormPosix.setEnabled(True)
            else:
                self.fLdapFormPosix.setEnabled(False)
                self.fLdapFormSamba.setEnabled(False)
                self.cLdapFormSamba.setChecked(False)
        
        

    def ldap_form_posixAccount_get_uidNumber(self):
        
        try:
            uidNumbers = self.ldap_query("(&(uidNumber=*)(!(objectClass=sambaUnixIdPool)))", ["uidNumber"])
            if uidNumbers:
                nextUidNumber = 999
                for item in uidNumbers:
                    uidNumber = uidNumbers.get(item).get("uidNumber")[0]
                    if int(uidNumber) > nextUidNumber:
                        nextUidNumber = int(uidNumber)
        
                if nextUidNumber > 998:
                    self.iLdapFormUidNumber.setText("%s" % (nextUidNumber + 1))
            
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
        
        

    def ldap_form_sambaSamAccount_enable(self):
        
        if self.cLdapFormSamba.isChecked():
            i=0
            domains = []
            while self.confDict.get("ldap.smb%s.domain" % i):
                domains.append(self.confDict.get("ldap.smb%s.domain" % i))
                i=i+1
        
            self.cbLdapFormSambaDomain.clear()
            domains.sort()
            for domain in domains:
                self.cbLdapFormSambaDomain.insertItem(domain)
        
            if self.cbLdapFormSambaDomain.count() == 0:
                self.console("<b>Atenção:</b> cadastre domínios netbios.")
                self.cLdapFormSamba.setChecked(False)
            else:
                self.cLdapFormPosix.setChecked(True)
                self.fLdapFormPosix.setEnabled(True)
                self.iLdapFormUidNumber.setEnabled(False)
                self.pLdapGetUidNumber.setEnabled(False)
                self.iLdapFormGidNumber.setEnabled(False)
                self.fLdapFormSamba.setEnabled(True)
                self.ldap_form_sambaSamAccount_domain_clicked()
        else:
            self.fLdapFormSamba.setEnabled(False)
            self.iLdapFormUidNumber.setEnabled(True)
            self.pLdapGetUidNumber.setEnabled(True)
            self.iLdapFormGidNumber.setEnabled(True)
            self.iLdapFormGidNumber.setText("100")
        
        

    def ldap_form_sambaSamAccount_domain_clicked(self):
        
        domain = self.cbLdapFormSambaDomain.currentText().ascii()
        i=0
        while self.confDict.get("ldap.smb%s.domain" % i):
            if self.confDict.get("ldap.smb%s.domain" % i) == domain:
                break
            i=i+1
        
        if self.confDict["ldap.smb%s.profileType" % i] == "0":
            self.cbLdapFormProfileType.setCurrentItem(0)
            self.iLdapFormProfilePath.setEnabled(False)
        else:
            self.cbLdapFormProfileType.setCurrentItem(1)
            self.iLdapFormProfilePath.setEnabled(True)
        
        self.iLdapFormProfilePath.setText(re.sub("#UID#", self.iLdapFormUid.text().ascii(), self.confDict["ldap.smb%s.profilePath" % i]))
        
        self.cbLdapFormPrimaryGroup.setCurrentItem(int(self.confDict["ldap.smb%s.primaryGroup" % i]))
        
        self.iLdapFormGidNumber.setText(self.cbLdapFormPrimaryGroup.currentText().ascii().split("(")[1].split(")")[0])
        
        self.iLdapFormHomeDrive.setText(self.confDict["ldap.smb%s.homeDrive" % i])
        self.iLdapFormDrivePath.setText(re.sub("#UID#", self.iLdapFormUid.text().ascii(), self.confDict["ldap.smb%s.drivePath" % i]))
        self.iLdapFormLogonScript.setText(re.sub("#UID#", self.iLdapFormUid.text().ascii(), self.confDict["ldap.smb%s.logonScript" % i]))
        if self.confDict["ldap.smb%s.pwdMustChange" % i] == "True":
            self.iLdapFormSambaPwdMustChange.setChecked(True)
        else:
            self.iLdapFormSambaPwdMustChange.setChecked(False)
        
        

    def ldap_form_sambaSamAccount_perfil_clicked(self):
        
            if self.cbLdapFormProfileType.currentItem() == 0:
                self.iLdapFormProfilePath.setEnabled(False)
            else:
                self.iLdapFormProfilePath.setEnabled(True)
        
        

    def ldap_form_sambaSamAccount_show_frame(self):
        
        if self.wsLdapFormSmb.id(self.wsLdapFormSmb.visibleWidget()) == 0:
            self.wsLdapFormSmb.raiseWidget(1)
            self.pLdapFormSmbShow.setText("<<")
        else:
            self.wsLdapFormSmb.raiseWidget(0)
            self.pLdapFormSmbShow.setText(">>")
        
        

    def ldap_form_astSipUser_enable(self):
        
            if self.cLdapFormAst.isChecked():
                self.fLdapFormAst.setEnabled(True)
            else:
                self.fLdapFormAst.setEnabled(False)
        
        

    def ldap_form_radiusProfile_enable(self):
        
            if self.cLdapFormRadius.isChecked():
                self.fLdapFormRadius.setEnabled(True)
            else:
                self.fLdapFormRadius.setEnabled(False)
        
        

    def ldap_form_uid_changed(self):
        
            self.iLdapFormHomeDirectory.setText("/home/%s" % self.iLdapFormUid.text().ascii())
            self.iLdapFormAstUsername.setText(self.iLdapFormUid.text().ascii())
        
        

    def ldap_form_inetOrgPerson_mail_changed(self):
        
            self.iLdapFormUid.setText(self.iLdapFormMail.text().ascii().split("@")[0])
        
        

    def ldap_form_insert_user(self):
        
        if not self.iLdapFormCn.text().ascii():
            self.console("<b>Atenção:</b> informe o nome do usuário.")
            self.wsLdapForm.raiseWidget(0)
            self.iLdapFormCn.setFocus()
            return False
        
        cn = iso2utf(self.iLdapFormCn.text().ascii())
        dn = iso2utf("cn=%s,%s" % (self.iLdapFormCn.text().ascii(), self.ldap_get_dn()))
        
        attrs = {}
        attrs['objectClass'] = ['inetOrgPerson']
        attrs['cn'] = [cn]
        attrs['sn'] = [cn.split(" ")[-1]]
        if self.iLdapFormMail.text().ascii():
            attrs['mail'] = [self.iLdapFormMail.text().ascii()]
        
        if self.iLdapFormStreet.text().ascii():
            attrs['street'] = [iso2utf(self.iLdapFormStreet.text().ascii())]
        
        if self.iLdapFormL.text().ascii():
            attrs['l'] = [iso2utf(self.iLdapFormL.text().ascii())]
        
        if self.iLdapFormPostalCode.text().ascii():
            attrs['postalCode'] = [self.iLdapFormPostalCode.text().ascii()]
        
        if self.iLdapFormHomePhone.text().ascii():
            attrs['homePhone'] = [self.iLdapFormHomePhone.text().ascii()]
        
        if self.iLdapFormUserP.text().ascii() != self.iLdapFormUserP2.text().ascii():
            self.console("<b>Atenção:</b> as senhas não conferem, digite novamente.")
            self.wsLdapForm.raiseWidget(0)
            self.iLdapFormUserP.clear()
            self.iLdapFormUserP2.clear()
            self.iLdapFormUserP.setFocus()
            return False
        
        if self.iLdapFormUserP.text().ascii():
            salt = ''
            for i in range(16):
                salt += choice(letters+digits)
            attrs['userPassword'] = ["{SSHA}%s"  % b2a_base64(sha.new(self.iLdapFormUserP.text().ascii() + salt).digest() + salt)[:-1]]
        
        if self.cLdapFormPosix.isChecked():
            attrs['objectClass'].extend(['posixAccount', 'shadowAccount'])
        
            if not self.iLdapFormUid.text().ascii():
                self.console("<b>Atenção:</b> informe o login do usuário.")
                self.iLdapFormUid.setFocus()
                return False
            attrs['uid'] = [iso2utf(self.iLdapFormUid.text().ascii())]
        
            if not self.iLdapFormUidNumber.text().ascii():
                self.console("<b>Atenção:</b> informe o uidNumber do usuário.")
                self.iLdapFormUidNumber.setFocus()
                return False
            attrs['uidNumber'] = [self.iLdapFormUidNumber.text().ascii()]
        
            if not self.iLdapFormGidNumber.text().ascii():
                self.console("<b>Atenção:</b> informe o gidNumber do usuário.")
                self.iLdapFormGidNumber.setFocus()
                return False
            attrs['gidNumber'] = [self.iLdapFormGidNumber.text().ascii()]
        
            if self.iLdapFormLoginShell.text().ascii():
                attrs['loginShell'] = [iso2utf(self.iLdapFormLoginShell.text().ascii())]
        
            if not self.iLdapFormHomeDirectory.text().ascii():
                self.console("<b>Atenção:</b> informe o diretório home do usuário.")
                self.iLdapFormHomeDirectory.setFocus()
                return False
            attrs['homeDirectory'] = [iso2utf(self.iLdapFormHomeDirectory.text().ascii())]
        
        if self.cLdapFormSamba.isChecked():
            attrs['objectClass'].extend(['sambaSamAccount'])
            attrs['uid'] = [iso2utf(self.iLdapFormUid.text().ascii())]
        
            domain = self.cbLdapFormSambaDomain.currentText().ascii()
            i=0
            while self.confDict.get("ldap.smb%s.domain" % i):
                if self.confDict.get("ldap.smb%s.domain" % i) == domain:
                    break
                i=i+1
        
            if not self.confDict.get("ldap.smb%s.domain" % i):
                self.console("<b>Atenção:</b> o domínio %s não esta configurado." % domain)
                self.wsLdapForm.raiseWidget(2)
                return False
        
            SIDEntry = self.confDict["ldap.smb%s.SIDEntry" % i]
            if not SIDEntry:
                self.console("<b>Atenção:</b> o registro de domínio netbios 'SIDdn' não esta configurado." % domain)
                self.wsLdapForm.raiseWidget(2)
                return False
            SID = self.ldap_query(SIDEntry.split(",")[0], None).get(SIDEntry).get("sambaSID")[0]
        
            profileType = self.confDict["ldap.smb%s.profileType" % i]
            profilePath = self.confDict["ldap.smb%s.profilePath" % i]
            homeDrive = self.confDict["ldap.smb%s.homeDrive" % i]
            drivePath = self.confDict["ldap.smb%s.drivePath" % i]
            logonScript = self.confDict["ldap.smb%s.logonScript" % i]
        
            uidCounter = self.confDict["ldap.smb%s.counterEntry" % i]
            if not uidCounter:
                self.console("<b>Atenção:</b> o contador de uidNumber do domínio %s não esta configurado." % domain)
                self.wsLdapForm.raiseWidget(2)
                return False
        
            attrs['uidNumber'] = ["%s" % self.ldap_query(uidCounter.split(",")[0], None).get(uidCounter).get("uidNumber")[0]]
            attrs['sambaSID'] = ["%s-%s" % (SID, int(attrs.get("uidNumber")[0]) * 2 + 1000)]
            gidNumber = self.cbLdapFormPrimaryGroup.currentText().ascii().split("(")[1].split(")")[0]
            attrs['gidNumber'] = [gidNumber]
            attrs['sambaPrimaryGroupSID'] = ["%s-%s" % (SID, gidNumber)]
        
            attrs['sambaLogonTime'] = ["0"]
            attrs['sambaLogoffTime'] = ["2147483647"]
            attrs['sambaKickoffTime'] = ["2147483647"]
            attrs['sambaPwdCanChange'] = ["0"]
            attrs['sambaAcctFlags'] = ["[U          ]"]
            attrs['sambaPwdLastSet'] = ["1"]
        
            if self.iLdapFormSambaPwdMustChange.isChecked():
                attrs['sambaPwdMustChange'] = ["1"]
            else:
                attrs['sambaPwdMustChange'] = ["2147483647"]
        
            if profileType == "1":
                attrs['sambaProfilePath'] = [re.sub("#UID#", attrs.get("uid")[0], profilePath)]
        
            if homeDrive:
                attrs['sambaHomeDrive'] = [homeDrive]
        
            if drivePath:
                attrs['sambaHomePath'] = [re.sub("#UID#", attrs.get("uid")[0], drivePath)]
        
            if logonScript:
                attrs['sambaLogonScript'] = [re.sub("#UID#", attrs.get("uid")[0], logonScript)]
        
            if self.iLdapFormUserP.text().ascii():
                attrs['sambaNTPassword'] = [smbpasswd.nthash(self.iLdapFormUserP.text().ascii())]
                attrs['sambaLMPassword'] = [smbpasswd.lmhash(self.iLdapFormUserP.text().ascii())]
        
        if self.cLdapFormAst.isChecked():
            attrs['objectClass'].extend(['astSipGeneric', 'astSipPeer'])
            attrs['astContext'] = ["from-sip"]
            attrs['astRegseconds'] = ["10"]
            attrs['astLanguage'] = ["en"]
            attrs['astHost'] = ["dynamic"]
        
            if not self.iLdapFormAstUsername.text().ascii():
                self.console("<b>Atenção:</b> informe o usuário do asterisk.")
                self.wsLdapForm.raiseWidget(3)
                self.iLdapFormAstUsername.setFocus()
                return False
            attrs['astUsername'] = [iso2utf(self.iLdapFormAstUsername.text().ascii())]
        
            if not self.iLdapFormAstName.text().ascii():
                self.console("<b>Atenção:</b> informe o ramal do asterisk.")
                self.wsLdapForm.raiseWidget(3)
                self.iLdapFormAstName.setFocus()
                return False
            attrs['astName'] = [iso2utf(self.iLdapFormAstName.text().ascii())]
        
            if not self.iLdapFormAstPort.text().ascii():
                self.console("<b>Atenção:</b> informe a porta do asterisk.")
                self.wsLdapForm.raiseWidget(3)
                self.iLdapFormAstPort.setFocus()
                return False
            attrs['astPort'] = [iso2utf(self.iLdapFormAstPort.text().ascii())]
        
            if self.cLdapFormAstSecret.isChecked():
                attrs['astSecret'] = [iso2utf(self.iLdapFormUserP.text().ascii())]
        
        if self.cLdapFormRadius.isChecked():
            attrs['objectClass'].extend(['radiusProfile'])
            if not self.iLdapFormRadiusGroup.text().ascii():
                self.console("<b>Atenção:</b> informe o grupo do radius.")
                self.wsLdapForm.raiseWidget(4)
                self.iLdapFormRadiusGroup.setFocus()
                return False
            attrs['radiusGroupName'] = [iso2utf(self.iLdapFormRadiusGroup.text().ascii())]
        
        if self.ldap_add(dn,attrs):
            if self.cLdapFormSamba.isChecked():
                attrold = {}
                attrold['uidNumber'] = [attrs.get("uidNumber")[0]]
                attrnew = {}
                attrnew['uidNumber'] = ["%s" % (int(attrs.get("uidNumber")[0]) + 1)]
                self.ldap_modify(uidCounter,attrold,attrnew)
            self.korreio_module_clear("ldap.form")
        
        

    def ldap_add(self,a0,a1):
        # a0 = DN, a1 = attrs
        
        dn = utf2iso(a0)
        
        try:
            ldif = modlist.addModlist(a1)
            l = self.ldap_connect()
            l.add_s(a0,ldif)
            l.unbind_s()
            self.ldap_cache_attr[dn] = {}
            for tuple in ldif:
                self.ldap_cache_attr[dn][tuple[0]] = tuple[1]
            item = QListViewItem(self.lvLdap.currentItem())
            item.setText(0, dn.split(',')[0])
            self.ldap_cache_items[dn] = item
            self.console("<b>Ok:</b> registro %s adicionado." % a0)
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_modify(self,a0,a1,a2):
        # a0 = DN, a1 = attrold, a2 = attrnew
        
        dn = iso2utf(a0)
        
        try:
            ldif = modlist.modifyModlist(a1, a2)
            l = self.ldap_connect()
            l.modify_s(dn,ldif)
            l.unbind_s()
            for tuple in ldif:
                if tuple[2] is not None:
                    self.ldap_cache_attr[a0][tuple[1]] = tuple[2]
            self.console("<b>Ok:</b> registro %s alterado." % dn)
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_modify_clicked(self):
        
        if self.lvLdap.currentItem() is None:
            self.console("<b>Atenção:</b> selecione o registro para executar esta ação.")
            return True
        
        stack = self.cbLdapStack.currentItem()
        if stack == 0:
            old = {}
            for attribute,values in self.ldap_cache_attr.get(self.ldap_get_dn()).items():
                if old.get(attribute):
                   old[attribute].extend(values)
                else:
                   old[attribute] = values
        
            new = {}
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if new.get(item.text(0).ascii()):
                    new[item.text(0).ascii()].extend([iso2utf(item.text(1).ascii())])
                else:
                    new[item.text(0).ascii()] = [iso2utf(item.text(1).ascii())]
                item = item.nextSibling()
        
            self.ldap_modify(self.ldap_get_dn(),old,new)
        
        else:
            new = {}
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if item.isSelected():
                    dn=iso2utf("%s=%s,%s" % (item.text(0).ascii(), item.text(1).ascii(), self.ldap_get_dn()))
                if new.get(item.text(0).ascii()):
                    new[item.text(0).ascii()].extend([iso2utf(item.text(1).ascii())])
                else:
                    new[item.text(0).ascii()] = [iso2utf(item.text(1).ascii())]
                item = item.nextSibling()
            try:
                self.ldap_add(dn,new)
            except UnboundLocalError, e:
                self.console("<b>Atenção:</b> selecione o DN entre os atributos.")
        
        

    def ldap_insert_ou(self):
        
        dn = iso2utf("ou=%s,%s" % (self.iLdapOu.text().ascii(), self.ldap_get_dn()))
        attrs = {}
        attrs['objectClass'] = ['organizationalUnit']
        attrs['ou'] = [iso2utf(self.iLdapOu.text().ascii())]
        if self.ldap_add(dn,attrs):
            self.iLdapOu.clear()
        
        

    def ldap_remove_entry(self):
        
        def ldap_remove_recursive(item):
            subitem = item.firstChild()
            while subitem is not None:
                ldap_remove_recursive(subitem)
                subitem = subitem.nextSibling()
        
            dn = item.text(0).ascii()
            while item.parent() is not None:
                dn = "%s,%s" % (dn, item.parent().text(0).ascii())
                item = item.parent()
        
            if self.ldap_del_entry(iso2utf(dn)):
                self.console("<b>Ok:</b> registro %s removido." % iso2utf(dn))
                del self.ldap_cache_attr[dn]
            else:
                self.console("Erro: não foi possível excluir o registro %s" % iso2utf(dn))
        
        dn =  iso2utf(self.ldap_get_dn())
        if dn is not None:
            ok = QMessageBox.information( None, "Confirme!", utf2iso("Confirme a remoção do registro:\n\n    - %s\n\n" % dn), "Sim", utf2iso("Não") )
            if ok == 0:
                item = self.ldap_cache_items[utf2iso(dn)]
                ldap_remove_recursive(item)            
                self.lvLdap.currentItem().parent().takeItem(item)
                self.lvLdap.currentItem().setSelected(True)
                self.ldap_dn_clicked()
            else:
                self.console("<b>Atenção:</b> a remoção do registro %s foi cancelada." % dn)
        
        

    def ldap_del_entry(self,a0):
        
        l = self.ldap_connect()
        try:
            l.delete_s(a0)
            return True
        except ldap.STRONG_AUTH_REQUIRED, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_remove_attr(self):
        
        itemAttr = self.lvLdapAttr.currentItem()
        
        if self.cConfLdapSchemaDelAttr.isChecked() and itemAttr.text(0).ascii().lower() == 'objectclass':
            depends = []
        
            item=self.lvConfLdapSchema.firstChild().firstChild()
            while item is not None:
                if item.text(0).ascii().lower() == itemAttr.text(1).ascii().lower():
                    subitem=item.firstChild()
                    while subitem is not None:
                        if subitem.text(0).ascii().lower() != 'objectclass':
                            depends.append(subitem.text(0).ascii())
                        subitem=subitem.nextSibling()
                    break
                item=item.nextSibling()
        
            item = self.lvLdapAttr.firstChild()
            while item is not None:
                if item.text(0).ascii() in depends:
                    tmp=item
                    item=item.nextSibling()
                    self.lvLdapAttr.takeItem(tmp)
                else:
                    item=item.nextSibling()
        
        self.lvLdapAttr.takeItem(itemAttr)
        
        try:
            self.lvLdapAttr.currentItem().setSelected(True)
        except AttributeError, e:
            pass
        
        
        
        

    def ldap_rename_attr_value(self):
        
        if not self.lvLdap.currentItem().text(0).ascii() == "=".join([self.lvLdapAttr.currentItem().text(0).ascii(),self.lvLdapAttr.currentItem().text(1).ascii()]):
            self.lvLdapAttr.currentItem().setRenameEnabled(1,True)
            self.lvLdapAttr.currentItem().startRename(1)
        
        

    def ldap_add_attr(self):
        
        attr=self.cbLdapAttr.currentText().ascii()
        value=self.cbLdapValue.currentText().ascii()
        if not attr:
            return True
        
        attrs = [(attr,value)]
        
        if self.cConfLdapSchemaAddAttr.isChecked() and attr.lower() == 'objectclass':
            if not value:
                return True
            item=self.lvConfLdapSchema.firstChild()
            item=item.firstChild()
            while item is not None:
                subitem=item.firstChild()
                if item.text(0).ascii().lower() == value.lower():
                    while subitem is not None:
                        if subitem.text(1).ascii() is None: newvalue=""
                        else: newvalue=subitem.text(1).ascii()
                        attrs.extend([(subitem.text(0).ascii(),newvalue)])
                        subitem=subitem.nextSibling()
                item=item.nextSibling()
        
        for attr,value in attrs:
            item=self.lvLdapAttr.firstChild()
            jump=False
            while item is not None:
                if item.text(0).ascii() == attr and (item.text(1).ascii() == value or value == ''):
                    jump=True
                    break
                item=item.nextSibling()
            if jump:
                continue
            item = QListViewItem(self.lvLdapAttr)
            item.setText(0,attr)
            item.setText(1,value)
        if self.cbLdapStack.currentItem() == 1:
            self.console("<b>Atenção:</b> ao criar o registro, pré-selecione um atributo como Distinguish Name.")
        
        

    def ldap_rename_rdn(self):
        
        rdnnew=iso2utf(self.lvLdap.currentItem().text(0).ascii())
        if self.rdnold.split(",")[0] == rdnnew:
            return True
        dnexist = 1
        item = self.lvLdapAttr.firstChild()
        while item is not None:
            if "%s=%s" % (item.text(0).ascii(), iso2utf(item.text(1).ascii())) == rdnnew:
                dnexist = 0
            item = item.nextSibling()
        if self.ldap_modify_rdn(self.rdnold, rdnnew,dnexist):
            self.console("<b>Ok:</b> registro %s alterado." % self.rdnold)
            self.lvLdapAttr.clear()
            return True
        else:
            self.lvLdap.currentItem().setText(0, self.rdnold.split(",")[0])
            return False
        
        

    def ldap_modify_rdn(self,a0,a1,a2):
        #a0 = oldDN, a1 = newDN, a2 = newDNexist
        
        print a0, a1, a2
        
        try:
            l = self.ldap_connect()
            l.rename_s(a0,a1,None,a2)
            del self.ldap_cache_attr[utf2iso(a0)]
            l.unbind_s()
            return True
        except ldap.LDAPError, e:
            self.parse_exception("LDAPError", e)
            return False
        
        

    def ldap_get_dn(self):
        
        item = self.lvLdap.currentItem()
        dn = item.text(0).ascii()
        while item.parent() is not None:
            dn = dn+","+item.parent().text(0).ascii()
            item = item.parent()
        return dn
        
        

    def ldap_change_widgetstack(self):
        
        selected_stack = self.cbLdapStack.currentItem()
        
        if self.lvLdap.currentItem() is None:
            if selected_stack != 0:
                self.cbLdapStack.setCurrentItem(0)
                self.console("<b>Atenção:</b> selecione o registro para executar esta ação.")
            return True
        
        if selected_stack == 1:
            self.lvLdapAttr.clear()
            self.wsLdap.raiseWidget(0)
            self.cbLdapAttr.setFocus()
            self.console("<b>Atenção:</b> o registro será inserido na base %s." % iso2utf(self.ldap_get_dn()))
        else:
            self.wsLdap.raiseWidget(selected_stack)
            if selected_stack == 0:
                self.ldap_dn_clicked()
                self.lvLdap.setFocus()
            elif selected_stack == 2:
                self.console("<b>Atenção:</b> o registro será inserido na base %s." % iso2utf(self.ldap_get_dn()))
                self.korreio_module_clear("ldap.form")
                self.iLdapFormCn.setFocus()
            elif selected_stack == 3:
                self.console("<b>Atenção:</b> o registro será inserido na base %s." % iso2utf(self.ldap_get_dn()))
                self.korreio_module_clear("ldap.form.ou")
                self.iLdapOu.setFocus()
            elif selected_stack == 4:
                self.console("<b>Atenção:</b> o registro selecionado é %s." % iso2utf(self.ldap_get_dn()))
                self.korreio_module_clear("ldap.form.password")
                self.iLdapPasswd.setFocus()
            elif selected_stack == 5:
                self.console("<b>Atenção:</b> o registro selecionado é %s." % iso2utf(self.ldap_get_dn()))
                self.korreio_module_clear("ldap.smb.populate")
                self.iLdapSMBdomain.setFocus()
        

    def ldap_passwd(self):
        
        if not self.cbLdapUserPassword.isChecked() and not self.cbLdapSambaPassword.isChecked() and not self.cbLdapAstPassword.isChecked():
            self.console("<b>Atenção:</b> selecione ao menos uma opção.")
            return False
        
        if self.iLdapPasswd.text().ascii() != self.iLdapPasswd2.text().ascii():
            self.console("<b>Atenção:</b> as senhas não conferem, digite novamente..")
            self.iLdapPasswd.clear()
            self.iLdapPasswd2.clear()
            return False
        
        old={}
        new={}
        
        if self.cbLdapUserPassword.isChecked():
        
            salt = ''
            for i in range(16):
                salt += choice(letters+digits)
        
            old["userPassword"] = 'None'
            hash = self.cbUserPassword.currentText().ascii()
            if hash == "{SSHA}":
                new["userPassword"] = ["{SSHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]]
            elif hash == "{SHA}":
                new["userPassword"] = ["{SHA}"+b2a_base64(sha.new(self.iLdapPasswd.text().ascii()).digest())[:-1]]
            elif hash == "{SMD5}":
                new["userPassword"] = ["{SMD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii() + salt).digest() + salt)[:-1]]
            elif hash == "{MD5}":
                new["userPassword"] = ["{MD5}"+b2a_base64(md5.new(self.iLdapPasswd.text().ascii()).digest())[:-1]]
            elif hash == "{CRYPT}":
                salt = ''
                for i in [0,1]:
                    salt += choice(letters+digits)
                new["userPassword"] = ["{CRYPT}" + crypt.crypt(str(self.iLdapPasswd.text().ascii()),salt)]
            elif hash == "{PLAINTEXT}":
                new["userPassword"] = [self.iLdapPasswd.text().ascii()]
            else:
                self.console("<b>Erro:</b> algoritmo não implementando.")
                return False
        
        if self.cbLdapSambaPassword.isChecked():
            old["sambaNTPassword"] = 'None'
            new["sambaNTPassword"] = [smbpasswd.nthash(self.iLdapPasswd.text().ascii())]
            old["sambaLMPassword"] = 'None'
            new["sambaLMPassword"] = [smbpasswd.lmhash(self.iLdapPasswd.text().ascii())]
        
        if self.cbLdapAstPassword.isChecked():
            old["astSecret"] = 'None'
            new["astSecret"] = [self.iLdapPasswd.text().ascii()]
        
        
        if self.ldap_modify(self.ldap_get_dn(),old,new):
            self.iLdapPasswd.clear()
            self.iLdapPasswd2.clear()
            self.iLdapPasswd.setFocus()
        
        self.ldap_dn_clicked()
        
        

    def ldap_samba_populate(self):
        
        domain = self.iLdapSMBdomain.text().ascii()
        if not domain:
            self.console("<b>Atenção:</b> informe o domínio netbios.")
            self.iLdapSMBdomain.setFocus()
            return False
        
        SID = self.iLdapSMBSID.text().ascii()
        if not SID:
            self.console("<b>Atenção:</b> informe o SID do domínio netbios.")
            self.iLdapSMBSID.setFocus()
            return False
        
        passwd = self.iLdapSMBpassword.text().ascii()
        if not passwd:
            self.console("<b>Atenção:</b> informe uma senha para o administrador.")
            self.iLdapSMBpassword.setFocus()
            return False
        
        
        #
        # Units
        #
        
        units = []
        units.append("Users")
        units.append("Groups")
        units.append("Computers")
        units.append("Idmap")
        
        for unit in units:
            dn = iso2utf("ou=%s,%s" % (unit, self.ldap_get_dn()))
            attrs = {}
            attrs['objectClass'] = ['organizationalUnit']
            attrs['ou'] = [unit]
            if not self.ldap_add(dn,attrs):
                self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)
        
        #
        # Groups
        #
        
        item = self.lvLdap.currentItem().firstChild()
        while item is not None:
            if item.text(0).ascii() == "ou=Groups":
                self.lvLdap.setCurrentItem(item)
                break
            item = item.nextSibling()
        
        groups = []
        groups.append(["2", "512", "Domain Admins", "Netbios Domain Administrators"])
        groups.append(["2", "513", "Domain Users", "Netbios Domain Users"])
        groups.append(["2", "514", "Domain Guests", "Netbios Domain Guests Users"])
        groups.append(["2", "515", "Domain Computers", "Netbios Domain Computers accounts"])
        groups.append(["5", "544", "Administrators", "Netbios Domain Members can fully administer the computer/sambaDomainName"])
        groups.append(["5", "548", "Account Operators", "Netbios Domain Users to manipulate users accounts"])
        groups.append(["5", "550", "Print Operators", "Netbios Domain Print Operators"])
        groups.append(["5", "551", "Backup Operators", "Netbios Domain Members can bypass file security to back up files"])
        groups.append(["5", "552", "Replicators", "Netbios Domain Supports file replication in a sambaDomainName"])
        
        for group in groups:
            dn = iso2utf("cn=%s,%s" % (group[2], self.ldap_get_dn()))
            attrs = {}
            attrs['objectClass'] = ['posixGroup', 'sambaGroupMapping']
            attrs['gidNumber'] = [group[1]]
            attrs['cn'] = [group[2]]
            attrs['displayName'] = [group[2]]
            if group[1] == '512':
                attrs['memberUid'] = ['root']
            attrs['description'] = [group[3]]
            attrs['sambaGroupType'] = [group[0]]
            if group[0] == "2":
                attrs['sambaSID'] = ["%s-%s" % (SID, group[1])]
            elif group[0] == "5":
                attrs['sambaSID'] = ["S-1-5-32-%s" % group[1]]
            if not self.ldap_add(dn,attrs):
                self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)
        
        #
        # Users
        #
        
        item = self.lvLdap.currentItem().parent().firstChild()
        while item is not None:
            if item.text(0).ascii() == "ou=Users":
                self.lvLdap.setCurrentItem(item)
                break
            item = item.nextSibling()
        
        #
        # Root
        #
        
        dn = iso2utf("uid=root,%s" % self.ldap_get_dn())
        attrs = {}
        attrs['objectClass'] = ['inetOrgPerson', 'sambaSamAccount','posixAccount','shadowAccount']
        attrs['cn'] = ["Administrador"]
        attrs['sn'] = ["root"]
        attrs['uidNumber'] = ["0"]
        attrs['gidNumber'] = ["0"]
        attrs['uid'] = ["root"]
        attrs['homeDirectory'] = ["/root"]
        attrs['loginShell'] = ["/bin/false"]
        attrs['gecos'] = ["Netbios Domain Administrator"]
        attrs['sambaLogonTime'] = ["0"]
        attrs['sambaLogoffTime'] = ["2147483647"]
        attrs['sambaKickoffTime'] = ["2147483647"]
        attrs['sambaPwdMustChange'] = ["2147483647"]
        attrs['sambaPwdCanChange'] = ["0"]
        attrs['sambaHomeDrive'] = ["H:"]
        attrs['sambaHomePath'] = ["\\\\server\\root"]
        attrs['sambaProfilePath'] = ["\\\\server\\profiles\\root"]
        attrs['sambaSID'] = ["%s-500" % SID]
        attrs['sambaPrimaryGroupSID'] = ["%s-512" % SID]
        attrs['sambaNTPassword'] = [smbpasswd.nthash(passwd)]
        attrs['sambaLMPassword'] = [smbpasswd.lmhash(passwd)]
        attrs['sambaAcctFlags'] = ["[U          ]"]
        attrs['sambaPwdLastSet'] = ["1"]
        salt = ''
        for i in range(16):
            salt += choice(letters+digits)
        attrs['userPassword'] = ["{SSHA}%s"  % b2a_base64(sha.new(self.iLdapFormUserP.text().ascii() + salt).digest() + salt)[:-1]]
        if not self.ldap_add(dn,attrs):
            self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)
        
        #
        # Nobody
        #
        
        dn = iso2utf("uid=nobody,%s" % self.ldap_get_dn())
        attrs = {}
        attrs['objectClass'] = ['inetOrgPerson', 'sambaSamAccount','posixAccount','shadowAccount']
        attrs['cn'] = ["nobody"]
        attrs['sn'] = ["nobody"]
        attrs['uidNumber'] = ["999"]
        attrs['gidNumber'] = ["514"]
        attrs['uid'] = ["nobody"]
        attrs['homeDirectory'] = ["/dev/null"]
        attrs['loginShell'] = ["/bin/false"]
        attrs['sambaLogonTime'] = ["0"]
        attrs['sambaLogoffTime'] = ["2147483647"]
        attrs['sambaKickoffTime'] = ["2147483647"]
        attrs['sambaPwdMustChange'] = ["2147483647"]
        attrs['sambaPwdCanChange'] = ["0"]
        attrs['sambaHomeDrive'] = ["H:"]
        attrs['sambaHomePath'] = ["\\\\server\\nonexistent"]
        attrs['sambaProfilePath'] = ["\\\\server\\profiles\\nonexistent"]
        attrs['sambaSID'] = ["%s-2998" % SID]
        attrs['sambaPrimaryGroupSID'] = ["%s-514" % SID]
        attrs['sambaNTPassword'] = ["NO PASSWORDXXXXXXXXXXXXXXXXXXXXX"]
        attrs['sambaLMPassword'] = ["NO PASSWORDXXXXXXXXXXXXXXXXXXXXX"]
        attrs['sambaAcctFlags'] = ["[NUD        ]"]
        attrs['sambaPwdLastSet'] = ["0"]
        if not self.ldap_add(dn,attrs):
            self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)
        
        #
        # sambaDomain
        #
        
        self.lvLdap.setCurrentItem(self.lvLdap.currentItem().parent())
        
        # from: 0=m, 1=h, 2=d
        def time2seconds(value, type):
            valueInt=int(value)
            if type == 0:
                return "%i" % (valueInt * 60)
            elif type == 1:
                return "%i" % (valueInt * 60 * 60)
            elif type == 2:
                return "%i" % (valueInt * 24 * 60 * 60)
            else:
                raise "Erro: parametro de tempo invalido."
        
        def time2minutes(value, type):
            valueInt=int(value)
            if type == 0:
                return "%i" % (valueInt)
            elif type == 1:
                return "%i" % (valueInt * 60)
            elif type == 2:
                return "%i" % (valueInt * 24 * 60)
            else:
                raise "Erro: parametro de tempo invalido."
        
        dn = iso2utf("sambaDomainName=%s,%s" % (domain.upper(), self.ldap_get_dn()))
        attrs = {}
        attrs['objectClass'] = ['sambaDomain', 'sambaUnixIdPool']
        attrs['sambaDomainName'] = [domain.upper()]
        attrs['sambaSID'] = [SID]
        attrs['uidNumber'] = [self.iLdapSMBuidNumber.text().ascii()]
        attrs['gidNumber'] = [self.iLdapSMBgidNumber.text().ascii()]
        attrs['sambaAlgorithmicRidBase'] = ["1000"]
        attrs['sambaNextUserRid'] = ["1000"]
        attrs['sambaNextRid'] = ["1000"]
        attrs['sambaMinPwdLength'] = [self.iLdapSMBminPwdLength.text().ascii()]
        attrs['sambaPwdHistoryLength'] = [self.iLdapSMBpwdHistLenght.text().ascii()]
        attrs['sambaMaxPwdAge'] = [time2seconds(self.iLdapSMBmaxPwdAge.text().ascii(), self.cbLdapSMBmaxPwdAge.currentItem())]
        attrs['sambaMinPwdAge'] = [time2seconds(self.iLdapSMBminPwdAge.text().ascii(), self.cbLdapSMBminPwdAge.currentItem())]
        attrs['sambaLockoutThreshold'] = [self.iLdapSMBlockout.text().ascii()]
        attrs['sambaLockoutDuration'] = [time2minutes(self.iLdapSMBlockoutDuration.text().ascii(), self.cbLdapSMBlockoutDuration.currentItem())]
        attrs['sambaLockoutObservationWindow'] = [time2minutes(self.iLdapSMBlockoutWindow.text().ascii(), self.cbLdapSMBlockoutWindow.currentItem())]
        attrs['sambaLogonToChgPwd'] = ["0"]
        attrs['sambaForceLogoff'] = ["-1"]
        attrs['sambaRefuseMachinePwdChange'] = ["0"]
        if not self.ldap_add(dn,attrs):
            self.console("<b>Erro:</b> não foi possível inserir o registro %s." % dn)
        
        self.lvLdap.currentItem().setOpen(True)
        
        

    def ldap_menu(self):
        
        x = 100
        item = self.lvLdap.currentItem()
        while item.parent() is not None:
            x+=20
            item = item.parent()
        
        y = self.lvLdap.currentItem().itemPos() + 110
        
        if self.lvLdap.currentItem().parent() is not None:
            self.lvLdapMenu.setItemEnabled(3, True)
        else:
            self.lvLdapMenu.setItemEnabled(3, False)
        
        if self.lvLdapMenu.clipBoard == "None" or not self.ldap_cache_attr.get(self.lvLdapMenu.clipBoard):
            self.lvLdapMenu.setItemEnabled(2, False)
        else:
            self.lvLdapMenu.setItemEnabled(2, True)
        
        self.lvLdapMenu.popup(self.mapToGlobal(QPoint(x, y)))
        
        

    def ldap_menu_clicked(self,a0):
        
        if a0 == 0 or a0 == 1:
            self.lvLdapMenu.clipBoardMode = a0
            self.lvLdapMenu.clipBoard = self.ldap_get_dn()
        elif a0 == 2:
            if self.ldap_add(iso2utf("%s,%s" % (self.lvLdapMenu.clipBoard.split(",")[0], self.ldap_get_dn())), self.ldap_cache_attr[self.lvLdapMenu.clipBoard]):
                if self.lvLdapMenu.clipBoardMode == 1:
                    if self.ldap_del_entry(iso2utf(self.lvLdapMenu.clipBoard)):
                        self.ldap_cache_items[self.lvLdapMenu.clipBoard].parent().takeItem(self.ldap_cache_items[self.lvLdapMenu.clipBoard])
                        self.lvLdapMenu.clipBoard = "None"
        elif a0 == 3:
            self.ldap_remove_entry()    
        
        

    def ssh_open(self,a0):
        
        print_cmd=[]
        try:
            self.console("<b>Info:</b> Executando comando remoto: %s." % a0)
            child = pexpect.spawn('ssh -p%s %s@%s "%s"' % (self.iSshPort.text().ascii(), self.iSshUser.text().ascii(), self.iSshHost.text().ascii(), a0))
            i = child.expect(['assword','want to continue connecting'], timeout=5)
            if i==0:
                child.sendline(self.iSshPass.text().ascii())
            elif i==1:
                child.sendline('yes')
                child.expect('assword', timeout=2)
                child.sendline(self.iSshPass.text().ascii())
            for line in child:
                line = re.sub("(\n|\r)","",line)
                print_cmd.append(line)
            child.kill(0)
        except pexpect.EOF, t:
            self.console("<b>Erro:</b> conexão com %s terminada." % self.iSshHost.text().ascii())
        except pexpect.TIMEOUT, t:
            self.console("<b>Erro:</b> conexão com %s sofreu timeout." % self.iSshHost.text().ascii())
        return print_cmd
        
        

    def ssh_connect(self):
        
        try:
            if self.ssh_connect_active_host != self.iSshHost.text().ascii() or self.ssh_connect_active_port != self.iSshPort.text().ascii() or self.ssh_connect_active_user != self.iSshUser.text().ascii():
                pass
            elif self.ssh:
                return self.ssh
        except:
            pass
        
        self.ssh = pxssh.pxssh()
        if self.ssh.login ("-p%s %s" % (self.iSshPort.text().ascii(), self.iSshHost.text().ascii()), self.iSshUser.text().ascii(), self.iSshPass.text().ascii()):
            self.ssh_connect_active_host = self.iSshHost.text().ascii()
            self.ssh_connect_active_port = self.iSshPort.text().ascii()
            self.ssh_connect_active_user = self.iSshUser.text().ascii()
            return self.ssh
        else:
            raise "Authentication error."
        
        

    def ssh_exec(self,a0):
        
        s = self.ssh_connect()
        s.sendline ("%s > /dev/null 2>&1 && echo OK" % a0)
        s.prompt()
        if re.search("\nOK", s.before):
            return True
        else:
            return False
        
        

    def scp_exec(self,a0):
        
        try:
            self.console("<b>Info:</b> salvando arquivo remoto: %s" % a0)
            child = pexpect.spawn('scp -P%s /tmp/korreio.tmp %s@%s:"%s"' % (self.iSshPort.text().ascii(), self.iSshUser.text().ascii(), self.iSshHost.text().ascii(), a0))
            i = child.expect(['assword','want to continue connecting'], timeout=5)
            if i==0:
                child.sendline(self.iSshPass.text().ascii())
            elif i==1:
                child.sendline('yes')
                child.expect('assword', timeout=2)
                child.sendline(self.iSshPass.text().ascii())
            print_cmd=[]
            for line in child:
                print_cmd.append(line)
            child.kill(0)
        except pexpect.EOF, t:
            self.console("<b>Erro:</b> conexão com %s terminada." % self.iSshHost.text().ascii())
        except pexpect.TIMEOUT, t:
            self.console("<b>Erro:</b> conexão com %s sofreu timeout." % self.iSshHost.text().ascii())
        
        

    def postfix_postconf(self):
        
        if self.rbPostconfN.isChecked():
            cmd = "postconf -n"
        elif self.rbPostconfAll.isChecked():
            cmd = "postconf"
        if self.rbPostconfD.isChecked():
            cmd = "postconf -d"
        cmd = self.ssh_open(cmd)
        self.postconf = {}
        lastOpt = self.cbPostconf.currentText().ascii()
        self.cbPostconf.clear()
        i = 0
        for config in cmd:
            if re.search("=",config):
                configlist = config.strip().split("=")
                configlist[0]=configlist[0].strip(" ")
                self.postconf[configlist[0]] = configlist[1]
                self.cbPostconf.insertItem(configlist[0])
                if configlist[0] == lastOpt:
                    lastItem = i
                i = i + 1
        try:
            self.cbPostconf.setCurrentItem(lastItem)
        except UnboundLocalError, e:
            pass
        self.postfix_postconf_changed()
        
        

    def postfix_postconf_changed(self):
        
        value = self.postconf.get(self.cbPostconf.currentText().ascii())
        value = re.sub("( )+"," ",value)
        value = re.sub(", ",",",value)
        value = re.sub(",",",\n",value)
        value = re.sub("^ ","",value)
        self.tePostconf.setText(value)
        
        

    def postfix_postconf_save(self):
        
        value = re.sub(",",", ",self.tePostconf.text().ascii())
        value = re.sub("( )+"," ",value)
        value = re.sub("\n","",value)
        value = re.sub("\r","",value)
        option = self.cbPostconf.currentText().ascii()
        if self.ssh_exec("postconf -e %s=%s" % (option, value) ):
            self.console("<b>Ok:</b> opção %s configurada." % option )
        else:
            self.console("<b>Erro:</b> não foi possível configurar %s." % option )
        
        

    def postfix_open_conf(self):
        
        value = self.ssh_open("cat "+self.iPostFileOpen.text().ascii())
        values = ""
        for line in value[1:]:
            values = values+line+"\n"
        if re.search("^cat:",values):
            self.console("<b>Erro:</b> arquivo %s nao encontrado." % self.iPostFileOpen.text().ascii())
            return True
        self.tePostFileOpen.setText(values)
        
        

    def postfix_save_conf(self):
        
        if self.tePostFileOpen.length () == 0:
            self.ssh_exec("rm -f "+self.iPostFileOpen.text().ascii())
            return True
        f = open("/tmp/korreio.tmp", 'w')
        for line in self.tePostFileOpen.text().ascii():
            f.write(line)
        f.close()
        self.scp_exec(self.iPostFileOpen.text().ascii())
        
        

    def postfix_postmap(self):
        
        file = self.iPostFileOpen.text().ascii()
        if self.ssh_exec("postmap %s" % file):
            self.console("<b>Ok:</b> database %s.db gerada." % file )
        else:
            self.console("<b>Erro:</b> não foi possível gerar database %s.db." % file )
        
        

    def postfix_stop(self):
        
        if self.ssh_exec("/etc/init.d/postfix stop"):
            self.console("<b>Ok:</b> postfix parado.")
        else:
            self.console("<b>Erro:</b> ao parar Postfix.")
        
        

    def postfix_start(self):
        
        if self.ssh_exec("/etc/init.d/postfix start"):
            self.console("<b>Ok:</b> postfix iniciado.")
        else:
            self.console("<b>Erro:</b> ao iniciar Postfix.")
        
        

    def postfix_restart(self):
        
        if self.ssh_exec("/etc/init.d/postfix restart"):
            self.console("<b>Ok:</b> postfix reiniciado.")
        else:
            self.console("<b>Erro:</b> ao reiniciar Postfix.")
        
        

    def sieve_search(self):
        
        self.lvSieve.clear()
        imap = self.imap_connect()
        for user in imap.lm("user%s%s%%" % (imap.SEP, self.iSieveSearch.text().ascii())):
            user=user.split(imap.SEP)[1]
            item = QListViewItem(self.lvSieve)
            item.setText(0, user)
            if self.cSieveScript.isChecked():
                s = self.sieve_connect(user)
                scripts = s.listscripts()
                s.logout()
                if scripts[0] == 'OK':
                    for script,active in scripts[1]:
                        if active:
                            item.setText(1, script)
                            break
        
        

    def sieve_connect(self,a0):
        
        admin = self.iCyrusUser.text().ascii().split("@")
        if admin[0] != self.iCyrusUser.text().ascii():
            user = "%s@%s" % (a0, admin[1])
        else:
            user = a0
        
        msg = "sieve://%s:%s/%s" % (self.iCyrusHost.text().ascii(), self.iCyrusSievePort.text().ascii(), user)
        
        s = sievelib.MANAGESIEVE(self.iCyrusHost.text().ascii(),int(self.iCyrusSievePort.text().ascii()))
        if s.alive:
            if s.login('PLAIN',user,self.iCyrusPass.text().ascii(),self.iCyrusUser.text().ascii()):
                self.console("<b>Ok:</b> servidor %s conectado." % msg)
                return s
            else:
                self.console("<b>Erro de conexão:</b> %s (Usuário ou senha inválidos)." % msg)
        else:
            self.console("<b>Erro de conexão:</b> %s (Conexão recusada)." % msg)
        
        return False
        
        

    def sieve_user_clicked(self):
        
        self.teSieveScript.clear()
        self.cbSieveScript.clear()
        
        item = self.lvSieve.currentItem()
        if item is None:
            return True
        
        s = self.sieve_connect(item.text(0).ascii())
        scripts = s.listscripts()
        s.logout()
        
        if scripts[0] == 'OK':
            for script,active in scripts[1]:
                self.cbSieveScript.insertItem(script)
                if self.lvSieve.currentItem().text(1).ascii() == script:
                    self.cbSieveScript.setCurrentText(script)
        
        if self.cbSieveScript.count() > 0:
            self.sieve_get_script()
        
        

    def sieve_get_script(self):
        
        s = self.sieve_connect(self.lvSieve.currentItem().text(0).ascii())
        script = s.getscript(self.cbSieveScript.currentText().ascii())
        s.logout()
        
        self.teSieveScript.clear()
        if script[0] == 'OK':
            self.teSieveScript.setText(script[1])
        
        

    def sieve_set_script(self):
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                if self.cbSieveScript.currentText().ascii():
                    status = s.putscript(self.cbSieveScript.currentText().ascii(),self.teSieveScript.text().ascii().replace("#USER#",item.text(0).ascii()))
                    if status == 'OK':
                        item.setText(1,self.cbSieveScript.currentText().ascii())
                        s.setactive(self.cbSieveScript.currentText().ascii())
                else:
                    item.setText(1,"")
                    s.setactive()
                s.logout()
            item=item.nextSibling()
        
        self.sieve_get_script()
        
        

    def sieve_unset_script(self):
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                s.setactive()
                s.logout()
                item.setText(1,"")
            item=item.nextSibling()
        
        

    def sieve_del_script(self):
        
        if not self.cbSieveScript.currentText().ascii():
            self.console("<b>Atenção:</b> digite o nome do script.")
            return True
        
        item = self.lvSieve.firstChild()
        while item is not None:
            if item.isSelected():
                s = self.sieve_connect(item.text(0).ascii())
                if s.deletescript(self.cbSieveScript.currentText().ascii()) == 'OK':
                    if self.cbSieveScript.currentText().ascii() == item.text(1).ascii():
                        item.setText(1,"")
                s.logout()
            item=item.nextSibling()
        
        self.sieve_get_script()
        
        

    def sieve_select_all(self):
        
        self.lvSieve.selectAll(True)
        
        

    def sieve_use_template(self):
        
        try:
            sep = self.m.SEP
        except AttributeError, e:
            sep = "/"
        
        self.cbSieveScript.setCurrentText("script.siv")
        template = self.lbSieveScripts.currentItem()
        if template == 0:
            self.teSieveScript.setText("redirect \"destinatario@exemplo.com.br\";\n")
        
        elif template == 1:
            self.teSieveScript.setText("""redirect "destinatario@exemplo.com.br";
        keep;
        """.replace("        ",""))
        
        elif template == 2:
            self.teSieveScript.setText("""require "fileinto";
        if address :contains "from" "remetente1@exemplo.com.br" {
           fileinto "INBOX%(sep)sPasta1";
        }
        """.replace("        ","") % {'sep':sep})
        
        elif template == 3:
            self.teSieveScript.setText("""require "fileinto";
        if address :contains "from" ["from1@dom1.com","from2@dom2.com"] {
            fileinto "INBOX%(sep)sPasta1";
        }
        elsif address :contains "from" ["from3@dom3.com","from4@dom4.com"] {
            fileinto "INBOX%(sep)sPasta2";
        }
        """.replace("        ","") % {'sep':sep})
        
        elif template == 4:
            self.teSieveScript.setText("""if header :contains "X-Spam-Flag" "YES" {
            discard;
        }
        """.replace("        ",""))
        
        elif template == 5:
            self.teSieveScript.setText("""require "fileinto";
        if header :contains "X-Spam-Flag" "YES" {
            fileinto "INBOX%(sep)sSpam";
        }
        """.replace("        ","") % {'sep':sep})
        
        elif template == 6:
            self.console("<b>Atenção:</b> a macro #USER# será substituida pelo respectivo usuário.")
            if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
                domain="dominio.com.br"
            else:
                domain=self.iCyrusUser.text().ascii().split("@")[1]
            self.teSieveScript.setText("""require ["vacation","fileinto"];
        
        if header :contains "X-Spam-Flag" "YES" {
            fileinto "INBOX%(sep)sSpam";
            stop;
        }
        
        vacation :days 5
        :subject "Estou ausente"
        :addresses ["#USER#@%(domain)s"]
         "Estarei ausente entre os dias ....
        
         Obrigado,
        
         --
         xxxxxxxxxxxx";
        """.replace("        ","") % {'sep':sep,'domain':domain})
        
        elif template == 7:
            if self.iCyrusUser.text().ascii().split("@")[0] == self.iCyrusUser.text().ascii():
                domain="exemplo.com.br"
            else:
                domain=self.iCyrusUser.text().ascii().split("@")[1]
            self.console("<b>Atenção:</b> a macro #USER# será substituida pelo respectivo usuário.")
            self.teSieveScript.setText("""require "vacation";
        vacation :days 5
        :subject "Estou ausente."
        :addresses ["#USER#@%s"]
         "Estarei ausente entre os dias ....
        
         Obrigado,
        
         --
         xxxxxxxxxxxx";
        """.replace("        ","") % domain)
        

    def queue_load(self):
        
        re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)\s+(\d+)\s([A-Z][a-z][a-z])\s([A-Z][a-z][a-z])\s+(\d+)\s(\d\d:\d\d:\d\d)\s+(.*)')
        re_rcpt  = re.compile(r'\s+(.*@.*)\b')
        re_log  = re.compile(r'(\s+)?\(.*\)')
        
        self.iQueueMessage.clear()
        self.lvQueue.clear()
        
        itemFrom = {}
        itemQueueID = {}
        self.itemLog = {}
        
        for line in self.ssh_open("postqueue -p"):
            match = re_queueid.match(line)
            if match is not None:
                tmp = ""
                #print "regexp: %s %s %s %s %s %s %s" % (match.group(1), match.group(2), match.group(3), match.group(4), match.group(5), match.group(6), match.group(7))
                mailFrom = match.group(7)
                if not itemFrom.get(mailFrom):
                    itemFrom[mailFrom] = QListViewItem(self.lvQueue)
                    itemFrom[mailFrom].setText(0,match.group(7))
                queueid = match.group(1)
                itemQueueID[queueid] = QListViewItem(itemFrom[mailFrom])
                itemQueueID[queueid].setText(0,"%s - %s Kb" % (queueid, int(match.group(2)) / 1024) )
                itemQueueID[queueid].setOpen(True)
                continue
            match = re_log.match(line)
            if match is not None:
                tmp = line
                continue
            match = re_rcpt.match(line)
            if match is not None:
                self.itemLog["%s:%s" % ( queueid, match.group(1) )] = tmp
                tmp = ""
                itemRcpt = QListViewItem(itemQueueID[queueid])
                itemRcpt.setText(0,match.group(1))
        
        item = self.lvQueue.firstChild()
        total = [0, 0]
        while item is not None:
            count = item.childCount()
            subcount = 0
            if count > 0:
                subitem = item.firstChild()
                while subitem is not None:
                    subcount = subcount + subitem.childCount()
                    subitem.setText(1,"%s" % subitem.childCount())
                    subitem = subitem.nextSibling()
            item.setText(1,"%s/%s" % (count, subcount))
            item = item.nextSibling()
            total[0] = total[0] + count
            total[1] = total[1] + subcount
        
        self.tlQueueMsgs.setText("%s/%s" % (total[0], total[1]))
        self.lvQueue.setColumnWidth(0, 300)
        self.lvQueue.setColumnWidth(1, 70)
        
        

    def queue_get_message(self):
        
        item = self.lvQueue.currentItem()
        
        if item is None:
            self.pQueueDel.setEnabled(False)
            return True
        
        if item.parent() is None:
            self.pQueueDel.setEnabled(True)
            return True
        
        if item.childCount() == 0:
            self.pQueueDel.setEnabled(False)
            re_queueid  = re.compile(r'\b([A-Z0-9]+\*?\!?)')
            match = re_queueid.match(item.parent().text(0).ascii())
            self.iQueueMessage.setText(self.itemLog.get("%s:%s" % (match.group(1), item.text(0).ascii()) ) )
            return True
        
        queueid = item.text(0).ascii()
        re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
        match = re_queueid.match(queueid)
        if match is not None:
            self.pQueueDel.setEnabled(True)
            self.iQueueMessage.setText("\n".join(self.ssh_open("postcat -q %s" % match.group(1))[1:]))
        
        

    def queue_del_message(self):
        
        self.iQueueMessage.clear()
        
        item = self.lvQueue.currentItem()
        re_queueid  = re.compile(r'\b([A-Z0-9]+)\*?\!?')
        
        if item.parent() is None:
            subitem = item.firstChild()
            success = False
            queuelist = []
            while subitem is not None:
                queuelist.append(re_queueid.match(subitem.text(0).ascii()).group(1))
                if len(queuelist) == 50 or subitem.nextSibling() is None:
                    if self.ssh_exec("cat <<< \"%s\" | postsuper -d - " % "\n".join(queuelist)):
                        success = True
                    queuelist = []
                subitem = subitem.nextSibling()
            if success:
                self.console("<b>Ok:</b> %s mensagen(s) removida(s)." % item.childCount())
            self.lvQueue.takeItem(item)
            return True
        
        match = re_queueid.match(item.text(0).ascii())
        if match is not None:
            if self.ssh_exec("postsuper -d %s" % match.group(1)):
                self.console("<b>Ok:</b> mensagem %s removida." % match.group(1))
            else:
                self.console("<b>Erro:</b> não foi possível remover a mensagem %s." % match.group(1))
            count = item.parent().text(1).ascii().split("/")
            if int(count[0]) == 1:
                self.lvQueue.takeItem(item.parent())
            else:
                item.parent().setText(1 ,"%s/%s" % (str(int(count[0]) - 1), str(int(count[1]) - int(item.childCount()))))
                item.parent().takeItem(item)
        
        

    def __tr(self,s,c = None):
        return qApp.translate("dKorreio",s,c)

    def __trUtf8(self,s,c = None):
        return qApp.translate("dKorreio",s,c,QApplication.UnicodeUTF8)
