# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'korreio.ui'
#
# Created: Ter Jul 31 13:45:53 2007
#      by: The PyQt User Interface Compiler (pyuic) 3.16
#
# WARNING! All changes made in this file will be lost!


from qt import *


class dKorreio(QDialog):
    def __init__(self,parent = None,name = None,modal = 0,fl = 0):
        QDialog.__init__(self,parent,name,modal,fl)

        if not name:
            self.setName("dKorreio")

        self.setSizeGripEnabled(1)

        dKorreioLayout = QGridLayout(self,1,1,11,6,"dKorreioLayout")

        self.wKorreio = QTabWidget(self,"wKorreio")
        self.wKorreio.setMinimumSize(QSize(800,570))

        self.tabLdap = QWidget(self.wKorreio,"tabLdap")
        tabLdapLayout = QGridLayout(self.tabLdap,1,1,11,6,"tabLdapLayout")

        self.KorreioSearch = QGroupBox(self.tabLdap,"KorreioSearch")
        self.KorreioSearch.setColumnLayout(0,Qt.Vertical)
        self.KorreioSearch.layout().setSpacing(6)
        self.KorreioSearch.layout().setMargin(11)
        KorreioSearchLayout = QGridLayout(self.KorreioSearch.layout())
        KorreioSearchLayout.setAlignment(Qt.AlignTop)

        self.cKorDnAttr = QComboBox(0,self.KorreioSearch,"cKorDnAttr")

        KorreioSearchLayout.addWidget(self.cKorDnAttr,0,0)

        self.pLdapSearch = QPushButton(self.KorreioSearch,"pLdapSearch")

        KorreioSearchLayout.addWidget(self.pLdapSearch,0,3)

        self.iKorDnAttr = QLineEdit(self.KorreioSearch,"iKorDnAttr")

        KorreioSearchLayout.addMultiCellWidget(self.iKorDnAttr,0,0,1,2)

        self.lvKorreio = QListView(self.KorreioSearch,"lvKorreio")
        self.lvKorreio.addColumn(self.__tr("Distinguished Name"))

        KorreioSearchLayout.addMultiCellWidget(self.lvKorreio,1,1,0,3)

        self.pKorDelete = QPushButton(self.KorreioSearch,"pKorDelete")

        KorreioSearchLayout.addMultiCellWidget(self.pKorDelete,2,2,2,3)
        spacer2 = QSpacerItem(541,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        KorreioSearchLayout.addMultiCell(spacer2,2,2,0,1)

        tabLdapLayout.addWidget(self.KorreioSearch,0,0)

        self.KorreioAdd = QGroupBox(self.tabLdap,"KorreioAdd")
        self.KorreioAdd.setColumnLayout(0,Qt.Vertical)
        self.KorreioAdd.layout().setSpacing(6)
        self.KorreioAdd.layout().setMargin(11)
        KorreioAddLayout = QGridLayout(self.KorreioAdd.layout())
        KorreioAddLayout.setAlignment(Qt.AlignTop)

        self.lineEdit19 = QLineEdit(self.KorreioAdd,"lineEdit19")

        KorreioAddLayout.addWidget(self.lineEdit19,0,1)

        self.textLabel3_2 = QLabel(self.KorreioAdd,"textLabel3_2")

        KorreioAddLayout.addWidget(self.textLabel3_2,0,0)

        self.textLabel4 = QLabel(self.KorreioAdd,"textLabel4")

        KorreioAddLayout.addWidget(self.textLabel4,1,0)

        self.textLabel5 = QLabel(self.KorreioAdd,"textLabel5")

        KorreioAddLayout.addMultiCellWidget(self.textLabel5,2,3,0,0)

        self.lineEdit20 = QLineEdit(self.KorreioAdd,"lineEdit20")

        KorreioAddLayout.addMultiCellWidget(self.lineEdit20,1,2,1,1)

        self.lineEdit21 = QLineEdit(self.KorreioAdd,"lineEdit21")

        KorreioAddLayout.addWidget(self.lineEdit21,3,1)

        self.pushButton11 = QPushButton(self.KorreioAdd,"pushButton11")

        KorreioAddLayout.addWidget(self.pushButton11,4,1)
        spacer10 = QSpacerItem(101,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        KorreioAddLayout.addItem(spacer10,4,0)
        spacer11 = QSpacerItem(421,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        KorreioAddLayout.addItem(spacer11,4,2)

        tabLdapLayout.addWidget(self.KorreioAdd,1,0)
        self.wKorreio.insertTab(self.tabLdap,QString.fromLatin1(""))

        self.tabCyrus = QWidget(self.wKorreio,"tabCyrus")
        tabCyrusLayout = QGridLayout(self.tabCyrus,1,1,11,6,"tabCyrusLayout")

        self.tCyrUser = QLabel(self.tabCyrus,"tCyrUser")

        tabCyrusLayout.addWidget(self.tCyrUser,0,0)

        self.iCyrUser = QLineEdit(self.tabCyrus,"iCyrUser")

        tabCyrusLayout.addWidget(self.iCyrUser,0,1)

        self.pCyrSearch = QPushButton(self.tabCyrus,"pCyrSearch")

        tabCyrusLayout.addWidget(self.pCyrSearch,0,2)

        self.textLabel1_2 = QLabel(self.tabCyrus,"textLabel1_2")

        tabCyrusLayout.addMultiCellWidget(self.textLabel1_2,0,0,4,5)

        self.iCyrMailbox = QLineEdit(self.tabCyrus,"iCyrMailbox")
        self.iCyrMailbox.setEnabled(1)
        self.iCyrMailbox.setMinimumSize(QSize(260,0))

        tabCyrusLayout.addWidget(self.iCyrMailbox,0,6)

        self.lvCyrus = QListView(self.tabCyrus,"lvCyrus")
        self.lvCyrus.addColumn(self.__tr("IMAP Mailboxes"))
        self.lvCyrus.setRootIsDecorated(1)
        self.lvCyrus.setResizeMode(QListView.AllColumns)

        tabCyrusLayout.addMultiCellWidget(self.lvCyrus,1,1,0,6)

        self.gbACL = QGroupBox(self.tabCyrus,"gbACL")
        self.gbACL.setEnabled(1)
        self.gbACL.setColumnLayout(0,Qt.Vertical)
        self.gbACL.layout().setSpacing(6)
        self.gbACL.layout().setMargin(11)
        gbACLLayout = QGridLayout(self.gbACL.layout())
        gbACLLayout.setAlignment(Qt.AlignTop)

        layout9 = QVBoxLayout(None,0,0,"layout9")

        self.cCyrPermL = QCheckBox(self.gbACL,"cCyrPermL")
        layout9.addWidget(self.cCyrPermL)

        self.cCyrPermR = QCheckBox(self.gbACL,"cCyrPermR")
        layout9.addWidget(self.cCyrPermR)

        self.cCyrPermS = QCheckBox(self.gbACL,"cCyrPermS")
        layout9.addWidget(self.cCyrPermS)

        self.cCyrPermW = QCheckBox(self.gbACL,"cCyrPermW")
        layout9.addWidget(self.cCyrPermW)

        self.cCyrPermI = QCheckBox(self.gbACL,"cCyrPermI")
        layout9.addWidget(self.cCyrPermI)

        gbACLLayout.addLayout(layout9,1,0)

        layout3 = QHBoxLayout(None,0,6,"layout3")

        self.textLabel3 = QLabel(self.gbACL,"textLabel3")
        layout3.addWidget(self.textLabel3)

        self.cbUserACL = QComboBox(0,self.gbACL,"cbUserACL")
        self.cbUserACL.setMinimumSize(QSize(189,0))
        self.cbUserACL.setEditable(1)
        layout3.addWidget(self.cbUserACL)
        spacer5 = QSpacerItem(150,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout3.addItem(spacer5)

        gbACLLayout.addMultiCellLayout(layout3,0,0,0,1)

        layout8 = QGridLayout(None,1,1,0,0,"layout8")

        layout7 = QHBoxLayout(None,0,6,"layout7")
        spacer7_2 = QSpacerItem(41,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        layout7.addItem(spacer7_2)

        self.pCyrSetAcl = QPushButton(self.gbACL,"pCyrSetAcl")
        self.pCyrSetAcl.setMinimumSize(QSize(131,0))
        self.pCyrSetAcl.setMaximumSize(QSize(130,25))
        layout7.addWidget(self.pCyrSetAcl)
        spacer8 = QSpacerItem(71,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout7.addItem(spacer8)

        layout8.addLayout(layout7,4,0)

        self.cCyrPermD = QCheckBox(self.gbACL,"cCyrPermD")

        layout8.addWidget(self.cCyrPermD,2,0)

        self.cCyrPermA = QCheckBox(self.gbACL,"cCyrPermA")

        layout8.addWidget(self.cCyrPermA,3,0)

        self.cCyrPermP = QCheckBox(self.gbACL,"cCyrPermP")

        layout8.addWidget(self.cCyrPermP,0,0)

        self.cCyrPermC = QCheckBox(self.gbACL,"cCyrPermC")

        layout8.addWidget(self.cCyrPermC,1,0)

        gbACLLayout.addLayout(layout8,1,1)

        tabCyrusLayout.addMultiCellWidget(self.gbACL,3,3,0,4)
        spacer1 = QSpacerItem(60,31,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabCyrusLayout.addItem(spacer1,0,3)

        self.gbAction = QGroupBox(self.tabCyrus,"gbAction")

        self.pCyrReconstruct = QPushButton(self.gbAction,"pCyrReconstruct")
        self.pCyrReconstruct.setGeometry(QRect(20,96,240,25))

        self.pCyrAdd = QPushButton(self.gbAction,"pCyrAdd")
        self.pCyrAdd.setGeometry(QRect(20,24,240,25))

        self.pCyrDelete = QPushButton(self.gbAction,"pCyrDelete")
        self.pCyrDelete.setEnabled(1)
        self.pCyrDelete.setGeometry(QRect(20,60,240,25))

        tabCyrusLayout.addMultiCellWidget(self.gbAction,2,3,5,6)

        self.gbQuota = QGroupBox(self.tabCyrus,"gbQuota")
        self.gbQuota.setEnabled(0)
        self.gbQuota.setColumnLayout(0,Qt.Vertical)
        self.gbQuota.layout().setSpacing(6)
        self.gbQuota.layout().setMargin(11)
        gbQuotaLayout = QGridLayout(self.gbQuota.layout())
        gbQuotaLayout.setAlignment(Qt.AlignTop)
        spacer9 = QSpacerItem(16,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        gbQuotaLayout.addItem(spacer9,0,6)

        self.pSetQuota = QPushButton(self.gbQuota,"pSetQuota")

        gbQuotaLayout.addWidget(self.pSetQuota,0,5)

        self.textLabel2 = QLabel(self.gbQuota,"textLabel2")

        gbQuotaLayout.addWidget(self.textLabel2,0,4)

        self.textLabel1 = QLabel(self.gbQuota,"textLabel1")

        gbQuotaLayout.addWidget(self.textLabel1,0,0)

        self.iQuotaUsed = QLineEdit(self.gbQuota,"iQuotaUsed")
        self.iQuotaUsed.setEnabled(0)
        self.iQuotaUsed.setMinimumSize(QSize(90,25))
        self.iQuotaUsed.setMaximumSize(QSize(90,25))

        gbQuotaLayout.addWidget(self.iQuotaUsed,0,1)

        self.textLabel2_2 = QLabel(self.gbQuota,"textLabel2_2")

        gbQuotaLayout.addWidget(self.textLabel2_2,0,2)

        self.iQuota = QLineEdit(self.gbQuota,"iQuota")
        self.iQuota.setMinimumSize(QSize(90,0))
        self.iQuota.setMaximumSize(QSize(90,32767))

        gbQuotaLayout.addWidget(self.iQuota,0,3)

        tabCyrusLayout.addMultiCellWidget(self.gbQuota,2,2,0,4)
        self.wKorreio.insertTab(self.tabCyrus,QString.fromLatin1(""))

        self.TabPage = QWidget(self.wKorreio,"TabPage")
        TabPageLayout = QGridLayout(self.TabPage,1,1,11,6,"TabPageLayout")

        self.groupBox9 = QGroupBox(self.TabPage,"groupBox9")
        self.groupBox9.setColumnLayout(0,Qt.Vertical)
        self.groupBox9.layout().setSpacing(6)
        self.groupBox9.layout().setMargin(11)
        groupBox9Layout = QGridLayout(self.groupBox9.layout())
        groupBox9Layout.setAlignment(Qt.AlignTop)

        self.comboBox5 = QComboBox(0,self.groupBox9,"comboBox5")

        groupBox9Layout.addMultiCellWidget(self.comboBox5,0,1,2,2)

        self.textLabel6 = QLabel(self.groupBox9,"textLabel6")

        groupBox9Layout.addMultiCellWidget(self.textLabel6,0,1,0,1)

        self.textEdit3 = QTextEdit(self.groupBox9,"textEdit3")

        groupBox9Layout.addMultiCellWidget(self.textEdit3,2,2,2,5)
        spacer18 = QSpacerItem(81,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox9Layout.addMultiCell(spacer18,2,2,0,1)
        spacer19 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox9Layout.addItem(spacer19,1,1)

        self.pushButton12 = QPushButton(self.groupBox9,"pushButton12")

        groupBox9Layout.addMultiCellWidget(self.pushButton12,0,1,4,4)
        spacer21 = QSpacerItem(201,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox9Layout.addItem(spacer21,1,5)
        spacer20 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox9Layout.addItem(spacer20,1,3)

        TabPageLayout.addWidget(self.groupBox9,1,0)

        self.groupBox10 = QGroupBox(self.TabPage,"groupBox10")
        self.groupBox10.setColumnLayout(0,Qt.Vertical)
        self.groupBox10.layout().setSpacing(6)
        self.groupBox10.layout().setMargin(11)
        groupBox10Layout = QGridLayout(self.groupBox10.layout())
        groupBox10Layout.setAlignment(Qt.AlignTop)

        self.textLabel7 = QLabel(self.groupBox10,"textLabel7")

        groupBox10Layout.addWidget(self.textLabel7,0,0)
        spacer14 = QSpacerItem(21,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer14,0,1)

        self.lineEdit22 = QLineEdit(self.groupBox10,"lineEdit22")
        self.lineEdit22.setMinimumSize(QSize(270,0))
        self.lineEdit22.setMaximumSize(QSize(270,32767))

        groupBox10Layout.addWidget(self.lineEdit22,0,2)
        spacer15 = QSpacerItem(91,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addMultiCell(spacer15,1,1,0,1)

        self.textEdit5 = QTextEdit(self.groupBox10,"textEdit5")

        groupBox10Layout.addMultiCellWidget(self.textEdit5,1,1,2,7)
        spacer12 = QSpacerItem(31,20,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer12,0,3)

        self.pushButton14 = QPushButton(self.groupBox10,"pushButton14")

        groupBox10Layout.addWidget(self.pushButton14,0,4)
        spacer13 = QSpacerItem(20,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer13,0,5)

        self.pushButton13 = QPushButton(self.groupBox10,"pushButton13")

        groupBox10Layout.addWidget(self.pushButton13,0,6)
        spacer17 = QSpacerItem(51,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox10Layout.addItem(spacer17,0,7)

        TabPageLayout.addWidget(self.groupBox10,2,0)

        self.groupBox11 = QGroupBox(self.TabPage,"groupBox11")
        self.groupBox11.setColumnLayout(0,Qt.Vertical)
        self.groupBox11.layout().setSpacing(6)
        self.groupBox11.layout().setMargin(11)
        groupBox11Layout = QGridLayout(self.groupBox11.layout())
        groupBox11Layout.setAlignment(Qt.AlignTop)

        self.textLabel8 = QLabel(self.groupBox11,"textLabel8")

        groupBox11Layout.addWidget(self.textLabel8,0,0)

        self.comboBox6 = QComboBox(0,self.groupBox11,"comboBox6")
        self.comboBox6.setEditable(1)

        groupBox11Layout.addMultiCellWidget(self.comboBox6,0,0,1,2)

        self.textLabel9 = QLabel(self.groupBox11,"textLabel9")

        groupBox11Layout.addWidget(self.textLabel9,1,0)

        self.comboBox7 = QComboBox(0,self.groupBox11,"comboBox7")

        groupBox11Layout.addMultiCellWidget(self.comboBox7,1,1,1,2)

        self.checkBox10 = QCheckBox(self.groupBox11,"checkBox10")

        groupBox11Layout.addWidget(self.checkBox10,2,0)

        self.checkBox11 = QCheckBox(self.groupBox11,"checkBox11")

        groupBox11Layout.addWidget(self.checkBox11,2,1)

        self.checkBox12 = QCheckBox(self.groupBox11,"checkBox12")

        groupBox11Layout.addWidget(self.checkBox12,2,2)

        self.textLabel10 = QLabel(self.groupBox11,"textLabel10")

        groupBox11Layout.addWidget(self.textLabel10,3,0)

        self.lineEdit23 = QLineEdit(self.groupBox11,"lineEdit23")

        groupBox11Layout.addMultiCellWidget(self.lineEdit23,3,3,1,2)

        self.textLabel11 = QLabel(self.groupBox11,"textLabel11")

        groupBox11Layout.addWidget(self.textLabel11,4,0)

        self.lineEdit24 = QLineEdit(self.groupBox11,"lineEdit24")

        groupBox11Layout.addMultiCellWidget(self.lineEdit24,4,4,1,2)

        self.pushButton12_2 = QPushButton(self.groupBox11,"pushButton12_2")

        groupBox11Layout.addWidget(self.pushButton12_2,4,7)
        spacer22 = QSpacerItem(311,21,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addMultiCell(spacer22,4,4,3,6)
        spacer24 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addItem(spacer24,1,3)
        spacer23 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addItem(spacer23,0,3)

        self.textLabel13 = QLabel(self.groupBox11,"textLabel13")

        groupBox11Layout.addWidget(self.textLabel13,1,4)
        spacer25 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addMultiCell(spacer25,2,2,3,4)
        spacer26 = QSpacerItem(130,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addMultiCell(spacer26,3,3,3,4)

        self.textEdit6 = QTextEdit(self.groupBox11,"textEdit6")
        self.textEdit6.setMinimumSize(QSize(350,0))

        groupBox11Layout.addMultiCellWidget(self.textEdit6,1,3,5,7)

        self.textLabel12 = QLabel(self.groupBox11,"textLabel12")

        groupBox11Layout.addWidget(self.textLabel12,0,4)
        spacer27 = QSpacerItem(220,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        groupBox11Layout.addMultiCell(spacer27,0,0,6,7)

        self.comboBox8 = QComboBox(0,self.groupBox11,"comboBox8")
        self.comboBox8.setEditable(1)

        groupBox11Layout.addWidget(self.comboBox8,0,5)

        TabPageLayout.addWidget(self.groupBox11,0,0)
        self.wKorreio.insertTab(self.TabPage,QString.fromLatin1(""))

        self.tabConfig = QWidget(self.wKorreio,"tabConfig")
        tabConfigLayout = QGridLayout(self.tabConfig,1,1,11,6,"tabConfigLayout")

        self.gConfigLdap = QGroupBox(self.tabConfig,"gConfigLdap")

        self.tLdapHost = QLabel(self.gConfigLdap,"tLdapHost")
        self.tLdapHost.setGeometry(QRect(30,29,70,21))

        self.tLdapBaseDN = QLabel(self.gConfigLdap,"tLdapBaseDN")
        self.tLdapBaseDN.setGeometry(QRect(30,59,83,21))

        self.tLdapUser = QLabel(self.gConfigLdap,"tLdapUser")
        self.tLdapUser.setGeometry(QRect(30,89,98,21))

        self.tLdapPass = QLabel(self.gConfigLdap,"tLdapPass")
        self.tLdapPass.setGeometry(QRect(30,119,60,21))

        self.cLdapConn = QComboBox(0,self.gConfigLdap,"cLdapConn")
        self.cLdapConn.setGeometry(QRect(140,29,85,24))

        self.tLdapPort = QLabel(self.gConfigLdap,"tLdapPort")
        self.tLdapPort.setGeometry(QRect(390,33,37,20))

        self.pGetBaseDN = QPushButton(self.gConfigLdap,"pGetBaseDN")
        self.pGetBaseDN.setGeometry(QRect(390,60,91,21))

        self.iLdapUser = QLineEdit(self.gConfigLdap,"iLdapUser")
        self.iLdapUser.setGeometry(QRect(142,89,240,25))

        self.iLdapPass = QLineEdit(self.gConfigLdap,"iLdapPass")
        self.iLdapPass.setGeometry(QRect(142,119,240,25))
        self.iLdapPass.setEchoMode(QLineEdit.Password)

        self.iLdapHost = QLineEdit(self.gConfigLdap,"iLdapHost")
        self.iLdapHost.setGeometry(QRect(230,29,151,25))

        self.iLdapPort = QLineEdit(self.gConfigLdap,"iLdapPort")
        self.iLdapPort.setGeometry(QRect(429,30,50,25))

        self.iLdapBaseDN = QLineEdit(self.gConfigLdap,"iLdapBaseDN")
        self.iLdapBaseDN.setGeometry(QRect(142,59,240,25))

        tabConfigLayout.addMultiCellWidget(self.gConfigLdap,1,1,0,2)

        self.gConfigCyrus = QGroupBox(self.tabConfig,"gConfigCyrus")

        self.tCyrusPass = QLabel(self.gConfigCyrus,"tCyrusPass")
        self.tCyrusPass.setGeometry(QRect(30,90,90,21))

        self.tCyrusHost = QLabel(self.gConfigCyrus,"tCyrusHost")
        self.tCyrusHost.setGeometry(QRect(30,30,50,21))

        self.tCyrusUser = QLabel(self.gConfigCyrus,"tCyrusUser")
        self.tCyrusUser.setGeometry(QRect(30,60,98,21))

        self.iCyrusUser = QLineEdit(self.gConfigCyrus,"iCyrusUser")
        self.iCyrusUser.setGeometry(QRect(142,60,230,25))

        self.iCyrusPass = QLineEdit(self.gConfigCyrus,"iCyrusPass")
        self.iCyrusPass.setGeometry(QRect(142,90,230,25))
        self.iCyrusPass.setEchoMode(QLineEdit.Password)

        self.iCyrusHost = QLineEdit(self.gConfigCyrus,"iCyrusHost")
        self.iCyrusHost.setGeometry(QRect(231,30,140,25))

        self.cCyrusConn = QComboBox(0,self.gConfigCyrus,"cCyrusConn")
        self.cCyrusConn.setGeometry(QRect(142,30,85,24))

        self.tCyrusPort = QLabel(self.gConfigCyrus,"tCyrusPort")
        self.tCyrusPort.setGeometry(QRect(383,30,37,21))

        self.iCyrusPort = QLineEdit(self.gConfigCyrus,"iCyrusPort")
        self.iCyrusPort.setGeometry(QRect(422,30,50,25))

        tabConfigLayout.addMultiCellWidget(self.gConfigCyrus,0,0,0,2)

        self.gConfigCyrus_2 = QGroupBox(self.tabConfig,"gConfigCyrus_2")

        self.tCyrusPass_2 = QLabel(self.gConfigCyrus_2,"tCyrusPass_2")
        self.tCyrusPass_2.setGeometry(QRect(30,90,90,21))

        self.tCyrusHost_2 = QLabel(self.gConfigCyrus_2,"tCyrusHost_2")
        self.tCyrusHost_2.setGeometry(QRect(30,30,50,21))

        self.iCyrusUser_2 = QLineEdit(self.gConfigCyrus_2,"iCyrusUser_2")
        self.iCyrusUser_2.setGeometry(QRect(142,60,230,25))

        self.iCyrusPass_2 = QLineEdit(self.gConfigCyrus_2,"iCyrusPass_2")
        self.iCyrusPass_2.setGeometry(QRect(142,90,230,25))
        self.iCyrusPass_2.setEchoMode(QLineEdit.Password)

        self.tCyrusPort_2 = QLabel(self.gConfigCyrus_2,"tCyrusPort_2")
        self.tCyrusPort_2.setGeometry(QRect(383,30,37,21))

        self.iCyrusPort_2 = QLineEdit(self.gConfigCyrus_2,"iCyrusPort_2")
        self.iCyrusPort_2.setGeometry(QRect(422,30,50,25))

        self.tCyrusUser_2 = QLabel(self.gConfigCyrus_2,"tCyrusUser_2")
        self.tCyrusUser_2.setGeometry(QRect(30,60,98,21))

        self.iCyrusHost_2 = QLineEdit(self.gConfigCyrus_2,"iCyrusHost_2")
        self.iCyrusHost_2.setGeometry(QRect(141,30,230,25))

        tabConfigLayout.addMultiCellWidget(self.gConfigCyrus_2,2,2,0,2)
        spacer7 = QSpacerItem(470,31,QSizePolicy.Expanding,QSizePolicy.Minimum)
        tabConfigLayout.addItem(spacer7,3,2)

        self.pSaveConfig = QPushButton(self.tabConfig,"pSaveConfig")
        self.pSaveConfig.setMinimumSize(QSize(151,0))
        self.pSaveConfig.setMaximumSize(QSize(151,32767))

        tabConfigLayout.addWidget(self.pSaveConfig,3,1)
        spacer6 = QSpacerItem(140,21,QSizePolicy.Fixed,QSizePolicy.Minimum)
        tabConfigLayout.addItem(spacer6,3,0)
        self.wKorreio.insertTab(self.tabConfig,QString.fromLatin1(""))

        dKorreioLayout.addWidget(self.wKorreio,0,0)

        self.languageChange()

        self.resize(QSize(822,592).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)

        self.connect(self.pCyrSearch,SIGNAL("clicked()"),self.cyrus_list)
        self.connect(self.wKorreio,SIGNAL("currentChanged(QWidget*)"),self.tab_changed)
        self.connect(self.pSaveConfig,SIGNAL("clicked()"),self.save_config)
        self.connect(self.lvCyrus,SIGNAL("selectionChanged(QListViewItem*)"),self.mailbox_clicked)
        self.connect(self.pCyrDelete,SIGNAL("clicked()"),self.delete_mailbox)
        self.connect(self.pCyrAdd,SIGNAL("clicked()"),self.create_mailbox)
        self.connect(self.pSetQuota,SIGNAL("clicked()"),self.set_quota)
        self.connect(self.cbUserACL,SIGNAL("activated(const QString&)"),self.check_permissions)
        self.connect(self.pCyrSetAcl,SIGNAL("clicked()"),self.set_cyracl)
        self.connect(self.pCyrReconstruct,SIGNAL("clicked()"),self.reconstruct_mailbox)
        self.connect(self.pGetBaseDN,SIGNAL("clicked()"),self.get_ldap_basedn)


    def languageChange(self):
        self.setCaption(self.__trUtf8("\x4b\x6f\x72\x72\x65\x69\x6f\x20\x2d\x20\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\xc3\xa7\xc3\xa3\x6f\x20\x64\x65\x20\x43\x6f\x72\x72\x65\x69\x6f\x20\x45\x6c\x65\x74\x72\xc3\xb4\x6e\x69\x63\x6f"))
        self.KorreioSearch.setTitle(self.__tr("Pesquisar"))
        self.cKorDnAttr.clear()
        self.cKorDnAttr.insertItem(self.__tr("cn"))
        self.cKorDnAttr.insertItem(self.__tr("uid"))
        self.cKorDnAttr.insertItem(self.__tr("mail"))
        self.pLdapSearch.setText(self.__tr("Pesquisar"))
        self.lvKorreio.header().setLabel(0,self.__tr("Distinguished Name"))
        self.pKorDelete.setText(self.__tr("Remover"))
        self.KorreioAdd.setTitle(self.__tr("Cadastrar"))
        self.textLabel3_2.setText(self.__tr("cn:"))
        self.textLabel4.setText(self.__tr("uid:"))
        self.textLabel5.setText(self.__tr("mail:"))
        self.pushButton11.setText(self.__tr("Cadastrar"))
        self.wKorreio.changeTab(self.tabLdap,self.__tr("LDAP Manager"))
        self.tCyrUser.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.pCyrSearch.setText(self.__tr("Pesquisar"))
        self.textLabel1_2.setText(self.__tr("Mailbox:"))
        self.lvCyrus.header().setLabel(0,self.__tr("IMAP Mailboxes"))
        self.gbACL.setTitle(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xb5\x65\x73\x20\x64\x65\x20\x61\x63\x65\x73\x73\x6f\x20\x61\x20\x4d\x61\x69\x6c\x62\x6f\x78"))
        self.cCyrPermL.setText(self.__tr("List (L)"))
        self.cCyrPermR.setText(self.__tr("Read (R)"))
        self.cCyrPermS.setText(self.__tr("Preserve status (S)"))
        self.cCyrPermW.setText(self.__tr("Write status (W)"))
        self.cCyrPermI.setText(self.__tr("Insert new msg (I)"))
        self.textLabel3.setText(self.__trUtf8("\x55\x73\x75\xc3\xa1\x72\x69\x6f\x3a"))
        self.pCyrSetAcl.setText(self.__tr("Aplicar"))
        self.cCyrPermD.setText(self.__tr("Delete a msg or this mailbox (D)"))
        self.cCyrPermA.setText(self.__tr("Change User ACLs (A)"))
        self.cCyrPermP.setText(self.__tr("Insert a msg by email address (P)"))
        self.cCyrPermC.setText(self.__tr("Create a child mailbox (C)"))
        self.gbAction.setTitle(self.__trUtf8("\x41\xc3\xa7\xc3\xb5\x65\x73"))
        self.pCyrReconstruct.setText(self.__tr("Reindexar Mailbox"))
        self.pCyrAdd.setText(self.__tr("Criar Mailbox"))
        self.pCyrDelete.setText(self.__tr("Remover Mailbox"))
        self.gbQuota.setTitle(self.__tr("Quota"))
        self.pSetQuota.setText(self.__tr("Aplicar"))
        self.textLabel2.setText(self.__tr("KB"))
        self.textLabel1.setText(self.__tr("Utilizado:"))
        self.textLabel2_2.setText(self.__tr("Limite:"))
        self.wKorreio.changeTab(self.tabCyrus,self.__tr("Cyrus Manager"))
        self.groupBox9.setTitle(self.__tr("main.cf"))
        self.textLabel6.setText(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xa3\x6f\x3a"))
        self.pushButton12.setText(self.__tr("Salvar"))
        self.groupBox10.setTitle(self.__tr("Arquivos"))
        self.textLabel7.setText(self.__tr("Arquivo:"))
        self.lineEdit22.setText(self.__tr("/etc/postfix/"))
        self.pushButton14.setText(self.__tr("Abrir"))
        self.pushButton13.setText(self.__tr("Salvar"))
        self.groupBox11.setTitle(self.__tr("master.cf"))
        self.textLabel8.setText(self.__trUtf8("\x4d\xc3\xb3\x64\x75\x6c\x6f\x3a"))
        self.textLabel9.setText(self.__tr("Tipo:"))
        self.checkBox10.setText(self.__tr("private"))
        self.checkBox11.setText(self.__tr("unpriv"))
        self.checkBox12.setText(self.__tr("chroot"))
        self.textLabel10.setText(self.__tr("Wakeup:"))
        self.textLabel11.setText(self.__tr("Max proc:"))
        self.pushButton12_2.setText(self.__tr("Salvar"))
        self.textLabel13.setText(self.__trUtf8("\x4f\x70\xc3\xa7\xc3\xb5\x65\x73\x3a"))
        self.textLabel12.setText(self.__tr("Comando:"))
        self.wKorreio.changeTab(self.TabPage,self.__tr("Postfix Manager"))
        self.gConfigLdap.setTitle(self.__tr("Ldap Config"))
        self.tLdapHost.setText(self.__tr("Host:"))
        self.tLdapBaseDN.setText(self.__tr("BaseDN:"))
        self.tLdapUser.setText(self.__tr("User Admin:"))
        self.tLdapPass.setText(self.__tr("Senha:"))
        self.cLdapConn.clear()
        self.cLdapConn.insertItem(self.__tr("ldaps://"))
        self.cLdapConn.insertItem(self.__tr("ldap://"))
        self.tLdapPort.setText(self.__tr("Port:"))
        self.pGetBaseDN.setText(self.__tr("Get It"))
        self.gConfigCyrus.setTitle(self.__tr("Cyrus Config"))
        self.tCyrusPass.setText(self.__tr("Senha:"))
        self.tCyrusHost.setText(self.__tr("Host:"))
        self.tCyrusUser.setText(self.__tr("User Admin:"))
        self.cCyrusConn.clear()
        self.cCyrusConn.insertItem(self.__tr("imaps://"))
        self.cCyrusConn.insertItem(self.__tr("imap://"))
        self.tCyrusPort.setText(self.__tr("Port:"))
        self.gConfigCyrus_2.setTitle(self.__tr("SSH Config"))
        self.tCyrusPass_2.setText(self.__tr("Senha:"))
        self.tCyrusHost_2.setText(self.__tr("Host:"))
        self.tCyrusPort_2.setText(self.__tr("Port:"))
        self.tCyrusUser_2.setText(self.__tr("User:"))
        self.pSaveConfig.setText(self.__tr("Salvar"))
        self.wKorreio.changeTab(self.tabConfig,self.__trUtf8("\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\xc3\xa7\xc3\xb5\x65\x73"))


    def cyrus_list(self):
        import cyruslib
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()))
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        mailboxes = m.lm("user",self.iCyrUser.text().ascii()+"*")
        self.lvCyrus.clear()
        mailbox=self.iCyrMailbox.text().ascii().split("/")
        i=True
        for group in mailboxes:
            for id in mailboxes[group]:
              print group+"::"+id
              idlist = id.split("/")
              if len(idlist) == 1:
                item = QListViewItem(self.lvCyrus)
                item.setText(0,idlist[0])
              elif idlist[0] == "INBOX":
                item = QListViewItem(self.lvCyrus)
                item.setText(0,idlist[0])
              else:
                subitem = QListViewItem(item)
                subitem.setText(0,idlist[1])
                if idlist[0] == mailbox[0]:
                    subitem.parent().setOpen(True)
        

    def save_config(self):
        import os.path
        
        try:
            os.mkdir(os.path.expanduser("~/.korreio"),0755)
        except OSError, e:
            pass
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'w')
            f.write('cyrus.host='+self.iCyrusHost.text().ascii()+'\n')
            f.write('cyrus.port='+self.iCyrusPort.text().ascii()+'\n')
            f.write('cyrus.user='+self.iCyrusUser.text().ascii()+'\n')
            f.write('cyrus.pass='+self.iCyrusPass.text().ascii()+'\n')
            f.write('ldap.host='+self.iLdapHost.text().ascii()+'\n')
            f.write('ldap.port='+self.iLdapPort.text().ascii()+'\n')
            f.write('ldap.basedn='+self.iLdapBaseDN.text().ascii()+'\n')
            f.write('ldap.user='+self.iLdapUser.text().ascii()+'\n')
            f.write('ldap.pass='+self.iLdapPass.text().ascii()+'\n')
            f.close()
        except OSError, e:
            print "Debug::conf() Info: "+e.filename+" "+e.strerror
        
        print "Debug::save_config() Configuration saved."
        
        
        

    def load_config(self):
        import os.path
        try:
            f = open(os.path.expanduser("~/.korreio/korreio.conf"), 'r')
            conf=f.read()
            f.close()
        except IOError, e:
            print "Debug::conf() Info: "+e.filename+" "+e.strerror
            return True
        
        confList = conf.split("\n")
        confList.pop()
        confDict = {}
        
        for line in confList:
           key=line.split("=")
           confDict[key[0]] = "=".join(key[1:])
        
        self.iCyrusHost.setText(confDict.get("cyrus.host"))
        self.iCyrusPort.setText(confDict.get("cyrus.port"))
        self.iCyrusUser.setText(confDict.get("cyrus.user"))
        self.iCyrusPass.setText(confDict.get("cyrus.pass"))
        self.iLdapHost.setText(confDict.get("ldap.host"))
        self.iLdapPort.setText(confDict.get("ldap.port"))
        self.iLdapBaseDN.setText(confDict.get("ldap.basedn"))
        self.iLdapUser.setText(confDict.get("ldap.user"))
        self.iLdapPass.setText(confDict.get("ldap.pass"))
        
        print "Debug::load_config() Configuration loaded."
        
        

    def tab_changed(self):
        import sys
        reload(sys)
        sys.setdefaultencoding("utf-8")
        menu=str(self.wKorreio.tabLabel(self.wKorreio.currentPage()))
        print "Debug::menu_click() Menu: "+menu
        if menu == "LDAP Manager":
            self.load_config()
        

    def mailbox_clicked(self):
        
        def child(item):
            if item.childCount() > 0:
                mailbox = child(item.firstChild())
                if isinstance(mailbox, basestring):
                    return mailbox
            while item is not None:
                if item.isSelected():
                    mailbox = item.parent().text(0).ascii()+"/"+item.text(0).ascii()
                    return mailbox
                item = item.nextSibling()
            return False
        
        def search_selected():
            item = self.lvCyrus.firstChild()
            while item is not None:
                if item.isSelected():
                    return item.text(0).ascii()
                else:
                    if item.childCount() > 0 and item.isOpen():
                        mailbox = child(item.firstChild())
                        if isinstance(mailbox, basestring):
                            return mailbox
                item = item.nextSibling()
        
        mailbox = search_selected()
        mblist = mailbox.split("/")
        if len(mblist) == 1:
            self.gbQuota.setEnabled(True)
            self.iQuotaUsed.setEnabled(False)
        else:
            self.gbQuota.setEnabled(False)
        self.iCyrMailbox.setText(mailbox)
        import cyruslib
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()))
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        quota = m.lq("user",self.iCyrMailbox.text().ascii())
        self.iQuotaUsed.setText(str(quota[0]))
        self.iQuota.setText(str(quota[1]))
        self.permissions = m.lam("user",mailbox);
        self.cbUserACL.clear();
        for user in self.permissions:
            self.cbUserACL.insertItem(user)
        self.check_permissions();
        

    def create_mailbox(self):
        import cyruslib
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()))
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        m.cm("user", self.iCyrMailbox.text().ascii())
        m.sam("user", self.iCyrMailbox.text().ascii(), self.iCyrusUser.text().ascii(), " ")
        self.cyrus_list()
        

    def delete_mailbox(self):
        import cyruslib
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()))
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        m.sam("user", self.iCyrMailbox.text().ascii(), self.iCyrusUser.text().ascii(), "c")
        m.dm("user", self.iCyrMailbox.text().ascii())
        self.cyrus_list()
        

    def set_quota(self):
        import cyruslib
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()))
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        m.sq("user",self.iCyrMailbox.text().ascii(),self.iQuota.text().ascii())
        

    def check_permissions(self):
        mailbox_perm = self.permissions[self.cbUserACL.currentText().ascii()]
        import re
        if re.search("l",mailbox_perm): self.cCyrPermL.setChecked(True)
        else: self.cCyrPermL.setChecked(False)
        if re.search("r",mailbox_perm): self.cCyrPermR.setChecked(True)
        else: self.cCyrPermR.setChecked(False)
        if re.search("s",mailbox_perm): self.cCyrPermS.setChecked(True)
        else: self.cCyrPermS.setChecked(False)
        if re.search("w",mailbox_perm): self.cCyrPermW.setChecked(True)
        else: self.cCyrPermW.setChecked(False)
        if re.search("i",mailbox_perm): self.cCyrPermI.setChecked(True)
        else: self.cCyrPermI.setChecked(False)
        if re.search("p",mailbox_perm): self.cCyrPermP.setChecked(True)
        else: self.cCyrPermP.setChecked(False)
        if re.search("c",mailbox_perm): self.cCyrPermC.setChecked(True)
        else: self.cCyrPermC.setChecked(False)
        if re.search("d",mailbox_perm): self.cCyrPermD.setChecked(True)
        else: self.cCyrPermD.setChecked(False)
        if re.search("a",mailbox_perm): self.cCyrPermA.setChecked(True)
        else: self.cCyrPermA.setChecked(False)
        

    def set_cyracl(self):
        perm=""
        if self.cCyrPermL.isChecked():
            perm="l"
        if self.cCyrPermR.isChecked():
            perm=perm+"r"
        if self.cCyrPermS.isChecked():
            perm=perm+"s"
        if self.cCyrPermW.isChecked():
            perm=perm+"w"
        if self.cCyrPermI.isChecked():
            perm=perm+"i"
        if self.cCyrPermP.isChecked():
            perm=perm+"p"
        if self.cCyrPermC.isChecked():
            perm=perm+"c"
        if self.cCyrPermD.isChecked():
            perm=perm+"d"
        if self.cCyrPermA.isChecked():
            perm=perm+"a"
        
        import cyruslib
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()))
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        m.sam("user",self.iCyrMailbox.text().ascii(),self.cbUserACL.currentText().ascii(),perm)
        

    def reconstruct_mailbox(self):
        import cyruslib
        m = cyruslib.CYRUS(self.iCyrusHost.text().ascii(),int(self.iCyrusPort.text().ascii()))
        m.login(self.iCyrusUser.text().ascii(),self.iCyrusPass.text().ascii())
        m.reconstruct("user",self.iCyrMailbox.text().ascii())
        
        

    def get_ldap_basedn(self):
        import ldap
        try:
            l = ldap.open(self.iLdapHost.text().ascii(),int(self.iLdapPort.text().ascii()))
            l.protocol_version = ldap.VERSION3
            if self.iLdapUser.text().ascii() and self.iLdapPass.text().ascii():
                l.simple_bind(self.iLdapUser.text().ascii(),self.iLdapPass.text().ascii())
            else:
                l.simple_bind()
            searchScope = ldap.SCOPE_BASE
            searchFilter = "objectclass=*"
            retrieveAttributes = None
            ldap_result_id = l.search("", searchScope, searchFilter, retrieveAttributes)
            result_set = []
            while 1:
                result_type, result_data = l.result(ldap_result_id, 0)
                print result_type
                print result_data
                if (result_data == []):
                    break
                else:
                    if result_type == ldap.RES_SEARCH_ENTRY:
                        for j in result_data:
                             pass
                             #self.iLdapBaseDN.setText(j[1]["dn"][0])
                             #print j[1]["dn"][0]
                             #break
        except ldap.LDAPError, e:
            print e
        
        

    def __tr(self,s,c = None):
        return qApp.translate("dKorreio",s,c)

    def __trUtf8(self,s,c = None):
        return qApp.translate("dKorreio",s,c,QApplication.UnicodeUTF8)
